# 通用业务模块-审批流程（approvalWorkflow）

- **生成时间**：2026-03-25

## 审批流程（approvalWorkflow）

### 功能概述

审批流程功能页面实现预算管理模块中的审批工作流配置和管理，基于通用工作流引擎实现标准化的预算审批流程。该页面支持定义预算审批的流程模板、配置审批节点、设置审批规则，并与预算分配、调整申请等业务功能集成。用户可以通过该页面创建、编辑、查看和删除预算审批流程，确保预算审批过程的规范化和可追溯性。审批流程作为预算管理的核心控制环节，连接了预算编制、分配、执行和调整的全生命周期管理。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.budgetManagement.views.approvalWorkflow.tsx"
$View({
    title: "审批流程",
    crumb: "审批流程",
    auth: true,
    isIndex: false,
})
export declare function approvalWorkflow(workflowId?: Integer);
```

### 验收列表

- 支持审批流程的列表展示，显示流程名称、关联的流程定义、创建时间等基本信息
- 支持审批流程的新增功能，可配置流程名称、关联流程定义和审批规则
- 支持审批流程的编辑功能，可修改流程名称、审批规则等信息
- 支持审批流程的删除功能，提供二次确认防止误操作
- 支持审批流程的详情查看，展示完整的流程配置信息
- 支持与工作流引擎的流程定义进行关联选择

### 交互操作

- **新增审批流程**：点击新增按钮打开表单弹框，填写流程名称、选择关联的流程定义、输入审批规则，提交后保存新的审批流程配置
- **编辑审批流程**：在列表中点击编辑按钮，加载现有审批流程数据到表单弹框，修改后提交更新
- **删除审批流程**：在列表中点击删除按钮，弹出二次确认对话框，确认后删除对应的审批流程配置
- **查看审批流程详情**：在列表中点击查看详情链接，跳转到详情页面展示完整的审批流程配置信息
- **关联流程定义**：在新增或编辑表单中，通过下拉选择器关联已有的工作流引擎流程定义
- **返回审批流程列表**：在详情页面提供返回列表的快捷入口，返回到审批流程列表页面

### 依赖的服务端逻辑

- **领域服务-逻辑-查询审批流程列表**：[预算管理-查询审批流程列表（queryApprovalWorkflowList）](specs/001-bootdo-management-system/plan/backend/logic-queryApprovalWorkflowList.md)
- **领域服务-逻辑-获取审批流程详情**：[预算管理-获取审批流程详情（getApprovalWorkflowDetail）](specs/001-bootdo-management-system/plan/backend/logic-getApprovalWorkflowDetail.md)
- **领域服务-逻辑-创建审批流程**：[预算管理-创建审批流程（createApprovalWorkflow）](specs/001-bootdo-management-system/plan/backend/logic-createApprovalWorkflow.md)
- **领域服务-逻辑-更新审批流程**：[通用领域服务-更新审批流程（updateApprovalWorkflow）](specs/001-bootdo-management-system/plan/backend/logic-updateApprovalWorkflow.md)
- **领域服务-逻辑-删除审批流程**：[预算管理-删除审批流程（deleteApprovalWorkflow）](specs/001-bootdo-management-system/plan/backend/logic-deleteApprovalWorkflow.md)
- **领域服务-逻辑-查询流程定义列表**：[工作流引擎-查询流程定义列表（queryProcessDefinitionList）](specs/001-bootdo-management-system/plan/backend/logic-queryProcessDefinitionList.md)

### 特殊组件

无特殊组件