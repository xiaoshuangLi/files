# 通用业务模块-流程监控（processMonitoring）

- **生成时间**：2026-03-25

## 流程监控（processMonitoring）

### 功能概述

流程监控功能页面提供对工作流执行状态和性能指标的全面监控能力，支持实时跟踪流程实例的运行状况、识别瓶颈环节、分析流程效率。该页面展示流程监控实体记录的关键数据，包括流程实例ID、性能指标详情和监控时间戳，帮助管理员及时发现和解决流程执行中的问题，优化业务流程效率，确保工作流引擎的稳定高效运行。用户可以通过输入特定的流程实例ID来筛选监控数据，查看详细的性能指标信息，包括响应时间、处理时长、资源消耗等关键指标。页面还支持按监控时间进行排序和筛选，便于历史数据分析，并提供数据导出功能，支持将监控数据导出为Excel格式，用于离线分析和生成管理报告，全面提升工作流管理的可视化和可操作性。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.workflowEngine.views.processMonitoring.tsx"
$Page({
    title: "流程监控",
    crumb: "流程监控",
    auth: true,
    isIndex: false,
})
export declare function processMonitoring(processInstanceId?: Integer);
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| processInstanceId | 流程实例ID | Integer | 用于筛选特定流程实例的监控数据，可选参数 |

### 验收列表

- 支持按流程实例ID查询对应的流程监控数据
- 支持查看流程监控的详细性能指标信息
- 支持按监控时间进行排序和筛选
- 支持导出流程监控数据报表

### 交互操作

- **查询流程监控数据**：用户可输入流程实例ID或选择时间范围，系统根据条件查询并展示对应的流程监控记录列表
- **查看详情**：点击监控记录，系统显示该监控记录的完整性能指标详情，包括具体的性能数据和监控时间
- **数据导出**：用户可选择导出当前查询结果为Excel格式，便于离线分析和报告制作
- **刷新监控数据**：用户可手动刷新页面，获取最新的流程监控数据，确保监控信息的实时性

### 依赖的服务端逻辑

- **领域服务-逻辑-获取流程监控列表**：[工作流引擎-获取流程监控列表（getProcessMonitoringList）](specs/001-bootdo-management-system/plan/backend/logic-getProcessMonitoringList.md)
- **领域服务-逻辑-导出流程监控报表**：[通用领域服务-导出流程监控报告（exportProcessMonitoringReport）](specs/001-bootdo-management-system/plan/backend/logic-exportProcessMonitoringReport.md)

### 特殊组件

无特殊组件