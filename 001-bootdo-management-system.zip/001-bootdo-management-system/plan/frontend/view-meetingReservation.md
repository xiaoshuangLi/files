# 通用业务模块-会议管理（meetingReservation）

- **生成时间**：2026-03-25

## 会议管理（meetingReservation）

### 功能概述

会议管理功能页面提供企业内部会议的全生命周期管理服务，支持用户进行会议预约、会议室预订、参会人员邀请和会议纪要管理。该页面实现了会议信息的集中展示、创建、编辑、查询和删除操作，通过与系统账户实体的关联确保会议组织者的身份验证，并支持会议时间冲突检测以避免会议室资源重复预订。页面采用标准的CRUD布局，包含顶部查询条件区域和下方数据表格区域，支持分页、排序和导出功能，为用户提供高效便捷的会议管理体验。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.officeAutomation.views.meetingReservation.tsx"
$View({
    title: "会议管理",
    crumb: "会议管理",
    auth: true,
    isIndex: false,
})
export declare function meetingReservation(meetingId?: Integer, title?: String, organizerId?: Integer, startTimeFrom?: DateTime, startTimeTo?: DateTime, location?: String);
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| meetingId | 会议ID | Integer | 会议ID参数，用于编辑或查看详情模式 |
| title | 会议标题 | String | 查询参数 - 会议标题（模糊搜索） |
| organizerId | 组织者ID | Integer | 查询参数 - 组织者ID（精确匹配） |
| startTimeFrom | 开始时间起始 | DateTime | 查询参数 - 开始时间范围（起始时间） |
| startTimeTo | 开始时间结束 | DateTime | 查询参数 - 开始时间范围（结束时间） |
| location | 地点 | String | 查询参数 - 地点（模糊搜索） |

### 验收列表

无验收列表

### 交互操作

- **创建会议预约**：用户点击"新建会议"按钮，系统打开会议创建表单弹框，用户填写会议标题、议程、选择组织者（默认当前用户）、设置开始时间和结束时间、输入地点等信息，点击保存后系统验证时间冲突并保存会议信息。
- **编辑会议预约**：用户在会议列表中点击某条会议记录的"编辑"按钮，系统加载该会议的详细信息到编辑表单，用户可修改会议信息，保存时同样进行时间冲突验证。
- **查看会议详情**：用户在会议列表中点击某条会议记录的"查看详情"按钮，系统在新页面或弹窗中展示该会议的完整信息，包括会议标题、议程、组织者、时间安排、地点等。
- **删除会议预约**：用户在会议列表中点击某条会议记录的"删除"按钮，系统弹出二次确认对话框，用户确认后系统删除该会议记录，并提供5秒内撤销删除的操作窗口。
- **查询会议列表**：用户在顶部查询区域输入会议标题、选择组织者、设置时间范围或输入地点，点击"查询"按钮，系统根据条件筛选并展示符合条件的会议列表。
- **重置查询条件**：用户点击"重置"按钮，系统清空所有查询条件并重新加载完整的会议列表。
- **导出会议数据**：用户点击"导出Excel"按钮，系统将当前查询结果导出为Excel文件，包含所有会议字段信息。
- **分页浏览**：用户通过分页控件浏览不同页面的会议数据，支持调整每页显示数量。
- **排序会议列表**：用户点击表格列头（如会议标题、开始时间等），系统按该字段对会议列表进行升序或降序排序。

### 依赖的服务端逻辑

- **领域服务-逻辑-创建会议预约**：[通用领域服务-创建会议预约（createMeetingReservation）](specs/001-bootdo-management-system/plan/backend/logic-createMeetingReservation.md)
- **领域服务-逻辑-更新会议预约**：[通用领域服务-更新会议预约（updateMeetingReservation）](specs/001-bootdo-management-system/plan/backend/logic-updateMeetingReservation.md)
- **领域服务-逻辑-删除会议预约**：[办公自动化-删除会议预约（deleteMeetingReservation）](specs/001-bootdo-management-system/plan/backend/logic-deleteMeetingReservation.md)
- **领域服务-逻辑-查询会议预约列表**：[办公自动化-查询会议预约列表（queryMeetingReservationList）](specs/001-bootdo-management-system/plan/backend/logic-queryMeetingReservationList.md)
- **领域服务-逻辑-获取会议预约详情**：[办公自动化-获取会议预约详情（getMeetingReservationDetail）](specs/001-bootdo-management-system/plan/backend/logic-getMeetingReservationDetail.md)
- **领域服务-逻辑-检查会议时间冲突**：[通用领域服务-检查会议时间冲突（checkMeetingTimeConflict）](specs/001-bootdo-management-system/plan/backend/logic-checkMeetingTimeConflict.md)
- **领域服务-逻辑-导出会议数据**：[办公自动化-导出会议数据（exportMeetingData）](specs/001-bootdo-management-system/plan/backend/logic-exportMeetingData.md)

### 特殊组件

无特殊组件