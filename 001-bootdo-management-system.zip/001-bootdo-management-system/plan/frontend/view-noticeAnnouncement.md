# 通用业务模块-通知公告（noticeAnnouncement）

- **生成时间**：2026-03-25

## 通知公告（noticeAnnouncement）

### 功能概述

通知公告功能为企业内部提供统一的信息发布和管理平台，支持管理员或授权用户向指定范围的用户群体发布重要信息，如公司政策变更、活动通知、系统维护提醒等。该功能支持公告的全生命周期管理，包括草稿保存、正式发布、置顶展示、阅读状态跟踪和归档处理。公告内容支持富文本格式，可包含文字、图片、链接等多种媒体元素，并支持定向发送给特定部门、角色或个人，实现精准的信息推送。通过有效的公告管理，提升企业内部沟通效率和信息传达效果。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.officeAutomation.views.noticeAnnouncement.tsx"
$View({
    title: "通知公告",
    crumb: "通知公告",
    auth: true,
    isIndex: false,
})
export declare function noticeAnnouncement(id?: Integer, mode?: 'view' | 'edit' | 'create', statusFilter?: 'DRAFT' | 'PUBLISHED' | 'ARCHIVED', keyword?: String, dateRange?: [DateTime, DateTime], page?: Integer, size?: Integer, sort?: String, order?: 'asc' | 'desc');
```

### 验收列表

- **公告列表展示**
  - **数据展示**
    - 系统管理员、部门管理员和普通用户可以在通知公告页面查看公告列表，页面采用表格形式展示数据，包含公告标题、发布人、发布时间、是否置顶等关键信息
  - **分页与筛选**
    - 支持分页显示公告列表，默认每页显示10条记录，支持自定义每页条数
    - 支持按公告状态（草稿、已发布、已归档）进行筛选
    - 支持按关键字模糊搜索公告标题
    - 支持按发布时间范围进行筛选
    - 支持按指定字段和排序方向进行排序

- **公告创建与编辑**
  - **表单字段**
    - 公告创建/编辑页面必须包含以下必填字段：公告标题、公告内容（富文本编辑器）
    - 公告创建/编辑页面必须包含以下可选字段：是否置顶、有效开始时间、有效结束时间
  - **操作模式**
    - 支持新建公告（create模式），表单初始为空
    - 支持编辑现有公告（edit模式），表单自动加载公告详情
    - 支持查看公告详情（view模式），表单字段为只读状态

- **公告操作**
  - **删除操作**
    - 支持单条公告删除，点击删除按钮后弹出二次确认对话框
    - 支持批量公告删除，勾选多条公告后点击批量删除按钮，弹出二次确认对话框
    - 删除操作仅对具有公告管理权限的用户可见
  - **状态管理**
    - 草稿状态的公告可以编辑、发布或删除
    - 已发布状态的公告可以置顶、取消置顶、归档或删除
    - 已归档状态的公告只能查看或删除

### 交互操作

- **公告列表查询**：用户进入通知公告页面后，系统默认加载已发布的公告列表，支持通过顶部筛选区域设置状态、关键字、日期范围等条件，点击查询按钮后刷新列表数据，同时支持表格列的排序操作。

- **公告详情查看**：用户在公告列表中点击任意公告标题，系统跳转到公告详情页面，以只读模式展示公告的完整内容，包括标题、内容、发布人、发布时间、是否置顶等信息。

- **新建公告**：用户点击页面顶部的"新增公告"按钮，系统跳转到公告创建页面，用户填写公告标题、内容等信息后，可以选择保存为草稿或直接发布。

- **编辑公告**：用户在公告列表中点击某条公告右侧的"编辑"按钮（仅对草稿状态或具有编辑权限的已发布公告显示），系统跳转到公告编辑页面，加载公告详情供用户修改。

- **删除公告**：用户在公告列表中点击某条公告右侧的"删除"按钮，或勾选多条公告后点击"批量删除"按钮，系统弹出二次确认对话框，用户确认后执行删除操作。

- **公告置顶/取消置顶**：用户在已发布的公告列表中，可以通过公告右侧的"置顶"或"取消置顶"按钮（根据当前状态动态显示）来控制公告在列表中的显示优先级。

- **公告归档**：用户在已发布的公告列表中点击"归档"按钮，系统将该公告状态更新为已归档，从正常公告列表中移除。

- **返回列表**：用户在公告详情、创建或编辑页面中，可以通过页面顶部的"返回"按钮或面包屑导航返回到公告列表页面。

### 依赖的服务端逻辑

- **领域服务-逻辑-加载通知公告列表**：[办公自动化-加载通知公告列表（loadNotificationList）](specs/001-bootdo-management-system/plan/backend/logic-loadNotificationList.md)
- **领域服务-逻辑-创建通知公告**：[办公自动化-创建通知公告（createNotification）](specs/001-bootdo-management-system/plan/backend/logic-createNotification.md)
- **领域服务-逻辑-更新通知公告**：[办公自动化-更新通知公告（updateMessage）](specs/001-bootdo-management-system/plan/backend/logic-updateMessage.md)
- **领域服务-逻辑-删除通知公告**：[办公自动化-删除通知公告（deleteMessage）](specs/001-bootdo-management-system/plan/backend/logic-deleteMessage.md)
- **领域服务-逻辑-加载通知公告详情**：[办公自动化-加载消息详情（loadMessageDetail）](specs/001-bootdo-management-system/plan/backend/logic-loadMessageDetail.md)
- **领域服务-逻辑-归档通知公告**：[办公自动化-归档公告（archiveNotice）](specs/001-bootdo-management-system/plan/backend/logic-archiveNotice.md)
- **领域服务-逻辑-批量操作通知公告**：[办公自动化-批量操作通知公告（batchOperateNotices）](specs/001-bootdo-management-system/plan/backend/logic-batchOperateNotices.md)
- **领域服务-逻辑-标记通知为已读**：[办公自动化-标记通知为已读（markNotificationAsRead）](specs/001-bootdo-management-system/plan/backend/logic-markNotificationAsRead.md)