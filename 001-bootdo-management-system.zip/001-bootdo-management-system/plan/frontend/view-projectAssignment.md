# 通用业务模块-项目分配（projectAssignment）

- **生成时间**：2026-03-25

## 项目分配（projectAssignment）

### 功能概述

项目分配功能页面用于管理分包商的项目分配工作，支持为分包商分配具体的项目任务。页面提供完整的CRUD操作，包括创建新的项目分配记录、查看现有分配详情、修改分配信息以及删除不再需要的分配记录。用户可以通过项目名称、分包商信息等条件进行筛选查询，并能查看每个项目分配的详细信息，包括项目范围描述、分配时间、完成期限等关键信息。该功能确保分包商管理模块能够有效跟踪和管理各个分包商承担的项目任务，为后续的项目执行和绩效评估提供数据基础。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.subcontractorManagement.views.projectAssignment.tsx"
$View({
    title: "项目分配",
    crumb: "项目分配",
    auth: true,
    isIndex: false,
})
export declare function projectAssignment();
```

无输入参数。

### 验收列表

- 支持分页展示所有项目分配记录
- 支持按项目名称进行模糊搜索
- 支持按分包商名称进行筛选
- 支持按分配时间范围进行筛选
- 支持按完成期限进行排序
- 支持创建新的项目分配记录
- 支持编辑现有的项目分配记录
- 支持删除项目分配记录（需二次确认）
- 显示项目分配的完整信息，包括项目名称、项目范围、分配时间、完成期限、关联分包商等
- 支持导出项目分配数据为Excel格式

### 交互操作

- **创建项目分配**：点击"创建"按钮打开表单弹窗，填写项目名称、选择分包商、输入项目范围描述、设置完成期限，点击提交保存新记录
- **编辑项目分配**：在列表中点击某条记录的"编辑"链接，打开表单弹窗预填充现有数据，修改后提交更新
- **删除项目分配**：点击某条记录的"删除"链接，弹出二次确认对话框，确认后删除该记录
- **查询筛选**：在顶部查询区域输入项目名称、选择分包商、设置时间范围，点击"查询"按钮刷新列表
- **重置查询**：点击"重置"按钮清空所有查询条件并刷新列表
- **导出数据**：点击"导出"按钮将当前筛选条件下的数据导出为Excel文件
- **查看详情**：点击列表中的项目名称可查看该项目分配的详细信息
- **分页导航**：使用分页控件在不同页面间切换浏览项目分配记录

### 依赖的服务端逻辑

- **领域服务-逻辑-加载项目分配列表**：[分包商管理-加载项目分配列表（loadProjectAssignmentList）](specs/001-bootdo-management-system/plan/backend/logic-loadProjectAssignmentList.md)
- **领域服务-逻辑-加载分包商选择列表**：[分包商管理-加载分包商选择列表（loadSubcontractorForSelect）](specs/001-bootdo-management-system/plan/backend/logic-loadSubcontractorForSelect.md)

### 特殊组件

无特殊组件