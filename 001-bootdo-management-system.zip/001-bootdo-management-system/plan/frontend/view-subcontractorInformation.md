# 通用业务模块-分包商信息维护（subcontractorInformation）

- **生成时间**：2026-03-25

## 分包商信息维护（subcontractorInformation）

### 功能概述

分包商信息维护功能是分包商管理模块的核心组成部分，用于全面管理和维护企业合作分包商的基本信息。该功能提供分包商信息的完整录入、编辑、查询、筛选和导出能力，支持对分包商的FBSNQRY（分包商编号查询）、legalPersonName（法人姓名）、baseAffiliatedName（基地关联名称）等关键字段进行条件筛选，并以表格形式直观展示所有分包商信息。通过该功能，系统管理员和部门管理员可以高效地管理分包商基础数据，确保分包商信息的准确性和完整性，为后续的资质管理、合同关联、人员配置等业务流程提供可靠的数据支撑。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.subcontractorManagement.views.subcontractorInformation.tsx"
$View({
    title: "分包商信息维护",
    crumb: "分包商信息维护",
    auth: false,
    isIndex: false,
})
export declare function subcontractorInformation();
```

无输入参数。

### 验收列表

- **分包商列表管理**：分包商列表管理功能用于管理分包商的全面信息，支持导出、查询操作，包含FBSNQRY、legalPersonName、baseAffiliatedName等字段的筛选和展示。
  - **数据查询**：当用户在分包商管理页面输入查询条件（如FBSNQRY、legalPersonName、baseAffiliatedName等字段）并点击查询按钮时，系统必须根据条件筛选显示匹配的分包商列表
  - **数据导出**：当用户在分包商管理页面点击导出按钮时，系统必须将当前显示的分包商列表数据导出为Excel文件，包含所有字段信息
  - **列表展示**：当用户访问分包商管理页面时，系统必须以表格形式展示所有分包商信息，包含FBSNQRY、legalPersonName、baseAffiliatedName等关键字段的列

### 交互操作

- **查询分包商信息**：用户可以在查询表单中输入FBSNQRY（分包商编号）、legalPersonName（法人姓名）或baseAffiliatedName（基地关联名称）等条件，点击查询按钮后，系统根据输入条件筛选并展示匹配的分包商列表
- **导出分包商数据**：用户点击导出按钮后，系统将当前页面显示的所有分包商列表数据（包括筛选后的结果）导出为Excel文件，文件包含分包商的所有字段信息，便于离线分析和存档
- **查看分包商详情**：用户在分包商列表中点击某条记录的查看详情链接或操作按钮，系统内部跳转到分包商详情页面，展示该分包商的完整信息
- **编辑分包商信息**：用户在分包商列表中点击某条记录的编辑按钮，系统内部跳转到分包商编辑页面，允许用户修改分包商的基本信息
- **创建新分包商**：用户点击新建按钮，系统内部跳转到分包商创建页面，提供完整的表单供用户录入新的分包商信息

### 依赖的服务端逻辑

- **领域服务-逻辑-获取分包商列表**：[通用领域服务-获取分包商列表（getSubcontractorList）](specs/001-bootdo-management-system/plan/backend/logic-getSubcontractorList.md)
- **领域服务-逻辑-导出分包商数据**：[分包商管理-导出分包商数据（exportSubcontractorData）](specs/001-bootdo-management-system/plan/backend/logic-exportSubcontractorData.md)

### 特殊组件