# 通用业务模块-回收记录（recyclingRecord）

- **生成时间**：2026-03-25

## 回收记录（recyclingRecord）

### 功能概述

回收记录功能页面用于管理和跟踪企业环保相关的废弃物回收处理活动，是环保管理模块的重要组成部分。该页面支持记录各类可回收物的收集、分类、处理和处置全过程，包括回收物品类型、回收数量、回收日期、处理方式、回收单位等关键信息。通过系统化的回收记录管理，企业能够有效监控资源回收利用情况，确保符合环保法规要求，并为可持续发展决策提供数据支持。页面提供完整的CRUD操作，支持回收记录的新增、查询、编辑和删除功能，同时集成环保合规检查和风险评估流程，当回收处理不符合标准时能够及时触发整改任务。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.environmentalManagement.views.recyclingRecord.tsx"
$View({
    title: "回收记录",
    crumb: "回收记录",
    auth: true,
    authDescription: "回收记录管理",
})
export declare function recyclingRecord(
    /**
     * 回收记录ID，用于编辑模式下加载特定记录详情
     */
    recordId?: Integer,
    
    /**
     * 部门ID，用于筛选特定部门的回收记录
     */
    departmentId?: Integer,
    
    /**
     * 回收物品类型，用于按类型筛选回收记录
     */
    wasteType?: String,
    
    /**
     * 回收日期范围起始时间，用于按时间范围查询
     */
    startDate?: Date,
    
    /**
     * 回收日期范围结束时间，用于按时间范围查询
     */
    endDate?: Date,
    
    /**
     * 合规状态，用于筛选不同合规状态的回收记录
     */
    complianceStatus?: app.enums.ComplianceStatusEnum
);
```

### 验收列表

- 支持按回收物品类型、回收日期范围、部门、合规状态等多维度条件查询回收记录
- 支持新增回收记录，包含回收物品类型、回收数量、回收日期、处理方式、回收单位、合规状态等必填字段
- 支持编辑已存在的回收记录，修改相关信息并保存更新
- 支持删除回收记录，执行软删除操作并提供二次确认
- 支持查看回收记录详情，展示完整的回收处理信息
- 支持导出回收记录数据为Excel格式，便于数据分析和报告生成
- 当回收记录的合规状态为"不合规"时，系统自动关联整改措施和风险评估流程

### 交互操作

- **查询回收记录**：用户可以在页面顶部的查询条件区域输入回收物品类型、选择回收日期范围、指定部门和合规状态，点击查询按钮后在下方表格中显示符合条件的回收记录列表
- **新增回收记录**：用户点击"新增"按钮，系统弹出表单对话框，用户填写回收物品类型、回收数量、回收日期、处理方式、回收单位等信息，选择合规状态，点击保存后创建新的回收记录
- **编辑回收记录**：用户在回收记录列表中点击某条记录的"编辑"按钮，系统加载该记录的详细信息到表单中，用户修改相关信息后点击保存，系统更新回收记录
- **删除回收记录**：用户在回收记录列表中点击某条记录的"删除"按钮，系统弹出二次确认对话框，用户确认后执行软删除操作，将记录标记为已删除状态
- **查看详情**：用户在回收记录列表中点击某条记录的"详情"按钮，系统跳转到回收记录详情页面，展示该记录的完整信息
- **导出数据**：用户点击"导出"按钮，系统根据当前查询条件生成Excel文件并下载，包含所有符合条件的回收记录数据
- **关联整改措施**：当回收记录的合规状态为"不合规"时，用户可以点击"关联整改措施"按钮，系统跳转到环保管理-整改措施页面，创建针对该回收问题的整改任务

### 依赖的服务端逻辑

- **领域服务-逻辑-查询回收记录列表**：[通用领域服务-查询回收记录列表（queryRecyclingRecords）](specs/001-bootdo-management-system/plan/backend/logic-queryRecyclingRecords.md)
- **领域服务-逻辑-保存回收记录**：[环保管理-保存回收记录（saveRecyclingRecord）](specs/001-bootdo-management-system/plan/backend/logic-saveRecyclingRecord.md)
- **领域服务-逻辑-删除回收记录**：[通用领域服务-删除回收站记录（deleteRecyclingRecord）](specs/001-bootdo-management-system/plan/backend/logic-deleteRecyclingRecord.md)
- **领域服务-逻辑-导出回收记录**：[通用领域服务-导出回收记录（exportRecyclingRecords）](specs/001-bootdo-management-system/plan/backend/logic-exportRecyclingRecords.md)

### 特殊组件

无特殊组件