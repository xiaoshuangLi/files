# 通用业务模块-执行监控（executionMonitoring）

## 执行监控（executionMonitoring）

### 功能概述

执行监控功能页面提供全面的预算执行情况跟踪和分析能力。用户可以通过表格形式查看所有预算分配的执行监控记录，每条记录包含预算分配ID、已花费金额、剩余金额、监控时间等关键信息。系统支持多维度筛选查询，用户可以根据预算分配、时间范围、预算类型、部门等条件灵活筛选执行监控数据，快速定位关注的预算执行情况。在执行监控详情页面，用户可以查看特定预算分配的完整执行轨迹，包括历史执行记录的时间序列数据、执行进度趋势图等可视化展示。页面还集成了执行偏差分析功能，自动计算实际执行金额与预算分配金额的偏差率、使用率等关键指标，并识别预算超支或执行滞后等异常情况。用户可以导出执行监控数据为Excel格式，便于离线分析和报告制作。此外，系统提供智能预警功能，当检测到预算执行异常时会自动标记并提醒用户关注。

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.budgetManagement.views.executionMonitoring.tsx"
$View({
    title: "执行监控",
    crumb: "执行监控",
    auth: false,
    isIndex: false,
})
export declare function executionMonitoring();
```

无输入参数。

### 依赖的服务端逻辑

- **领域服务-逻辑-加载预算历史记录**：[预算管理-加载预算历史记录（loadBudgetHistory）](specs/001-bootdo-management-system/plan/backend/logic-loadBudgetHistory.md)
- **领域服务-逻辑-分析预算执行情况**：[预算管理-分析预算执行情况（analyzeBudget）](specs/001-bootdo-management-system/plan/backend/logic-analyzeBudget.md)
- **领域服务-逻辑-计算执行偏差分析**：[预算管理-计算执行偏差分析（calculateExecutionDeviationAnalysis）](specs/001-bootdo-management-system/plan/backend/logic-calculateExecutionDeviationAnalysis.md)
- **领域服务-逻辑-加载预算分配列表**：[预算管理-加载预算分配列表（loadBudgetAllocations）](specs/001-bootdo-management-system/plan/backend/logic-loadBudgetAllocations.md)