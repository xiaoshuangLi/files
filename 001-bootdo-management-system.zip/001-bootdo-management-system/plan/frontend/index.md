# 业务模块

- **生成时间**：2026-03-25

## 层级路由

- **关联文档**：[业务模块-层级路由](specs/001-bootdo-management-system/plan/frontend/routes.md)

## 功能页面

### 登录（login）

- **关联文档**：[登录（login）](specs/001-bootdo-management-system/plan/frontend/view-login.md)

### 无权限页（noAuth）

- **关联文档**：[无权限页（noAuth）](specs/001-bootdo-management-system/plan/frontend/view-noAuth.md)

### 权限中心（permissionCenter）

- **关联文档**：[权限中心（permissionCenter）](specs/001-bootdo-management-system/plan/frontend/view-permissionCenter.md)

### 用户管理（userManagement）

- **关联文档**：[权限中心-用户管理（userManagement）](specs/001-bootdo-management-system/plan/frontend/view-userManagement.md)

### 角色管理（roleManagement）

- **关联文档**：[权限中心-角色管理（roleManagement）](specs/001-bootdo-management-system/plan/frontend/view-roleManagement.md)

### 权限管理（permissionManagement）

- **关联文档**：[权限中心-权限管理（permissionManagement）](specs/001-bootdo-management-system/plan/frontend/view-permissionManagement.md)

### 部门管理（departmentManagement）

- **关联文档**：[权限中心-部门管理（departmentManagement）](specs/001-bootdo-management-system/plan/frontend/view-departmentManagement.md)

### Dashboard（dashboard）

- **关联文档**：[Dashboard（dashboard）](specs/001-bootdo-management-system/plan/frontend/view-dashboard.md)

### 菜单管理（menuManagement）

- **关联文档**：[Dashboard-系统管理-菜单管理（menuManagement）](specs/001-bootdo-management-system/plan/frontend/view-menuManagement.md)

### 字典管理（dictionaryManagement）

- **关联文档**：[Dashboard-系统管理-字典管理（dictionaryManagement）](specs/001-bootdo-management-system/plan/frontend/view-dictionaryManagement.md)

### 日志管理（logManagement）

- **关联文档**：[Dashboard-系统管理-日志管理（logManagement）](specs/001-bootdo-management-system/plan/frontend/view-logManagement.md)

### 在线用户管理（onlineUserManagement）

- **关联文档**：[Dashboard-系统管理-在线用户管理（onlineUserManagement）](specs/001-bootdo-management-system/plan/frontend/view-onlineUserManagement.md)

### 系统参数配置（systemParameterConfiguration）

- **关联文档**：[Dashboard-系统管理-系统参数配置（systemParameterConfiguration）](specs/001-bootdo-management-system/plan/frontend/view-systemParameterConfiguration.md)

### 通知公告（noticeAnnouncement）

- **关联文档**：[Dashboard-办公自动化-通知公告（noticeAnnouncement）](specs/001-bootdo-management-system/plan/frontend/view-noticeAnnouncement.md)

### 文件管理（fileManagement）

- **关联文档**：[Dashboard-办公自动化-文件管理（fileManagement）](specs/001-bootdo-management-system/plan/frontend/view-fileManagement.md)

### 日程管理（scheduleArrangement）

- **关联文档**：[Dashboard-办公自动化-日程管理（scheduleArrangement）](specs/001-bootdo-management-system/plan/frontend/view-scheduleArrangement.md)

### 会议管理（meetingReservation）

- **关联文档**：[Dashboard-办公自动化-会议管理（meetingReservation）](specs/001-bootdo-management-system/plan/frontend/view-meetingReservation.md)

### 待办事项（todoTask）

- **关联文档**：[Dashboard-办公自动化-待办事项（todoTask）](specs/001-bootdo-management-system/plan/frontend/view-todoTask.md)

### 邮件集成（emailCommunication）

- **关联文档**：[Dashboard-办公自动化-邮件集成（emailCommunication）](specs/001-bootdo-management-system/plan/frontend/view-emailCommunication.md)

### 文档协作（documentCollaboration）

- **关联文档**：[Dashboard-办公自动化-文档协作（documentCollaboration）](specs/001-bootdo-management-system/plan/frontend/view-documentCollaboration.md)

### 个人门户（personalWorkspace）

- **关联文档**：[Dashboard-办公自动化-个人门户（personalWorkspace）](specs/001-bootdo-management-system/plan/frontend/view-personalWorkspace.md)

### 流程定义（processDefinition）

- **关联文档**：[Dashboard-工作流引擎-流程定义（processDefinition）](specs/001-bootdo-management-system/plan/frontend/view-processDefinition.md)

### 流程实例管理（processInstanceManagement）

- **关联文档**：[Dashboard-工作流引擎-流程实例管理（processInstanceManagement）](specs/001-bootdo-management-system/plan/frontend/view-processInstanceManagement.md)

### 任务管理（taskManagement）

- **关联文档**：[Dashboard-工作流引擎-任务管理（taskManagement）](specs/001-bootdo-management-system/plan/frontend/view-taskManagement.md)

### 用户和组管理（userGroupManagement）

- **关联文档**：[Dashboard-工作流引擎-用户和组管理（userGroupManagement）](specs/001-bootdo-management-system/plan/frontend/view-userGroupManagement.md)

### 表单集成（formIntegration）

- **关联文档**：[Dashboard-工作流引擎-表单集成（formIntegration）](specs/001-bootdo-management-system/plan/frontend/view-formIntegration.md)

### 审批流程（approvalProcess）

- **关联文档**：[Dashboard-工作流引擎-审批流程（approvalProcess）](specs/001-bootdo-management-system/plan/frontend/view-approvalProcess.md)

### 节点配置（nodeConfiguration）

- **关联文档**：[Dashboard-工作流引擎-节点配置（nodeConfiguration）](specs/001-bootdo-management-system/plan/frontend/view-nodeConfiguration.md)

### 流程监控（processMonitoring）

- **关联文档**：[Dashboard-工作流引擎-流程监控（processMonitoring）](specs/001-bootdo-management-system/plan/frontend/view-processMonitoring.md)

### 质量问题登记（qualityIssueRegistration）

- **关联文档**：[Dashboard-质量管理-质量问题登记（qualityIssueRegistration）](specs/001-bootdo-management-system/plan/frontend/view-qualityIssueRegistration.md)

### 整改任务分配（rectificationTaskAssignment）

- **关联文档**：[Dashboard-质量管理-整改任务分配（rectificationTaskAssignment）](specs/001-bootdo-management-system/plan/frontend/view-rectificationTaskAssignment.md)

### 质量检验（qualityInspection）

- **关联文档**：[Dashboard-质量管理-质量检验（qualityInspection）](specs/001-bootdo-management-system/plan/frontend/view-qualityInspection.md)

### 问题跟踪（issueTracking）

- **关联文档**：[Dashboard-质量管理-问题跟踪（issueTracking）](specs/001-bootdo-management-system/plan/frontend/view-issueTracking.md)

### 质量验收（acceptanceStandard）

- **关联文档**：[Dashboard-质量管理-质量验收（acceptanceStandard）](specs/001-bootdo-management-system/plan/frontend/view-acceptanceStandard.md)

### 检验报告（inspectionReport）

- **关联文档**：[Dashboard-质量管理-检验报告（inspectionReport）](specs/001-bootdo-management-system/plan/frontend/view-inspectionReport.md)

### 整改进度（rectificationProgress）

- **关联文档**：[Dashboard-质量管理-整改进度（rectificationProgress）](specs/001-bootdo-management-system/plan/frontend/view-rectificationProgress.md)

### 质量指标（qualityIndicator）

- **关联文档**：[Dashboard-质量管理-质量指标（qualityIndicator）](specs/001-bootdo-management-system/plan/frontend/view-qualityIndicator.md)

### 文章管理（articleManagement）

- **关联文档**：[Dashboard-内容管理/博客-文章管理（articleManagement）](specs/001-bootdo-management-system/plan/frontend/view-articleManagement.md)

### 栏目管理（columnStructure）

- **关联文档**：[Dashboard-内容管理/博客-栏目管理（columnStructure）](specs/001-bootdo-management-system/plan/frontend/view-columnStructure.md)

### 评论管理（commentInteraction）

- **关联文档**：[Dashboard-内容管理/博客-评论管理（commentInteraction）](specs/001-bootdo-management-system/plan/frontend/view-commentInteraction.md)

### 用户订阅（userSubscription）

- **关联文档**：[Dashboard-内容管理/博客-用户订阅（userSubscription）](specs/001-bootdo-management-system/plan/frontend/view-userSubscription.md)

### 权限控制（contentPermission）

- **关联文档**：[Dashboard-内容管理/博客-权限控制（contentPermission）](specs/001-bootdo-management-system/plan/frontend/view-contentPermission.md)

### SEO优化（seoOptimization）

- **关联文档**：[Dashboard-内容管理/博客-SEO优化（seoOptimization）](specs/001-bootdo-management-system/plan/frontend/view-seoOptimization.md)

### 附件管理（attachmentResource）

- **关联文档**：[Dashboard-内容管理/博客-附件管理（attachmentResource）](specs/001-bootdo-management-system/plan/frontend/view-attachmentResource.md)

### 统计分析（contentStatistics）

- **关联文档**：[Dashboard-内容管理/博客-统计分析（contentStatistics）](specs/001-bootdo-management-system/plan/frontend/view-contentStatistics.md)

### 预算类型管理（budgetType）

- **关联文档**：[Dashboard-预算管理-预算类型管理（budgetType）](specs/001-bootdo-management-system/plan/frontend/view-budgetType.md)

### 预算周期管理（budgetCycle）

- **关联文档**：[Dashboard-预算管理-预算周期管理（budgetCycle）](specs/001-bootdo-management-system/plan/frontend/view-budgetCycle.md)

### 审批流程（approvalWorkflow）

- **关联文档**：[Dashboard-预算管理-审批流程（approvalWorkflow）](specs/001-bootdo-management-system/plan/frontend/view-approvalWorkflow.md)

### 报表格式（reportFormat）

- **关联文档**：[Dashboard-预算管理-报表格式（reportFormat）](specs/001-bootdo-management-system/plan/frontend/view-reportFormat.md)

### 预算分配（budgetAllocation）

- **关联文档**：[Dashboard-预算管理-预算分配（budgetAllocation）](specs/001-bootdo-management-system/plan/frontend/view-budgetAllocation.md)

### 执行监控（executionMonitoring）

- **关联文档**：[Dashboard-预算管理-执行监控（executionMonitoring）](specs/001-bootdo-management-system/plan/frontend/view-executionMonitoring.md)

### 调整申请（adjustmentApplication）

- **关联文档**：[Dashboard-预算管理-调整申请（adjustmentApplication）](specs/001-bootdo-management-system/plan/frontend/view-adjustmentApplication.md)

### 分析报告（analysisReport）

- **关联文档**：[Dashboard-预算管理-分析报告（analysisReport）](specs/001-bootdo-management-system/plan/frontend/view-analysisReport.md)

### 分包商信息维护（subcontractorInformation）

- **关联文档**：[Dashboard-分包商管理-分包商信息维护（subcontractorInformation）](specs/001-bootdo-management-system/plan/frontend/view-subcontractorInformation.md)

### 资质管理（qualificationCertificate）

- **关联文档**：[Dashboard-分包商管理-资质管理（qualificationCertificate）](specs/001-bootdo-management-system/plan/frontend/view-qualificationCertificate.md)

### 合同关联（contractAssociation）

- **关联文档**：[Dashboard-分包商管理-合同关联（contractAssociation）](specs/001-bootdo-management-system/plan/frontend/view-contractAssociation.md)

### 人员管理（personnelConfiguration）

- **关联文档**：[Dashboard-分包商管理-人员管理（personnelConfiguration）](specs/001-bootdo-management-system/plan/frontend/view-personnelConfiguration.md)

### 评估记录（evaluationRecord）

- **关联文档**：[Dashboard-分包商管理-评估记录（evaluationRecord）](specs/001-bootdo-management-system/plan/frontend/view-evaluationRecord.md)

### 付款管理（paymentManagement）

- **关联文档**：[Dashboard-分包商管理-付款管理（paymentManagement）](specs/001-bootdo-management-system/plan/frontend/view-paymentManagement.md)

### 项目分配（projectAssignment）

- **关联文档**：[Dashboard-分包商管理-项目分配（projectAssignment）](specs/001-bootdo-management-system/plan/frontend/view-projectAssignment.md)

### 风险评估（riskAssessment）

- **关联文档**：[Dashboard-分包商管理-风险评估（riskAssessment）](specs/001-bootdo-management-system/plan/frontend/view-riskAssessment.md)

### 薪资结构定义（salaryStructure）

- **关联文档**：[Dashboard-薪资管理-薪资结构定义（salaryStructure）](specs/001-bootdo-management-system/plan/frontend/view-salaryStructure.md)

### 薪资调整审批（salaryAdjustment）

- **关联文档**：[Dashboard-薪资管理-薪资调整审批（salaryAdjustment）](specs/001-bootdo-management-system/plan/frontend/view-salaryAdjustment.md)

### 薪酬档级（compensationGrade）

- **关联文档**：[Dashboard-薪资管理-薪酬档级（compensationGrade）](specs/001-bootdo-management-system/plan/frontend/view-compensationGrade.md)

### 月工资额计算（monthlySalaryAmount）

- **关联文档**：[Dashboard-薪资管理-月工资额计算（monthlySalaryAmount）](specs/001-bootdo-management-system/plan/frontend/view-monthlySalaryAmount.md)

### 年薪总额计算（annualSalaryTotal）

- **关联文档**：[Dashboard-薪资管理-年薪总额计算（annualSalaryTotal）](specs/001-bootdo-management-system/plan/frontend/view-annualSalaryTotal.md)

### 薪资报表（salaryReport）

- **关联文档**：[Dashboard-薪资管理-薪资报表（salaryReport）](specs/001-bootdo-management-system/plan/frontend/view-salaryReport.md)

### 税务计算（taxCalculation）

- **关联文档**：[Dashboard-薪资管理-税务计算（taxCalculation）](specs/001-bootdo-management-system/plan/frontend/view-taxCalculation.md)

### 发放记录（paymentRecord）

- **关联文档**：[Dashboard-薪资管理-发放记录（paymentRecord）](specs/001-bootdo-management-system/plan/frontend/view-paymentRecord.md)

### 环境监测（environmentalMonitoring）

- **关联文档**：[Dashboard-环保管理-环境监测（environmentalMonitoring）](specs/001-bootdo-management-system/plan/frontend/view-environmentalMonitoring.md)

### 排放控制（emissionControl）

- **关联文档**：[Dashboard-环保管理-排放控制（emissionControl）](specs/001-bootdo-management-system/plan/frontend/view-emissionControl.md)

### 合规检查（complianceInspection）

- **关联文档**：[Dashboard-环保管理-合规检查（complianceInspection）](specs/001-bootdo-management-system/plan/frontend/view-complianceInspection.md)

### 整改措施（rectificationMeasure）

- **关联文档**：[Dashboard-环保管理-整改措施（rectificationMeasure）](specs/001-bootdo-management-system/plan/frontend/view-rectificationMeasure.md)

### 报告提交（reportSubmission）

- **关联文档**：[Dashboard-环保管理-报告提交（reportSubmission）](specs/001-bootdo-management-system/plan/frontend/view-reportSubmission.md)

### 风险评估（environmentalRiskAssessment）

- **关联文档**：[Dashboard-环保管理-风险评估（environmentalRiskAssessment）](specs/001-bootdo-management-system/plan/frontend/view-environmentalRiskAssessment.md)

### 应急预案（emergencyPlan）

- **关联文档**：[Dashboard-环保管理-应急预案（emergencyPlan）](specs/001-bootdo-management-system/plan/frontend/view-emergencyPlan.md)

### 资源消耗（resourceConsumption）

- **关联文档**：[Dashboard-环保管理-资源消耗（resourceConsumption）](specs/001-bootdo-management-system/plan/frontend/view-resourceConsumption.md)

### 通用业务模块-文章管理（articleContent）

- **关联文档**：[通用业务模块-文章管理（articleContent）](specs/001-bootdo-management-system/plan/frontend/view-articleContent.md)

### 通用业务模块-邮件集成（emailIntegration）

- **关联文档**：[通用业务模块-邮件集成（emailIntegration）](specs/001-bootdo-management-system/plan/frontend/view-emailIntegration.md)

### 通用业务模块-会议管理（meetingManagement）

- **关联文档**：[通用业务模块-会议管理（meetingManagement）](specs/001-bootdo-management-system/plan/frontend/view-meetingManagement.md)

### 通用业务模块-流程实例管理（processInstance）

- **关联文档**：[通用业务模块-流程实例管理（processInstance）](specs/001-bootdo-management-system/plan/frontend/view-processInstance.md)

### 通用业务模块-质量问题登记（qualityIssue）

- **关联文档**：[通用业务模块-质量问题登记（qualityIssue）](specs/001-bootdo-management-system/plan/frontend/view-qualityIssue.md)

### 通用业务模块-整改任务分配（rectificationTask）

- **关联文档**：[通用业务模块-整改任务分配（rectificationTask）](specs/001-bootdo-management-system/plan/frontend/view-rectificationTask.md)

### 通用业务模块-回收记录（recyclingRecord）

- **关联文档**：[通用业务模块-回收记录（recyclingRecord）](specs/001-bootdo-management-system/plan/frontend/view-recyclingRecord.md)

### 通用业务模块-日程管理（scheduleManagement）

- **关联文档**：[通用业务模块-日程管理（scheduleManagement）](specs/001-bootdo-management-system/plan/frontend/view-scheduleManagement.md)

### 通用业务模块-系统参数配置（systemConfig）

- **关联文档**：[通用业务模块-系统参数配置（systemConfig）](specs/001-bootdo-management-system/plan/frontend/view-systemConfig.md)

### 通用业务模块-用户和组管理（userGroup）

- **关联文档**：[通用业务模块-用户和组管理（userGroup）](specs/001-bootdo-management-system/plan/frontend/view-userGroup.md)
