# 通用业务模块-资源消耗（resourceConsumption）

- **生成时间**：2026-03-25

## 资源消耗（resourceConsumption）

### 功能概述

资源消耗功能页面是环保管理模块的核心组成部分，专注于企业能源资源消耗的统计分析与可视化展示。该页面支持对电力消耗、水资源消耗、燃料消耗、原材料消耗等多种能源资源的用量数据进行采集、统计和趋势分析，帮助企业全面掌握资源使用情况，识别节能降耗的机会点，优化资源配置，降低运营成本，同时满足环保合规要求。系统提供多维度的数据筛选、图表展示和报表导出功能，支持按时间周期、资源类型、部门或生产线等条件进行数据查询和分析，为企业的可持续发展决策提供数据支撑。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.environmentalManagement.views.resourceConsumption.tsx"
$View({
    title: "资源消耗",
    crumb: "资源消耗",
    auth: false,
    isIndex: false,
})
export declare function resourceConsumption(id?: Integer, resourceType?: String, startDate?: String, endDate?: String, departmentId?: Integer, productionLineId?: Integer);
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| id | 资源消耗记录ID | Integer | 用于查看详情的资源消耗记录ID |
| resourceType | 资源类型 | String | 资源类型筛选参数 |
| startDate | 开始日期 | String | 时间范围开始日期 |
| endDate | 结束日期 | String | 时间范围结束日期 |
| departmentId | 部门ID | Integer | 部门ID筛选参数 |
| productionLineId | 生产线ID | Integer | 生产线ID筛选参数 |

### 验收列表

- **能源资源消耗统计功能**：
  - **资源消耗数据统计**：
    - 系统支持能源资源消耗统计功能，包括电力消耗、水资源消耗、燃料消耗、原材料消耗等能源资源的用量统计和趋势分析

### 交互操作

- **查看资源消耗详情**：用户可以点击资源消耗记录查看详细信息，包括具体的消耗量、时间、地点、负责人等详细数据
- **筛选资源类型**：用户可以通过下拉选择器筛选特定的资源类型（电力、水资源、燃料、原材料等）进行数据查看和分析
- **设置时间范围**：用户可以设置开始日期和结束日期来限定查询的时间范围，支持按日、周、月、季度、年等不同粒度查看数据
- **部门筛选**：用户可以选择特定部门来查看该部门的资源消耗情况，支持多部门对比分析
- **生产线筛选**：用户可以选择特定生产线来查看该生产线的资源消耗情况，便于精细化管理
- **趋势图表查看**：系统以折线图、柱状图等形式展示资源消耗的趋势变化，用户可以直观了解消耗模式和异常波动
- **数据导出**：用户可以将资源消耗统计数据导出为Excel或PDF格式，便于离线分析和报告制作
- **刷新数据**：用户可以点击刷新按钮获取最新的资源消耗数据，确保数据的实时性

### 依赖的服务端逻辑

- **领域服务-逻辑-获取资源消耗统计数据**：[环保管理-获取资源消耗统计数据（getResourceConsumptionStatistics）](specs/001-bootdo-management-system/plan/backend/logic-getResourceConsumptionStatistics.md)
- **领域服务-逻辑-导出资源消耗报表**：[环保管理-导出资源消耗报表（exportResourceConsumptionReport）](specs/001-bootdo-management-system/plan/backend/logic-exportResourceConsumptionReport.md)

### 特殊组件

无特殊组件。资源消耗功能页面使用标准用户界面组件库中的图表组件（CwChartJs）实现所有趋势分析和数据可视化功能，无需使用业务定制的特殊组件。