# 通用业务模块-质量问题登记（qualityIssueRegistration）

- **生成时间**：2026-03-25

## 质量问题登记（qualityIssueRegistration）

### 功能概述

质量问题登记页面是质量管理模块的核心功能页面，用于记录和跟踪发现的质量问题。该页面支持质量管理员创建新的质量问题记录，包括问题标题、详细描述、报告人信息、问题状态等关键信息。页面提供完整的质量问题生命周期管理，从问题报告到最终关闭的全过程跟踪。通过该页面，企业可以建立系统化的质量问题管理体系，确保所有质量问题都能被及时发现、记录、分配和解决，从而持续改进产品质量和服务质量。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.qualityManagement.views.qualityIssueRegistration.tsx"
$View({
    title: "质量问题登记",
    crumb: "通用业务模块-质量问题登记",
    auth: true,
})
export declare function qualityIssueRegistration();
```

### 验收列表

- **质量问题数据管理**：
  - **质量问题增删改操作**：
    - 质量管理员可以在质量问题登记界面查看所有质量问题的列表，以表格形式展示质量问题信息
    - 质量管理员可以点击"保存"按钮，提交质量问题表单数据，保存质量问题信息
    - 质量管理员可以直接删除不需要的质量问题记录，删除操作无需二次确认，执行后立即生效
    - 质量管理员可以提交质量问题数据，完成质量问题的确认和流转
  - **质量问题导出功能**：
    - 质量管理员可以通过导出按钮将质量问题数据导出为外部文件格式，支持标准格式的数据导出
  - **质量问题图片附件管理**：
    - 质量问题表单支持图片附件上传，质量管理员可以在质量问题中上传相关图片作为附件

### 交互操作

- **新增质量问题**：质量管理员点击新增按钮，在表单中填写问题标题、问题描述、选择报告人等信息，上传相关图片附件，点击保存按钮提交质量问题记录
- **编辑质量问题**：质量管理员在质量问题列表中点击编辑按钮，系统根据issueId参数加载质量问题详情并填充到表单中，管理员修改相关信息后点击保存按钮更新质量问题记录
- **删除质量问题**：质量管理员在质量问题列表中选择要删除的记录，点击删除按钮直接删除质量问题，无需二次确认
- **查询质量问题**：质量管理员在查询条件区域输入搜索关键词，点击查询按钮筛选显示符合条件的质量问题列表
- **导出质量问题**：质量管理员点击导出按钮，系统将当前质量问题列表数据导出为Excel文件格式
- **查看质量问题详情**：质量管理员在质量问题列表中点击查看详情按钮，系统跳转到质量问题详情页面，展示完整的质量问题信息
- **上传图片附件**：质量管理员在质量问题表单中点击上传按钮，选择本地图片文件上传作为质量问题的附件资源

### 依赖的服务端逻辑

- **领域服务-逻辑-创建质量问题**：[质量管理-创建质量问题（createQualityIssue）](specs/001-bootdo-management-system/plan/backend/logic-createQualityIssue.md)
- **领域服务-逻辑-更新质量问题**：[质量管理-更新质量问题（updateQualityIssue）](specs/001-bootdo-management-system/plan/backend/logic-updateQualityIssue.md)
- **领域服务-逻辑-删除质量问题**：[质量管理-删除质量问题（deleteQualityIssue）](specs/001-bootdo-management-system/plan/backend/logic-deleteQualityIssue.md)
- **领域服务-逻辑-查询质量问题列表**：[质量管理-获取质量问题列表（queryQualityIssues）](specs/001-bootdo-management-system/plan/backend/logic-queryQualityIssues.md)
- **领域服务-逻辑-上传质量问题附件**：[质量管理-上传质量问题附件（uploadQualityIssueAttachment）](specs/001-bootdo-management-system/plan/backend/logic-uploadQualityIssueAttachment.md)

### 特殊组件

无特殊组件。质量问题登记功能页面使用标准用户界面组件库中的表单、表格、上传等基础组件实现所有功能，无需使用业务定制的特殊组件。