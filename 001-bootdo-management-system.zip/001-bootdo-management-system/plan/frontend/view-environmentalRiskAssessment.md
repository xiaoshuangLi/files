# 通用业务模块-风险评估（environmentalRiskAssessment）

- **生成时间**：2026-03-25

## 风险评估（environmentalRiskAssessment）

### 功能概述

环境风险评估功能页面用于记录和管理环境风险的评估结果，包括风险类型、严重程度、风险描述和评估时间等关键信息。该页面支持环保管理人员对环境风险进行全面评估，为制定相应的风险控制措施提供数据支持，确保企业环保合规和风险管理的有效性。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.environmentalManagement.views.environmentalRiskAssessment.tsx"
$View({
    title: "风险评估",
    crumb: "风险评估",
    auth: true,
    authDescription: "环境风险评估分析",
    isIndex: false,
})
export declare function environmentalRiskAssessment();
```

无输入参数。

### 验收列表

- 支持环境风险评估记录的创建、查看、编辑和删除操作
- 支持按风险类型、严重程度、评估时间等条件进行筛选查询
- 支持关联合规检查记录，实现风险评估与合规检查的联动
- 支持风险严重程度的量化评估（1-5级）
- 支持详细的环境风险描述和评估时间记录
- 支持环境风险评估报告的导出功能

### 交互操作

- **创建环境风险评估**：用户可以填写风险类型、风险描述、严重程度等信息，创建新的环境风险评估记录，并关联到特定的合规检查记录
- **编辑环境风险评估**：用户可以修改已存在的环境风险评估记录的各项信息，包括风险类型、描述、严重程度等
- **删除环境风险评估**：用户可以删除不再需要的环境风险评估记录，系统会进行二次确认以防止误操作
- **查看环境风险评估详情**：用户可以查看单个环境风险评估记录的完整信息，包括关联的合规检查详情
- **筛选查询环境风险评估**：用户可以通过风险类型、严重程度范围、评估时间区间等条件筛选查询环境风险评估记录
- **导出环境风险评估报告**：用户可以将当前查询结果导出为Excel格式的环境风险评估报告
- **系统内部跳转**：点击关联的合规检查ID可跳转到[Dashboard-环保管理-合规检查（complianceInspection）](specs/001-bootdo-management-system/plan/frontend/view-complianceInspection.md)页面查看详细信息

### 依赖的服务端逻辑

- **领域服务-逻辑-获取环境风险评估列表**：[环保管理-获取环境风险评估列表（getEnvironmentalRiskAssessmentList）](specs/001-bootdo-management-system/plan/backend/logic-getEnvironmentalRiskAssessmentList.md)
- **领域服务-逻辑-创建环境风险评估**：[通用领域服务-创建环境风险评估（createEnvironmentalRiskAssessment）](specs/001-bootdo-management-system/plan/backend/logic-createEnvironmentalRiskAssessment.md)
- **领域服务-逻辑-更新环境风险评估**：[环保管理-更新环境风险评估（updateEnvironmentalRiskAssessment）](specs/001-bootdo-management-system/plan/backend/logic-updateEnvironmentalRiskAssessment.md)
- **领域服务-逻辑-删除环境风险评估**：[环保管理-删除环境风险评估（deleteEnvironmentalRiskAssessment）](specs/001-bootdo-management-system/plan/backend/logic-deleteEnvironmentalRiskAssessment.md)
- **领域服务-逻辑-获取合规检查详情**：[环保管理-获取合规检查详情（getComplianceInspectionDetail）](specs/001-bootdo-management-system/plan/backend/logic-getComplianceInspectionDetail.md)
- **领域服务-逻辑-导出环境风险评估报告**：[环保管理-导出环境风险评估报告（exportEnvironmentalRiskAssessmentReport）](specs/001-bootdo-management-system/plan/backend/logic-exportEnvironmentalRiskAssessmentReport.md)

### 特殊组件

无特殊组件