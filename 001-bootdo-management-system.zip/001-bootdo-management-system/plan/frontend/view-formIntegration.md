# 通用业务模块-表单集成（formIntegration）

- **生成时间**：2026-03-25

## 表单集成（formIntegration）

### 功能概述

表单集成功能页面实现工作流引擎中表单数据的管理与集成，支持将业务表单数据与工作流流程实例进行关联。该页面允许用户查看、创建、编辑和删除表单集成记录，每个表单集成记录包含具体的表单数据内容，并与特定的流程实例绑定，确保业务数据能够在工作流执行过程中被正确传递和处理。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.workflowEngine.views.formIntegration.tsx"
$View({
    title: "表单集成",
    crumb: "表单集成",
    auth: true,
    isIndex: false,
})
export declare function formIntegration(instanceId?: Integer);
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| instanceId | 流程实例ID | Integer | 用于筛选特定流程实例的表单数据 |

### 验收列表

无验收列表

### 交互操作

- **查看表单列表**：根据流程实例ID参数筛选并展示对应的表单集成记录列表，支持分页查看
- **创建新表单**：通过表单弹框的形式实现新增表单集成记录，需要填写流程实例ID和表单数据内容
- **编辑表单**：点击编辑按钮，通过表单弹框的形式修改现有表单集成记录的表单数据内容
- **删除表单**：点击删除按钮，经过二次确认后删除选中的表单集成记录
- **查看表单详情**：点击表单记录，以只读模式查看完整的表单数据内容和关联信息

### 依赖的服务端逻辑

- **领域服务-逻辑-获取表单集成列表**：[工作流引擎-获取表单集成列表（getFormIntegrationList）](specs/001-bootdo-management-system/plan/backend/logic-getFormIntegrationList.md)
- **领域服务-逻辑-创建表单集成**：[工作流引擎-创建表单集成（createFormIntegration）](specs/001-bootdo-management-system/plan/backend/logic-createFormIntegration.md)
- **领域服务-逻辑-更新表单集成**：[工作流引擎-更新表单集成（updateFormIntegration）](specs/001-bootdo-management-system/plan/backend/logic-updateFormIntegration.md)
- **领域服务-逻辑-删除表单集成**：[工作流引擎-删除表单集成（deleteFormIntegration）](specs/001-bootdo-management-system/plan/backend/logic-deleteFormIntegration.md)

### 特殊组件

无特殊组件