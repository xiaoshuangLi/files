# 通用业务模块-分析报告（analysisReport）

- **生成时间**：2026-03-25

## 分析报告（analysisReport）

### 功能概述

分析报告功能页面实现预算执行分析报告的生成、查看和管理功能。该页面允许用户基于预设的报表格式对预算分配数据进行汇总分析，生成详细的预算执行分析报告。用户可以查看历史生成的分析报告，了解预算执行情况，并支持导出报告用于进一步的数据分析和决策支持。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.budgetManagement.views.analysisReport.tsx"
$View({
    title: "分析报告",
    auth: true,
    isIndex: false,
})
export declare function analysisReport();
```

输入参数：
- allocationId?: Integer - 预算分配ID，用于查看特定预算分配的分析报告
- reportId?: Integer - 分析报告ID，用于查看特定分析报告详情

### 验收列表

- 支持查看所有已生成的预算执行分析报告列表
- 支持按预算分配筛选分析报告
- 支持按报表格式筛选分析报告
- 支持查看分析报告的详细内容
- 支持导出分析报告为PDF或Excel格式
- 支持基于现有预算分配和报表格式生成新的分析报告

### 交互操作

- **查看分析报告列表**：在分析报告页面展示所有已生成的预算执行分析报告，包含报告ID、关联的预算分配、报表格式、生成时间等基本信息，支持分页显示。
- **筛选分析报告**：提供筛选条件，支持按预算分配和报表格式进行筛选，帮助用户快速定位目标分析报告。
- **查看分析报告详情**：点击分析报告列表中的某条记录，进入详情页面查看完整的报告内容，包括详细的预算执行数据分析结果。
- **导出分析报告**：在报告详情页面提供导出功能，支持将分析报告导出为PDF或Excel格式，便于离线查看和分享。
- **生成新分析报告**：提供生成新分析报告的功能入口，用户可以选择预算分配和报表格式，系统自动生成对应的分析报告并保存到数据库中。
- **返回预算管理首页**：在页面顶部提供面包屑导航，支持用户快速返回到预算管理模块的首页。

### 依赖的服务端逻辑

- **领域服务-逻辑-获取分析报告列表**：[预算管理-获取分析报告列表（getAnalysisReportList）](specs/001-bootdo-management-system/plan/backend/logic-getAnalysisReportList.md)
- **领域服务-逻辑-获取分析报告详情**：[预算管理-获取分析报告详情（getAnalysisReportDetail）](specs/001-bootdo-management-system/plan/backend/logic-getAnalysisReportDetail.md)
- **领域服务-逻辑-生成分析报告**：[预算管理-生成分析报告（generateAnalysisReport）](specs/001-bootdo-management-system/plan/backend/logic-generateAnalysisReport.md)
- **领域服务-逻辑-导出分析报告**：[预算管理-导出分析报告（exportAnalysisReport）](specs/001-bootdo-management-system/plan/backend/logic-exportAnalysisReport.md)

### 特殊组件

无特殊组件