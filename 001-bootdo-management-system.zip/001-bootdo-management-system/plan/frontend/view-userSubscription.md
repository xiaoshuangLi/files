# 通用业务模块-用户订阅（userSubscription）

- **生成时间**：2026-03-25

## 用户订阅（userSubscription）

### 功能概述

用户订阅功能提供对系统中栏目和文章内容的订阅管理能力，支持用户个性化的内容推送和更新通知。该功能允许用户订阅特定的栏目或具体的文章，当所订阅的栏目有新文章发布或已订阅的文章有内容更新时，系统会自动向用户发送通知提醒。用户订阅管理界面支持查看当前用户的订阅列表、添加新的订阅关系、取消已有订阅等操作，同时管理员可以查看和管理所有用户的订阅情况。该功能通过建立用户与内容之间的关联关系，提升了用户体验和平台内容的参与度，实现了精准的内容分发机制。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.contentManagement.views.userSubscription.tsx"
$View({
    title: "用户订阅",
    crumb: "用户订阅",
    auth: true,
    isIndex: true,
})
export declare function userSubscription(
    // 当前登录用户的ID，用于过滤显示该用户的订阅列表
    currentUserId?: Integer,
    // 栏目ID参数，用于查看特定栏目的订阅用户列表
    columnId?: Integer,
    // 文章ID参数，用于查看特定文章的订阅用户列表  
    articleId?: Integer,
    // 订阅ID参数，用于编辑或查看详情
    subscriptionId?: Integer
);
```

### 验收列表

- **用户订阅管理**
  - **订阅列表展示**
    - 当用户访问用户订阅管理页面时，系统应以表格形式展示用户的订阅列表，表格列应包含：订阅类型（栏目/文章）、订阅对象名称、订阅时间、操作（取消订阅、查看详情）
    - 当管理员访问用户订阅管理页面时，系统应支持按用户、栏目、文章等条件进行筛选查询，并显示所有用户的订阅记录
  - **订阅操作管理**
    - 当用户在订阅列表页面点击添加订阅按钮时，系统应显示订阅表单，支持选择要订阅的栏目或文章，并保存订阅关系
    - 当用户在订阅列表中选择某个订阅记录并点击取消订阅按钮时，系统应直接删除该订阅关系，删除前应显示确认对话框
    - 当用户订阅的栏目有新文章发布或已订阅的文章有更新时，系统应自动向用户发送通知提醒

### 交互操作

- **查看订阅列表**：用户进入用户订阅页面后，系统根据当前用户ID自动加载并展示该用户的订阅列表，以表格形式呈现，包含订阅类型、订阅对象、订阅时间等信息，并提供分页功能
- **添加新订阅**：用户点击"添加订阅"按钮后，系统弹出订阅表单，用户可以选择要订阅的栏目（从栏目下拉列表中选择）或文章（从文章下拉列表中选择），填写完成后点击保存，系统创建新的订阅关系并刷新列表
- **取消订阅**：用户在订阅列表中找到要取消的订阅记录，点击"取消订阅"按钮，系统弹出确认对话框，用户确认后系统删除该订阅关系并从列表中移除对应记录
- **按条件筛选**：管理员可以在页面顶部的筛选区域输入用户名称、栏目名称或文章标题等关键词，点击查询按钮后系统根据条件过滤并显示匹配的订阅记录
- **查看详情**：用户点击订阅记录的"查看详情"链接，系统跳转到对应的栏目页面或文章详情页面，方便用户快速访问订阅的内容

### 依赖的服务端逻辑

- **领域服务-逻辑-获取用户订阅列表**：[内容管理-获取用户订阅（getUserSubscriptions）](specs/001-bootdo-management-system/plan/backend/logic-getUserSubscriptions.md)
- **领域服务-逻辑-创建用户订阅**：[办公自动化-创建用户订阅（createUserSubscription）](specs/001-bootdo-management-system/plan/backend/logic-createUserSubscription.md)
- **领域服务-逻辑-删除用户订阅**：[内容管理-删除用户订阅（deleteUserSubscription）](specs/001-bootdo-management-system/plan/backend/logic-deleteUserSubscription.md)
- **领域服务-逻辑-获取可订阅栏目列表**：[内容管理-获取可订阅栏目（getAvailableColumnsForSubscription）](specs/001-bootdo-management-system/plan/backend/logic-getAvailableColumnsForSubscription.md)
- **领域服务-逻辑-获取可订阅文章列表**：[内容管理-获取可用于订阅的文章（getAvailableArticlesForSubscription）](specs/001-bootdo-management-system/plan/backend/logic-getAvailableArticlesForSubscription.md)

### 特殊组件

无特殊组件