# 通用业务模块-整改任务分配（rectificationTask）

- **生成时间**：2026-03-25

## 整改任务分配（rectificationTask）

### 功能概述

整改任务分配功能页面是质量管理模块的核心组成部分，专门用于管理质量问题的整改任务分配与跟踪。该页面支持质量管理员对已发现的质量问题进行系统化的整改任务创建、分配和监控。具体功能包括：在整改输入界面填写完整的整改任务信息，包括项目ID、整改描述、提出日期、项目名称、整改分类、部位、机号、是否特检、提出人等详细字段；支持上传相关图片作为整改证据附件；在整改列表界面查看所有整改任务的汇总信息；通过搜索功能快速定位特定的整改任务；执行取消和确认操作来管理任务流程。该页面确保了质量问题整改过程的规范化、可追溯性和高效性，为企业的质量管理体系提供了强有力的数字化支撑。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.qualityManagement.views.rectificationTask.tsx"
$View({
    title: "整改任务分配",
    crumb: "整改任务分配",
    auth: true,
    isIndex: false,
})
export declare function rectificationTask(rectificationTaskId?: Integer, qualityIssueId?: Integer, assigneeId?: Integer, operationCategory?: String);
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| rectificationTaskId | 整改任务ID | Integer | 用于编辑场景的整改任务ID |
| qualityIssueId | 质量问题ID | Integer | 关联的质量问题ID，用于新建整改任务时关联质量问题 |
| assigneeId | 分配用户ID | Integer | 分配给的用户ID |
| operationCategory | 操作类别 | String | 页面操作类别，可选值：'create'、'edit'、'view' |

### 验收列表

- **整改输入数据管理**：
  - **整改输入提交功能**：
    - 质量管理员可以在整改输入管理界面填写整改任务信息
    - 质量管理员可以点击"提交"按钮，提交整改输入表单数据，保存整改任务信息
  - **整改输入表单字段管理**：
    - 整改输入表单包含项目id、备注、整改描述、提出日期、项目名称、请选择整改分类、请输入整改描述、请输入备注、请选择项目工号、项目工号、请选择机号、是否特检、机号、提出人编号、请输入提出人、请输入提出日期、请输入提出人编号、图片、提出人、部位、请选择部位、请输入是否特检、整改分类等字段，质量管理员需要填写这些字段信息
  - **整改输入图片附件管理**：
    - 整改输入表单支持图片附件上传，质量管理员可以在整改输入中上传相关图片作为附件
- **整改列表数据管理**：
  - **整改列表操作功能**：
    - 质量管理员可以在整改列表管理界面查看所有整改任务的列表
    - 质量管理员可以取消当前操作，返回到整改列表管理界面
    - 质量管理员可以确认整改列表操作，完成整改列表的最终确认
  - **整改列表搜索功能**：
    - 质量管理员可以通过搜索按钮搜索特定整改任务，支持按搜索条件进行筛选
  - **整改列表搜索条件管理**：
    - 整改列表表单包含搜索字段，质量管理员可以输入搜索条件进行查询

### 交互操作

- **创建整改任务**：质量管理员在整改输入管理界面填写整改任务的基本信息（包括整改描述、分配人员、截止日期等），上传相关图片附件，点击"提交"按钮保存整改任务。
- **查看整改任务列表**：质量管理员在整改列表管理界面查看所有整改任务的列表。
- **搜索整改任务**：质量管理员在整改列表管理界面的搜索框中输入搜索条件，点击"搜索"按钮，系统根据搜索条件筛选并显示匹配的整改任务列表。
- **取消操作**：质量管理员可以取消当前操作，返回到整改列表管理界面。
- **确认操作**：质量管理员可以确认整改列表操作，完成整改列表的最终确认。

### 依赖的服务端逻辑

- **领域服务-逻辑-查询整改任务列表**：[质量管理-加载整改任务列表（loadRectificationTaskList）](specs/001-bootdo-management-system/plan/backend/logic-loadRectificationTaskList.md)
- **领域服务-逻辑-分配整改任务**：[质量管理-分配整改任务（assignRectificationTask）](specs/001-bootdo-management-system/plan/backend/logic-assignRectificationTask.md)
- **领域服务-逻辑-更新整改进度**：[质量管理-更新整改进度（updateRectificationProgress）](specs/001-bootdo-management-system/plan/backend/logic-updateRectificationProgress.md)

### 特殊组件

无特殊组件