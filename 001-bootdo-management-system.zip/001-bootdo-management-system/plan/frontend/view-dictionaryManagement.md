# 通用业务模块-字典管理（dictionaryManagement）

- **生成时间**：2026-03-25

## 字典管理（dictionaryManagement）

### 功能概述

字典管理功能页面实现数据字典的全生命周期管理，支持系统管理员对各类分类数据和配置项进行统一维护。该页面提供字典类型的分类管理、字典项的增删改查操作，以及字典数据的查询筛选功能。通过标准化的数据字典服务，为整个应用提供一致的数据引用标准，避免各业务模块重复定义相同的数据分类，确保数据使用的准确性和一致性。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.sysAdmin.views.dictionaryManagement.tsx"
$View({
    title: "字典管理",
    crumb: "Dashboard > 系统管理 > 字典管理",
    auth: true,
})
export declare function dictionaryManagement(dictId?: Integer);
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| dictId | 字典项ID | Integer | 可选参数，用于编辑模式下指定要编辑的字典项ID |

### 验收列表

- 支持按字典类型、标签名进行精确查询和模糊搜索
- 支持字典项的新增、编辑、删除操作
- 支持批量删除字典项
- 支持字典数据的分页展示，每页显示10条记录
- 支持字典项的排序功能，按创建时间倒序排列
- 支持导出字典数据为Excel格式
- 支持字典类型的分类管理，同一类型下的字典项可进行批量操作

### 交互操作

- **查询字典数据**：用户可在顶部查询区域输入字典类型或标签名进行筛选，系统实时刷新下方数据表格，支持精确匹配和模糊搜索
- **新增字典项**：点击"新增"按钮，弹出表单对话框，用户填写字典类型、标签名、数据值和描述信息，点击保存后创建新的字典项
- **编辑字典项**：点击数据表格中的"编辑"按钮，弹出表单对话框并自动填充当前字典项信息，用户修改后点击保存更新数据
- **删除单个字典项**：点击数据表格中的"删除"按钮，系统弹出二次确认对话框，用户确认后删除该字典项，并提供5秒内撤销操作的临时窗口
- **批量删除字典项**：用户勾选多个字典项，点击"批量删除"按钮，系统显示选中数量并弹出二次确认对话框，用户确认后批量删除选中的字典项
- **导出字典数据**：点击"导出Excel"按钮，系统将当前查询条件下的所有字典数据导出为Excel文件
- **查看字典详情**：点击数据表格中的字典项，系统在右侧以卡片式布局展示该字典项的详细信息，包括创建时间、更新时间等元数据
- **返回字典列表**：在详情页面点击"返回列表"按钮，系统返回到字典管理主页面

### 依赖的服务端逻辑

- **领域服务-逻辑-查询字典列表**：[系统管理-查询字典列表（queryDictionaryList）](specs/001-bootdo-management-system/plan/backend/logic-queryDictionaryList.md)
- **领域服务-逻辑-保存字典项**：[系统管理-保存字典项（saveDictionaryItem）](specs/001-bootdo-management-system/plan/backend/logic-saveDictionaryItem.md)
- **领域服务-逻辑-删除字典项**：[系统管理-删除字典项（deleteDictionaryItem）](specs/001-bootdo-management-system/plan/backend/logic-deleteDictionaryItem.md)
- **领域服务-逻辑-导出字典数据**：[通用领域服务-导出数据字典（exportDictionaryData）](specs/001-bootdo-management-system/plan/backend/logic-exportDictionaryData.md)

### 特殊组件

无特殊组件