# 通用业务模块-税务计算（taxCalculation）

- **生成时间**：2026-03-25

## 税务计算（taxCalculation）

### 功能概述

税务计算功能是薪资管理模块的核心组成部分，专门用于个人所得税的自动化计算。该功能基于国家最新的个人所得税法规定，支持累计预扣法计算个人所得税，能够准确处理工资薪金所得、专项附加扣除、社保公积金扣除等各项税务要素。系统会根据员工的基本信息、薪资结构、专项附加扣除申报情况以及当地社保公积金缴纳标准，自动计算每月应缴纳的个人所得税金额，并生成详细的税务计算明细和汇总报表，确保企业薪资发放的税务合规性和准确性。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.salaryManagement.views.taxCalculation.tsx"
$View({
    title: "税务计算",
    crumb: "税务计算",
    auth: true,
    isIndex: false,
})
export declare function taxCalculation(employeeId?: Integer, taxYear?: Integer, month?: Integer, departmentId?: Integer);
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| employeeId | 员工ID | Integer? | 用于查看特定员工的税务计算详情 |
| taxYear | 年份 | Integer? | 用于查询指定年份的税务计算数据 |
| month | 月份 | Integer? | 用于查询指定月份的税务计算数据 |
| departmentId | 部门ID | Integer? | 用于按部门筛选税务计算数据 |

### 验收列表

- **个人所得税自动计算**：个人所得税自动计算
  - **税务计算准确性**：税务计算准确性
    - 当系统计算个人所得税时，必须严格按照国家税务总局发布的最新个人所得税法规定执行，包括起征点、税率表、速算扣除数等参数
    - 当系统计算个人所得税时，必须正确应用累计预扣法，确保每月税额计算的连续性和准确性
    - 当系统计算个人所得税时，必须正确处理各项扣除项目，包括基本减除费用（5000元/月）、专项扣除（社保公积金）、专项附加扣除（子女教育、继续教育、大病医疗、住房贷款利息、住房租金、赡养老人）等
  - **数据输入验证**：数据输入验证
    - 当用户输入员工薪资数据时，系统必须验证薪资金额的格式和范围，确保为正数且不超过系统设定的最大值
    - 当用户输入专项附加扣除信息时，系统必须验证扣除项目的合法性和金额范围，确保符合国家规定的扣除标准
    - 当用户输入社保公积金缴纳基数时，系统必须验证基数是否在当地规定的上下限范围内
  - **计算结果展示**：计算结果展示
    - 当税务计算完成后，系统必须以清晰的表格形式展示每位员工的税务计算明细，包括税前工资、各项扣除、应纳税所得额、适用税率、应纳税额等关键信息
    - 当税务计算完成后，系统必须提供税务计算汇总信息，包括总税额、平均税率、最高最低税额等统计指标
    - 当用户查看特定员工的税务计算详情时，系统必须显示该员工全年的税务计算历史记录和累计数据

### 交互操作

- **查看税务计算列表**：用户可以查看指定月份或年份的所有员工税务计算结果列表，支持按部门、岗位等条件进行筛选和排序
- **查看员工税务详情**：用户可以点击列表中的任意员工，查看该员工详细的税务计算过程和历史记录，包括每月的累计预扣计算明细
- **导出税务计算报表**：用户可以将当前查询结果导出为Excel格式的税务计算报表，包含详细的计算公式和参数说明，便于财务审核和税务申报
- **批量重新计算**：当税率政策或扣除标准发生变化时，用户可以对指定时间段内的所有员工税务数据进行批量重新计算，确保数据的准确性和合规性
- **打印税务计算单**：用户可以打印单个员工或批量员工的税务计算单，用于薪资发放通知或员工查询
- **系统内部跳转**：用户可以从税务计算页面跳转到薪资结构定义页面（[通用业务模块-薪资结构定义（salaryStructure）](specs/001-bootdo-management-system/plan/frontend/view-salaryStructure.md)）查看或修改薪资结构，也可以跳转到专项附加扣除管理页面进行扣除信息维护

### 依赖的服务端逻辑

- **领域服务-逻辑-计算个人所得税**：[薪资管理-计算个人所得税（calculatePersonalIncomeTax）](specs/001-bootdo-management-system/plan/backend/logic-calculatePersonalIncomeTax.md)
- **领域服务-逻辑-获取税务计算明细**：[薪资管理-获取税务计算明细（getTaxCalculationDetails）](specs/001-bootdo-management-system/plan/backend/logic-getTaxCalculationDetails.md)
- **领域服务-逻辑-批量重新计算税务**：[通用领域服务-批量重新计算税务（batchRecalculateTax）](specs/001-bootdo-management-system/plan/backend/logic-batchRecalculateTax.md)
- **领域服务-逻辑-导出税务计算报表**：[薪资管理-导出税务计算报表（exportTaxCalculationReport）](specs/001-bootdo-management-system/plan/backend/logic-exportTaxCalculationReport.md)

### 特殊组件

无特殊组件。税务计算功能页面使用标准用户界面组件库中的图表组件（CwChartJs）实现所有税务数据可视化功能，无需使用业务定制的特殊组件。