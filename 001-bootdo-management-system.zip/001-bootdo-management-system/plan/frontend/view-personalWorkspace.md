# 通用业务模块-个人门户（personalWorkspace）

- **生成时间**：2026-03-25

## 个人门户（personalWorkspace）

### 功能概述

个人门户功能为用户提供个性化的专属工作环境，支持用户根据自身工作习惯和业务需求定制工作台界面。该功能允许用户配置模块布局、设置常用功能的快捷入口、查看关键业务数据的统计摘要，并支持个性化提醒和通知设置。系统会根据用户的部门角色和权限范围，动态调整可配置的布局选项和快捷入口内容，确保个性化配置与权限控制的一致性。通过个人门户，用户可以快速访问高频使用的功能模块，提升日常工作效率和使用体验。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.officeAutomation.views.personalWorkspace.tsx"
$View({
    title: "个人门户",
    crumb: "个人门户",
    auth: true,
    isIndex: false,
})
export declare function personalWorkspace(userId?: Integer);
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| userId | 用户ID | Integer | 当前用户的ID标识，用于加载对应的个人工作台配置 |

### 验收列表

- **个性化工作台配置**：用户可以在个人门户页面自定义工作台的模块布局，包括模块的位置、大小和显示/隐藏状态
- **快捷入口设置**：用户可以配置常用功能的快捷入口，快速跳转到相关业务页面
- **数据统计展示**：个人门户页面能够展示用户相关的业务数据统计摘要，如待办任务数量、未读消息数、近期会议安排等
- **个性化提醒**：系统支持用户设置个性化提醒和通知，确保重要信息及时传达

### 交互操作

- **配置个性化布局**：用户可以通过拖拽、点击等方式自定义工作台的模块布局，系统实时保存布局配置并应用到当前视图
- **管理快捷入口**：用户可以添加、删除或重新排序快捷入口，选择需要快速访问的功能模块，系统根据用户权限动态过滤可选功能
- **查看业务数据统计**：个人门户自动聚合展示用户相关的业务数据统计，包括待办任务、未读消息、日程安排等关键指标
- **设置个性化提醒**：用户可以配置各类业务提醒的开启/关闭状态和通知方式，系统根据配置推送相应的提醒信息
- **重置默认配置**：提供重置按钮，允许用户将个人门户恢复到系统默认配置，清除所有自定义设置
- **跨设备同步配置**：用户的个人门户配置在不同设备间自动同步，确保一致的工作体验

### 依赖的服务端逻辑

- **领域服务-逻辑-保存个人工作台布局配置**：[办公自动化-保存个人工作台布局配置（savePersonalWorkspaceLayout）](specs/001-bootdo-management-system/plan/backend/logic-savePersonalWorkspaceLayout.md)
- **领域服务-逻辑-获取个人工作台数据**：[通用领域服务-获取个人工作台数据（getPersonalWorkspaceData）](specs/001-bootdo-management-system/plan/backend/logic-getPersonalWorkspaceData.md)
- **领域服务-逻辑-重置个人工作台配置**：[办公自动化-重置个人工作台配置（resetPersonalWorkspaceConfig）](specs/001-bootdo-management-system/plan/backend/logic-resetPersonalWorkspaceConfig.md)

### 特殊组件

无特殊组件。个人门户功能页面使用UI组件库中的标准布局组件（ElFlex、ElCard等）和表单组件（ElSelect、ElCheckbox等）实现所有个性化配置和数据展示功能，无需使用业务定制的特殊组件。