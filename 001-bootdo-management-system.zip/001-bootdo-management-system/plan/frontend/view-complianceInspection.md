# 通用业务模块-合规检查（complianceInspection）

- **生成时间**：2026-03-25

## 合规检查（complianceInspection）

### 功能概述

合规检查功能页面用于管理环保法规的合规检查工作，支持环保管理人员对各项环保法规执行情况进行系统性检查和记录。页面提供合规检查的创建、编辑、删除和列表查询功能，支持按检查员、检查时间、合规状态等条件进行筛选。检查结果包括详细的检查发现描述和合规状态（合规、不合规、整改中、已整改），对于不合规项可关联整改措施进行跟踪处理。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.environmentalManagement.views.complianceInspection.tsx"
$View({
    title: "合规检查",
    crumb: "合规检查",
    auth: true,
    authDescription: "环保法规合规检查",
    isIndex: false,
})
export declare function complianceInspection();
```

无输入参数。

### 验收列表

- 系统应以分页表格展示合规检查列表，包含检查员、检查发现、合规状态、检查时间等字段，支持按检查员、检查时间范围、合规状态筛选【实体-合规检查（ComplianceInspection）】
- 系统应通过表单弹框支持创建合规检查，包含检查员（必填）、检查发现（必填）、合规状态（必填）、检查时间（必填）等字段【实体-合规检查（ComplianceInspection）】
- 系统应通过表单弹框支持编辑合规检查，预填充当前数据并允许修改所有字段【实体-合规检查（ComplianceInspection）】
- 系统应支持删除合规检查，删除前需二次确认，删除成功后刷新列表【实体-合规检查（ComplianceInspection）】
- 对于不合规或整改中的检查项，系统应提供关联整改措施的功能入口，点击后跳转到整改措施页面【实体-整改措施（RectificationMeasure）】

### 交互操作

- **创建合规检查**：点击"新增"按钮，弹出表单弹框，用户填写检查员、检查发现、合规状态、检查时间等必填信息，提交后保存合规检查记录并刷新列表
- **编辑合规检查**：在列表中点击某条记录的"编辑"按钮，弹出表单弹框并预填充当前数据，用户修改后提交更新并刷新列表
- **删除合规检查**：在列表中点击某条记录的"删除"按钮，弹出二次确认对话框，确认后删除该合规检查记录并刷新列表
- **查询合规检查**：在顶部查询区域输入检查员姓名、选择检查时间范围、选择合规状态等条件，点击"查询"按钮筛选显示符合条件的合规检查列表
- **重置查询条件**：点击"重置"按钮清空所有查询条件，恢复显示全部合规检查列表
- **关联整改措施**：对于合规状态为"不合规"或"整改中"的检查项，在操作列显示"关联措施"按钮，点击后跳转到整改措施页面并自动带入当前检查ID参数

### 依赖的服务端逻辑

- **领域服务-逻辑-获取合规检查列表**：[环保管理-获取合规检查列表（getComplianceInspectionList）](specs/001-bootdo-management-system/plan/backend/logic-getComplianceInspectionList.md)
- **领域服务-逻辑-创建合规检查**：[环保管理-创建合规检查（createComplianceInspection）](specs/001-bootdo-management-system/plan/backend/logic-createComplianceInspection.md)
- **领域服务-逻辑-更新合规检查**：[环保管理-更新合规检查（updateComplianceInspection）](specs/001-bootdo-management-system/plan/backend/logic-updateComplianceInspection.md)
- **领域服务-逻辑-删除合规检查**：[环保管理-删除合规检查（deleteComplianceInspection）](specs/001-bootdo-management-system/plan/backend/logic-deleteComplianceInspection.md)
- **领域服务-逻辑-获取检查员列表**：[环保管理-获取检查员列表（getInspectorList）](specs/001-bootdo-management-system/plan/backend/logic-getInspectorList.md)

### 特殊组件

无特殊组件。