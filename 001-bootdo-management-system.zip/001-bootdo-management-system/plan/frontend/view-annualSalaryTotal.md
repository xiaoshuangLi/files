# 通用业务模块-年薪总额计算（annualSalaryTotal）

- **生成时间**：2026-03-25

## 年薪总额计算（annualSalaryTotal）

### 功能概述

年薪总额计算功能页面用于管理和展示员工的年度薪酬总额数据，支持人力资源部门对员工年度薪资进行统计、计算和分析。该页面提供年薪总额记录的创建、查询、编辑和删除功能，确保薪资数据的准确性和完整性。用户可以通过该页面查看特定员工在指定年份的薪酬总额，包括基本工资、奖金、津贴等各项收入的汇总计算结果，并支持导出报表用于财务分析和决策支持。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.salaryManagement.views.annualSalaryTotal.tsx"
$View({
    title: "年薪总额计算",
    crumb: "年薪总额计算",
    auth: true,
    authDescription: "年薪总额计算",
})
export declare function annualSalaryTotal(
  employeeId?: Integer,
  fiscalYear?: Integer
);
```

### 验收列表

无验收列表

### 交互操作

- **查询年薪总额列表**：用户可以在页面顶部输入查询条件（如员工ID、年份等），点击查询按钮后系统显示符合条件的年薪总额记录列表，支持分页浏览。
- **查看年薪总额详情**：用户点击列表中的某条年薪总额记录，系统跳转到详情页面展示该记录的完整信息，包括员工ID、总额、年份和计算时间。
- **新增年薪总额记录**：用户点击"新增"按钮，系统弹出表单供用户填写员工ID、年份和总额等信息，提交后系统保存新记录并刷新列表。
- **编辑年薪总额记录**：用户点击列表中的"编辑"按钮，系统加载对应记录的数据到表单中，用户修改后提交更新，系统保存修改并刷新列表。
- **删除年薪总额记录**：用户点击列表中的"删除"按钮，系统弹出确认对话框，用户确认后系统删除该记录并刷新列表。
- **导出年薪总额报表**：用户点击"导出"按钮，系统根据当前查询条件生成Excel格式的年薪总额报表并下载到本地。

### 依赖的服务端逻辑

- **领域服务-逻辑-计算年薪总额**：[薪资管理-计算年薪总额（calculateAnnualSalaryTotal）](specs/001-bootdo-management-system/plan/backend/logic-calculateAnnualSalaryTotal.md)
- **领域服务-逻辑-查询年薪总额列表**：[薪资管理-查询年薪总额列表（queryAnnualSalaryTotalList）](specs/001-bootdo-management-system/plan/backend/logic-queryAnnualSalaryTotalList.md)

### 特殊组件

无特殊组件