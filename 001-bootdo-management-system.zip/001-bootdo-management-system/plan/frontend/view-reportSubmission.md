# 通用业务模块-报告提交（reportSubmission）

- **生成时间**：2026-03-25

## 报告提交（reportSubmission）

### 功能概述

报告提交功能是环保管理模块的核心业务功能之一，专注于企业环境报告的定期提交管理。该功能支持月度环境报告、季度环境报告、年度环境报告等不同类型报告的全生命周期管理，包括报告模板管理、数据填报、审核审批和提交归档等完整流程。系统提供标准化的报告格式配置，确保环境报告符合环保法规要求；支持多级审核审批流程，保障报告数据的准确性和合规性；实现报告提交状态的实时跟踪，便于企业及时履行环保责任。通过该功能，企业能够高效完成环境报告的编制和提交工作，降低合规风险，提升环境管理水平，满足环保监管部门的数据报送要求。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.environmentalManagement.views.reportSubmission.tsx"
$View({
    title: "报告提交",
    crumb: "报告提交",
    auth: true,
    isIndex: false,
})
export declare function reportSubmission(reportId?: Integer, reportType?: Text);
```

### 验收列表

- **环保管理核心业务功能**：环境问题整改管理
  - 系统支持环境报告定期提交功能，包括月度环境报告、季度环境报告、年度环境报告等不同类型报告的模板管理、数据填报、审核审批和提交归档

### 交互操作

- **提交环境报告** 用户可以填写环境报告内容，选择报告类型（月度、季度、年度），点击提交按钮将报告提交到系统，系统会记录提交人、提交时间和报告内容
- **查看报告详情** 用户可以点击报告列表中的报告条目，查看已提交报告的详细内容，包括报告类型、报告内容、提交人、提交时间和批准状态
- **删除报告** 用户可以对未批准的报告执行删除操作，系统会弹出确认对话框，确认后删除该报告记录
- **取消操作** 用户在报告编辑页面可以点击取消按钮，返回报告列表页面，不保存任何更改

### 依赖的服务端逻辑

- **领域服务-逻辑-提交环境报告**：[环保管理-提交环境报告（submitEnvironmentalReport）](specs/001-bootdo-management-system/plan/backend/logic-submitEnvironmentalReport.md)
- **领域服务-逻辑-获取环境报告列表**：[环保管理-获取环境报告列表（getEnvironmentalReportList）](specs/001-bootdo-management-system/plan/backend/logic-getEnvironmentalReportList.md)
- **领域服务-逻辑-删除环境报告**：[环保管理-删除环境监测报告（deleteEnvironmentalReport）](specs/001-bootdo-management-system/plan/backend/logic-deleteEnvironmentalReport.md)
- **领域服务-逻辑-获取环境报告详情**：[环保管理-获取环境报告详情（getEnvironmentalReportDetail）](specs/001-bootdo-management-system/plan/backend/logic-getEnvironmentalReportDetail.md)