# 通用业务模块-Dashboard（dashboard）

- **生成时间**：2026-03-25

## Dashboard（dashboard）

### 功能概述

Dashboard页面作为系统的核心布局容器，提供统一的用户界面框架和导航结构。该页面实现了经典的上-左-右布局模式，包含顶部导航区、左侧主菜单栏和右侧主内容区三个核心区域。顶部导航区展示系统Logo、用户头像下拉菜单（包含个人信息、修改密码、切换语言、退出登录等功能）、消息通知中心和系统设置入口；左侧主菜单栏根据用户权限动态加载P0和P1优先级的功能模块菜单，支持菜单项的折叠/展开操作；右侧主内容区用于加载和展示当前选中的功能页面内容，并包含面包屑导航以显示当前位置。Dashboard页面还负责处理用户的认证状态验证、权限控制和全局配置加载，确保用户只能访问其有权限的功能模块。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.tsx"
$View({
    title: "Dashboard",
    crumb: "Dashboard",
    auth: true,
    isIndex: true,
})
export declare function dashboard(userId: Integer, userRoleIds: List<Integer>, isAuthenticated: Boolean, globalConfig: GlobalConfiguration);
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| userId | 用户ID | Integer | 当前登录用户的唯一标识 |
| userRoleIds | 用户角色ID列表 | List<Integer> | 当前用户拥有的所有角色ID列表 |
| isAuthenticated | 认证状态 | Boolean | 用户是否已通过身份认证 |
| globalConfig | 全局配置 | GlobalConfiguration | 系统的全局配置信息 |

### 验收列表

- 支持根据用户权限动态加载和展示对应的功能菜单项
- 支持菜单项的折叠/展开操作，提升大屏和小屏设备的用户体验
- 支持在主内容区正确加载和渲染所选菜单对应的功能页面
- 支持显示面包屑导航，清晰展示用户当前位置
- 支持显示未读消息数量，提供消息通知中心入口
- 支持用户头像下拉菜单，包含个人信息、修改密码、切换语言、退出登录等功能
- 支持响应式布局，在PC端为主的前提下兼顾平板设备的基本浏览体验

### 交互操作

- **菜单导航操作** 用户点击左侧主菜单栏中的任意菜单项时，系统在右侧主内容区加载并展示对应的页面内容，同时更新面包屑导航显示当前位置路径
- **菜单折叠/展开操作** 用户点击菜单折叠/展开按钮时，系统切换左侧菜单栏的显示状态，在紧凑模式和完整模式之间切换，优化不同屏幕尺寸下的空间利用
- **用户信息操作** 用户点击顶部导航区的用户头像时，系统显示下拉菜单，包含个人信息查看、密码修改、语言切换和退出登录等选项
- **消息通知操作** 用户点击顶部导航区的消息通知图标时，系统显示未读消息列表，支持标记已读和跳转到消息详情页面
- **系统设置操作** 用户点击顶部导航区的系统设置入口时，系统跳转到系统参数配置页面，允许用户管理全局系统配置
- **面包屑导航操作** 用户点击面包屑导航中的任意层级时，系统跳转到对应层级的页面，实现快速导航返回

### 依赖的服务端逻辑

- **领域服务-逻辑-获取用户菜单权限**：[权限中心-获取用户菜单权限（getUserMenuPermissions）](specs/001-bootdo-management-system/plan/backend/logic-getUserMenuPermissions.md)
- **领域服务-逻辑-获取全局系统配置**：[通用领域服务-获取全局系统配置（getGlobalSystemConfiguration）](specs/001-bootdo-management-system/plan/backend/logic-getGlobalSystemConfiguration.md)
- **领域服务-逻辑-获取用户未读消息数量**：[通用领域服务-获取用户未读消息数量（getUserUnreadMessageCount）](specs/001-bootdo-management-system/plan/backend/logic-getUserUnreadMessageCount.md)

### 特殊组件

无特殊组件