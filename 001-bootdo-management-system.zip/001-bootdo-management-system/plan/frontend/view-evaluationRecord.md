# 通用业务模块-评估记录（evaluationRecord）

- **生成时间**：2026-03-25

## 评估记录（evaluationRecord）

### 功能概述

评估记录功能页面用于管理分包商的绩效评估结果，包括记录评估分数、评估意见和评估时间等信息。该页面支持对分包商进行定期或不定期的绩效评估，帮助企业全面了解分包商的服务质量和合作表现，为后续的合作决策提供数据支持。用户可以在该页面查看所有分包商的历史评估记录，进行新增、编辑和删除操作，并能根据分包商、评估人、评估时间等条件进行筛选查询。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.subcontractorManagement.views.evaluationRecord.tsx"
$View({
    title: "评估记录",
    crumb: "评估记录",
    auth: true,
    isIndex: false,
})
export declare function evaluationRecord(subcontractorId?: Integer);
```

### 验收列表

- 支持查看分包商的绩效评估记录列表
- 支持按分包商、评估人、评估时间范围进行筛选查询
- 支持新增分包商绩效评估记录
- 支持编辑已有的评估记录
- 支持删除不需要的评估记录
- 评估记录必须包含绩效评分、评估意见和评估时间
- 支持导出评估记录为Excel格式

### 交互操作

- **查看评估记录列表**：加载并展示所有分包商的绩效评估记录，支持分页显示
- **筛选查询评估记录**：根据分包商名称、评估人姓名、评估时间范围等条件筛选评估记录
- **新增评估记录**：点击新增按钮，打开评估记录表单，填写分包商、评估人、绩效评分、评估意见等信息后保存
- **编辑评估记录**：点击编辑按钮，加载现有评估记录数据到表单中，修改后保存更新
- **删除评估记录**：点击删除按钮，弹出确认对话框，确认后删除对应的评估记录
- **导出评估记录**：点击导出按钮，将当前筛选条件下的评估记录导出为Excel文件
- **查看分包商详情**：点击分包商名称，系统内部跳转到通用业务模块-分包商信息维护（subcontractorInformation）页面
- **查看评估人详情**：点击评估人姓名，系统内部跳转到权限中心-用户管理（userManagement）页面

### 依赖的服务端逻辑

- **领域服务-逻辑-获取分包商评估记录列表**：[分包商管理-获取分包商评估记录（getSubcontractorEvaluationRecords）](specs/001-bootdo-management-system/plan/backend/logic-getSubcontractorEvaluationRecords.md)
- **领域服务-逻辑-创建分包商评估记录**：[分包商管理-创建分包商评估记录（createSubcontractorEvaluationRecord）](specs/001-bootdo-management-system/plan/backend/logic-createSubcontractorEvaluationRecord.md)
- **领域服务-逻辑-更新分包商评估记录**：[分包商管理-更新分包商评估记录（updateSubcontractorEvaluationRecord）](specs/001-bootdo-management-system/plan/backend/logic-updateSubcontractorEvaluationRecord.md)
- **领域服务-逻辑-删除分包商评估记录**：[分包商管理-删除分包商评估记录（deleteSubcontractorEvaluationRecord）](specs/001-bootdo-management-system/plan/backend/logic-deleteSubcontractorEvaluationRecord.md)
- **领域服务-逻辑-导出分包商评估记录**：[分包商管理-导出分包商评估记录（exportSubcontractorEvaluationRecords）](specs/001-bootdo-management-system/plan/backend/logic-exportSubcontractorEvaluationRecords.md)

### 特殊组件

无特殊组件