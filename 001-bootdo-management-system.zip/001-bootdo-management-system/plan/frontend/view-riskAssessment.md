# 通用业务模块-风险评估（riskAssessment）

- **生成时间**：2026-03-25

## 风险评估（riskAssessment）

### 功能概述

风险评估功能是企业管理系统中的重要业务功能，专门用于各类风险的系统化分析和管理。该功能支持环境风险和分包商风险的全面识别、风险等级的科学评估、风险防控措施的制定以及风险监控预警机制的建立。通过该功能，企业能够主动识别潜在的风险点，如污染物超标排放、危险废物处理不当、环保设施运行异常、分包商资质问题、合作合规风险等，并根据风险的严重程度和发生概率进行等级划分。系统提供标准化的风险评估流程，支持风险因素的量化分析，帮助企业制定针对性的防控措施，并建立实时监控预警机制，确保各类风险得到及时发现和有效控制，从而降低事故发生的可能性，保障企业生产经营活动的合规性和安全性。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.subcontractorManagement.views.riskAssessment.tsx"
$View({
    title: "风险评估",
    crumb: "风险评估",
    auth: true,
    isIndex: false,
})
export declare function riskAssessment(enterpriseId?: String, riskAssessmentId?: String, assessmentType?: String);
```

### 验收列表

- **环境风险评估分析功能**
  - **风险识别与评估类别**
    - 系统支持环境风险识别功能，包括污染物排放风险、危险废物处理风险、环保设施运行风险、环境合规风险等多维度风险点的识别
    - 系统支持风险等级评估功能，根据风险的严重程度和发生概率进行量化评分，并自动划分风险等级（高、中、低）
    - 系统支持风险防控措施制定功能，针对识别出的风险点提供标准化的防控措施建议，并支持自定义防控方案
    - 系统支持风险监控预警功能，对高风险和中风险项目设置监控指标和预警阈值，当指标超过阈值时自动触发预警通知

### 交互操作

- **查看风险评估列表**：用户可以在风险评估页面查看所有环境风险评估记录的列表，支持按企业、评估时间、风险等级等条件进行筛选和查询
- **创建新的风险评估**：用户可以点击"新建评估"按钮，进入风险评估表单页面，填写风险识别信息、评估参数、防控措施等内容，完成新的风险评估创建
- **编辑风险评估记录**：用户可以选择已有的风险评估记录，点击"编辑"按钮修改评估内容、更新风险等级或调整防控措施
- **删除风险评估记录**：用户可以选择不再需要的风险评估记录，点击"删除"按钮将其从系统中移除，系统会提示确认删除操作
- **查看风险评估详情**：用户可以点击风险评估记录，查看完整的风险评估详情，包括风险识别结果、评估过程、等级划分依据、防控措施详情等
- **导出风险评估报告**：用户可以点击"导出"按钮，将当前显示的风险评估数据导出为PDF或Excel格式的报告文件，便于存档和分享
- **设置风险监控预警**：用户可以在风险评估详情页面配置监控指标和预警阈值，系统将根据设置进行实时监控并在触发预警时发送通知

### 依赖的服务端逻辑

- **领域服务-逻辑-环境风险评估分析**：[环保管理-环境风险评估分析（environmentalRiskAssessmentAnalysis）](specs/001-bootdo-management-system/plan/backend/logic-environmentalRiskAssessmentAnalysis.md)
- **领域服务-逻辑-风险等级评估计算**：[通用领域服务-风险等级评估计算（riskLevelAssessmentCalculation）](specs/001-bootdo-management-system/plan/backend/logic-riskLevelAssessmentCalculation.md)
- **领域服务-逻辑-风险监控预警配置**：[通用领域服务-风险监控告警配置（riskMonitoringAlertConfiguration）](specs/001-bootdo-management-system/plan/backend/logic-riskMonitoringAlertConfiguration.md)

### 特殊组件

无特殊组件。风险评估功能页面使用标准用户界面组件库中的图表组件（CwChartJs）实现风险评估矩阵图等数据可视化功能，无需使用业务定制的特殊组件。