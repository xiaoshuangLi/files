# 通用业务模块-流程定义（processDefinition）

- **生成时间**：2026-03-25

## 流程定义（processDefinition）

### 功能概述

流程定义功能提供工作流模型的全生命周期管理能力，支持系统管理员对业务流程模板进行可视化设计、创建、编辑、删除和查询操作。该功能基于Activiti标准实现，允许用户通过图形化界面定义复杂的业务流程，包括流程节点、流转条件、任务分配等核心要素。管理员可以创建新的流程模型、导入现有的BPMN文件、查看流程列表、编辑流程属性，并对不再需要的流程模型进行删除操作。流程定义作为工作流引擎的基础，为后续的流程实例化和执行提供标准化的模板支撑，确保企业各类审批和业务流程能够按照预设规则自动化执行。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.workflowEngine.views.processDefinition.tsx"
$Page({
    title: "流程定义",
    crumb: "流程定义",
    auth: true,
    isIndex: true,
})
export declare function processDefinition();
```

无输入参数。

### 验收列表

- **工作流模型管理**：
  - **数据展示**：系统管理员角色可以查看工作流模型列表，列表以表格形式展示
  - **用户操作**：系统管理员角色可以在工作流模型列表中点击删除按钮，系统将直接删除选中的工作流模型记录，删除前需要确认操作；系统管理员角色可以在工作流模型列表中点击导入按钮，系统将按照Web应用通用交互标准执行文件导入操作，支持工作流模型的批量导入；系统管理员角色可以在工作流模型列表中点击查询按钮，系统将触发搜索功能，根据输入的查询条件筛选工作流模型记录；系统管理员角色可以在工作流模型列表中点击添加按钮，系统将新页面打开工作流模型添加界面，允许管理员创建新的工作流模型

### 交互操作

- **查看流程定义列表**：系统管理员可以查看所有已定义的工作流模型列表，列表以表格形式展示流程名称、描述、创建时间和更新时间等基本信息，支持分页和排序功能。
- **添加新流程定义**：系统管理员点击添加按钮后，系统跳转到新建流程定义页面，提供流程名称、描述和BPMN设计器等配置项，管理员完成配置后可保存创建新的流程模型。
- **编辑流程定义**：系统管理员在流程列表中选择特定流程模型，点击编辑按钮后跳转到编辑页面，可以修改流程的基本信息和BPMN定义，保存后更新现有流程模型。
- **删除流程定义**：系统管理员在流程列表中选择一个或多个流程模型，点击删除按钮后弹出确认对话框，确认后系统将永久删除选中的流程定义记录。
- **导入流程定义**：系统管理员点击导入按钮后，系统弹出文件选择对话框，支持上传BPMN格式的流程定义文件，导入成功后自动添加到流程列表中。
- **查询流程定义**：系统管理员在搜索框中输入流程名称或描述关键词，点击查询按钮后系统根据输入条件筛选并显示匹配的流程定义列表。

### 依赖的服务端逻辑

- **领域服务-逻辑-获取流程定义列表**：[工作流引擎-获取流程定义列表（getProcessDefinitionList）](specs/001-bootdo-management-system/plan/backend/logic-getProcessDefinitionList.md)
- **领域服务-逻辑-创建流程定义**：[工作流引擎-创建流程定义（createProcessDefinition）](specs/001-bootdo-management-system/plan/backend/logic-createProcessDefinition.md)
- **领域服务-逻辑-更新流程定义**：[工作流引擎-更新流程定义（updateProcessDefinition）](specs/001-bootdo-management-system/plan/backend/logic-updateProcessDefinition.md)
- **领域服务-逻辑-删除流程定义**：[工作流引擎-删除流程定义（deleteProcessDefinition）](specs/001-bootdo-management-system/plan/backend/logic-deleteProcessDefinition.md)
- **领域服务-逻辑-导入流程定义**：[工作流引擎-导入流程定义（importProcessDefinition）](specs/001-bootdo-management-system/plan/backend/logic-importProcessDefinition.md)

### 特殊组件

#### BPMN流程设计器（bpmnModeler）

BPMN流程设计器是一个专业的业务流程建模工具，支持拖拽式节点添加、连线配置、属性编辑等功能。该组件允许用户通过可视化界面创建符合BPMN 2.0标准的流程定义，包括开始事件、结束事件、用户任务、服务任务、网关等各种流程元素，并支持流程验证和导出功能。

- **关联文档**：[特殊组件-BPMN流程设计器（bpmnModeler）](specs/001-bootdo-management-system/plan/dependencies/component-bpmnModeler.md)