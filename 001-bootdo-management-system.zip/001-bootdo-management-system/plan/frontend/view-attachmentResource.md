# 通用业务模块-附件管理（attachmentResource）

- **生成时间**：2026-03-25

## 附件管理（attachmentResource）

### 功能概述

附件管理功能提供内容管理系统中文章关联附件的统一管理能力，支持图片、文档、音视频等各类多媒体文件的上传、存储、查看和删除操作。该功能确保附件资源能够与对应的文章内容建立正确的关联关系，为内容创作者提供便捷的附件管理体验，同时保证附件数据的完整性和一致性。通过附件管理功能，用户可以高效地处理文章相关的所有附件资源，包括上传新附件、查看现有附件详情、下载附件文件以及删除不再需要的附件，从而实现内容与附件的一体化管理。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.contentManagement.views.attachmentResource.tsx"
$View({
    title: "附件管理",
    crumb: "附件管理",
    auth: true,
})
export declare function attachmentResource(
    // 文章ID参数，用于筛选特定文章的附件
    articleId?: Integer
);
```

输出数据结构：
- attachments: AttachmentResourceItem[] - 附件列表
- total: Integer - 总记录数
- currentPage: Integer - 当前页码
- pageSize: Integer - 每页记录数

附件项数据结构 AttachmentResourceItem：
- id: Integer - 附件ID
- fileName: String - 文件名
- filePath: String - 文件路径
- fileType: String - 文件类型
- fileSize: Integer - 文件大小
- uploadedAt: String - 上传时间
- articleId: Integer - 关联文章ID

### 验收列表

- **附件列表管理**：附件展示与搜索
    - 当用户访问附件管理页面时，系统应以表格形式展示所有附件列表，表格列应包含：文件名、文件类型、文件大小、上传时间、所属文章、操作（下载、删除）
    - 当用户在附件列表页面的搜索框中输入文件名关键词并点击查询按钮时，系统应根据文件名进行模糊搜索，并显示匹配的附件记录
- **附件列表管理**：附件操作管理
    - 当系统管理员在附件列表中选择某个附件并点击删除按钮时，系统应直接删除该附件，删除前应显示确认对话框提示删除后将无法恢复，删除成功后从列表中移除该记录
    - 当用户点击附件列表中的下载按钮时，系统应触发文件下载，将对应的附件文件保存到用户本地设备
    - 当用户在附件管理页面点击上传按钮时，系统应打开文件选择对话框，支持常见的文件格式（如jpg、png、pdf、doc、docx等），上传成功后在列表中显示新上传的附件
- **附件上传功能**：文件上传管理
    - 当用户上传附件文件时，系统应支持常见的文件格式（如jpg、png、pdf、doc、docx等），显示文件上传进度，并在上传成功后显示文件名和大小信息
    - 当用户上传附件时，系统应自动关联到当前选中的文章（如果存在articleId参数），或者允许用户选择要关联的文章

### 交互操作

- **附件上传操作**：用户点击上传按钮后，系统打开文件选择对话框，用户选择文件后系统自动上传并关联到指定文章，上传成功后在附件列表中显示新上传的附件信息
- **附件下载操作**：用户点击附件列表中的下载按钮，系统触发文件下载，将对应的附件文件保存到用户本地设备
- **附件删除操作**：用户点击附件列表中的删除按钮，系统显示确认对话框，用户确认后系统删除该附件记录及其物理文件，删除成功后从列表中移除该记录
- **附件搜索操作**：用户在搜索框中输入文件名关键词并点击查询按钮，系统根据关键词在文件名字段中进行模糊搜索，并显示匹配的附件记录
- **附件列表分页操作**：当附件数量较多时，系统自动启用分页功能，用户可以通过分页控件浏览不同页面的附件列表
- **文章关联筛选操作**：当页面接收到articleId参数时，系统自动筛选并只显示该文章关联的附件列表

### 依赖的服务端逻辑

- **领域服务-逻辑-查询附件列表**：[内容管理-查询附件列表（queryAttachmentList）](specs/001-bootdo-management-system/plan/backend/logic-queryAttachmentList.md)
- **领域服务-逻辑-上传附件文件**：[内容管理-上传附件文件（uploadAttachmentFile）](specs/001-bootdo-management-system/plan/backend/logic-uploadAttachmentFile.md)
- **领域服务-逻辑-删除附件文件**：[内容管理-删除附件文件（deleteAttachmentFile）](specs/001-bootdo-management-system/plan/backend/logic-deleteAttachmentFile.md)
- **领域服务-逻辑-下载附件文件**：[内容管理-下载附件文件（downloadAttachmentFile）](specs/001-bootdo-management-system/plan/backend/logic-downloadAttachmentFile.md)

### 特殊组件

无特殊组件。附件管理功能页面使用标准用户界面组件库中的文件上传组件（ElUpload）实现所有附件上传和管理功能，无需使用业务定制的特殊组件。