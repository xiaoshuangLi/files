# 通用业务模块-应急预案（emergencyPlan）

- **生成时间**：2026-03-25

## 应急预案（emergencyPlan）

### 功能概述

应急预案功能页面实现环境事故应急预案的全生命周期管理，包括应急预案的制定、编辑、审核、发布、演练计划安排以及应急响应记录跟踪。系统支持企业根据环保法规要求和实际风险情况，制定针对性的环境事故应急预案，明确应急组织架构、应急程序、资源配置和响应措施。页面提供应急预案模板管理、应急资源清单维护、应急演练计划制定、应急响应记录归档等核心功能，确保企业在发生环境事故时能够快速、有序、有效地开展应急处置工作，最大限度减少环境污染和损失。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.environmentalManagement.views.emergencyPlan.tsx"
$View({
    title: "应急预案",
    crumb: "应急预案",
    auth: true,
    isIndex: false,
})
export declare function emergencyPlan(planId: String, departmentId: String);
```

### 验收列表

- **环保管理核心业务功能**：
  - **环境应急与资源管理**：系统支持环境事故应急预案管理功能，包括应急预案制定、应急资源管理、应急演练计划、应急响应记录等

### 交互操作

- **应急预案制定与编辑**：用户可以在应急预案页面创建新的应急预案或编辑现有预案，填写预案名称、应急程序、最后更新时间等详细信息，并保存到系统中
- **应急预案删除**：用户可以选择已存在的应急预案，通过二次确认对话框删除不需要的预案，系统会验证是否有相关联的应急演练或响应记录
- **应急预案详情查看**：用户可以点击应急预案列表中的任意预案，查看该预案的完整详细信息，包括应急程序全文和关联的应急资源清单
- **应急预案分配到部门**：用户可以将制定好的应急预案分配给指定的组织部门，确保相关部门能够访问和执行相应的应急预案
- **应急演练计划管理**：用户可以在应急预案详情页面管理相关的应急演练计划，包括创建新的演练计划、编辑现有计划和查看演练历史记录
- **应急响应记录跟踪**：用户可以在应急预案详情页面查看和管理历史应急响应记录，跟踪实际应急处置过程和效果评估

### 依赖的服务端逻辑

- **领域服务-逻辑-应急预案管理**：[环保管理-应急预案管理（emergencyPlanManagement）](specs/001-bootdo-management-system/plan/backend/logic-emergencyPlanManagement.md)
- **领域服务-逻辑-应急资源分配**：[环保管理-应急资源分配（emergencyResourceAllocation）](specs/001-bootdo-management-system/plan/backend/logic-emergencyResourceAllocation.md)
- **领域服务-逻辑-应急演练计划管理**：[环保管理-应急演练规划（emergencyDrillPlanning）](specs/001-bootdo-management-system/plan/backend/logic-emergencyDrillPlanning.md)

### 特殊组件

无特殊组件