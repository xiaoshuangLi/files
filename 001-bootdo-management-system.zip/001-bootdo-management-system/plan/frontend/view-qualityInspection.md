# 通用业务模块-质量检验（qualityInspection）

- **生成时间**：2026-03-25

## 质量检验（qualityInspection）

### 功能概述

质量检验页面实现对质量问题的检验功能，支持质量管理员对已登记的质量问题进行检验操作。页面提供检验结果录入、检验员信息记录、检验通过状态设置等功能，确保质量问题处理过程的规范化和可追溯性。质量检验是质量管理流程中的关键环节，连接质量问题登记与整改任务分配，为后续的质量验收提供依据。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.qualityManagement.views.qualityInspection.tsx"
$View({
    title: "质量检验",
    crumb: "质量检验",
    auth: true,
    isIndex: false,
})
export declare function qualityInspection(issueId?: Integer, inspectionId?: Integer);
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| issueId | 关联的质量问题ID | Integer | 用于查看特定问题的检验详情 |
| inspectionId | 检验记录ID | Integer | 用于编辑现有检验记录 |

### 验收列表

- **质量检验数据管理**：
  - **检验数据查看功能**：
    - 质量管理员可以在质量检验页面查看所有质量检验记录的列表，以表格形式展示检验信息
    - 质量管理员可以查看特定质量问题的检验详情，包括检验结果、检验员和检验时间
  - **检验数据录入功能**：
    - 质量管理员可以录入新的质量检验记录，填写检验结果、选择检验员、设置检验通过状态
    - 质量管理员可以保存质量检验数据，完成检验记录的创建
  - **检验数据编辑功能**：
    - 质量管理员可以编辑现有的质量检验记录，修改检验结果和通过状态
    - 质量管理员可以更新质量检验数据，保存修改后的检验信息
  - **检验数据删除功能**：
    - 质量管理员可以直接删除不需要的质量检验记录，删除操作需经过二次确认

### 交互操作

- **查看检验列表**：质量管理员进入质量检验页面后，默认显示所有质量检验记录的列表，以表格形式展示检验ID、关联问题、检验员、检验时间、通过状态等信息
- **查看检验详情**：质量管理员点击列表中的某条检验记录，系统跳转到检验详情页面，显示完整的检验信息包括检验结果描述、检验员信息、检验时间等
- **创建新检验**：质量管理员点击"新建检验"按钮，系统打开检验表单弹框，质量管理员填写检验结果、选择检验员、设置通过状态后点击保存，系统创建新的检验记录
- **编辑检验记录**：质量管理员在检验列表或详情页面点击"编辑"按钮，系统打开检验表单弹框，质量管理员修改检验信息后点击保存，系统更新检验记录
- **删除检验记录**：质量管理员在检验列表中选择一条或多条检验记录，点击"删除"按钮，系统弹出二次确认对话框，确认后删除选中的检验记录
- **筛选检验记录**：质量管理员可以通过顶部筛选条件（如检验员、通过状态、检验时间范围等）筛选检验记录，系统实时更新列表显示
- **导出检验数据**：质量管理员点击"导出"按钮，系统将当前筛选条件下的检验数据导出为Excel文件

### 依赖的服务端逻辑

- **领域服务-逻辑-获取质量检验列表**：[质量管理-获取质量检验列表（getQualityInspectionList）](specs/001-bootdo-management-system/plan/backend/logic-getQualityInspectionList.md)
- **领域服务-逻辑-获取质量检验详情**：[质量管理-获取质量检验详情（getQualityInspectionDetail）](specs/001-bootdo-management-system/plan/backend/logic-getQualityInspectionDetail.md)
- **领域服务-逻辑-创建质量检验记录**：[质量管理-创建质量检验（createQualityInspection）](specs/001-bootdo-management-system/plan/backend/logic-createQualityInspection.md)
- **领域服务-逻辑-更新质量检验记录**：[质量管理](specs/001-bootdo-management-system/plan/backend/logic-updateQualityInspection.md)
- **领域服务-逻辑-删除质量检验记录**：[质量管理-删除质量检验（deleteQualityInspection）](specs/001-bootdo-management-system/plan/backend/logic-deleteQualityInspection.md)

### 特殊组件

无特殊组件