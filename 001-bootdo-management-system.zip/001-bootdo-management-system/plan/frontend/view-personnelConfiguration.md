# 通用业务模块-人员管理（personnelConfiguration）

- **生成时间**：2026-03-25

## 人员管理（personnelConfiguration）

### 功能概述

人员管理功能页面用于维护分包商的人员信息，包括员工姓名、职位、联系信息、雇佣日期等基本信息。该页面支持对分包商人员的增删改查操作，确保分包商人员配置数据的完整性和准确性，为薪资计算、项目分配等后续业务流程提供基础数据支撑。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.subcontractorManagement.views.personnelConfiguration.tsx"
$View({
    title: "人员管理",
    crumb: "人员管理",
    auth: true,
    authDescription: "分包商人员管理",
})
export declare function personnelConfiguration(
  subcontractorId?: SubcontractorInformation.subcontractorId
);
```

页面参数：
- `subcontractorId`：分包商ID（可选），用于关联特定分包商的人员信息

### 验收列表

- 支持分包商人员管理，包括员工姓名、职位、联系信息、雇佣日期、终止日期等字段的维护
- 支持按分包商ID查询对应的人员列表
- 支持人员信息的新增、编辑、删除操作
- 支持人员雇佣状态的有效性验证（终止日期不能早于雇佣日期）

### 交互操作

- **查看人员列表**：根据分包商ID加载并展示该分包商的所有人员信息列表，支持分页显示
- **新增人员**：点击新增按钮打开表单弹框，填写员工姓名、职位、联系信息、雇佣日期等必填信息，提交后保存到系统
- **编辑人员**：点击编辑按钮打开表单弹框，加载现有人员信息进行修改，支持更新所有字段信息
- **删除人员**：点击删除按钮弹出确认对话框，确认后删除指定人员记录
- **日期验证**：在表单提交时自动验证终止日期不能早于雇佣日期，如不符合条件则提示用户修正

### 依赖的服务端逻辑

- **领域服务-逻辑-分包商人员管理**：[分包商管理-分包商人员管理（subcontractorPersonnelManagement）](specs/001-bootdo-management-system/plan/backend/logic-subcontractorPersonnelManagement.md)

### 特殊组件

无特殊组件