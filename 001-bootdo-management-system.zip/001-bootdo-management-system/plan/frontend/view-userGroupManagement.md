# 通用业务模块-用户和组管理（userGroupManagement）

- **生成时间**：2026-03-25

## 用户和组管理（userGroupManagement）

### 功能概述

用户和组管理页面用于管理工作流引擎中的用户分组和团队组织功能，支持批量权限分配和任务分配。该页面提供用户组的增删改查操作，以及为用户组添加或移除成员的功能，确保工作流任务能够高效地分配给合适的团队或个人。通过用户组管理，系统管理员可以简化工作流中任务分配的复杂度，提高审批和处理效率。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.workflowEngine.views.userGroupManagement.tsx"
$View({
    title: "用户和组管理",
    crumb: "用户和组管理",
    auth: true,
    isIndex: false,
})
export declare function userGroupManagement(groupId?: Integer);
```

### 验收列表

- 支持用户组的创建、编辑、删除和查询操作
- 支持为用户组添加和移除成员
- 支持按用户组名称搜索过滤
- 支持分页显示用户组列表
- 支持查看用户组的详细信息和成员列表
- 支持批量选择用户并添加到指定用户组

### 交互操作

- **创建用户组**：点击"新建"按钮打开表单弹框，填写用户组名称和描述后保存，系统验证必填字段并创建新的用户组
- **编辑用户组**：在用户组列表中点击"编辑"按钮，跳转到编辑页面，自动加载用户组详情并填充表单，修改后保存更新
- **删除用户组**：在用户组列表中点击"删除"按钮，弹出二次确认对话框，确认后删除用户组及其关联数据
- **查看用户组详情**：点击用户组名称，系统内部跳转到用户组详情页面，显示用户组基本信息和成员列表
- **添加组成员**：在用户组详情页面点击"添加成员"按钮，打开用户选择弹框，支持搜索和多选用户，确认后将选中用户添加到当前用户组
- **移除组成员**：在用户组成员列表中点击"移除"按钮，弹出确认对话框，确认后将该用户从用户组中移除
- **搜索用户组**：在顶部搜索框输入关键词，系统实时过滤显示匹配的用户组列表
- **分页浏览**：使用分页控件切换用户组列表页面，系统加载对应页码的数据

### 依赖的服务端逻辑

- **领域服务-逻辑-查询用户组列表**：[系统管理-查询用户组列表（queryUserGroups）](specs/001-bootdo-management-system/plan/backend/logic-queryUserGroups.md)
- **领域服务-逻辑-创建用户组**：[通用领域服务-创建用户组（createUserGroup）](specs/001-bootdo-management-system/plan/backend/logic-createUserGroup.md)
- **领域服务-逻辑-更新用户组**：[工作流引擎-更新用户组（updateUserGroup）](specs/001-bootdo-management-system/plan/backend/logic-updateUserGroup.md)
- **领域服务-逻辑-删除用户组**：[工作流引擎-删除用户组（deleteUserGroup）](specs/001-bootdo-management-system/plan/backend/logic-deleteUserGroup.md)
- **领域服务-逻辑-查询用户组成员**：[工作流引擎-查询用户组成员列表（queryUserGroupMembers）](specs/001-bootdo-management-system/plan/backend/logic-queryUserGroupMembers.md)
- **领域服务-逻辑-添加用户组成员**：[系统管理-添加用户组成员（addUserGroupMembers）](specs/001-bootdo-management-system/plan/backend/logic-addUserGroupMembers.md)
- **领域服务-逻辑-移除用户组成员**：[系统管理-移除用户组成员（removeUserGroupMembers）](specs/001-bootdo-management-system/plan/backend/logic-removeUserGroupMembers.md)
- **领域服务-逻辑-查询可添加用户**：[权限中心-查询可用用户（queryAvailableUsers）](specs/001-bootdo-management-system/plan/backend/logic-queryAvailableUsers.md)

### 特殊组件

无特殊组件