# 通用业务模块-文章管理（articleContent）

- **生成时间**：2026-03-25

## 文章管理（articleContent）

### 功能概述

文章管理功能页面实现内容管理系统中的文章草稿审核发布管理，支持文章的创建、编辑、审核、发布、归档等全生命周期管理。用户可以在该页面进行文章内容的撰写、格式化、附件上传、SEO优化配置等操作，并通过工作流引擎实现文章的审核审批流程，确保内容质量和合规性。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.contentManagement.views.articleContent.tsx"
$View({
    title: "文章管理",
    crumb: "文章管理",
    auth: true,
    isIndex: false,
})
export declare function articleContent(articleId?: Integer, columnId?: Integer, status?: ArticleStatusEnum);
```

### 验收列表

无验收列表

### 交互操作

- **创建新文章**：用户点击"新建文章"按钮，在富文本编辑器中撰写文章内容，填写标题，选择所属栏目，可上传附件资源，配置SEO优化参数，保存为草稿状态。
- **编辑文章**：用户在文章列表中点击某篇文章的"编辑"按钮，系统根据文章ID加载文章详情并填充到编辑表单中，用户可修改文章内容、附件、SEO参数等信息。
- **提交审核**：用户在文章编辑页面点击"提交审核"按钮，将文章状态从草稿变更为待审核，触发工作流引擎的审核流程。
- **审核文章**：具有审核权限的用户在待审核文章列表中点击"审核"按钮，可查看文章内容并决定批准发布或驳回修改。
- **发布文章**：审核通过后，文章状态自动变更为已发布，文章内容对外公开可见。
- **归档文章**：用户可将已发布的文章变更为归档状态，使其不再对外显示但保留历史记录。
- **删除文章**：用户可删除草稿状态的文章，对于已发布或归档的文章需经过二次确认才能删除。
- **查看文章统计**：用户可查看文章的浏览量、评论数、分享数等统计指标。
- **管理文章评论**：用户可在文章详情页面查看和管理评论，包括审核、回复、删除评论等操作。
- **订阅文章更新**：用户可订阅特定文章的更新通知，当文章内容发生变化时收到提醒。

### 依赖的服务端逻辑

- **领域服务-逻辑-获取文章列表**：[内容管理-获取文章内容列表（getArticleContentList）](specs/001-bootdo-management-system/plan/backend/logic-getArticleContentList.md)
- **领域服务-逻辑-提交文章审核**：[内容管理-提交文章审核（submitArticleForReview）](specs/001-bootdo-management-system/plan/backend/logic-submitArticleForReview.md)
- **领域服务-逻辑-审核文章**：[内容管理-审核文章（reviewArticleContent）](specs/001-bootdo-management-system/plan/backend/logic-reviewArticleContent.md)
- **领域服务-逻辑-获取文章统计数据**：[内容管理-获取文章统计数据（getArticleContentStatistics）](specs/001-bootdo-management-system/plan/backend/logic-getArticleContentStatistics.md)

### 特殊组件

#### 富文本编辑器（richTextEditor）

富文本编辑器特殊组件支持文章内容的所见即所得编辑，提供文字格式化、图片插入、表格创建、代码块高亮等丰富的文本编辑功能，满足内容创作者对文章排版和格式的多样化需求。

- **关联文档**：[特殊组件-富文本编辑器（richTextEditor）](specs/001-bootdo-management-system/plan/dependencies/component-richTextEditor.md)