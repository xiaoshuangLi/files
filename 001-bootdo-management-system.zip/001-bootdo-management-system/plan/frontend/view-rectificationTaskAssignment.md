# 通用业务模块-整改任务分配（rectificationTaskAssignment）

- **生成时间**：2026-03-25

## 整改任务分配（rectificationTaskAssignment）

### 功能概述

整改任务分配页面是质量管理模块的核心功能页面，用于管理质量问题相关的整改任务分配。质量管理员可以通过该页面查看所有整改任务分配的列表，对整改任务进行分配、编辑、删除等操作，并支持上传相关图片作为附件。页面提供完整的整改任务生命周期管理，包括任务分配、进度跟踪和状态更新，确保质量问题得到及时有效的处理。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.qualityManagement.views.rectificationTaskAssignment.tsx"
rectificationTaskAssignment {
  qualityIssueId: Integer?
  status: TaskStatusEnum?
  assigneeId: Integer?
}
```

### 验收列表

- **分配详情数据管理**：
  - **数据增删改操作**：
    - 质量管理员可以在分配详情管理界面查看所有分配详情的列表，以表格形式展示分配详情信息
    - 质量管理员可以点击"保存"按钮，提交分配详情表单数据，保存分配详情信息
    - 质量管理员可以直接删除不需要的分配详情记录，删除操作无需二次确认，执行后立即生效
    - 质量管理员可以提交分配详情数据，完成分配详情的确认和流转
  - **数据导出功能**：
    - 质量管理员可以通过导出按钮将分配详情数据导出为外部文件格式，支持标准格式的数据导出
  - **图片附件管理**：
    - 分配详情表单支持图片附件上传，质量管理员可以在分配详情中上传相关图片作为附件

### 交互操作

- **查看整改任务分配列表**：质量管理员进入整改任务分配页面后，系统自动加载所有整改任务分配记录，以表格形式展示任务ID、关联质量问题、分配人、任务状态、创建时间等关键信息，并支持按状态、分配人、时间范围等条件进行筛选查询。
- **新增整改任务分配**：质量管理员点击"新增"按钮，系统弹出整改任务分配表单，表单包含关联质量问题选择、分配人选择、整改措施描述、截止日期设置等字段，支持上传相关图片作为附件，填写完成后点击"保存"按钮提交分配信息。
- **编辑整改任务分配**：质量管理员在任务列表中点击某条记录的"编辑"按钮，系统加载该任务的详细信息到表单中，允许修改分配人、整改措施、截止日期等信息，修改完成后点击"保存"按钮更新任务信息。
- **删除整改任务分配**：质量管理员在任务列表中点击某条记录的"删除"按钮，系统直接删除该整改任务分配记录，删除操作无需二次确认，执行后立即生效并在列表中移除该记录。
- **导出整改任务数据**：质量管理员点击页面顶部的"导出"按钮，系统将当前筛选条件下的所有整改任务分配数据导出为Excel文件，包含任务基本信息、关联质量问题、分配详情等完整数据。
- **查看质量问题详情**：质量管理员在任务列表中点击关联的质量问题标题，系统内部跳转到Dashboard-质量管理-质量问题登记（qualityIssueRegistration）页面，并传递质量问题ID参数，显示该质量问题的详细信息。
- **分配任务给指定用户**：质量管理员在新增或编辑表单中选择分配人，系统从可分配用户列表中选择合适的处理人员，确保任务能够正确分配给具有相应权限的用户进行处理。

### 依赖的服务端逻辑

- **领域服务-逻辑-分配整改任务**：[质量管理-分配整改任务（assignRectificationTask）](specs/001-bootdo-management-system/plan/backend/logic-assignRectificationTask.md)
- **领域服务-逻辑-获取整改任务列表**：[质量管理-获取整改任务列表（getRectificationTaskList）](specs/001-bootdo-management-system/plan/backend/logic-getRectificationTaskList.md)
- **领域服务-逻辑-删除整改任务**：[质量管理-删除整改任务（deleteRectificationTask）](specs/001-bootdo-management-system/plan/backend/logic-deleteRectificationTask.md)
- **领域服务-逻辑-导出整改任务数据**：[质量管理-导出整改任务数据（exportRectificationTaskData）](specs/001-bootdo-management-system/plan/backend/logic-exportRectificationTaskData.md)

### 特殊组件

无特殊组件。整改任务分配功能页面使用用户界面组件库中的ElUpload标准文件上传组件实现所有图片附件上传功能，包括预览、删除、批量上传等操作，无需使用业务定制的特殊组件。