# 通用业务模块-薪资报表（salaryReport）

- **生成时间**：2026-03-25

## 薪资报表（salaryReport）

### 功能概述

薪资报表页面提供全面的薪资数据分析和查询功能，是人力资源管理的核心模块之一。用户可以通过多种筛选条件（如部门、岗位、时间范围、员工姓名等）进行精准查询，系统支持按月度、季度、年度等不同时间维度展示薪资数据。页面包含详细的薪资构成展示，包括基本工资、绩效奖金、津贴补贴、社保公积金扣款、个税等明细项目。用户可以导出Excel格式的报表用于进一步分析，同时支持打印功能。页面还提供图表可视化功能，以柱状图、折线图等形式直观展示薪资分布和趋势变化。对于有权限的管理人员，还可以进行批量审核和确认操作，确保薪资数据的准确性和及时性。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.salaryManagement.views.salaryReport.tsx"
$View({
    title: "薪资报表",
    crumb: "薪资报表",
    auth: true,
    isIndex: false,
})
export declare function salaryReport(departmentId?: Integer, positionId?: Integer, timeRange?: TimeRangeFilter, employeeName?: String);
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| departmentId | 部门ID | Integer | 筛选指定部门的薪资数据 |
| positionId | 岗位ID | Integer | 筛选指定岗位的薪资数据 |
| timeRange | 时间范围 | TimeRangeFilter | 筛选指定时间范围的薪资数据 |
| employeeName | 员工姓名 | String | 筛选指定员工的薪资数据 |

### 验收列表

- 支持多维度筛选条件组合查询薪资数据
- 支持按月度、季度、年度等不同时间维度展示数据
- 支持详细的薪资构成明细展示
- 支持Excel格式报表导出功能
- 支持打印功能
- 支持图表可视化展示薪资分布和趋势
- 支持批量审核和确认操作
- 支持响应式布局，适配不同屏幕尺寸

### 交互操作

- **筛选查询操作** 用户在筛选区域选择部门、岗位、时间范围或输入员工姓名后，点击查询按钮，系统根据筛选条件加载对应的薪资报表数据
- **时间维度切换操作** 用户点击时间维度切换按钮（月度/季度/年度），系统重新计算并展示对应时间维度的薪资数据
- **薪资明细查看操作** 用户点击某条薪资记录的详情按钮，系统弹出模态框展示该员工的详细薪资构成信息
- **报表导出操作** 用户点击导出按钮，系统生成并下载Excel格式的薪资报表文件
- **打印操作** 用户点击打印按钮，系统调用浏览器打印功能，允许用户打印当前薪资报表
- **图表切换操作** 用户在图表区域切换不同的图表类型（柱状图/折线图），系统更新图表展示方式
- **批量审核操作** 用户勾选多条薪资记录后，点击批量审核按钮，系统执行批量审核确认操作

### 依赖的服务端逻辑

- **领域服务-逻辑-查询薪资报表列表**：[薪资管理-加载薪资报表（loadSalaryReports）](specs/001-bootdo-management-system/plan/backend/logic-loadSalaryReports.md)
- **领域服务-逻辑-获取薪资报表详情**：[薪资管理-获取薪资报表详情（getSalaryReportDetail）](specs/001-bootdo-management-system/plan/backend/logic-getSalaryReportDetail.md)
- **领域服务-逻辑-导出薪资报表**：[薪资管理-导出薪资报表（exportSalaryReport）](specs/001-bootdo-management-system/plan/backend/logic-exportSalaryReport.md)
- **领域服务-逻辑-批量审核薪资报表**：[通用领域服务-批量审核薪资报表（batchApproveSalaryReports）](specs/001-bootdo-management-system/plan/backend/logic-batchApproveSalaryReports.md)
- **领域服务-逻辑-获取薪资数据汇总**：[薪资管理-获取薪资数据汇总（getSalaryDataSummary）](specs/001-bootdo-management-system/plan/backend/logic-getSalaryDataSummary.md)
- **领域服务-逻辑-获取部门列表**：[权限中心-加载部门列表（loadDepartments）](specs/001-bootdo-management-system/plan/backend/logic-loadDepartments.md)
- **领域服务-逻辑-获取岗位列表**：[权限中心-获取岗位列表（loadPositions）](specs/001-bootdo-management-system/plan/backend/logic-loadPositions.md)

### 特殊组件

无特殊组件