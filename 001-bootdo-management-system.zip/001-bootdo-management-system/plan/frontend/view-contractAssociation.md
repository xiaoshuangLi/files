# 通用业务模块-合同关联（contractAssociation）

- **生成时间**：2026-03-25

## 合同关联（contractAssociation）

### 功能概述

合同关联功能页面实现分包商合同的全生命周期管理，支持企业对分包商签订的各类合同进行规范化管理。该页面提供合同信息的创建、查询、修改、删除等核心操作，确保合同数据的完整性、准确性和可追溯性。通过该功能，用户可以维护分包商的合同编号、合同条款、签署日期、合同有效期和合同价值等关键业务数据，实现对分包商合作成本的有效控制和合同状态的实时跟踪，为企业供应链管理提供可靠的数据支撑。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.subcontractorManagement.views.contractAssociation.tsx"
$View({
    title: "合同关联",
    crumb: "合同关联",
    auth: true,
    isIndex: false,
})
export declare function contractAssociation(subcontractorId?: Integer, contractId?: Integer, operationType?: String);
```

### 验收列表

- **分包商合同管理**：分包商合同管理
  - **合同数据录入**：合同数据录入
    - 当用户在合同关联页面创建新合同时，系统必须提供包含以下必填字段的表单：contractNumber（合同编号）、contractTerms（合同条款）、signedDate（签署日期）、startDate（开始日期）、endDate（结束日期）、contractValue（合同价值）
  - **合同数据查询**：合同数据查询
    - 当用户在合同关联页面输入查询条件（如合同编号、分包商名称等字段）并点击查询按钮时，系统必须根据条件筛选显示匹配的合同列表
  - **合同数据导出**：合同数据导出
    - 当用户在合同关联页面点击导出按钮时，系统必须将当前显示的合同列表数据导出为Excel文件，包含所有字段信息
  - **合同数据修改**：合同数据修改
    - 当用户在合同详情页面点击编辑按钮时，系统必须加载合同的当前数据到表单中，并支持用户修改合同信息后保存更新
  - **合同数据删除**：合同数据删除
    - 当用户在合同列表中选择某条合同记录并点击删除按钮时，系统必须提示确认删除，用户确认后删除该合同记录并记录操作日志

### 交互操作

- **合同信息创建**：用户点击"新建合同"按钮，系统打开合同创建表单，用户填写合同编号、合同条款、签署日期、开始日期、结束日期、合同价值等必填信息，点击保存后系统验证数据完整性并保存到数据库，成功后返回合同列表页面并显示成功提示。
- **合同信息查询**：用户在合同列表页面的搜索区域输入合同编号、分包商名称等查询条件，点击查询按钮，系统根据条件筛选并展示匹配的合同记录列表，支持分页浏览。
- **合同详情查看**：用户在合同列表中点击某条合同记录的"查看详情"链接，系统跳转到合同详情页面，以只读模式展示该合同的完整信息，包括所有字段数据和关联的分包商信息。
- **合同信息编辑**：用户在合同详情页面点击"编辑"按钮，系统切换到编辑模式，用户可以修改合同的各项信息，点击保存后系统验证数据有效性并更新数据库，成功后返回详情页面并显示更新成功提示。
- **合同信息删除**：用户在合同列表中选择一条或多条合同记录，点击"删除"按钮，系统弹出二次确认对话框，用户确认后系统执行删除操作，删除成功后从列表中移除对应记录并显示删除成功提示。
- **合同数据导出**：用户在合同列表页面点击"导出"按钮，系统将当前筛选条件下的所有合同数据生成Excel文件并触发下载，文件包含合同编号、合同条款摘要、签署日期、合同价值等关键字段。
- **分包商合同关联**：当用户从分包商详情页面进入合同管理时，系统自动将当前分包商ID作为查询条件，只显示该分包商相关的合同记录，并在创建新合同时自动关联到当前分包商。

### 依赖的服务端逻辑

- **领域服务-逻辑-创建分包商合同**：[分包商管理-创建分包商合同（createSubcontractorContract）](specs/001-bootdo-management-system/plan/backend/logic-createSubcontractorContract.md)
- **领域服务-逻辑-查询分包商合同列表**：[分包商管理-查询分包商合同列表（querySubcontractorContracts）](specs/001-bootdo-management-system/plan/backend/logic-querySubcontractorContracts.md)
- **领域服务-逻辑-更新分包商合同**：[分包商管理-更新分包商合同（updateSubcontractorContract）](specs/001-bootdo-management-system/plan/backend/logic-updateSubcontractorContract.md)
- **领域服务-逻辑-删除分包商合同**：[分包商管理-删除分包商合同（deleteSubcontractorContract）](specs/001-bootdo-management-system/plan/backend/logic-deleteSubcontractorContract.md)
- **领域服务-逻辑-导出分包商合同数据**：[分包商管理-导出分包商合同数据（exportSubcontractorContractData）](specs/001-bootdo-management-system/plan/backend/logic-exportSubcontractorContractData.md)

### 特殊组件

无特殊组件