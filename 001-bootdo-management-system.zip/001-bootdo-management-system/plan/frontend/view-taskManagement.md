# 通用业务模块-任务管理（taskManagement）

- **生成时间**：2026-03-25

## 任务管理（taskManagement）

### 功能概述

任务管理页面负责处理工作流引擎中的具体任务节点，为用户提供任务分配、状态跟踪和处理界面。该页面展示当前用户需要处理或已处理的任务列表，支持任务的详细查看、状态更新和完成操作。通过任务管理功能，用户可以高效地处理分配给自己的工作流任务，确保业务流程的顺畅执行。页面集成了任务搜索、筛选、批量操作等功能，提升任务处理效率，并提供任务历史记录和进度跟踪能力。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.workflowEngine.views.taskManagement.tsx"
$View({
    title: "任务管理",
    crumb: "任务管理",
    auth: true,
    authDescription: "任务管理",
    isIndex: true,
})
export declare function taskManagement();
```

支持以下页面参数：
- taskId (Integer): 任务ID，用于查看特定任务详情
- processInstanceId (String): 流程实例ID，用于筛选特定流程实例的任务  
- assigneeId (String): 分配用户ID，用于筛选特定用户的任务
- taskStatus (String): 任务状态，用于筛选不同状态的任务

### 验收列表

- 系统应以分页表格展示任务节点列表，含任务名称、分配用户、流程实例、创建时间、状态等，支持按流程实例ID、分配用户ID、任务状态筛选【服务端逻辑-查询任务列表】【实体-任务节点（TaskNode）】
- 系统应支持查看任务详情，显示任务的完整信息包括任务名称、分配用户、创建时间、完成时间、状态等详细信息【服务端逻辑-获取任务详情】【实体-任务节点（TaskNode）】
- 系统应支持更新任务状态，用户可以在任务详情页面或列表页面更新任务状态（如标记为已完成）【服务端逻辑-更新任务状态】【实体-任务节点（TaskNode）】
- 系统应支持批量任务操作，用户可以勾选多个任务进行批量状态更新或批量删除（软删除）【服务端逻辑-批量更新任务】【实体-任务节点（TaskNode）】
- 系统应支持任务搜索功能，用户可以在搜索框中输入关键词搜索任务名称或描述【服务端逻辑-查询任务列表】【实体-任务节点（TaskNode）】

### 交互操作

- **查看任务详情**：点击任务列表中的任务项，跳转到任务详情页面，显示任务的完整信息包括任务名称、分配用户、创建时间、完成时间、状态等详细信息
- **更新任务状态**：在任务详情页面或列表页面，用户可以更新任务状态（如标记为已完成），系统会调用相应的服务端逻辑更新任务状态并记录操作日志
- **筛选任务列表**：用户可以通过流程实例ID、分配用户ID、任务状态等条件筛选任务列表，系统实时刷新显示符合条件的任务
- **搜索任务**：用户可以在搜索框中输入关键词搜索任务名称或描述，系统返回匹配的任务结果
- **批量操作任务**：用户可以勾选多个任务进行批量操作，如批量更新状态或批量删除（软删除）
- **分页浏览任务**：任务列表支持分页显示，用户可以切换页面查看更多的任务数据
- **系统内部跳转**：点击任务关联的流程实例ID，跳转到Dashboard-工作流引擎-流程实例管理（processInstanceManagement）页面查看流程实例详情

### 依赖的服务端逻辑

- **领域服务-逻辑-查询任务列表**：[工作流引擎-查询任务列表（queryTaskList）](specs/001-bootdo-management-system/plan/backend/logic-queryTaskList.md)
- **领域服务-逻辑-获取任务详情**：[通用领域服务-获取任务详情（getTaskDetail）](specs/001-bootdo-management-system/plan/backend/logic-getTaskDetail.md)
- **领域服务-逻辑-更新任务状态**：[工作流引擎-更新任务状态（updateTaskStatus）](specs/001-bootdo-management-system/plan/backend/logic-updateTaskStatus.md)
- **领域服务-逻辑-批量更新任务**：[工作流引擎-批量更新任务（batchUpdateTasks）](specs/001-bootdo-management-system/plan/backend/logic-batchUpdateTasks.md)

### 特殊组件

无特殊组件