# 通用业务模块-会议管理（meetingManagement）

- **生成时间**：2026-03-25

## 会议管理（meetingManagement）

### 功能概述

会议管理功能页面为企业用户提供完整的会议生命周期管理服务，支持会议预约、会议室预订、参会人员邀请和会议纪要管理等核心功能。用户可以通过该页面创建新的会议安排，设置会议标题、议程内容、时间安排和地点信息，并指定会议组织者。系统支持自动检测会议室时间冲突，避免资源重复预订。页面提供参会人员邀请功能，可向相关人员发送会议通知并跟踪确认状态。同时支持会议纪要的记录和管理，便于后续跟进和归档。该功能有效提升了企业会议管理的效率和规范化水平，减少了人工协调成本，确保会议资源的合理分配和利用。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.officeAutomation.views.meetingManagement.tsx"
$View({
    title: "会议管理",
    crumb: "会议管理",
    auth: true,
    isIndex: false,
})
export declare function meetingManagement(meetingId?: Integer, organizerId?: Integer, startTime?: DateTime, endTime?: DateTime, location?: String);
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| meetingId | 会议ID | Integer | 用于编辑或查看详情模式的会议标识 |
| organizerId | 组织者ID | Integer | 用于筛选特定用户的会议 |
| startTime | 开始时间 | DateTime | 会议时间范围筛选的开始时间 |
| endTime | 结束时间 | DateTime | 会议时间范围筛选的结束时间 |
| location | 地点 | String | 会议地点筛选条件 |

### 验收列表

- **会议管理**：会议管理
  - **数据展示**：数据展示
    - 系统管理员、部门管理员和普通用户可以在会议管理页面查看会议列表，页面采用表格形式展示会议数据，包含会议标题、组织者、开始时间、结束时间、地点等关键信息
  - **会议创建**：会议创建
    - 用户可以创建新的会议预约，填写会议标题、议程、时间安排、地点等必要信息，系统需验证时间冲突并保存会议数据
  - **会议编辑**：会议编辑
    - 会议组织者可以编辑已创建的会议信息，包括修改会议标题、议程、时间、地点等字段
  - **会议删除**：会议删除
    - 会议组织者可以删除自己创建的会议，系统需提供二次确认提示
  - **参会人员管理**：参会人员管理
    - 支持为会议添加和移除参会人员，系统自动发送会议邀请通知
  - **会议纪要管理**：会议纪要管理
    - 支持在会议结束后添加和编辑会议纪要，记录会议讨论要点和决策结果

### 交互操作

- **创建会议预约**：用户点击"新建会议"按钮，系统弹出会议创建表单，用户填写会议标题、议程、开始时间、结束时间、地点等信息后提交，系统验证时间冲突并保存会议数据，成功后刷新会议列表
- **编辑会议信息**：用户在会议列表中点击某条会议记录的"编辑"按钮，系统加载该会议的详细信息到编辑表单，用户修改后提交更新，系统保存变更并刷新列表
- **删除会议预约**：用户在会议列表中点击某条会议记录的"删除"按钮，系统弹出二次确认对话框，用户确认后系统删除该会议记录并刷新列表
- **查看会议详情**：用户在会议列表中点击某条会议记录，系统跳转到会议详情页面，展示完整的会议信息包括参会人员列表和会议纪要
- **邀请参会人员**：在会议详情页面，用户可以点击"邀请参会人员"按钮，系统弹出人员选择器，用户选择参会人员后系统发送会议邀请通知
- **添加会议纪要**：在会议详情页面，用户可以点击"添加纪要"按钮，系统弹出纪要编辑器，用户输入会议纪要内容后保存，系统更新会议记录
- **筛选会议列表**：用户可以在页面顶部的筛选区域输入会议标题、选择时间范围、地点等条件，系统实时过滤并展示符合条件的会议列表
- **分页浏览**：当会议列表数据较多时，用户可以通过分页控件浏览不同页面的数据

### 依赖的服务端逻辑

- **领域服务-逻辑-查询会议列表**：[办公自动化-查询会议列表（queryMeetingList）](specs/001-bootdo-management-system/plan/backend/logic-queryMeetingList.md)
- **领域服务-逻辑-创建会议预约**：[通用领域服务-创建会议预约（createMeetingReservation）](specs/001-bootdo-management-system/plan/backend/logic-createMeetingReservation.md)
- **领域服务-逻辑-更新会议预约**：[通用领域服务-更新会议预约（updateMeetingReservation）](specs/001-bootdo-management-system/plan/backend/logic-updateMeetingReservation.md)
- **领域服务-逻辑-删除会议预约**：[办公自动化-删除会议预约（deleteMeetingReservation）](specs/001-bootdo-management-system/plan/backend/logic-deleteMeetingReservation.md)
- **领域服务-逻辑-邀请参会人员**：[办公自动化-邀请参会人员（inviteMeetingParticipants）](specs/001-bootdo-management-system/plan/backend/logic-inviteMeetingParticipants.md)
- **领域服务-逻辑-管理会议纪要**：[办公自动化-管理会议纪要（manageMeetingMinutes）](specs/001-bootdo-management-system/plan/backend/logic-manageMeetingMinutes.md)

### 特殊组件

无特殊组件