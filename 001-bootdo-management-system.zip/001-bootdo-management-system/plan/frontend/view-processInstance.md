# 通用业务模块-流程实例管理（processInstance）

- **生成时间**：2026-03-25

## 流程实例管理（processInstance）

### 功能概述

流程实例管理页面提供对工作流引擎中所有流程实例的统一管理和监控功能。用户可以通过该页面查看当前系统中所有正在运行和已完成的流程实例，包括实例的基本信息、当前状态、启动时间、结束时间等关键数据。页面支持按流程定义、状态、时间范围等多种条件进行筛选查询，并提供详细的实例详情查看、任务节点跟踪、流程图可视化展示等功能。同时支持对异常流程实例进行人工干预操作，如流程终止、任务重分配等，确保业务流程的正常运转和问题及时处理。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.workflowEngine.views.processInstance.tsx"
$View({
    title: "流程实例管理",
    crumb: "流程实例管理",
    auth: true,
    isIndex: false,
})
export declare function processInstance(processInstanceId?: Integer, processDefinitionId?: String, status?: String, startTimeFrom?: String, startTimeTo?: String, endTimeFrom?: String, endTimeTo?: String);
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| processInstanceId | 流程实例ID | Integer | 用于查看特定实例详情 |
| processDefinitionId | 流程定义ID | String | 用于筛选特定流程类型的实例 |
| status | 实例状态 | String | 实例状态筛选条件 |
| startTimeFrom | 开始时间范围起始 | String | 开始时间范围起始 |
| startTimeTo | 开始时间范围结束 | String | 开始时间范围结束 |
| endTimeFrom | 结束时间范围起始 | String | 结束时间范围起始 |
| endTimeTo | 结束时间范围结束 | String | 结束时间范围结束 |

### 验收列表

- 支持查看所有流程实例的列表，包含实例ID、流程名称、当前状态、启动人、启动时间、结束时间等基本信息
- 支持按流程定义、实例状态、时间范围等条件进行筛选查询
- 支持点击实例查看详细信息，包括流程图、任务节点、表单数据等
- 支持对运行中的流程实例进行终止操作
- 支持对异常任务节点进行重新分配操作
- 支持导出流程实例列表数据为Excel格式

### 交互操作

- **查看流程实例列表**：加载并展示所有流程实例的基本信息，支持分页显示和排序功能
- **筛选查询流程实例**：根据用户输入的流程定义、状态、时间范围等条件，调用服务端接口获取匹配的流程实例列表
- **查看实例详情**：点击流程实例行，跳转到实例详情页面，展示完整的流程执行信息和流程图
- **终止流程实例**：对选中的运行中流程实例执行终止操作，需二次确认后调用服务端终止接口
- **重新分配任务**：对异常或停滞的任务节点，选择新的处理人进行重新分配，确保流程继续执行
- **导出实例数据**：将当前筛选条件下的流程实例列表数据导出为Excel文件，便于离线分析

### 依赖的服务端逻辑

- **领域服务-逻辑-查询流程实例列表**：[工作流引擎-查询流程实例列表（queryProcessInstances）](specs/001-bootdo-management-system/plan/backend/logic-queryProcessInstances.md)
- **领域服务-逻辑-获取流程实例详情**：[工作流引擎-获取流程实例详情（getProcessInstanceDetail）](specs/001-bootdo-management-system/plan/backend/logic-getProcessInstanceDetail.md)
- **领域服务-逻辑-终止流程实例**：[工作流引擎-终止流程实例（terminateProcessInstance）](specs/001-bootdo-management-system/plan/backend/logic-terminateProcessInstance.md)
- **领域服务-逻辑-重新分配任务节点**：[工作流引擎-重新分配任务节点（reassignTaskNode）](specs/001-bootdo-management-system/plan/backend/logic-reassignTaskNode.md)
- **领域服务-逻辑-导出流程实例数据**：[工作流引擎-导出流程实例数据（exportProcessInstanceData）](specs/001-bootdo-management-system/plan/backend/logic-exportProcessInstanceData.md)

### 特殊组件

#### 流程图可视化组件（processDiagramViewer）

流程图可视化组件用于在流程实例详情页面中展示BPMN流程图，支持高亮显示当前执行节点、已完成节点和未执行节点。组件能够实时反映流程的执行状态，并提供节点详情查看、历史轨迹回放等交互功能，帮助用户直观理解流程的执行进度和状态。