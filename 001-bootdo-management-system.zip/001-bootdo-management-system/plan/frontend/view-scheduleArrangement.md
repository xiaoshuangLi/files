# 通用业务模块-日程管理（scheduleArrangement）

- **生成时间**：2026-03-25

## 日程管理（scheduleArrangement）

### 功能概述

日程管理功能为用户提供个人和共享日程的全面管理能力，支持创建、编辑、查询、删除各类日程事件。用户可以设置精确到分钟的时间范围日程或全天事件，并配置多种提醒方式确保不会错过重要安排。系统提供灵活的日程查询和筛选功能，支持按时间范围、日程标题等条件进行过滤。同时，用户可以查看团队成员和部门共享的日程，实现高效的团队协作和时间协调。该功能与通知提醒系统集成，能够在日程开始前自动发送提醒通知，帮助用户有效管理时间并提升工作效率。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.officeAutomation.views.scheduleArrangement.tsx"
$View({
    title: "日程管理",
    crumb: "日程管理",
    auth: true,
    authDescription: "日程管理",
    isIndex: true,
})
export declare function scheduleArrangement(
  scheduleId?: Integer,
  userId?: Integer,
  startTime?: DateTime,
  endTime?: DateTime,
  title?: String,
  shareType?: String,
  sharerId?: Integer
);
```

### 验收列表

- 系统应以日历视图和列表视图展示用户的日程安排，支持按时间范围、日程标题关键词等条件进行筛选【服务端逻辑-获取日程列表（getScheduleList）】【实体-日程安排（ScheduleArrangement）】
- 系统应通过表单页面支持创建日程，包含日程标题（必填）、描述、开始时间（必填）、结束时间（必填）、是否为全天事件（必填）等字段【服务端逻辑-无】【实体-日程安排（ScheduleArrangement）】
- 系统应通过表单页面支持编辑日程，预填充当前日程数据，允许修改日程的基本属性和时间安排【服务端逻辑-无】【实体-日程安排（ScheduleArrangement）】
- 系统应支持删除日程，删除前需二次确认，删除成功后刷新日程列表【服务端逻辑-无】【实体-日程安排（ScheduleArrangement）】
- 系统应提供共享日程视图，展示团队成员和部门共享的日程安排，支持按共享类型、共享人等条件筛选【服务端逻辑-获取共享日程列表（getSharedScheduleList）】【实体-日程安排（ScheduleArrangement）】
- 系统应支持为日程设置提醒功能，包括提醒时间、提醒方式（邮件、站内信、短信）和重复规则等配置【服务端逻辑-设置日程提醒（setScheduleReminder）】【实体-日程安排（ScheduleArrangement）】

### 交互操作

- **创建日程**：用户点击"新建日程"按钮，跳转到日程创建页面，填写日程标题、描述、时间范围、是否全天事件等信息后保存，系统创建日程并返回列表页面
- **编辑日程**：用户在日程列表中点击某个日程的"编辑"按钮，跳转到日程编辑页面，修改日程信息后保存，系统更新日程数据并返回列表页面
- **删除日程**：用户在日程列表中点击某个日程的"删除"按钮，系统弹出二次确认对话框，用户确认后删除日程并刷新列表
- **查询日程**：用户在页面顶部的查询条件区域输入时间范围、日程标题等筛选条件，点击"查询"按钮，系统调用getScheduleList服务端逻辑获取符合条件的日程列表
- **查看共享日程**：用户切换到"共享日程"标签页，系统调用getSharedScheduleList服务端逻辑获取用户可查看的共享日程列表
- **设置日程提醒**：用户在日程详情或编辑页面中配置提醒设置，选择提醒时间、方式和重复规则，保存时调用setScheduleReminder服务端逻辑设置提醒
- **日程详情查看**：用户点击日程列表中的某个日程，系统跳转到日程详情页面，展示日程的完整信息包括基本属性、描述、提醒设置等
- **返回日程列表**：用户在日程详情或编辑页面点击"返回列表"按钮，系统返回到日程管理主页面

### 依赖的服务端逻辑

- **领域服务-逻辑-获取日程列表**：[办公自动化-获取日程列表（getScheduleList）](specs/001-bootdo-management-system/plan/backend/logic-getScheduleList.md)
- **领域服务-逻辑-获取共享日程列表**：[办公自动化-获取共享日程列表（getSharedScheduleList）](specs/001-bootdo-management-system/plan/backend/logic-getSharedScheduleList.md)
- **领域服务-逻辑-设置日程提醒**：[办公自动化-设置日程提醒（setScheduleReminder）](specs/001-bootdo-management-system/plan/backend/logic-setScheduleReminder.md)

### 特殊组件

无特殊组件