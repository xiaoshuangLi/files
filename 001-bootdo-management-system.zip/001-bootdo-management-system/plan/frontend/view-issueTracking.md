# 通用业务模块-问题跟踪（issueTracking）

- **生成时间**：2026-03-25

## 问题跟踪（issueTracking）

### 功能概述

问题跟踪页面实现质量问题处理进度的全程跟踪功能，记录质量问题的处理过程、进度备注和更新信息。该页面允许用户查看特定质量问题的所有跟踪记录，添加新的进度更新，编辑现有跟踪记录，并监控问题处理的实时状态。通过问题跟踪功能，质量管理人员可以全面掌握每个质量问题的处理进展，确保问题得到及时有效的解决。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.qualityManagement.views.issueTracking.tsx"
$View({
    title: "问题跟踪",
    crumb: "问题跟踪",
    auth: true,
    authDescription: "问题跟踪",
})
export declare function issueTracking();
```

页面参数：
- issueId: Integer - 质量问题ID，用于加载对应的问题跟踪记录

### 验收列表

- 支持查看特定质量问题的所有跟踪记录
- 支持按更新时间倒序显示跟踪记录
- 支持显示每条跟踪记录的更新人和更新时间
- 支持添加新的问题跟踪记录
- 支持编辑现有的问题跟踪记录
- 支持删除问题跟踪记录
- 支持显示关联的质量问题基本信息

### 交互操作

- **查看问题跟踪记录**：根据传入的issueId参数，加载并显示该质量问题的所有跟踪记录，按更新时间倒序排列，每条记录显示进度备注、更新时间和更新人信息
- **显示质量问题基本信息**：在页面顶部显示关联的质量问题基本信息，包括问题标题、状态、报告时间和报告人信息
- **添加跟踪记录**：点击"添加跟踪"按钮，弹出表单弹框，用户输入进度备注后提交，系统创建新的跟踪记录并与质量问题关联
- **编辑跟踪记录**：点击某条跟踪记录的"编辑"按钮，弹出表单弹框预填充当前内容，用户修改后提交更新
- **删除跟踪记录**：点击某条跟踪记录的"删除"按钮，弹出二次确认对话框，确认后删除该跟踪记录
- **刷新跟踪列表**：点击页面上的刷新按钮，重新加载最新的问题跟踪记录数据

### 依赖的服务端逻辑

- **领域服务-逻辑-获取问题跟踪记录列表**：[质量管理-获取问题跟踪记录（getIssueTrackingRecords）](specs/001-bootdo-management-system/plan/backend/logic-getIssueTrackingRecords.md)
- **领域服务-逻辑-获取质量问题详情**：[质量管理-获取质量问题详情（getQualityIssueDetail）](specs/001-bootdo-management-system/plan/backend/logic-getQualityIssueDetail.md)

### 特殊组件

无特殊组件