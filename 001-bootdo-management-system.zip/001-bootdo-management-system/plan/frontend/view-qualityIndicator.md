# 通用业务模块-质量指标（qualityIndicator）

- **生成时间**：2026-03-25

## 质量指标（qualityIndicator）

### 功能概述

质量指标页面是质量管理模块的重要组成部分，用于定义和管理企业质量管理过程中的关键绩效指标（KPI）。该页面支持质量管理员创建、编辑、删除和查询质量指标记录，包括指标名称、计量单位、目标值、实际值等关键信息。通过该页面，系统能够量化评估质量管理体系的有效性，识别质量改进的机会点，并为管理层提供数据驱动的决策支持。质量指标与质量问题实体建立关联关系，可以针对特定质量问题设置相应的衡量标准，实现问题解决效果的量化跟踪。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.qualityManagement.views.qualityIndicator.tsx"
$View({
    title: "质量指标",
    crumb: "通用业务模块-质量指标",
    auth: true,
})
export declare function qualityIndicator();
```

### 验收列表

- **质量指标数据管理**：
  - **质量指标增删改操作**：
    - 质量管理员可以在质量指标管理界面查看所有质量指标的列表，以表格形式展示质量指标信息，包括指标名称、单位、目标值、实际值、测量时间等
    - 质量管理员可以点击"保存"按钮，提交质量指标表单数据，保存质量指标信息
    - 质量管理员可以直接删除不需要的质量指标记录，删除操作无需二次确认，执行后立即生效
    - 质量管理员可以提交质量指标数据，完成质量指标的确认和流转
  - **质量指标查询功能**：
    - 质量管理员可以通过查询条件区域按指标名称、质量问题等字段进行筛选，点击查询按钮显示符合条件的质量指标列表
  - **质量指标导出功能**：
    - 质量管理员可以通过导出按钮将质量指标数据导出为Excel文件格式，支持标准格式的数据导出
  - **质量问题关联管理**：
    - 质量管理员在创建或编辑质量指标时，必须选择关联的质量问题，确保质量指标与具体质量问题的关联性

### 交互操作

- **新增质量指标**：质量管理员点击新增按钮，在表单中填写指标名称、单位、目标值、实际值、测量时间等信息，选择关联的质量问题，点击保存按钮提交质量指标记录
- **编辑质量指标**：质量管理员在质量指标列表中点击编辑按钮，系统根据id参数加载质量指标详情并填充到表单中，管理员修改相关信息后点击保存按钮更新质量指标记录
- **删除质量指标**：质量管理员在质量指标列表中选择要删除的记录，点击删除按钮直接删除质量指标，无需二次确认
- **查询质量指标**：质量管理员在查询条件区域输入指标名称或选择质量问题，点击查询按钮筛选显示符合条件的质量指标列表
- **导出质量指标**：质量管理员点击导出按钮，系统将当前质量指标列表数据导出为Excel文件格式
- **查看质量指标详情**：质量管理员在质量指标列表中点击查看详情按钮，系统展示完整的质量指标信息，包括关联的质量问题详情
- **关联质量问题**：质量管理员在质量指标表单中通过下拉选择框选择已存在的质量问题，建立质量指标与质量问题的关联关系

### 依赖的服务端逻辑

- **领域服务-逻辑-创建质量指标**：[质量管理-创建质量指标（createQualityIndicator）](specs/001-bootdo-management-system/plan/backend/logic-createQualityIndicator.md)
- **领域服务-逻辑-更新质量指标**：[质量管理-更新质量指标（updateQualityIndicator）](specs/001-bootdo-management-system/plan/backend/logic-updateQualityIndicator.md)
- **领域服务-逻辑-删除质量指标**：[质量管理-删除质量指标（deleteQualityIndicator）](specs/001-bootdo-management-system/plan/backend/logic-deleteQualityIndicator.md)
- **领域服务-逻辑-查询质量指标列表**：[质量管理-查询质量指标列表（queryQualityIndicators）](specs/001-bootdo-management-system/plan/backend/logic-queryQualityIndicators.md)
- **领域服务-逻辑-获取质量问题列表**：[质量管理-获取质量问题列表（queryQualityIssues）](specs/001-bootdo-management-system/plan/backend/logic-queryQualityIssues.md)

### 特殊组件

无特殊组件。