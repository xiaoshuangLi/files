# 通用业务模块-在线用户管理（onlineUserManagement）

- **生成时间**：2026-03-26

## 在线用户管理（onlineUserManagement）

### 功能概述

在线用户管理功能页面实现对系统当前所有在线用户会话的实时监控和管理。系统管理员可以通过该页面查看所有活跃用户的会话信息，包括用户身份、登录时间、最后活跃时间、IP地址等关键信息，并支持通过查询功能快速定位特定用户。该功能基于在线会话实体（OnlineSession）提供数据支撑，确保系统安全性和用户活动的可追溯性。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.sysAdmin.views.onlineUserManagement.tsx"
$View({
    title: "在线用户管理",
    crumb: "在线用户管理",
    auth: true,
    isIndex: false,
})
export declare function onlineUserManagement();
```

无输入参数。

### 验收列表

- **在线会话监控**：
  - **在线用户查询**：
    - 系统管理员可以在在线用户管理界面查看当前所有在线用户的列表，以表格形式展示用户会话信息
    - 系统管理员可以通过查询按钮搜索特定在线用户，支持按用户名等字段进行筛选

### 交互操作

- **查看在线用户列表**：系统管理员进入在线用户管理页面后，默认加载并展示当前所有在线用户的会话列表，以表格形式呈现用户ID、登录时间、最后活跃时间、IP地址和活跃状态等关键信息
- **查询特定在线用户**：系统管理员可以使用查询功能，通过输入用户名等条件筛选特定的在线用户会话，系统将实时更新表格显示匹配的会话记录
- **刷新在线用户列表**：系统管理员可以手动刷新页面，重新获取最新的在线用户会话数据，确保显示的信息实时准确

### 依赖的服务端逻辑

- **领域服务-逻辑-加载在线用户列表**：[系统管理-加载在线用户列表（loadOnlineUsersForTable）](specs/001-bootdo-management-system/plan/backend/logic-loadOnlineUsersForTable.md)
- **领域服务-逻辑-搜索在线用户**：[系统管理-搜索在线用户（searchOnlineUsers）](specs/001-bootdo-management-system/plan/backend/logic-searchOnlineUsers.md)

### 特殊组件

无特殊组件