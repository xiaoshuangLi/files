# 通用业务模块-报表格式（reportFormat）

- **生成时间**：2026-03-25

## 报表格式（reportFormat）

### 功能概述

报表格式功能页面用于定义和管理预算分析报告的模板和格式，支持标准化的报表生成。用户可以创建、编辑、删除和查看各种报表格式模板，每个模板包含格式名称、模板内容等信息。该功能确保预算分析报告的一致性和规范性，为预算执行分析提供标准化的数据展示格式。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.budgetManagement.views.reportFormat.tsx"
$View({
    title: "报表格式",
    crumb: "报表格式",
    auth: true,
    isIndex: false,
})
export declare function reportFormat(reportFormatId?: Integer);
```

### 验收列表

无验收列表

### 交互操作

- **创建报表格式**：用户点击"新增"按钮，系统弹出表单弹框，用户填写报表格式名称和模板内容后点击保存，系统调用服务端逻辑创建新的报表格式记录。
- **编辑报表格式**：用户在报表格式列表中点击某条记录的"编辑"按钮，系统弹出表单弹框并自动填充该报表格式的当前信息，用户修改后点击保存，系统调用服务端逻辑更新报表格式记录。
- **删除报表格式**：用户在报表格式列表中点击某条记录的"删除"按钮，系统弹出二次确认对话框，用户确认后系统调用服务端逻辑删除该报表格式记录。
- **查看报表格式详情**：用户在报表格式列表中点击某条记录的"详情"按钮，系统跳转到报表格式详情页面，展示该报表格式的完整信息。
- **查询报表格式列表**：用户在页面顶部的查询条件区域输入报表格式名称进行模糊搜索，系统实时刷新下方的报表格式列表数据。
- **分页浏览**：用户可以通过分页控件浏览不同页面的报表格式列表数据，系统根据当前页码和页面大小加载对应的数据。

### 依赖的服务端逻辑

- **领域服务-逻辑-获取报表格式列表**：[预算管理-获取报表格式列表（getReportFormatList）](specs/001-bootdo-management-system/plan/backend/logic-getReportFormatList.md)
- **领域服务-逻辑-创建报表格式**：[预算管理-创建报表格式（createReportFormat）](specs/001-bootdo-management-system/plan/backend/logic-createReportFormat.md)
- **领域服务-逻辑-更新报表格式**：[预算管理-更新报表格式（updateReportFormat）](specs/001-bootdo-management-system/plan/backend/logic-updateReportFormat.md)
- **领域服务-逻辑-删除报表格式**：[预算管理-删除报表格式（deleteReportFormat）](specs/001-bootdo-management-system/plan/backend/logic-deleteReportFormat.md)
- **领域服务-逻辑-获取报表格式详情**：[预算管理-获取报表格式详情（getReportFormatDetail）](specs/001-bootdo-management-system/plan/backend/logic-getReportFormatDetail.md)

### 特殊组件

无特殊组件