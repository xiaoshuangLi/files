# 通用业务模块-付款管理（paymentManagement）

- **生成时间**：2026-03-25

## 付款管理（paymentManagement）

### 功能概述

付款管理功能页面是分包商管理模块的核心组成部分，专门用于管理企业与分包商之间的付款结算全流程。该页面提供分包商付款记录的创建、编辑、查询、删除和导出等完整操作能力，支持多种付款方式（如银行转账、支票、现金等）的灵活配置，并实现付款状态的实时跟踪。通过与分包商信息实体的关联，系统能够准确识别付款对象，并自动关联相关的合同和项目信息。页面还支持发票号的记录和付款确认机制，确保财务数据的准确性和完整性。该功能为企业提供了分包商付款的精细化管控能力，有效支撑财务合规要求和供应链资金管理，是分包商全生命周期管理中财务环节的关键工具。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.subcontractorManagement.views.paymentManagement.tsx"
$View({
    title: "付款管理",
    crumb: "付款管理",
    auth: true,
    isIndex: false,
})
export declare function paymentManagement(subcontractorId?: Integer, paymentId?: Integer);
```

### 验收列表

无验收列表

### 交互操作

- **创建付款记录**：当用户在付款管理页面点击新建按钮时，系统打开付款信息录入表单，用户填写分包商、付款金额、付款方式、付款日期、发票号和付款状态等信息后，点击保存按钮将新付款记录保存到数据库并刷新列表。
- **编辑付款记录**：当用户在付款管理列表中选择某条付款记录并点击编辑按钮时，系统加载该记录的详细信息到编辑表单，用户修改相关信息后点击保存按钮更新数据库中的付款记录。
- **查询付款记录**：当用户在付款管理页面的搜索区域输入分包商名称、付款状态、付款日期范围等条件并点击查询按钮时，系统根据条件筛选并显示匹配的付款记录列表。
- **删除付款记录**：当用户在付款管理列表中选择一条或多条付款记录并点击删除按钮时，系统弹出二次确认对话框，用户确认后删除选中的付款记录并刷新列表。
- **导出付款数据**：当用户在付款管理页面点击导出按钮时，系统将当前显示的付款记录列表数据导出为Excel文件，包含所有字段信息以便离线分析和存档。
- **查看付款详情**：当用户在付款管理列表中点击某条付款记录时，系统在新页面或弹窗中显示该付款记录的完整详细信息，包括关联的分包商信息和付款历史。

### 依赖的服务端逻辑

- **领域服务-逻辑-获取分包商付款列表**：[分包商管理-获取分包商付款列表（getSubcontractorPaymentList）](specs/001-bootdo-management-system/plan/backend/logic-getSubcontractorPaymentList.md)
- **领域服务-逻辑-创建分包商付款记录**：[分包商管理-创建分包商付款（createSubcontractorPayment）](specs/001-bootdo-management-system/plan/backend/logic-createSubcontractorPayment.md)
- **领域服务-逻辑-更新分包商付款记录**：[分包商管理-更新分包商付款记录（updateSubcontractorPayment）](specs/001-bootdo-management-system/plan/backend/logic-updateSubcontractorPayment.md)
- **领域服务-逻辑-删除分包商付款记录**：[通用领域服务-删除分包商付款（deleteSubcontractorPayment）](specs/001-bootdo-management-system/plan/backend/logic-deleteSubcontractorPayment.md)
- **领域服务-逻辑-导出分包商付款数据**：[分包商管理-导出分包商付款数据（exportSubcontractorPaymentData）](specs/001-bootdo-management-system/plan/backend/logic-exportSubcontractorPaymentData.md)

### 特殊组件

无特殊组件