# 通用业务模块-整改进度（rectificationProgress）

## [整改进度]（rectificationProgress）

### 功能概述

整改进度页面提供完整的整改任务进度跟踪功能，支持用户查看、管理和监控整改任务的执行情况。主要交互操作包括：

1. **整改进度列表展示**：以表格形式展示所有整改任务的进度信息，包含任务编号、任务名称、责任部门、责任人、计划完成时间、实际完成时间、进度百分比、当前状态等关键字段，支持分页显示和排序功能。

2. **整改进度详情查看**：用户可以点击列表中的任意整改任务，进入详情页面查看完整的进度信息，包括进度说明、更新历史、相关附件、关联的质量问题等详细内容。

3. **整改进度搜索筛选**：提供多条件搜索功能，支持按任务编号、任务名称、责任部门、责任人、状态、时间范围等条件进行筛选，帮助用户快速定位特定的整改任务。

4. **整改进度数据导出**：支持将当前筛选条件下的整改进度数据导出为Excel或CSV格式，便于离线分析和报告生成。

5. **整改进度记录删除**：对于无效或重复的整改进度记录，管理员可以直接删除，删除操作无需二次确认，执行后立即生效。

6. **整改进度统计分析**：提供进度统计图表，展示不同状态的整改任务分布、按时完成率、延期任务占比等关键指标，帮助管理层了解整体整改执行情况。

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.qualityManagement.views.rectificationProgress.tsx"
$View({
    title: "整改进度",
    crumb: "整改进度",
    auth: true,
    isIndex: false,
})
export declare function rectificationProgress();
```

无输入参数。

### 依赖的服务端逻辑

- **领域服务-逻辑-查询整改进度列表**：[质量管理-查询整改进度列表（queryRectificationProgressList）](specs/001-bootdo-management-system/plan/backend/logic-queryRectificationProgressList.md)
- **领域服务-逻辑-获取整改进度详情**：[质量管理-获取整改进度详情（getRectificationProgressDetail）](specs/001-bootdo-management-system/plan/backend/logic-getRectificationProgressDetail.md)
- **领域服务-逻辑-删除整改进度记录**：[质量管理-删除整改进度（deleteRectificationProgress）](specs/001-bootdo-management-system/plan/backend/logic-deleteRectificationProgress.md)
- **领域服务-逻辑-导出整改进度数据**：[质量管理-导出整改进度数据（exportRectificationProgressData）](specs/001-bootdo-management-system/plan/backend/logic-exportRectificationProgressData.md)