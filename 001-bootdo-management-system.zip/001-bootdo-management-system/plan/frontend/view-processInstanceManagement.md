# 通用业务模块-流程实例管理（processInstanceManagement）

- **生成时间**：2026-03-25

## 流程实例管理（processInstanceManagement）

### 功能概述

流程实例管理功能提供对工作流引擎中已启动的流程实例进行全面的监控和管理能力。用户可以查看所有流程实例的详细信息，包括流程定义、启动时间、当前状态、处理进度等关键数据，并支持对流程实例进行批量操作如挂起、恢复、终止等管理操作。该功能帮助管理员实时掌握业务流程的执行状况，及时发现和处理异常流程，确保业务流程的顺畅运行和高效管理。通过统一的列表视图和详情页面，管理员能够快速定位问题流程实例，执行必要的管理操作，并通过统计分析功能了解整体流程运行效率，为流程优化提供数据支撑。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.workflowEngine.views.processInstanceManagement.tsx"
$View({
    title: "流程实例管理",
    crumb: "流程实例管理",
    auth: true,
    isIndex: false,
})
export declare function processInstanceManagement(
    userId: Integer, 
    userRoleIds: List<Integer>, 
    isAuthenticated: Boolean,
    processDefinitionId: Optional<Integer>,
    status: Optional<String>,
    startTimeFrom: Optional<DateTime>,
    startTimeTo: Optional<DateTime>,
    assigneeId: Optional<Integer>,
    page: Integer,
    size: Integer,
    sortField: String,
    sortOrder: String
);
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| userId | 用户ID | Integer | 当前登录用户的唯一标识 |
| userRoleIds | 用户角色ID列表 | List<Integer> | 当前用户拥有的所有角色ID列表 |
| isAuthenticated | 认证状态 | Boolean | 用户是否已通过身份认证 |
| processDefinitionId | 流程定义ID | Optional<Integer> | 用于筛选特定流程模板的实例 |
| status | 流程实例状态 | Optional<String> | 用于筛选特定状态的实例 |
| startTimeFrom | 启动时间范围起始 | Optional<DateTime> | 用于时间范围筛选 |
| startTimeTo | 启动时间范围结束 | Optional<DateTime> | 用于时间范围筛选 |
| assigneeId | 处理人ID | Optional<Integer> | 用于筛选指定处理人的流程实例 |
| page | 当前页码 | Integer | 默认为1 |
| size | 每页条数 | Integer | 默认为10 |
| sortField | 排序字段 | String | 默认为'startedAt' |
| sortOrder | 排序顺序 | String | 默认为'desc' |

### 验收列表

- **流程实例管理**：工作流审批列表展示与管理
  - **数据展示**：数据展示
    - 系统管理员角色可以查看工作流审批列表，列表以表格形式展示，包含审批结果、发布/审批时间、负责人、处理环节、处理环节1、审批意见等字段
    - 系统管理员角色可以在工作流审批列表中查看每个审批流程的详细信息，包括审批结果（通过/驳回/待审批）、发布/审批时间（精确到分钟）、负责人（处理人姓名）、处理环节（当前处理节点）、处理环节1（上一处理节点）、审批意见（审批人填写的意见内容）
  - **用户操作**：用户操作
    - 系统管理员角色可以在工作流审批列表中点击编辑按钮，系统将新页面打开编辑界面，允许管理员修改审批流程的相关信息
    - 系统管理员角色可以在工作流审批列表中点击取消按钮，系统将按照Web应用通用交互标准执行返回上一页或关闭当前弹窗/页面的操作

### 交互操作

- **查看流程实例列表**：系统管理员进入流程实例管理页面后，系统自动加载并展示所有流程实例的列表，以表格形式呈现，包含实例ID、流程名称、当前状态、启动时间、启动用户、当前处理节点等关键信息，支持分页显示。
- **筛选流程实例**：系统管理员可以通过顶部的查询条件区域输入流程名称、选择流程状态、设置时间范围等条件来筛选流程实例，点击查询按钮后系统刷新列表显示符合条件的结果。
- **查看流程实例详情**：系统管理员点击列表中的任意流程实例行，系统将在新页面打开该流程实例的详情页面，展示完整的流程信息、任务节点状态、处理历史等详细数据。
- **批量选择流程实例**：系统管理员可以在列表左侧的复选框中勾选一个或多个流程实例，系统会记录选中的实例ID列表，用于后续的批量操作。
- **批量操作流程实例**：系统管理员在选中一个或多个流程实例后，可以点击批量操作按钮（如批量挂起、批量恢复、批量终止），系统会弹出确认对话框，确认后执行相应的批量操作。
- **排序流程实例列表**：系统管理员可以点击表格的列标题（如启动时间、流程名称等）对列表进行排序，支持升序和降序切换。
- **分页浏览流程实例**：系统管理员可以通过底部的分页控件切换不同页面，查看更多的流程实例数据。

### 依赖的服务端逻辑

- **领域服务-逻辑-加载工作流详情**：[工作流引擎-加载工作流详情（loadWorkflowDetail）](specs/001-bootdo-management-system/plan/backend/logic-loadWorkflowDetail.md)
- **领域服务-逻辑-批量操作流程实例**：[工作流引擎-批量操作流程实例（batchOperateProcessInstances）](specs/001-bootdo-management-system/plan/backend/logic-batchOperateProcessInstances.md)
- **领域服务-逻辑-获取工作流统计信息**：[工作流引擎-获取工作流统计信息（getWorkflowStatistics）](specs/001-bootdo-management-system/plan/backend/logic-getWorkflowStatistics.md)

### 特殊组件

无特殊组件