# 通用业务模块-日志管理（logManagement）

- **生成时间**：2026-03-25

## 日志管理（logManagement）

### 功能概述

日志管理页面是系统管理模块的重要组成部分，用于对系统操作日志进行全生命周期管理。提供操作日志的分页表格展示，支持按用户、操作类型、时间范围等多维度条件查询；表格展示用户、操作类型、操作详情、IP地址、操作时间等关键字段；支持单条和批量删除不需要的日志记录，删除操作无需二次确认，执行后立即生效，帮助系统管理员进行安全审计、异常行为检测和操作追溯。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.sysAdmin.views.logManagement.tsx"
$View({
    title: "日志管理",
    crumb: "日志管理",
    auth: true,
    authDescription: "系统操作日志记录",
})
export declare function logManagement();
```

无输入参数。

### 验收列表

- 系统管理员可以在日志管理界面查看所有操作日志的列表，以表格形式展示日志信息，包括用户、操作等字段【服务端逻辑-加载操作日志（loadOperationLogs）】【实体-操作记录（OperationRecord）】
- 系统管理员可以通过查询按钮搜索特定日志记录，支持按用户、操作类型等字段进行筛选【服务端逻辑-搜索操作日志（searchOperationLogs）】【实体-操作记录（OperationRecord）】
- 系统管理员可以直接删除不需要的日志记录，删除操作无需二次确认，执行后立即生效【服务端逻辑-删除操作日志（deleteOperationLog）】【实体-操作记录（OperationRecord）】
- 系统管理员可以选择多个日志记录进行批量删除，提高日志清理效率【服务端逻辑-批量删除操作日志（batchDeleteOperationLogs）】【实体-操作记录（OperationRecord）】

### 交互操作

- **查询操作日志**：系统管理员在日志管理页面顶部的查询区域设置筛选条件（如操作时间范围、操作类型、操作用户等），点击查询按钮后，系统调用搜索操作日志服务端逻辑，获取符合条件的操作日志列表并在下方表格中展示。
- **查看操作日志列表**：系统在页面初始化时自动调用加载操作日志服务端逻辑，以分页表格形式展示所有操作日志记录，每行显示用户、操作类型、操作详情、IP地址、操作时间等关键信息，并提供分页控件支持翻页浏览。
- **删除单条操作日志**：系统管理员在日志列表的操作列中点击删除按钮，系统直接调用删除操作日志服务端逻辑，无需二次确认对话框，删除成功后自动刷新当前页面的日志列表。
- **批量删除操作日志**：系统管理员在日志列表中勾选多条记录，点击批量删除按钮，系统调用批量删除操作日志服务端逻辑，一次性删除所有选中的日志记录，删除成功后自动刷新当前页面的日志列表。

### 依赖的服务端逻辑

- **领域服务-逻辑-加载操作日志**：[系统管理-加载操作日志（loadOperationLogs）](specs/001-bootdo-management-system/plan/backend/logic-loadOperationLogs.md)
- **领域服务-逻辑-搜索操作日志**：[系统管理-搜索操作日志（searchOperationLogs）](specs/001-bootdo-management-system/plan/backend/logic-searchOperationLogs.md)
- **领域服务-逻辑-删除操作日志**：[系统管理-删除操作日志（deleteOperationLog）](specs/001-bootdo-management-system/plan/backend/logic-deleteOperationLog.md)
- **领域服务-逻辑-批量删除操作日志**：[系统管理-批量删除操作日志（batchDeleteOperationLogs）](specs/001-bootdo-management-system/plan/backend/logic-batchDeleteOperationLogs.md)

### 特殊组件

无特殊组件。