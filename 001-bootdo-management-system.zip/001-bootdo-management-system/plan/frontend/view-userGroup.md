# 通用业务模块-用户和组管理（userGroup）

- **生成时间**：2026-03-25

## 用户和组管理（userGroup）

### 功能概述

用户和组管理功能页面实现工作流引擎中的用户分组和团队组织管理，支持创建、编辑、删除用户组，并为用户组分配成员。该功能主要用于批量权限分配和任务分配，提升工作流处理效率。用户组可以作为工作流任务的分配目标，也可以用于批量设置系统权限，简化用户管理操作。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.workflowEngine.views.userGroup.tsx"
$View({
    title: "用户和组管理",
    crumb: "用户和组管理",
    auth: true,
    isIndex: false,
})
export declare function userGroup(groupId?: Integer);
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| groupId | 用户组ID | Integer | 可选参数，用于查看或编辑特定用户组的详情 |

### 验收列表

无验收列表

### 交互操作

- **创建用户组**：点击"新增"按钮打开创建表单，填写用户组名称和描述后保存，系统验证必填字段并创建新的用户组
- **编辑用户组**：在用户组列表中点击"编辑"按钮，加载用户组详情到表单中，修改用户组名称或描述后保存更新
- **删除用户组**：在用户组列表中点击"删除"按钮，弹出二次确认对话框，确认后删除用户组及其关联数据
- **查看用户组详情**：点击用户组名称或"详情"按钮，进入用户组详情页面，显示用户组基本信息和成员列表
- **添加组成员**：在用户组详情页面点击"添加成员"按钮，打开用户选择器，从系统用户中选择成员添加到当前用户组
- **移除组成员**：在用户组成员列表中点击成员对应的"移除"按钮，弹出确认对话框，确认后将该成员从用户组中移除
- **批量操作**：在用户组列表中支持批量选择多个用户组进行批量删除操作
- **搜索筛选**：支持按用户组名称进行模糊搜索，快速定位目标用户组
- **分页浏览**：用户组列表支持分页显示，每页显示固定数量的用户组记录

### 依赖的服务端逻辑

- **领域服务-逻辑-查询用户组列表**：[系统管理-查询用户组列表（queryUserGroupList）](specs/001-bootdo-management-system/plan/backend/logic-queryUserGroupList.md)
- **领域服务-逻辑-获取用户组详情**：[工作流引擎-获取用户组详情（getUserGroupDetail）](specs/001-bootdo-management-system/plan/backend/logic-getUserGroupDetail.md)
- **领域服务-逻辑-创建用户组**：[通用领域服务-创建用户组（createUserGroup）](specs/001-bootdo-management-system/plan/backend/logic-createUserGroup.md)
- **领域服务-逻辑-更新用户组**：[工作流引擎-更新用户组（updateUserGroup）](specs/001-bootdo-management-system/plan/backend/logic-updateUserGroup.md)
- **领域服务-逻辑-删除用户组**：[工作流引擎-删除用户组（deleteUserGroup）](specs/001-bootdo-management-system/plan/backend/logic-deleteUserGroup.md)
- **领域服务-逻辑-查询可选用户列表**：[权限中心-查询可用用户（queryAvailableUsers）](specs/001-bootdo-management-system/plan/backend/logic-queryAvailableUsers.md)
- **领域服务-逻辑-添加用户组成员**：[系统管理-添加用户组成员（addUserGroupMembers）](specs/001-bootdo-management-system/plan/backend/logic-addUserGroupMembers.md)
- **领域服务-逻辑-移除用户组成员**：[系统管理-移除用户组成员（removeUserGroupMembers）](specs/001-bootdo-management-system/plan/backend/logic-removeUserGroupMembers.md)

### 特殊组件

无特殊组件