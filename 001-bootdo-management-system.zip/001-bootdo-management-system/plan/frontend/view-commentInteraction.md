# 通用业务模块-评论管理（commentInteraction）

- **生成时间**：2026-03-25

## 评论管理（commentInteraction）

### 功能概述

评论管理功能提供博客文章评论的审核和管理功能，支持对用户评论进行审核、回复、删除等操作。系统管理员可以查看所有文章的评论列表，对评论内容进行管理，确保评论区的秩序和内容质量。该功能以表格形式展示所有博客评论列表，支持按用户名进行搜索，并提供完整的评论操作管理能力，包括审核通过、删除和添加系统回复等操作。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.contentManagement.views.commentInteraction.tsx"
$View({
    title: "评论管理",
    crumb: "评论管理",
    auth: true,
    isIndex: false,
})
export declare function commentInteraction(commentId?: Integer, articleId?: Integer, username?: String, status?: String);
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| commentId | 评论ID | Integer | 用于编辑或查看详情时传入 |
| articleId | 文章ID | Integer | 用于筛选特定文章的评论 |
| username | 用户名搜索关键词 | String | 用于按用户名进行模糊搜索 |
| status | 评论状态筛选 | String | 评论状态筛选（待审核/已审核/已删除） |

### 验收列表

- **博客评论管理**：评论列表管理
  - **评论展示与搜索**：当系统管理员访问博客评论管理页面时，系统应以表格形式展示所有博客评论列表，表格列应包含：用户名、评论内容、所属文章、评论时间、状态（待审核/已审核/已删除）、操作（审核、回复、删除）。当系统管理员在评论列表页面的搜索框中输入用户名关键词并点击查询按钮时，系统应根据用户名进行模糊搜索，并显示匹配的评论记录。
  - **评论操作管理**：当系统管理员在评论列表中选择某条评论并点击删除按钮时，系统应直接删除该评论，删除前应显示确认对话框，删除后评论状态应标记为已删除。当系统管理员在评论列表页面点击添加按钮时，系统应新页面打开评论添加表单，用于添加系统回复或管理员评论。当系统管理员在评论列表中选择待审核的评论并点击审核通过按钮时，系统应将评论状态从待审核更改为已审核，该评论将在前端页面显示。

### 交互操作

- **评论列表查询**：系统管理员进入评论管理页面后，系统自动加载所有评论列表数据，支持按用户名关键词进行模糊搜索，搜索结果实时更新表格显示。
- **评论审核操作**：系统管理员在评论列表中选择待审核状态的评论，点击"审核通过"按钮，系统将该评论的状态更新为"已审核"，并在前端页面立即显示该评论。
- **评论删除操作**：系统管理员在评论列表中选择任意评论，点击"删除"按钮，系统弹出二次确认对话框，确认后直接删除该评论，评论状态标记为"已删除"并从列表中移除。
- **添加系统回复**：系统管理员点击评论列表页面的"添加"按钮，系统跳转到新页面打开评论添加表单，管理员可填写回复内容并关联到指定文章，提交后作为系统回复显示在对应文章评论区。
- **评论详情查看**：系统管理员点击评论列表中的"查看详情"链接，系统跳转到评论详情页面，显示评论的完整内容、关联文章信息、评论者信息和审核历史记录。

### 依赖的服务端逻辑

- **领域服务-逻辑-获取评论列表**：[内容管理-获取评论列表（getCommentList）](specs/001-bootdo-management-system/plan/backend/logic-getCommentList.md)
- **领域服务-逻辑-审核评论**：[内容管理-审核评论（approveComment）](specs/001-bootdo-management-system/plan/backend/logic-approveComment.md)
- **领域服务-逻辑-删除评论**：[内容管理-删除评论（deleteComment）](specs/001-bootdo-management-system/plan/backend/logic-deleteComment.md)
- **领域服务-逻辑-添加系统回复**：[内容管理-添加系统回复（addSystemReply）](specs/001-bootdo-management-system/plan/backend/logic-addSystemReply.md)
- **领域服务-逻辑-获取评论详情**：[内容管理-获取评论详情（getCommentDetail）](specs/001-bootdo-management-system/plan/backend/logic-getCommentDetail.md)

### 特殊组件

#### 富文本编辑器（richTextEditor）

评论添加和回复功能需要富文本编辑器组件来支持格式化的评论内容输入，包括文字样式、链接、图片插入等富文本功能，确保系统回复能够包含丰富的格式化内容。

- **关联文档**：[特殊组件-富文本编辑器（richTextEditor）](specs/001-bootdo-management-system/plan/dependencies/component-richTextEditor.md)