# 通用业务模块-栏目管理（columnStructure）

- **生成时间**：2026-03-25

## 栏目管理（columnStructure）

### 功能概述

栏目管理功能提供内容管理系统的核心栏目结构维护能力，支持多级栏目树形管理。管理员可以通过该功能创建、编辑、删除和排序栏目，建立清晰的内容组织架构。每个栏目可以包含多篇文章内容，形成层次化的信息结构。系统支持父子级联关系配置、栏目排序控制、描述信息维护等功能，并与用户订阅、权限控制、SEO优化等模块集成，确保内容管理的完整性和灵活性。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.contentManagement.views.columnStructure.tsx"
$View({
    title: "栏目管理",
    crumb: "栏目管理",
    auth: true,
    isIndex: false,
})
export declare function columnStructure();
```

无输入参数。

### 验收列表

- **栏目树形结构管理**：栏目展示与操作
  - 当系统管理员访问栏目管理页面时，系统应以树形结构展示所有栏目层级关系，支持展开/折叠父级栏目查看子栏目
  - 当系统管理员在栏目树中选择某个栏目并点击编辑按钮时，系统应打开栏目编辑表单，预填充该栏目的现有信息
  - 当系统管理员在栏目树中选择某个栏目并点击删除按钮时，系统应检查该栏目下是否有子栏目或关联文章，如果有则提示无法删除，需要先处理子内容
- **栏目创建与编辑**：表单数据输入
  - 当系统管理员在栏目管理页面点击添加按钮时，系统应打开新页面显示栏目创建表单，表单包含以下必填字段：栏目名称（文本输入框，必填）、父栏目（树形选择器，默认为根栏目）、描述（文本域，可选）、排序（数字输入框，默认值为0）
  - 当系统管理员提交栏目表单时，系统应验证栏目名称是否已存在（同级栏目不允许重名），验证通过后保存栏目信息并刷新栏目树

### 交互操作

- **查看栏目树形结构**：系统管理员访问栏目管理页面时，系统以树形结构展示所有栏目层级关系，支持展开/折叠父级栏目查看子栏目，每个栏目节点显示栏目名称和排序值
- **创建新栏目**：系统管理员点击添加按钮，系统跳转到栏目创建页面，显示包含栏目名称（必填）、父栏目选择（树形选择器）、描述（可选）、排序（数字，默认0）的表单，提交后验证数据完整性并保存
- **编辑栏目信息**：系统管理员在栏目树中选择栏目并点击编辑按钮，系统跳转到栏目编辑页面，预填充现有栏目信息，允许修改栏目名称、父栏目、描述和排序值
- **删除栏目**：系统管理员在栏目树中选择栏目并点击删除按钮，系统检查该栏目是否有子栏目或关联文章，如有则提示无法删除，如无则显示确认对话框后执行删除操作
- **调整栏目排序**：系统管理员可以在栏目表单中修改排序值（数值越大排序越靠前），保存后栏目在树形结构中的显示顺序相应调整
- **系统内部跳转**：从栏目管理页面可以跳转到文章管理页面（/dashboard/contentManagement/articleManagement），用于管理特定栏目的文章内容

### 依赖的服务端逻辑

- **领域服务-逻辑-获取栏目树形结构**：[内容管理-获取栏目结构树（getColumnStructureTree）](specs/001-bootdo-management-system/plan/backend/logic-getColumnStructureTree.md)
- **领域服务-逻辑-创建栏目**：[内容管理-创建栏目结构（createColumnStructure）](specs/001-bootdo-management-system/plan/backend/logic-createColumnStructure.md)
- **领域服务-逻辑-更新栏目**：[内容管理-更新栏目结构（updateColumnStructure）](specs/001-bootdo-management-system/plan/backend/logic-updateColumnStructure.md)
- **领域服务-逻辑-删除栏目**：[内容管理-删除栏目结构（deleteColumnStructure）](specs/001-bootdo-management-system/plan/backend/logic-deleteColumnStructure.md)
- **领域服务-逻辑-验证栏目名称唯一性**：[内容管理-验证栏目名称唯一性（validateColumnNameUniqueness）](specs/001-bootdo-management-system/plan/backend/logic-validateColumnNameUniqueness.md)

### 特殊组件

无特殊组件。栏目管理功能页面使用标准用户界面组件库中的树形选择器（ElCascader）实现栏目层级选择功能，无需使用业务定制的特殊组件。