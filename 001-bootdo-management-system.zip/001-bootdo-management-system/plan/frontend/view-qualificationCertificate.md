# 通用业务模块-资质管理（qualificationCertificate）

- **生成时间**：2026-03-25

## 资质管理（qualificationCertificate）

### 功能概述

资质管理功能页面用于维护分包商持有的各类资质证书信息，包括证书名称、证书编号、颁发机构、颁发日期和有效期等关键信息。该页面支持对分包商资质证书的增删改查操作，确保证书信息的完整性和时效性，为分包商评估和合规检查提供数据支撑。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.subcontractorManagement.views.qualificationCertificate.tsx"
$View({
    title: "资质管理",
    crumb: "资质管理",
    auth: true,
    isIndex: false,
})
export declare function qualificationCertificate(subcontractorId?: Integer);
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| subcontractorId | 分包商ID | Integer | 用于查看特定分包商的资质证书，可选参数 |

### 验收列表

- 支持按分包商查看其所有资质证书信息
- 支持新增资质证书，必填字段包括证书名称、证书编号、颁发机构、颁发日期、过期日期
- 支持编辑现有资质证书信息
- 支持删除不再有效的资质证书
- 支持查看证书的详细信息，包括所有字段的完整展示
- 支持按证书名称、证书编号进行搜索筛选

### 交互操作

- **查看分包商资质列表**：当用户进入资质管理页面时，如果提供了分包商ID参数，则自动加载并展示该分包商的所有资质证书列表；如果没有提供分包商ID，则显示空状态提示
- **新增资质证书**：点击"新增"按钮，弹出表单对话框，用户填写证书名称、证书编号、颁发机构、颁发日期、过期日期等必填信息，点击保存后创建新的资质证书记录
- **编辑资质证书**：在资质证书列表中点击某条记录的"编辑"按钮，弹出预填充表单，用户可修改证书信息，点击保存后更新资质证书记录
- **删除资质证书**：在资质证书列表中点击某条记录的"删除"按钮，弹出二次确认对话框，确认后删除对应的资质证书记录
- **查看详情**：在资质证书列表中点击某条记录的"详情"按钮，跳转到资质证书详情页面，展示该证书的完整信息
- **搜索筛选**：在页面顶部的搜索框中输入证书名称或证书编号，实时筛选显示匹配的资质证书记录

### 依赖的服务端逻辑

- **领域服务-逻辑-查询分包商资质证书列表**：[分包商管理-查询分包商资质证书列表（querySubcontractorQualificationCertificates）](specs/001-bootdo-management-system/plan/backend/logic-querySubcontractorQualificationCertificates.md)
- **领域服务-逻辑-创建分包商资质证书**：[分包商管理-创建分包商资质证书（createSubcontractorQualificationCertificate）](specs/001-bootdo-management-system/plan/backend/logic-createSubcontractorQualificationCertificate.md)
- **领域服务-逻辑-更新分包商资质证书**：[分包商管理-更新分包商资质证书（updateSubcontractorQualificationCertificate）](specs/001-bootdo-management-system/plan/backend/logic-updateSubcontractorQualificationCertificate.md)
- **领域服务-逻辑-删除分包商资质证书**：[分包商管理-删除分包商资质证书（deleteSubcontractorQualificationCertificate）](specs/001-bootdo-management-system/plan/backend/logic-deleteSubcontractorQualificationCertificate.md)

### 特殊组件

无特殊组件