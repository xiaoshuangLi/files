# 通用业务模块-月工资额计算（monthlySalaryAmount）

- **生成时间**：2026-03-25

## 月工资额计算（monthlySalaryAmount）

### 功能概述

月工资额计算功能页面负责管理员工月度薪资的详细计算和管理，包括税前金额、税后金额的自动计算以及支付月份的设置。该页面支持薪资管理人员查看、编辑和确认员工的月度薪资数据，确保薪资发放的准确性和及时性。页面集成了税务计算功能，能够根据员工的薪资结构和当地税收政策自动计算应缴税额，并生成详细的薪资明细报表。同时，该功能还支持薪资历史记录的查询和对比分析，帮助人力资源部门进行薪资成本控制和预算规划。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.salaryManagement.views.monthlySalaryAmount.tsx"
$View({
    title: "月工资额计算",
    auth: true,
    isIndex: false,
})
export declare function monthlySalaryAmount(
  employeeId?: Integer, // 员工ID，用于查看特定员工的月工资额
  paymentMonth?: String, // 支付月份，格式为YYYY-MM，用于筛选特定月份的薪资记录
  structureId?: Integer // 薪资结构ID，关联到具体的薪资组成结构
);
```

页面返回数据结构：
- salaryRecords: Array<{
    salaryId: Integer,
    employeeId: Integer,
    employeeName: String,
    structureId: Integer,
    grossAmount: Decimal, // 税前金额
    netAmount: Decimal, // 税后金额
    paymentMonth: String,
    paidAt: DateTime,
    taxAmount: Decimal,
    taxRate: Decimal
  }>
- pagination: {
    currentPage: Integer,
    pageSize: Integer,
    total: Integer
  }

### 验收列表

无验收列表

### 交互操作

- **查看月工资详情**：用户可以点击薪资记录查看详细的月工资计算明细，包括基本工资、奖金、津贴、税前总额、税后金额等完整信息。
- **编辑月工资数据**：具有编辑权限的用户可以修改月工资的税前金额、税后金额等数据，系统会自动重新计算相关税务信息并保存变更。
- **批量导入薪资数据**：支持通过Excel模板批量导入多个月度薪资记录，系统会自动验证数据格式并处理导入结果。
- **导出薪资报表**：用户可以将当前查询结果导出为Excel或PDF格式的薪资报表，便于存档和分发。
- **筛选查询薪资记录**：支持按员工姓名、支付月份、薪资状态等条件进行筛选查询，快速定位目标薪资记录。
- **删除薪资记录**：对于错误录入的薪资记录，用户可以执行删除操作，系统会弹出二次确认对话框确保操作安全。
- **系统内部跳转**：点击员工姓名可跳转到Dashboard-薪资管理-薪资结构定义（salaryStructure）页面查看该员工的薪资结构详情。

### 依赖的服务端逻辑

- **领域服务-逻辑-计算月度薪资**：[薪资管理-计算月工资额（calculateMonthlySalary）](specs/001-bootdo-management-system/plan/backend/logic-calculateMonthlySalary.md)
- **领域服务-逻辑-批量导入薪资数据**：[薪资管理-批量导入薪资数据（batchImportSalaryData）](specs/001-bootdo-management-system/plan/backend/logic-batchImportSalaryData.md)
- **领域服务-逻辑-导出薪资报表**：[薪资管理-导出薪资报表（exportSalaryReport）](specs/001-bootdo-management-system/plan/backend/logic-exportSalaryReport.md)

### 特殊组件

无特殊组件。月工资额计算功能页面使用用户界面组件库中的标准表单组件（ElForm系列）和计算逻辑实现所有薪资计算功能，无需使用业务定制的特殊组件。