# 通用业务模块-审批流程（approvalProcess）

- **生成时间**：2026-03-25

## 审批流程（approvalProcess）

### 功能概述

审批流程功能页面提供业务审批流程的全生命周期管理能力，支持工作流管理员对各类业务场景中的审批流程进行配置、维护和监控。该页面允许用户创建新的审批流程模板，编辑现有流程的配置参数，启用或停用流程，以及批量管理多个审批流程。通过此功能，系统能够为预算调整、薪资变更、质量整改等需要审批的业务模块提供统一的流程定义基础，确保审批流程的标准化、可配置性和高效管理。页面采用表格形式展示审批流程列表，支持按流程名称、状态、类型等条件进行筛选查询，并提供详细的操作审计日志追踪。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.workflowEngine.views.approvalProcess.tsx"
$View({
    title: "审批流程",
    crumb: "审批流程",
    auth: false,
    isIndex: false,
})
export declare function approvalProcess(processId?: Integer);
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| processId | 审批流程ID | Integer | 用于编辑模式下加载特定流程的详细信息，可选参数 |

### 验收列表

- **审批流程管理功能**：审批流程管理
  - **数据展示类别**：数据展示
    - 系统管理员角色可以查看审批流程列表，列表以表格形式展示，包含流程名称、流程状态、流程类型、是否启用、版本号、创建时间、创建者等字段
    - 系统管理员角色可以在审批流程详情页面查看流程的完整信息，包括流程名称、流程描述、流程状态、流程类型、是否启用、版本号、创建时间和更新时间等详细信息
  - **用户操作类别**：用户操作
    - 系统管理员角色可以在审批流程列表中点击添加按钮，系统将新页面打开审批流程添加界面，允许管理员创建新的审批流程配置
    - 系统管理员角色可以在审批流程列表中点击编辑按钮，系统将新页面打开审批流程编辑界面，允许管理员修改现有审批流程的配置信息
    - 系统管理员角色可以在审批流程列表中选择多个审批流程，点击批量操作按钮，系统将执行批量启用、批量停用或批量删除等操作
    - 系统管理员角色可以在审批流程列表中点击查询按钮，系统将根据输入的流程名称、状态、类型等条件筛选审批流程记录
    - 系统管理员角色可以在审批流程列表中点击删除按钮，系统将直接删除选中的审批流程记录，删除前需要确认操作

### 交互操作

- **添加审批流程**：系统管理员点击添加按钮后，跳转到审批流程添加页面，填写流程名称、描述、状态、类型等基本信息，提交后调用创建工作流服务端逻辑保存新的审批流程配置
- **编辑审批流程**：系统管理员点击编辑按钮后，跳转到审批流程编辑页面，加载现有流程的详细信息并允许修改，提交后更新审批流程配置
- **批量操作审批流程**：系统管理员在列表中选择多个审批流程，选择批量操作类型（启用、停用、删除），确认后调用批量操作审批流程服务端逻辑执行相应操作
- **查询审批流程**：系统管理员在查询条件区域输入流程名称、选择状态或类型，点击查询按钮后刷新列表显示符合条件的审批流程
- **删除审批流程**：系统管理员点击删除按钮，系统弹出确认对话框，确认后调用删除工作流服务端逻辑删除选中的审批流程

### 依赖的服务端逻辑

- **领域服务-逻辑-批量操作审批流程**：[工作流引擎-批量操作审批流程（batchOperateApprovalProcess）](specs/001-bootdo-management-system/plan/backend/logic-batchOperateApprovalProcess.md)
- **领域服务-逻辑-创建工作流**：[工作流引擎-创建工作流（createWorkflow）](specs/001-bootdo-management-system/plan/backend/logic-createWorkflow.md)
- **领域服务-逻辑-更新工作流**：[工作流引擎-更新流程定义（updateWorkflow）](specs/001-bootdo-management-system/plan/backend/logic-updateWorkflow.md)
- **领域服务-逻辑-删除工作流**：[工作流引擎-删除工作流（deleteWorkflow）](specs/001-bootdo-management-system/plan/backend/logic-deleteWorkflow.md)
- **领域服务-逻辑-加载工作流列表**：[工作流引擎-加载流程列表（loadWorkflowList）](specs/001-bootdo-management-system/plan/backend/logic-loadWorkflowList.md)
- **领域服务-逻辑-加载工作流详情**：[工作流引擎-加载工作流详情（loadWorkflowDetail）](specs/001-bootdo-management-system/plan/backend/logic-loadWorkflowDetail.md)

### 特殊组件

无特殊组件