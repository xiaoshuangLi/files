# 通用业务模块-系统参数配置（systemConfig）

- **生成时间**：2026-03-25

## 系统参数配置（systemConfig）

### 功能概述

系统参数配置页面用于管理全局系统配置参数，支持管理员对系统运行所需的各种配置项进行动态设置和管理。该功能允许用户查看、新增、修改和删除系统配置参数，包括配置键、配置值和描述信息，并提供缓存管理功能以确保配置变更能够及时生效。通过此页面，管理员可以灵活调整系统行为而无需修改代码或重启服务。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.sysAdmin.views.systemConfig.tsx"
$View({
    title: "系统参数配置",
    crumb: "系统参数配置",
    auth: false,
    isIndex: false,
})
export declare function systemConfig();
```

无输入参数。

### 验收列表

- 支持系统全局参数的增删改查操作
- 支持按配置键和描述进行查询筛选
- 支持配置参数的批量删除操作
- 支持缓存刷新功能，确保配置变更及时生效
- 支持配置历史记录查看

### 交互操作

- **查询系统配置**：用户可以在顶部查询区域输入配置键或描述关键词，点击查询按钮后在下方表格中显示匹配的系统配置列表
- **新增配置参数**：用户点击新增按钮，弹出表单弹框，填写配置键、配置值和描述信息后保存，成功后在列表中显示新配置项
- **编辑配置参数**：用户点击列表中的编辑按钮，跳转到配置编辑页面，页面参数包含configId，自动加载配置详情并填充表单，用户修改后保存更新
- **删除配置参数**：用户点击列表中的删除按钮，弹出二次确认对话框，确认后删除对应配置项；支持批量勾选多个配置项后批量删除
- **刷新缓存**：用户点击缓存刷新按钮，触发系统缓存清理操作，确保配置变更立即生效
- **查看配置历史**：用户点击历史记录按钮，系统内部跳转到Dashboard-系统管理-日志管理（logManagement）页面，查看相关操作记录

### 依赖的服务端逻辑

- **领域服务-逻辑-加载系统配置列表**：[系统管理-加载系统配置列表（loadSystemConfigurations）](specs/001-bootdo-management-system/plan/backend/logic-loadSystemConfigurations.md)
- **领域服务-逻辑-刷新系统配置缓存**：[通用领域服务-刷新系统配置缓存（refreshSystemConfigurationCache）](specs/001-bootdo-management-system/plan/backend/logic-refreshSystemConfigurationCache.md)

### 特殊组件

无特殊组件