# 通用业务模块-环境监测（environmentalMonitoring）

- **生成时间**：2026-03-25

## 环境监测（environmentalMonitoring）

### 功能概述

环境监测功能页面实现对环境指标的实时监测数据管理，包括温度、湿度、空气质量等关键环境参数的采集、展示和分析。该页面支持环境监测数据的列表查询、详情查看、新增录入和编辑修改，为环保管理提供基础数据支撑。用户可以通过该页面全面了解各监测点的环境状况，及时发现异常情况并采取相应措施。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.environmentalManagement.views.environmentalMonitoring.tsx"
$View({
    title: "环境监测",
    crumb: "环境监测",
    auth: true,
    isIndex: true,
})
export declare function environmentalMonitoring(monitoringId?: Integer);
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| monitoringId | 环境监测数据ID | Integer | 用于详情查看和编辑模式的环境监测数据ID |

### 验收列表

无验收列表

### 交互操作

- **查看环境监测数据列表**：在环境监测页面展示所有环境监测数据的列表，包含监测位置、监测时间、温度、湿度、空气质量指数等关键信息，支持按监测位置和时间范围进行筛选查询。
- **查看环境监测数据详情**：点击列表中的某条记录，跳转到环境监测数据详情页面，展示该监测点的完整环境指标数据，包括温度、湿度、空气质量指数等详细信息。
- **新增环境监测数据**：通过表单弹框的形式实现新增环境监测数据的交互，用户可以输入监测位置、监测时间、温度、湿度、空气质量指数等信息，提交后保存到系统中。
- **编辑环境监测数据**：通过表单弹框的形式实现编辑环境监测数据的交互，用户可以修改已有的环境监测数据，包括监测位置、监测时间、温度、湿度、空气质量指数等信息，提交后更新系统中的数据。
- **删除环境监测数据**：在列表页面选择一条或多条环境监测数据，点击删除按钮，经过二次确认后从系统中删除选中的数据记录。

### 依赖的服务端逻辑

- **领域服务-逻辑-获取环境监测数据列表**：[环保管理-加载环境监测列表（loadEnvironmentalMonitoringList）](specs/001-bootdo-management-system/plan/backend/logic-loadEnvironmentalMonitoringList.md)

### 特殊组件

无特殊组件