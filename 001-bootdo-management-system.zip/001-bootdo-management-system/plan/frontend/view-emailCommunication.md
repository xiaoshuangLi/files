# 通用业务模块-邮件集成（emailCommunication）

- **生成时间**：2026-03-25

## 邮件集成（emailCommunication）

### 功能概述

邮件集成功能页面提供企业内部邮件通信管理能力，支持邮件的收发、附件管理、邮件模板等功能。用户可以通过该页面发送新邮件、查看收件箱、管理已发送邮件、设置邮件模板，并对重要邮件进行标记和分类管理。系统支持邮件阅读状态跟踪，确保重要信息的有效传达。

### 页面签名

```naturalts path="app.frontendTypes.pc.frontends.pc.views.dashboard.views.officeAutomation.views.emailCommunication.tsx"
$View({
    title: "邮件集成",
    crumb: "办公自动化 > 邮件集成",
    auth: true,
})
export declare function emailCommunication(emailId?: Integer, mailType?: String, searchKeyword?: String, recipientId?: Integer);
```

### 验收列表

- 支持邮件收发管理
- 支持附件管理
- 支持邮件模板
- 邮件阅读状态跟踪

### 交互操作

- **发送新邮件**：用户可以点击"撰写"按钮打开邮件编辑界面，填写收件人、主题、正文内容，添加附件后发送邮件。系统会自动保存邮件副本到发件箱，并更新收件人的未读邮件计数。
- **查看邮件详情**：用户在邮件列表中点击任意邮件，系统会加载并显示邮件的完整内容，包括发件人、收件人、主题、正文、附件等信息，并自动标记为已读状态。
- **回复邮件**：在邮件详情页面，用户可以点击"回复"按钮，系统会自动填充原邮件的收件人为新邮件的收件人，并在正文中引用原邮件内容，用户编辑后可发送回复。
- **转发邮件**：在邮件详情页面，用户可以点击"转发"按钮，系统会创建新邮件并在正文中包含原邮件的完整内容，用户指定新的收件人后可发送转发邮件。
- **管理附件**：在撰写邮件时，用户可以上传、删除附件，系统支持常见的文件格式，并显示附件大小和类型信息。
- **使用邮件模板**：用户可以选择预设的邮件模板，系统会自动填充模板内容到邮件正文中，用户可以在此基础上进行编辑。
- **标记重要邮件**：用户可以对重要邮件进行星标标记，方便后续快速查找和管理。
- **删除邮件**：用户可以将不需要的邮件移动到垃圾箱，系统提供二次确认对话框防止误删，并支持在一定时间内恢复已删除邮件。
- **搜索邮件**：用户可以在搜索框中输入关键词，系统会实时过滤显示匹配的邮件，支持按发件人、主题、内容等字段搜索。

### 依赖的服务端逻辑

- **领域服务-逻辑-发送邮件**：[办公自动化-发送邮件（sendEmail）](specs/001-bootdo-management-system/plan/backend/logic-sendEmail.md)
- **领域服务-逻辑-获取邮件列表**：[办公自动化-获取邮件列表（getEmailList）](specs/001-bootdo-management-system/plan/backend/logic-getEmailList.md)
- **领域服务-逻辑-获取邮件详情**：[办公自动化-获取邮件详情（getEmailDetail）](specs/001-bootdo-management-system/plan/backend/logic-getEmailDetail.md)
- **领域服务-逻辑-删除邮件**：[通用领域服务-deleteEmail（deleteEmail）](specs/001-bootdo-management-system/plan/backend/logic-deleteEmail.md)
- **领域服务-逻辑-管理邮件模板**：[办公自动化-管理邮件模板（manageEmailTemplates）](specs/001-bootdo-management-system/plan/backend/logic-manageEmailTemplates.md)

### 特殊组件

#### 邮件富文本编辑器（emailRichTextEditor）

邮件富文本编辑器组件支持用户在撰写邮件时使用丰富的文本格式，包括字体样式、颜色、段落格式、列表、链接等。该组件还集成了附件上传功能，允许用户直接在编辑区域拖拽或点击上传文件。编辑器支持HTML格式的内容存储和渲染，确保邮件在不同邮件客户端中的兼容性。

- **关联文档**：[特殊组件-邮件富文本编辑器（emailRichTextEditor）](specs/001-bootdo-management-system/plan/dependencies/component-emailRichTextEditor.md)