# 薪资管理-删除薪资结构项（deleteSalaryStructureItem）

- **生成时间**：2026-03-25

## 删除薪资结构项（deleteSalaryStructureItem）

### 功能概述

该服务端逻辑用于从系统中删除指定的薪资结构项。薪资结构项是构成完整薪资结构的基本组成部分，如基本工资、绩效奖金、津贴补贴等。删除操作需要确保该薪资结构项未被任何在职员工的薪资方案引用，以保证数据一致性。删除前会进行权限验证，确保只有具备相应权限的用户（如系统管理员或薪资管理员）才能执行此操作。删除成功后，系统会记录操作日志，并更新相关的薪资结构配置。

### 功能要点

- **安全删除验证**：在执行删除操作前，系统必须验证该薪资结构项是否已被任何在职员工的薪资方案所引用。如果存在引用关系，则禁止删除操作并返回明确的错误信息，提示用户先解除所有引用关系。这确保了薪资数据的完整性和一致性，避免因误删导致薪资计算异常。

### 逻辑签名

```naturalts path="app.logics.deleteSalaryStructureItem.ts"
$Logic({
    description: '删除薪资结构项',
    directory: 'salary_management(薪资管理)'
})
export declare function deleteSalaryStructureItem(salaryStructureItemId: String): { success: Boolean, info: String };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| salaryStructureItemId | 薪资结构项ID | String | 要删除的薪资结构项的唯一标识符 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| success | 操作结果 | Boolean | 删除操作是否成功 |
| info | 提示信息 | String | 操作结果的详细提示信息 |

### 被前端调用

- **薪资结构定义（salaryStructure）**：在薪资结构定义页面中，管理员可以通过点击删除按钮调用此服务端逻辑，移除不再需要的薪资结构项。该功能允许管理员动态调整薪资结构组成，以适应公司薪酬政策的变化。

### 依赖的枚举、实体

- **数据建模-实体-薪资结构**：[薪资管理-实体-薪资结构（SalaryStructure）](specs/001-bootdo-management-system/plan/data-model/entity-SalaryStructure.md)
- **数据建模-实体-薪资结构项**：[薪资管理-实体-薪资结构项（SalaryStructureItem）](specs/001-bootdo-management-system/plan/data-model/entity-SalaryStructureItem.md)

### 依赖的外部能力

无