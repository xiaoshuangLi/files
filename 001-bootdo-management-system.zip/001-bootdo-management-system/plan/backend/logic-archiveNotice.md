# 办公自动化-归档通知公告（archiveNotice）

- **生成时间**：2026-03-25

## 归档通知公告（archiveNotice）

### 功能概述

归档通知公告服务端逻辑负责将已发布的通知公告从活跃状态转换为归档状态，使其不再显示在常规公告列表中，但仍保留在系统中以供历史查询。该逻辑确保只有具有相应权限的用户（如系统管理员、部门管理员或公告原作者）才能执行归档操作，并自动记录归档时间和操作人信息。归档后的公告无法再被编辑或重新发布，只能查看或删除，从而维护公告生命周期的完整性和数据的一致性。

### 功能要点

- **权限控制与验证**：归档操作必须经过严格的权限验证，确保只有系统管理员、部门管理员或公告原作者才能执行归档操作。系统会检查当前用户的角色和权限，以及与目标公告的关联关系，防止未授权用户对公告进行归档操作，保障数据安全和操作合规性。

### 逻辑签名

```naturalts path="app.logics.archiveNotice.ts"
$Logic({
    description: '归档通知公告',
    directory: 'office_automation(办公自动化)'
})
export declare function archiveNotice(noticeId: Integer): app.dataSources.defaultDS.entities.NoticeAnnouncement;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| noticeId | 公告ID | Integer | 需要归档的通知公告的唯一标识符 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 归档结果 | app.dataSources.defaultDS.entities.NoticeAnnouncement | 归档后的通知公告实体，包含更新后的状态和其他属性信息 |

### 被前端调用

- **通知公告（noticeAnnouncement）**：在通知公告管理页面中，用户可以通过点击已发布公告右侧的"归档"按钮来调用此服务端逻辑，将选中的公告从活跃状态转换为归档状态，使其从正常公告列表中移除，仅在归档状态筛选下可见。

### 依赖的枚举、实体

- **数据建模-实体-通知公告**：[办公自动化-实体-通知公告（NoticeAnnouncement）](specs/001-bootdo-management-system/plan/data-model/entity-NoticeAnnouncement.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力
