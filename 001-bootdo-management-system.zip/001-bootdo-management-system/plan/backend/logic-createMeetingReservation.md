# 通用领域服务-创建会议预约（createMeetingReservation）

- **生成时间**：2026-03-25

## 创建会议预约（createMeetingReservation）

### 功能概述

创建会议预约服务端逻辑负责处理用户提交的会议预约请求，实现会议信息的创建和存储功能。该逻辑接收包含会议标题、议程内容、组织者ID、开始时间、结束时间和地点等必要信息的输入参数，首先验证会议时间的有效性（确保结束时间晚于开始时间），然后检查是否存在时间冲突（同一时间段内相同地点是否已有其他会议），在通过所有验证后将会议信息持久化到数据库中，并返回创建成功的会议记录。此逻辑作为会议管理功能的核心组成部分，确保了会议数据的一致性和完整性，为用户提供可靠的会议预约服务。

### 功能要点

- **会议信息验证**：系统必须对用户提交的会议信息进行完整验证，包括必填字段检查（会议标题、组织者ID、开始时间和结束时间不能为空）、时间逻辑验证（结束时间必须晚于开始时间）以及组织者身份验证（确保organizerId对应有效的系统账户）。只有当所有验证条件都满足时，才能继续执行后续的创建流程，否则应返回相应的错误信息提示用户修正。

- **时间冲突检测**：在创建会议预约前，系统必须执行时间冲突检测，查询数据库中是否存在与新会议在同一时间段（开始时间至结束时间）且在同一地点的其他会议记录。如果检测到冲突，系统应拒绝创建请求并返回明确的冲突提示，告知用户该时间段和地点已被占用，建议选择其他时间或地点。

- **数据持久化与返回**：通过所有验证和冲突检测后，系统将会议信息保存到MeetingReservation实体对应的数据库表中，自动生成主键ID和其他系统字段（如创建时间、更新时间、创建人等），并将完整的会议记录作为响应返回给前端。返回的数据应包含所有会议字段，确保前端能够正确显示新创建的会议信息。

### 逻辑签名

```naturalts path="app.logics.createMeetingReservation.ts"
$Logic({
    description: '创建会议预约',
    directory: 'office_automation(办公自动化)',
    transactional: true
})
export declare function createMeetingReservation(
  title: String,
  agenda: String,
  organizerId: Integer,
  startTime: DateTime,
  endTime: DateTime,
  location: String
): app.dataSources.defaultDS.entities.MeetingReservation;
```

### 被前端调用

- **会议管理（meetingReservation）**：在会议管理页面中，当用户点击"新建会议"按钮并填写完会议信息后，前端调用此服务端逻辑来创建新的会议预约。该逻辑负责处理会议创建请求，验证输入数据，检查时间冲突，并将会议信息保存到数据库，实现会议预约的核心业务功能。

### 依赖的枚举、实体

- **数据建模-实体-会议预约**：[办公自动化-实体-会议预约（MeetingReservation）](specs/001-bootdo-management-system/plan/data-model/entity-MeetingReservation.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无外部能力依赖