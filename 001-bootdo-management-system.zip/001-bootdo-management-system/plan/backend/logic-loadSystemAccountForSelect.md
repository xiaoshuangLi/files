# 权限中心-获取系统账户选择列表（loadSystemAccountForSelect）

- **生成时间**：2026-03-25

## 获取系统账户选择列表（loadSystemAccountForSelect）

### 功能概述

该服务端逻辑提供系统账户的选择列表数据，主要用于前端页面中的下拉选择组件。在调整申请功能页面中，用户需要选择申请人进行筛选查询，此接口返回所有可用的系统账户信息，包括用户名、全名和邮箱等关键字段，便于用户快速定位和选择目标账户。接口支持基本的分页和状态过滤功能，确保在大量用户数据场景下的性能表现，并且只返回状态为"正常"的活跃账户，避免禁用账户出现在选择列表中影响用户体验。

### 功能要点

- **提供系统账户选择数据**：返回系统中所有状态为"正常"的活跃账户列表，包含id、username、fullName、email等核心字段，用于前端下拉选择组件的数据源。接口确保只返回有效的、可使用的账户信息，排除已禁用或异常状态的账户，保证数据的准确性和实用性。
- **支持基础筛选和分页**：虽然主要用途是提供选择列表，但接口仍支持基本的分页参数（page、pageSize）以应对大量用户数据的场景，同时可根据用户名或全名进行模糊搜索，提升用户在大量账户中查找特定账户的效率。默认情况下返回前100条记录，满足大多数选择场景的需求。

### 逻辑签名

```naturalts path="app.logics.loadSystemAccountForSelect.ts"
$Logic({
    description: '获取系统账户选择列表',
    directory: 'permission_center(权限中心)'
})
export declare function loadSystemAccountForSelect(page?: Integer, pageSize?: Integer, search?: String): { list: Array<{ id: Integer, username: String, fullName: String, email: String }>, total: Integer };
```

### 被前端调用

- **调整申请（adjustmentApplication）**：在调整申请页面的查询筛选区域，用户可以通过下拉选择框选择申请人进行筛选。该页面调用此服务端逻辑获取所有可用的系统账户列表，供用户选择作为筛选条件，从而实现基于申请人的调整申请记录查询功能。

### 依赖的枚举、实体

- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无匹配内容

