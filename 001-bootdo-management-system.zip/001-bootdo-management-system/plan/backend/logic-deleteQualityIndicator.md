# 质量管理-删除质量指标（deleteQualityIndicator）

- **生成时间**：2026-03-25

## 删除质量指标（deleteQualityIndicator）

### 功能概述

删除质量指标服务端逻辑用于从系统中移除指定的质量指标记录。该功能允许质量管理员根据业务需求删除不再需要的质量指标数据，确保质量管理数据的准确性和时效性。删除操作会永久移除质量指标实体及其相关数据，但会保留操作日志以满足审计要求。该逻辑通过验证用户权限确保只有授权用户才能执行删除操作，并在删除前检查是否存在依赖关系，防止误删关键数据。删除操作完成后，系统会自动更新相关统计数据，保持数据一致性。

### 功能要点

- **安全删除机制**：删除质量指标时，系统会先验证当前用户是否具有删除权限，确保只有质量管理员或系统管理员能够执行此操作。同时，系统会检查待删除的质量指标是否存在关联的整改任务或检验报告，如果存在强依赖关系，则阻止删除操作并提示用户先处理依赖项，避免数据不一致问题。删除操作会记录详细的操作日志，包括操作人、操作时间和被删除的数据ID，满足系统审计和追溯需求。

### 逻辑签名

```naturalts path="app.logics.deleteQualityIndicator.ts"
$Logic({
    description: '删除质量指标',
    directory: 'quality_management(质量管理)',
    transactional: true
})
export declare function deleteQualityIndicator(id: Integer): Boolean;
```

### 被前端调用

- **质量指标（qualityIndicator）**：质量管理员在质量指标管理页面中选择要删除的质量指标记录，点击删除按钮后，前端调用此服务端逻辑执行删除操作。该逻辑实现删除质量指标的核心业务功能，确保数据被正确移除且系统状态保持一致。

### 依赖的枚举、实体

- **质量管理-实体-质量指标**：[质量管理-实体-质量指标（QualityIndicator）](specs/001-bootdo-management-system/plan/data-model/entity-QualityIndicator.md)

### 依赖的外部能力

无