# 工作流引擎-获取流程监控列表（getProcessMonitoringList）

- **生成时间**：2026-03-25

## 获取流程监控列表（getProcessMonitoringList）

### 功能概述

获取流程监控列表服务端逻辑提供对工作流引擎中流程监控数据的分页查询功能，支持根据流程实例ID、监控时间范围等条件进行筛选，并返回包含流程监控记录及其关联的流程实例和流程定义信息的完整数据集。该逻辑通过关联查询ProcessMonitoring、ProcessInstance和ProcessDefinition三个实体，为前端流程监控页面提供全面的数据支撑，包括流程实例的基本信息、流程定义的名称以及详细的性能指标数据。用户可以通过该接口获取特定时间段内的流程监控记录，分析工作流执行效率，识别性能瓶颈，并为流程优化提供数据依据。同时支持按监控时间进行排序，确保数据展示的有序性和可读性。

### 功能要点

- **分页查询与筛选功能**：支持标准的分页参数（页码、每页条数）以及多维度筛选条件，包括流程实例ID和监控时间范围。用户可以根据实际需求灵活组合查询条件，精确获取所需的流程监控数据子集，避免一次性加载过多数据导致的性能问题，提升系统响应速度和用户体验。
- **关联数据整合**：在返回结果中不仅包含流程监控实体本身的数据，还整合了关联的流程实例和流程定义的关键信息。这种数据整合方式减少了前端多次请求的开销，提供了更完整的业务上下文，使用户能够在一个视图中同时了解监控数据、实例状态和流程定义名称等关键信息。
- **性能指标解析支持**：虽然性能指标在数据库中以JSON字符串格式存储，但该逻辑确保返回的数据结构清晰，便于前端进行后续的解析和可视化展示。支持对性能指标中的关键字段进行提取和格式化，为流程性能分析和瓶颈识别提供便利的数据基础。

### 逻辑签名

```naturalts path="app.logics.getProcessMonitoringList.ts"
$Logic({
    description: '获取流程监控列表',
    directory: 'workflow_engine(工作流引擎)'
})
export declare function getProcessMonitoringList(page: Integer, size: Integer, sort: String, order: String, processInstanceId?: Integer, monitoredAtStart?: DateTime, monitoredAtEnd?: DateTime): { list: List<{ processMonitoring: app.dataSources.defaultDS.entities.ProcessMonitoring, processInstance: app.dataSources.defaultDS.entities.ProcessInstance, processDefinition: app.dataSources.defaultDS.entities.ProcessDefinition }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 分页查询的页码，从1开始 |
| size | 每页条数 | Integer | 每页返回的记录数量 |
| sort | 排序字段 | String | 排序的字段名，默认为"monitoredAt" |
| order | 排序顺序 | String | 排序顺序，"asc"表示升序，"desc"表示降序 |
| processInstanceId | 流程实例ID | Integer | 筛选特定流程实例的监控数据，可选参数 |
| monitoredAtStart | 监控开始时间 | DateTime | 监控时间范围的开始时间，可选参数 |
| monitoredAtEnd | 监控结束时间 | DateTime | 监控时间范围的结束时间，可选参数 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 流程监控列表 | List<{ processMonitoring: app.dataSources.defaultDS.entities.ProcessMonitoring, processInstance: app.dataSources.defaultDS.entities.ProcessInstance, processDefinition: app.dataSources.defaultDS.entities.ProcessDefinition }> | 流程监控记录列表，每个列表项包含流程监控实体、关联的流程实例实体和流程定义实体 |
| total | 总条数 | Integer | 符合查询条件的总记录数 |

### 被前端调用

- **流程监控（processMonitoring）**：流程监控页面通过调用此服务端逻辑获取分页的流程监控数据列表，支持用户按流程实例ID和时间范围进行筛选，并展示监控记录的详细信息，包括性能指标、监控时间以及关联的流程实例和定义信息。

### 依赖的枚举、实体

- **数据建模-实体-流程监控**：[工作流引擎-实体-流程监控（ProcessMonitoring）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessMonitoring.md)
- **数据建模-实体-流程实例**：[工作流引擎-实体-流程实例（ProcessInstance）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessInstance.md)
- **数据建模-实体-流程定义**：[工作流引擎-实体-流程定义（ProcessDefinition）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessDefinition.md)

### 依赖的外部能力

无