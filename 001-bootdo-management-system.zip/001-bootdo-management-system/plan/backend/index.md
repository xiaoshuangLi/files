# 领域服务

## 获取验收标准列表（getAcceptanceStandardsList）

- **关联文档**：[质量管理-获取验收标准列表（getAcceptanceStandardsList）](specs/001-bootdo-management-system/plan/backend/logic-getAcceptanceStandardsList.md)

## 分页查询调整申请列表（loadAdjustmentApplicationList）

- **关联文档**：[预算管理-分页查询调整申请列表（loadAdjustmentApplicationList）](specs/001-bootdo-management-system/plan/backend/logic-loadAdjustmentApplicationList.md)

## 获取预算分配选择列表（loadBudgetAllocationForSelect）

- **关联文档**：[预算管理-获取预算分配选择列表（loadBudgetAllocationForSelect）](specs/001-bootdo-management-system/plan/backend/logic-loadBudgetAllocationForSelect.md)

## 获取系统账户选择列表（loadSystemAccountForSelect）

- **关联文档**：[权限中心-获取系统账户选择列表（loadSystemAccountForSelect）](specs/001-bootdo-management-system/plan/backend/logic-loadSystemAccountForSelect.md)

## 获取分析报告列表（getAnalysisReportList）

- **关联文档**：[预算管理-获取分析报告列表（getAnalysisReportList）](specs/001-bootdo-management-system/plan/backend/logic-getAnalysisReportList.md)

## 获取分析报告详情（getAnalysisReportDetail）

- **关联文档**：[预算管理-获取分析报告详情（getAnalysisReportDetail）](specs/001-bootdo-management-system/plan/backend/logic-getAnalysisReportDetail.md)

## 生成分析报告（generateAnalysisReport）

- **关联文档**：[预算管理-生成分析报告（generateAnalysisReport）](specs/001-bootdo-management-system/plan/backend/logic-generateAnalysisReport.md)

## 导出分析报告（exportAnalysisReport）

- **关联文档**：[预算管理-导出分析报告（exportAnalysisReport）](specs/001-bootdo-management-system/plan/backend/logic-exportAnalysisReport.md)

## 计算年薪总额（calculateAnnualSalaryTotal）

- **关联文档**：[薪资管理-计算年薪总额（calculateAnnualSalaryTotal）](specs/001-bootdo-management-system/plan/backend/logic-calculateAnnualSalaryTotal.md)

## 查询年薪总额列表（queryAnnualSalaryTotalList）

- **关联文档**：[薪资管理-查询年薪总额列表（queryAnnualSalaryTotalList）](specs/001-bootdo-management-system/plan/backend/logic-queryAnnualSalaryTotalList.md)

## 批量操作审批流程（batchOperateApprovalProcess）

- **关联文档**：[工作流引擎-批量操作审批流程（batchOperateApprovalProcess）](specs/001-bootdo-management-system/plan/backend/logic-batchOperateApprovalProcess.md)

## 创建工作流（createWorkflow）

- **关联文档**：[工作流引擎-创建工作流（createWorkflow）](specs/001-bootdo-management-system/plan/backend/logic-createWorkflow.md)

## 更新工作流（updateWorkflow）

- **关联文档**：[工作流引擎-更新流程定义（updateWorkflow）](specs/001-bootdo-management-system/plan/backend/logic-updateWorkflow.md)

## 删除工作流（deleteWorkflow）

- **关联文档**：[工作流引擎-删除工作流（deleteWorkflow）](specs/001-bootdo-management-system/plan/backend/logic-deleteWorkflow.md)

## 加载工作流列表（loadWorkflowList）

- **关联文档**：[工作流引擎-加载工作流列表（loadWorkflowList）](specs/001-bootdo-management-system/plan/backend/logic-loadWorkflowList.md)

## 加载工作流详情（loadWorkflowDetail）

- **关联文档**：[工作流引擎-加载工作流详情（loadWorkflowDetail）](specs/001-bootdo-management-system/plan/backend/logic-loadWorkflowDetail.md)

## 查询审批流程列表（queryApprovalWorkflowList）

- **关联文档**：[预算管理-查询审批流程列表（queryApprovalWorkflowList）](specs/001-bootdo-management-system/plan/backend/logic-queryApprovalWorkflowList.md)

## 获取审批流程详情（getApprovalWorkflowDetail）

- **关联文档**：[预算管理-获取审批流程详情（getApprovalWorkflowDetail）](specs/001-bootdo-management-system/plan/backend/logic-getApprovalWorkflowDetail.md)

## 创建审批流程（createApprovalWorkflow）

- **关联文档**：[预算管理-创建审批流程（createApprovalWorkflow）](specs/001-bootdo-management-system/plan/backend/logic-createApprovalWorkflow.md)

## 更新审批流程（updateApprovalWorkflow）

- **关联文档**：[通用领域服务-更新审批流程（updateApprovalWorkflow）](specs/001-bootdo-management-system/plan/backend/logic-updateApprovalWorkflow.md)

## 删除审批流程（deleteApprovalWorkflow）

- **关联文档**：[预算管理-删除审批流程（deleteApprovalWorkflow）](specs/001-bootdo-management-system/plan/backend/logic-deleteApprovalWorkflow.md)

## 查询流程定义列表（queryProcessDefinitionList）

- **关联文档**：[工作流引擎-查询流程定义列表（queryProcessDefinitionList）](specs/001-bootdo-management-system/plan/backend/logic-queryProcessDefinitionList.md)

## 获取文章列表（getArticleContentList）

- **关联文档**：[内容管理-获取文章内容列表（getArticleContentList）](specs/001-bootdo-management-system/plan/backend/logic-getArticleContentList.md)

## 提交文章审核（submitArticleForReview）

- **关联文档**：[内容管理-提交文章审核（submitArticleForReview）](specs/001-bootdo-management-system/plan/backend/logic-submitArticleForReview.md)

## 审核文章（reviewArticleContent）

- **关联文档**：[内容管理-审核文章（reviewArticleContent）](specs/001-bootdo-management-system/plan/backend/logic-reviewArticleContent.md)

## 获取文章统计数据（getArticleContentStatistics）

- **关联文档**：[内容管理-获取文章统计数据（getArticleContentStatistics）](specs/001-bootdo-management-system/plan/backend/logic-getArticleContentStatistics.md)

## 加载文章列表（loadArticleList）

- **关联文档**：[内容管理-加载文章列表（loadArticleList）](specs/001-bootdo-management-system/plan/backend/logic-loadArticleList.md)

## 加载文章类型选项（loadArticleTypeOptions）

- **关联文档**：[内容管理-加载文章类型选项（loadArticleTypeOptions）](specs/001-bootdo-management-system/plan/backend/logic-loadArticleTypeOptions.md)

## 加载文章状态选项（loadArticleStatusOptions）

- **关联文档**：[内容管理-加载文章状态选项（loadArticleStatusOptions）](specs/001-bootdo-management-system/plan/backend/logic-loadArticleStatusOptions.md)

## 查询附件列表（queryAttachmentList）

- **关联文档**：[内容管理-查询附件列表（queryAttachmentList）](specs/001-bootdo-management-system/plan/backend/logic-queryAttachmentList.md)

## 上传附件文件（uploadAttachmentFile）

- **关联文档**：[内容管理-上传附件文件（uploadAttachmentFile）](specs/001-bootdo-management-system/plan/backend/logic-uploadAttachmentFile.md)

## 删除附件文件（deleteAttachmentFile）

- **关联文档**：[内容管理-删除附件文件（deleteAttachmentFile）](specs/001-bootdo-management-system/plan/backend/logic-deleteAttachmentFile.md)

## 下载附件文件（downloadAttachmentFile）

- **关联文档**：[内容管理-下载附件文件（downloadAttachmentFile）](specs/001-bootdo-management-system/plan/backend/logic-downloadAttachmentFile.md)

## 分配预算额度（allocateBudgetAmount）

- **关联文档**：[预算管理-分配预算额度（allocateBudgetAmount）](specs/001-bootdo-management-system/plan/backend/logic-allocateBudgetAmount.md)

## 更新预算分配（updateBudgetAllocation）

- **关联文档**：[预算管理-更新预算分配（updateBudgetAllocation）](specs/001-bootdo-management-system/plan/backend/logic-updateBudgetAllocation.md)

## 删除预算分配（deleteBudgetAllocation）

- **关联文档**：[预算管理-删除预算分配（deleteBudgetAllocation）](specs/001-bootdo-management-system/plan/backend/logic-deleteBudgetAllocation.md)

## 加载预算分配列表（loadBudgetAllocations）

- **关联文档**：[预算管理-加载预算分配列表（loadBudgetAllocations）](specs/001-bootdo-management-system/plan/backend/logic-loadBudgetAllocations.md)

## 加载预算分配详情（loadBudgetAllocationDetail）

- **关联文档**：[预算管理-加载预算分配详情（loadBudgetAllocationDetail）](specs/001-bootdo-management-system/plan/backend/logic-loadBudgetAllocationDetail.md)

## 获取预算周期列表（getBudgetCycleList）

- **关联文档**：[预算管理-获取预算周期列表（getBudgetCycleList）](specs/001-bootdo-management-system/plan/backend/logic-getBudgetCycleList.md)

## 创建预算周期（createBudgetCycle）

- **关联文档**：[预算管理-创建预算周期（createBudgetCycle）](specs/001-bootdo-management-system/plan/backend/logic-createBudgetCycle.md)

## 更新预算周期（updateBudgetCycle）

- **关联文档**：[预算管理-更新预算周期（updateBudgetCycle）](specs/001-bootdo-management-system/plan/backend/logic-updateBudgetCycle.md)

## 删除预算周期（deleteBudgetCycle）

- **关联文档**：[预算管理-删除预算周期（deleteBudgetCycle）](specs/001-bootdo-management-system/plan/backend/logic-deleteBudgetCycle.md)

## 获取预算周期详情（getBudgetCycleDetail）

- **关联文档**：[预算管理-获取预算周期详情（getBudgetCycleDetail）](specs/001-bootdo-management-system/plan/backend/logic-getBudgetCycleDetail.md)

## 获取预算类型列表（getBudgetTypeList）

- **关联文档**：[通用领域服务-获取预算类型列表（getBudgetTypeList）](specs/001-bootdo-management-system/plan/backend/logic-getBudgetTypeList.md)

## 创建预算类型（createBudgetType）

- **关联文档**：[预算管理-创建预算类型（createBudgetType）](specs/001-bootdo-management-system/plan/backend/logic-createBudgetType.md)

## 更新预算类型（updateBudgetType）

- **关联文档**：[预算管理-更新预算类型（updateBudgetType）](specs/001-bootdo-management-system/plan/backend/logic-updateBudgetType.md)

## 删除预算类型（deleteBudgetType）

- **关联文档**：[预算管理-删除预算类型（deleteBudgetType）](specs/001-bootdo-management-system/plan/backend/logic-deleteBudgetType.md)

## 获取预算类型详情（getBudgetTypeDetail）

- **关联文档**：[预算管理-获取预算类型详情（getBudgetTypeDetail）](specs/001-bootdo-management-system/plan/backend/logic-getBudgetTypeDetail.md)

## 获取栏目树形结构（getColumnStructureTree）

- **关联文档**：[内容管理-获取栏目结构树（getColumnStructureTree）](specs/001-bootdo-management-system/plan/backend/logic-getColumnStructureTree.md)

## 创建栏目（createColumnStructure）

- **关联文档**：[内容管理-创建栏目结构（createColumnStructure）](specs/001-bootdo-management-system/plan/backend/logic-createColumnStructure.md)

## 更新栏目（updateColumnStructure）

- **关联文档**：[内容管理-更新栏目结构（updateColumnStructure）](specs/001-bootdo-management-system/plan/backend/logic-updateColumnStructure.md)

## 删除栏目（deleteColumnStructure）

- **关联文档**：[内容管理-删除栏目结构（deleteColumnStructure）](specs/001-bootdo-management-system/plan/backend/logic-deleteColumnStructure.md)

## 验证栏目名称唯一性（validateColumnNameUniqueness）

- **关联文档**：[内容管理-验证栏目名称唯一性（validateColumnNameUniqueness）](specs/001-bootdo-management-system/plan/backend/logic-validateColumnNameUniqueness.md)

## 获取评论列表（getCommentList）

- **关联文档**：[内容管理-获取评论列表（getCommentList）](specs/001-bootdo-management-system/plan/backend/logic-getCommentList.md)

## 审核评论（approveComment）

- **关联文档**：[内容管理-审核评论（approveComment）](specs/001-bootdo-management-system/plan/backend/logic-approveComment.md)

## 删除评论（deleteComment）

- **关联文档**：[内容管理-删除评论（deleteComment）](specs/001-bootdo-management-system/plan/backend/logic-deleteComment.md)

## 添加系统回复（addSystemReply）

- **关联文档**：[内容管理-添加系统回复（addSystemReply）](specs/001-bootdo-management-system/plan/backend/logic-addSystemReply.md)

## 获取评论详情（getCommentDetail）

- **关联文档**：[内容管理-获取评论详情（getCommentDetail）](specs/001-bootdo-management-system/plan/backend/logic-getCommentDetail.md)

## 查询薪酬档级列表（queryCompensationGradeList）

- **关联文档**：[薪资管理-查询薪酬档级列表（queryCompensationGradeList）](specs/001-bootdo-management-system/plan/backend/logic-queryCompensationGradeList.md)

## 保存薪酬档级（saveCompensationGrade）

- **关联文档**：[薪资管理-保存薪酬档级（saveCompensationGrade）](specs/001-bootdo-management-system/plan/backend/logic-saveCompensationGrade.md)

## 删除薪酬档级（deleteCompensationGrade）

- **关联文档**：[薪资管理-删除薪酬档级（deleteCompensationGrade）](specs/001-bootdo-management-system/plan/backend/logic-deleteCompensationGrade.md)

## 获取合规检查列表（getComplianceInspectionList）

- **关联文档**：[环保管理-获取合规检查列表（getComplianceInspectionList）](specs/001-bootdo-management-system/plan/backend/logic-getComplianceInspectionList.md)

## 创建合规检查（createComplianceInspection）

- **关联文档**：[环保管理-创建合规检查（createComplianceInspection）](specs/001-bootdo-management-system/plan/backend/logic-createComplianceInspection.md)

## 更新合规检查（updateComplianceInspection）

- **关联文档**：[环保管理-更新合规检查（updateComplianceInspection）](specs/001-bootdo-management-system/plan/backend/logic-updateComplianceInspection.md)

## 删除合规检查（deleteComplianceInspection）

- **关联文档**：[环保管理-删除合规检查（deleteComplianceInspection）](specs/001-bootdo-management-system/plan/backend/logic-deleteComplianceInspection.md)

## 获取检查员列表（getInspectorList）

- **关联文档**：[环保管理-获取检查员列表（getInspectorList）](specs/001-bootdo-management-system/plan/backend/logic-getInspectorList.md)

## 加载内容权限列表（loadContentPermissionList）

- **关联文档**：[内容管理-加载内容权限列表（loadContentPermissionList）](specs/001-bootdo-management-system/plan/backend/logic-loadContentPermissionList.md)

## 创建内容权限配置（createContentPermission）

- **关联文档**：[内容管理-创建内容权限（createContentPermission）](specs/001-bootdo-management-system/plan/backend/logic-createContentPermission.md)

## 更新内容权限配置（updateContentPermission）

- **关联文档**：[权限中心-更新内容权限（updateContentPermission）](specs/001-bootdo-management-system/plan/backend/logic-updateContentPermission.md)

## 删除内容权限配置（deleteContentPermission）

- **关联文档**：[权限中心-删除内容权限（deleteContentPermission）](specs/001-bootdo-management-system/plan/backend/logic-deleteContentPermission.md)

## 获取系统角色列表（getSystemRoleList）

- **关联文档**：[系统管理-获取系统角色列表（getSystemRoleList）](specs/001-bootdo-management-system/plan/backend/logic-getSystemRoleList.md)

## 获取内容类型列表（getContentTypeList）

- **关联文档**：[内容管理-获取内容类型列表（getContentTypeList）](specs/001-bootdo-management-system/plan/backend/logic-getContentTypeList.md)

## 获取内容统计数据（getContentStatistics）

- **关联文档**：[内容管理-获取内容统计信息（getContentStatistics）](specs/001-bootdo-management-system/plan/backend/logic-getContentStatistics.md)

## 获取热门文章排行（getTopArticles）

- **关联文档**：[内容管理-获取热门文章排行（getTopArticles）](specs/001-bootdo-management-system/plan/backend/logic-getTopArticles.md)

## 导出统计数据（exportStatisticsData）

- **关联文档**：[内容管理-导出统计数据（exportStatisticsData）](specs/001-bootdo-management-system/plan/backend/logic-exportStatisticsData.md)

## 创建分包商合同（createSubcontractorContract）

- **关联文档**：[分包商管理-创建分包商合同（createSubcontractorContract）](specs/001-bootdo-management-system/plan/backend/logic-createSubcontractorContract.md)

## 查询分包商合同列表（querySubcontractorContracts）

- **关联文档**：[分包商管理-查询分包商合同列表（querySubcontractorContracts）](specs/001-bootdo-management-system/plan/backend/logic-querySubcontractorContracts.md)

## 更新分包商合同（updateSubcontractorContract）

- **关联文档**：[分包商管理-更新分包商合同（updateSubcontractorContract）](specs/001-bootdo-management-system/plan/backend/logic-updateSubcontractorContract.md)

## 删除分包商合同（deleteSubcontractorContract）

- **关联文档**：[分包商管理-删除分包商合同（deleteSubcontractorContract）](specs/001-bootdo-management-system/plan/backend/logic-deleteSubcontractorContract.md)

## 导出分包商合同数据（exportSubcontractorContractData）

- **关联文档**：[分包商管理-导出分包商合同数据（exportSubcontractorContractData）](specs/001-bootdo-management-system/plan/backend/logic-exportSubcontractorContractData.md)

## 获取用户菜单权限（getUserMenuPermissions）

- **关联文档**：[权限中心-获取用户菜单权限（getUserMenuPermissions）](specs/001-bootdo-management-system/plan/backend/logic-getUserMenuPermissions.md)

## 获取全局系统配置（getGlobalSystemConfiguration）

- **关联文档**：[通用领域服务-获取全局系统配置（getGlobalSystemConfiguration）](specs/001-bootdo-management-system/plan/backend/logic-getGlobalSystemConfiguration.md)

## 获取用户未读消息数量（getUserUnreadMessageCount）

- **关联文档**：[通用领域服务-获取用户未读消息数量（getUserUnreadMessageCount）](specs/001-bootdo-management-system/plan/backend/logic-getUserUnreadMessageCount.md)

## 获取部门表格视图（LcapGetDepartmentTableView）

- **关联文档**：[权限中心-获取部门表格视图数据（LcapGetDepartmentTableView）](specs/001-bootdo-management-system/plan/backend/logic-LcapGetDepartmentTableView.md)

## 创建根部门（LcapCreateRootDept）

- **关联文档**：[权限中心-创建根部门（LcapCreateRootDept）](specs/001-bootdo-management-system/plan/backend/logic-LcapCreateRootDept.md)

## 批量删除部门（LcapBatchDeleteDepartment）

- **关联文档**：[权限中心-批量删除部门（LcapBatchDeleteDepartment）](specs/001-bootdo-management-system/plan/backend/logic-LcapBatchDeleteDepartment.md)

## 批量添加部门用户（LcapBatchAddDeptUser）

- **关联文档**：[权限中心-批量添加部门用户（LcapBatchAddDeptUser）](specs/001-bootdo-management-system/plan/backend/logic-LcapBatchAddDeptUser.md)

## 设置部门负责人（LcapSetDeptLeader）

- **关联文档**：[权限中心-设置部门负责人（LcapSetDeptLeader）](specs/001-bootdo-management-system/plan/backend/logic-LcapSetDeptLeader.md)

## 获取部门列表（LcapGetDeptList）

- **关联文档**：[权限中心-获取部门列表（LcapGetDeptList）](specs/001-bootdo-management-system/plan/backend/logic-LcapGetDeptList.md)

## 根据部门标识获取部门（LcapGetDept）

- **关联文档**：[权限中心-根据部门标识获取部门（LcapGetDept）](specs/001-bootdo-management-system/plan/backend/logic-LcapGetDept.md)

## 获取部门用户列表（LcapGetDeptUsers）

- **关联文档**：[权限中心-获取部门用户列表（LcapGetDeptUsers）](specs/001-bootdo-management-system/plan/backend/logic-LcapGetDeptUsers.md)

## 获取子部门列表（LcapGetChildDepts）

- **关联文档**：[权限中心-获取子部门列表（LcapGetChildDepts）](specs/001-bootdo-management-system/plan/backend/logic-LcapGetChildDepts.md)

## 获取部门及其所有子部门列表（LcapGetDepts）

- **关联文档**：[权限中心-获取部门及其所有子部门列表（LcapGetDepts）](specs/001-bootdo-management-system/plan/backend/logic-LcapGetDepts.md)

## 获取第二级父部门（LcapGetSecondParentDept）

- **关联文档**：[权限中心-获取第二级父部门（LcapGetSecondParentDept）](specs/001-bootdo-management-system/plan/backend/logic-LcapGetSecondParentDept.md)

## 部门名称搜索（LcapSearchDepts）

- **关联文档**：[权限中心-部门名称搜索（LcapSearchDepts）](specs/001-bootdo-management-system/plan/backend/logic-LcapSearchDepts.md)

## 部门成员搜索（LcapSearchDeptUsers）

- **关联文档**：[权限中心-部门成员搜索（LcapSearchDeptUsers）](specs/001-bootdo-management-system/plan/backend/logic-LcapSearchDeptUsers.md)

## 创建部门（LcapCreateDepartment）

- **关联文档**：[权限中心-创建部门（LcapCreateDepartment）](specs/001-bootdo-management-system/plan/backend/logic-LcapCreateDepartment.md)

## 更新部门（LcapUpdateDepartment）

- **关联文档**：[权限中心-更新部门（LcapUpdateDepartment）](specs/001-bootdo-management-system/plan/backend/logic-LcapUpdateDepartment.md)

## 加载部门设置主管选择列表（LcapLoadDeptSetLeaderSelect）

- **关联文档**：[权限中心-加载部门设置主管选择列表（LcapLoadDeptSetLeaderSelect）](specs/001-bootdo-management-system/plan/backend/logic-LcapLoadDeptSetLeaderSelect.md)

## 加载部门添加用户选择列表（LcapLoadDeptAddUserSelect）

- **关联文档**：[权限中心-加载部门添加用户选择列表（LcapLoadDeptAddUserSelect）](specs/001-bootdo-management-system/plan/backend/logic-LcapLoadDeptAddUserSelect.md)

## 批量移除部门用户（LcapBatchRemoveDeptUser）

- **关联文档**：[权限中心-批量移除部门用户（LcapBatchRemoveDeptUser）](specs/001-bootdo-management-system/plan/backend/logic-LcapBatchRemoveDeptUser.md)

## 取消部门负责人（LcapCancelDeptLeader）

- **关联文档**：[权限中心-取消部门负责人（LcapCancelDeptLeader）](specs/001-bootdo-management-system/plan/backend/logic-LcapCancelDeptLeader.md)

## 批量更新用户部门（LcapBatchUpdateDeptUser）

- **关联文档**：[权限中心-批量更新用户部门（LcapBatchUpdateDeptUser）](specs/001-bootdo-management-system/plan/backend/logic-LcapBatchUpdateDeptUser.md)

## 查询字典列表（queryDictionaryList）

- **关联文档**：[系统管理-查询字典列表（queryDictionaryList）](specs/001-bootdo-management-system/plan/backend/logic-queryDictionaryList.md)

## 保存字典项（saveDictionaryItem）

- **关联文档**：[系统管理-保存字典项（saveDictionaryItem）](specs/001-bootdo-management-system/plan/backend/logic-saveDictionaryItem.md)

## 删除字典项（deleteDictionaryItem）

- **关联文档**：[系统管理-删除字典项（deleteDictionaryItem）](specs/001-bootdo-management-system/plan/backend/logic-deleteDictionaryItem.md)

## 导出字典数据（exportDictionaryData）

- **关联文档**：[通用领域服务-导出数据字典（exportDictionaryData）](specs/001-bootdo-management-system/plan/backend/logic-exportDictionaryData.md)

## 创建文档协作（createDocumentCollaboration）

- **关联文档**：[通用领域服务-创建文档协作（createDocumentCollaboration）](specs/001-bootdo-management-system/plan/backend/logic-createDocumentCollaboration.md)

## 更新文档协作（updateDocumentCollaboration）

- **关联文档**：[办公自动化-更新文档协作（updateDocumentCollaboration）](specs/001-bootdo-management-system/plan/backend/logic-updateDocumentCollaboration.md)

## 获取文档协作列表（getDocumentCollaborationList）

- **关联文档**：[办公自动化-获取文档协作列表（getDocumentCollaborationList）](specs/001-bootdo-management-system/plan/backend/logic-getDocumentCollaborationList.md)

## 获取文档协作详情（getDocumentCollaborationDetail）

- **关联文档**：[通用领域服务-获取文档协作详情（getDocumentCollaborationDetail）](specs/001-bootdo-management-system/plan/backend/logic-getDocumentCollaborationDetail.md)

## 删除文档协作（deleteDocumentCollaboration）

- **关联文档**：[通用领域服务-删除文档协作（deleteDocumentCollaboration）](specs/001-bootdo-management-system/plan/backend/logic-deleteDocumentCollaboration.md)

## 提交文档审批（submitDocumentForApproval）

- **关联文档**：[办公自动化-提交文档审批（submitDocumentForApproval）](specs/001-bootdo-management-system/plan/backend/logic-submitDocumentForApproval.md)

## 获取文档历史版本（getDocumentHistoryVersions）

- **关联文档**：[办公自动化-获取文档历史版本（getDocumentHistoryVersions）](specs/001-bootdo-management-system/plan/backend/logic-getDocumentHistoryVersions.md)

## 恢复文档历史版本（restoreDocumentVersion）

- **关联文档**：[办公自动化-恢复文档历史版本（restoreDocumentVersion）](specs/001-bootdo-management-system/plan/backend/logic-restoreDocumentVersion.md)

## 添加文档评论（addDocumentComment）

- **关联文档**：[内容管理-添加文档评论（addDocumentComment）](specs/001-bootdo-management-system/plan/backend/logic-addDocumentComment.md)

## 设置文档权限（setDocumentPermissions）

- **关联文档**：[办公自动化-设置文档权限（setDocumentPermissions）](specs/001-bootdo-management-system/plan/backend/logic-setDocumentPermissions.md)

## 发送邮件（sendEmail）

- **关联文档**：[办公自动化-发送邮件（sendEmail）](specs/001-bootdo-management-system/plan/backend/logic-sendEmail.md)

## 获取邮件列表（getEmailList）

- **关联文档**：[办公自动化-获取邮件列表（getEmailList）](specs/001-bootdo-management-system/plan/backend/logic-getEmailList.md)

## 获取邮件详情（getEmailDetail）

- **关联文档**：[办公自动化-获取邮件详情（getEmailDetail）](specs/001-bootdo-management-system/plan/backend/logic-getEmailDetail.md)

## 删除邮件（deleteEmail）

- **关联文档**：[通用领域服务-删除邮件（deleteEmail）](specs/001-bootdo-management-system/plan/backend/logic-deleteEmail.md)

## 管理邮件模板（manageEmailTemplates）

- **关联文档**：[办公自动化-管理邮件模板（manageEmailTemplates）](specs/001-bootdo-management-system/plan/backend/logic-manageEmailTemplates.md)

## 加载邮件列表（loadEmailList）

- **关联文档**：[办公自动化-加载邮件列表（loadEmailList）](specs/001-bootdo-management-system/plan/backend/logic-loadEmailList.md)

## 创建新邮件（createEmail）

- **关联文档**：[办公自动化-创建新邮件（createEmail）](specs/001-bootdo-management-system/plan/backend/logic-createEmail.md)

## 加载邮件详情（loadEmailDetail）

- **关联文档**：[办公自动化-加载邮件详情（loadEmailDetail）](specs/001-bootdo-management-system/plan/backend/logic-loadEmailDetail.md)

## 更新邮件状态（updateEmail）

- **关联文档**：[办公自动化-更新邮件（updateEmail）](specs/001-bootdo-management-system/plan/backend/logic-updateEmail.md)

## 加载邮件模板（loadEmailTemplates）

- **关联文档**：[办公自动化-加载邮件模板（loadEmailTemplates）](specs/001-bootdo-management-system/plan/backend/logic-loadEmailTemplates.md)

## 同步邮件（syncEmails）

- **关联文档**：[办公自动化-同步邮件（syncEmails）](specs/001-bootdo-management-system/plan/backend/logic-syncEmails.md)

## 导出邮件（exportEmails）

- **关联文档**：[通用领域服务-导出邮件（exportEmails）](specs/001-bootdo-management-system/plan/backend/logic-exportEmails.md)

## 导入邮件（importEmails）

- **关联文档**：[通用领域服务-导入邮件（importEmails）](specs/001-bootdo-management-system/plan/backend/logic-importEmails.md)

## 获取邮件统计（getEmailStatistics）

- **关联文档**：[办公自动化-获取邮件统计信息（getEmailStatistics）](specs/001-bootdo-management-system/plan/backend/logic-getEmailStatistics.md)

## 应急预案管理（emergencyPlanManagement）

- **关联文档**：[环保管理-应急预案管理（emergencyPlanManagement）](specs/001-bootdo-management-system/plan/backend/logic-emergencyPlanManagement.md)

## 应急资源分配（emergencyResourceAllocation）

- **关联文档**：[环保管理-应急资源分配（emergencyResourceAllocation）](specs/001-bootdo-management-system/plan/backend/logic-emergencyResourceAllocation.md)

## 应急演练计划管理（emergencyDrillPlanning）

- **关联文档**：[环保管理-应急演练规划（emergencyDrillPlanning）](specs/001-bootdo-management-system/plan/backend/logic-emergencyDrillPlanning.md)

## 加载排放控制列表（loadEmissionControlList）

- **关联文档**：[环保管理-加载排放控制列表（loadEmissionControlList）](specs/001-bootdo-management-system/plan/backend/logic-loadEmissionControlList.md)

## 加载环境监测选择项（loadEnvironmentalMonitoringForSelect）

- **关联文档**：[环保管理-加载环境监测下拉选项（loadEnvironmentalMonitoringForSelect）](specs/001-bootdo-management-system/plan/backend/logic-loadEnvironmentalMonitoringForSelect.md)

## 获取环境监测数据列表（loadEnvironmentalMonitoringList）

- **关联文档**：[环保管理-加载环境监测列表（loadEnvironmentalMonitoringList）](specs/001-bootdo-management-system/plan/backend/logic-loadEnvironmentalMonitoringList.md)

## 获取环境风险评估列表（getEnvironmentalRiskAssessmentList）

- **关联文档**：[环保管理-获取环境风险评估列表（getEnvironmentalRiskAssessmentList）](specs/001-bootdo-management-system/plan/backend/logic-getEnvironmentalRiskAssessmentList.md)

## 创建环境风险评估（createEnvironmentalRiskAssessment）

- **关联文档**：[通用领域服务-创建环境风险评估（createEnvironmentalRiskAssessment）](specs/001-bootdo-management-system/plan/backend/logic-createEnvironmentalRiskAssessment.md)

## 更新环境风险评估（updateEnvironmentalRiskAssessment）

- **关联文档**：[环保管理-更新环境风险评估（updateEnvironmentalRiskAssessment）](specs/001-bootdo-management-system/plan/backend/logic-updateEnvironmentalRiskAssessment.md)

## 删除环境风险评估（deleteEnvironmentalRiskAssessment）

- **关联文档**：[环保管理-删除环境风险评估（deleteEnvironmentalRiskAssessment）](specs/001-bootdo-management-system/plan/backend/logic-deleteEnvironmentalRiskAssessment.md)

## 获取合规检查详情（getComplianceInspectionDetail）

- **关联文档**：[环保管理-获取合规检查详情（getComplianceInspectionDetail）](specs/001-bootdo-management-system/plan/backend/logic-getComplianceInspectionDetail.md)

## 导出环境风险评估报告（exportEnvironmentalRiskAssessmentReport）

- **关联文档**：[环保管理-导出环境风险评估报告（exportEnvironmentalRiskAssessmentReport）](specs/001-bootdo-management-system/plan/backend/logic-exportEnvironmentalRiskAssessmentReport.md)

## 获取分包商评估记录列表（getSubcontractorEvaluationRecords）

- **关联文档**：[分包商管理-获取分包商评估记录（getSubcontractorEvaluationRecords）](specs/001-bootdo-management-system/plan/backend/logic-getSubcontractorEvaluationRecords.md)

## 创建分包商评估记录（createSubcontractorEvaluationRecord）

- **关联文档**：[分包商管理-创建分包商评估记录（createSubcontractorEvaluationRecord）](specs/001-bootdo-management-system/plan/backend/logic-createSubcontractorEvaluationRecord.md)

## 更新分包商评估记录（updateSubcontractorEvaluationRecord）

- **关联文档**：[分包商管理-更新分包商评估记录（updateSubcontractorEvaluationRecord）](specs/001-bootdo-management-system/plan/backend/logic-updateSubcontractorEvaluationRecord.md)

## 删除分包商评估记录（deleteSubcontractorEvaluationRecord）

- **关联文档**：[分包商管理-删除分包商评估记录（deleteSubcontractorEvaluationRecord）](specs/001-bootdo-management-system/plan/backend/logic-deleteSubcontractorEvaluationRecord.md)

## 导出分包商评估记录（exportSubcontractorEvaluationRecords）

- **关联文档**：[分包商管理-导出分包商评估记录（exportSubcontractorEvaluationRecords）](specs/001-bootdo-management-system/plan/backend/logic-exportSubcontractorEvaluationRecords.md)

## 加载预算历史记录（loadBudgetHistory）

- **关联文档**：[预算管理-加载预算历史记录（loadBudgetHistory）](specs/001-bootdo-management-system/plan/backend/logic-loadBudgetHistory.md)

## 分析预算执行情况（analyzeBudget）

- **关联文档**：[预算管理-预算分析（analyzeBudget）](specs/001-bootdo-management-system/plan/backend/logic-analyzeBudget.md)

## 计算执行偏差分析（calculateExecutionDeviationAnalysis）

- **关联文档**：[预算管理-计算执行偏差分析（calculateExecutionDeviationAnalysis）](specs/001-bootdo-management-system/plan/backend/logic-calculateExecutionDeviationAnalysis.md)

## 文件上传处理（fileUploadProcessing）

- **关联文档**：[通用领域服务-文件上传处理（fileUploadProcessing）](specs/001-bootdo-management-system/plan/backend/logic-fileUploadProcessing.md)

## 文件版本管理（fileVersionManagement）

- **关联文档**：[办公自动化-文件版本管理（fileVersionManagement）](specs/001-bootdo-management-system/plan/backend/logic-fileVersionManagement.md)

## 文件权限控制（filePermissionControl）

- **关联文档**：[通用领域服务-文件权限控制（filePermissionControl）](specs/001-bootdo-management-system/plan/backend/logic-filePermissionControl.md)

## 文件搜索与筛选（fileSearchAndFilter）

- **关联文档**：[通用领域服务-文件搜索与过滤（fileSearchAndFilter）](specs/001-bootdo-management-system/plan/backend/logic-fileSearchAndFilter.md)

## 文件批量操作（fileBatchOperations）

- **关联文档**：[办公自动化-文件批量操作（fileBatchOperations）](specs/001-bootdo-management-system/plan/backend/logic-fileBatchOperations.md)

## 获取表单集成列表（getFormIntegrationList）

- **关联文档**：[工作流引擎-获取表单集成列表（getFormIntegrationList）](specs/001-bootdo-management-system/plan/backend/logic-getFormIntegrationList.md)

## 创建表单集成（createFormIntegration）

- **关联文档**：[工作流引擎-创建表单集成（createFormIntegration）](specs/001-bootdo-management-system/plan/backend/logic-createFormIntegration.md)

## 更新表单集成（updateFormIntegration）

- **关联文档**：[工作流引擎-更新表单集成（updateFormIntegration）](specs/001-bootdo-management-system/plan/backend/logic-updateFormIntegration.md)

## 删除表单集成（deleteFormIntegration）

- **关联文档**：[工作流引擎-删除表单集成（deleteFormIntegration）](specs/001-bootdo-management-system/plan/backend/logic-deleteFormIntegration.md)

## 导出检验报告（exportInspectionReport）

- **关联文档**：[质量管理-导出检验报告（exportInspectionReport）](specs/001-bootdo-management-system/plan/backend/logic-exportInspectionReport.md)

## 获取问题跟踪记录列表（getIssueTrackingRecords）

- **关联文档**：[质量管理-获取问题跟踪记录（getIssueTrackingRecords）](specs/001-bootdo-management-system/plan/backend/logic-getIssueTrackingRecords.md)

## 获取质量问题详情（getQualityIssueDetail）

- **关联文档**：[质量管理-获取质量问题详情（getQualityIssueDetail）](specs/001-bootdo-management-system/plan/backend/logic-getQualityIssueDetail.md)

## 加载操作日志（loadOperationLogs）

- **关联文档**：[系统管理-加载操作日志（loadOperationLogs）](specs/001-bootdo-management-system/plan/backend/logic-loadOperationLogs.md)

## 搜索操作日志（searchOperationLogs）

- **关联文档**：[系统管理-搜索操作日志（searchOperationLogs）](specs/001-bootdo-management-system/plan/backend/logic-searchOperationLogs.md)

## 删除操作日志（deleteOperationLog）

- **关联文档**：[系统管理-删除操作日志（deleteOperationLog）](specs/001-bootdo-management-system/plan/backend/logic-deleteOperationLog.md)

## 批量删除操作日志（batchDeleteOperationLogs）

- **关联文档**：[系统管理-批量删除操作日志（batchDeleteOperationLogs）](specs/001-bootdo-management-system/plan/backend/logic-batchDeleteOperationLogs.md)

## 用户登录（LcapLoginNormal）

- **关联文档**：[权限中心-普通用户登录（LcapLoginNormal）](specs/001-bootdo-management-system/plan/backend/logic-LcapLoginNormal.md)

## 查询会议列表（queryMeetingList）

- **关联文档**：[办公自动化-查询会议列表（queryMeetingList）](specs/001-bootdo-management-system/plan/backend/logic-queryMeetingList.md)

## 创建会议预约（createMeetingReservation）

- **关联文档**：[通用领域服务-创建会议预约（createMeetingReservation）](specs/001-bootdo-management-system/plan/backend/logic-createMeetingReservation.md)

## 更新会议预约（updateMeetingReservation）

- **关联文档**：[通用领域服务-更新会议预约（updateMeetingReservation）](specs/001-bootdo-management-system/plan/backend/logic-updateMeetingReservation.md)

## 删除会议预约（deleteMeetingReservation）

- **关联文档**：[办公自动化-删除会议预约（deleteMeetingReservation）](specs/001-bootdo-management-system/plan/backend/logic-deleteMeetingReservation.md)

## 邀请参会人员（inviteMeetingParticipants）

- **关联文档**：[办公自动化-邀请参会人员（inviteMeetingParticipants）](specs/001-bootdo-management-system/plan/backend/logic-inviteMeetingParticipants.md)

## 管理会议纪要（manageMeetingMinutes）

- **关联文档**：[办公自动化-管理会议纪要（manageMeetingMinutes）](specs/001-bootdo-management-system/plan/backend/logic-manageMeetingMinutes.md)

## 查询会议预约列表（queryMeetingReservationList）

- **关联文档**：[办公自动化-查询会议预约列表（queryMeetingReservationList）](specs/001-bootdo-management-system/plan/backend/logic-queryMeetingReservationList.md)

## 获取会议预约详情（getMeetingReservationDetail）

- **关联文档**：[办公自动化-获取会议预约详情（getMeetingReservationDetail）](specs/001-bootdo-management-system/plan/backend/logic-getMeetingReservationDetail.md)

## 检查会议时间冲突（checkMeetingTimeConflict）

- **关联文档**：[通用领域服务-检查会议时间冲突（checkMeetingTimeConflict）](specs/001-bootdo-management-system/plan/backend/logic-checkMeetingTimeConflict.md)

## 导出会议数据（exportMeetingData）

- **关联文档**：[办公自动化-导出会议数据（exportMeetingData）](specs/001-bootdo-management-system/plan/backend/logic-exportMeetingData.md)

## 加载菜单列表（loadMenuList）

- **关联文档**：[系统管理-加载菜单列表（loadMenuList）](specs/001-bootdo-management-system/plan/backend/logic-loadMenuList.md)

## 保存菜单项（saveMenuItem）

- **关联文档**：[系统管理-保存菜单项（saveMenuItem）](specs/001-bootdo-management-system/plan/backend/logic-saveMenuItem.md)

## 计算月度薪资（calculateMonthlySalary）

- **关联文档**：[薪资管理-计算月度工资（calculateMonthlySalary）](specs/001-bootdo-management-system/plan/backend/logic-calculateMonthlySalary.md)

## 批量导入薪资数据（batchImportSalaryData）

- **关联文档**：[薪资管理-批量导入薪资数据（batchImportSalaryData）](specs/001-bootdo-management-system/plan/backend/logic-batchImportSalaryData.md)

## 导出薪资报表（exportSalaryReport）

- **关联文档**：[薪资管理-导出薪资报表（exportSalaryReport）](specs/001-bootdo-management-system/plan/backend/logic-exportSalaryReport.md)

## 获取节点配置详情（getNodeConfigurationDetail）

- **关联文档**：[工作流引擎-获取节点配置详情（getNodeConfigurationDetail）](specs/001-bootdo-management-system/plan/backend/logic-getNodeConfigurationDetail.md)

## 更新节点配置（updateNodeConfiguration）

- **关联文档**：[工作流引擎-更新节点配置（updateNodeConfiguration）](specs/001-bootdo-management-system/plan/backend/logic-updateNodeConfiguration.md)

## 查询节点配置列表（queryNodeConfigurationList）

- **关联文档**：[工作流引擎-查询节点配置列表（queryNodeConfigurationList）](specs/001-bootdo-management-system/plan/backend/logic-queryNodeConfigurationList.md)

## 加载通知公告列表（loadNotificationList）

- **关联文档**：[办公自动化-加载通知公告列表（loadNotificationList）](specs/001-bootdo-management-system/plan/backend/logic-loadNotificationList.md)

## 创建通知公告（createNotification）

- **关联文档**：[办公自动化-创建通知（createNotification）](specs/001-bootdo-management-system/plan/backend/logic-createNotification.md)

## 更新通知公告（updateMessage）

- **关联文档**：[办公自动化-更新消息（updateMessage）](specs/001-bootdo-management-system/plan/backend/logic-updateMessage.md)

## 删除通知公告（deleteMessage）

- **关联文档**：[通用领域服务-删除消息（deleteMessage）](specs/001-bootdo-management-system/plan/backend/logic-deleteMessage.md)

## 加载通知公告详情（loadMessageDetail）

- **关联文档**：[办公自动化-加载通知公告详情（loadMessageDetail）](specs/001-bootdo-management-system/plan/backend/logic-loadMessageDetail.md)

## 归档通知公告（archiveNotice）

- **关联文档**：[办公自动化-归档通知公告（archiveNotice）](specs/001-bootdo-management-system/plan/backend/logic-archiveNotice.md)

## 批量操作通知公告（batchOperateNotices）

- **关联文档**：[办公自动化-批量操作通知公告（batchOperateNotices）](specs/001-bootdo-management-system/plan/backend/logic-batchOperateNotices.md)

## 标记通知为已读（markNotificationAsRead）

- **关联文档**：[通用领域服务-标记通知为已读（markNotificationAsRead）](specs/001-bootdo-management-system/plan/backend/logic-markNotificationAsRead.md)

## 加载在线用户列表（loadOnlineUsersForTable）

- **关联文档**：[系统管理-加载在线用户列表（loadOnlineUsersForTable）](specs/001-bootdo-management-system/plan/backend/logic-loadOnlineUsersForTable.md)

## 搜索在线用户（searchOnlineUsers）

- **关联文档**：[系统管理-搜索在线用户（searchOnlineUsers）](specs/001-bootdo-management-system/plan/backend/logic-searchOnlineUsers.md)

## 获取分包商付款列表（getSubcontractorPaymentList）

- **关联文档**：[分包商管理-获取分包商付款列表（getSubcontractorPaymentList）](specs/001-bootdo-management-system/plan/backend/logic-getSubcontractorPaymentList.md)

## 创建分包商付款记录（createSubcontractorPayment）

- **关联文档**：[分包商管理-创建分包商付款（createSubcontractorPayment）](specs/001-bootdo-management-system/plan/backend/logic-createSubcontractorPayment.md)

## 更新分包商付款记录（updateSubcontractorPayment）

- **关联文档**：[分包商管理-更新分包商付款记录（updateSubcontractorPayment）](specs/001-bootdo-management-system/plan/backend/logic-updateSubcontractorPayment.md)

## 删除分包商付款记录（deleteSubcontractorPayment）

- **关联文档**：[通用领域服务-删除分包商付款（deleteSubcontractorPayment）](specs/001-bootdo-management-system/plan/backend/logic-deleteSubcontractorPayment.md)

## 导出分包商付款数据（exportSubcontractorPaymentData）

- **关联文档**：[分包商管理-导出分包商付款数据（exportSubcontractorPaymentData）](specs/001-bootdo-management-system/plan/backend/logic-exportSubcontractorPaymentData.md)

## 加载发放记录列表（loadPaymentRecordList）

- **关联文档**：[薪资管理-加载发放记录列表（loadPaymentRecordList）](specs/001-bootdo-management-system/plan/backend/logic-loadPaymentRecordList.md)

## 加载权限管理表格视图数据（LcapLoadPermissionManagementTableView）

- **关联文档**：[权限中心-加载权限管理表格视图数据（LcapLoadPermissionManagementTableView）](specs/001-bootdo-management-system/plan/backend/logic-LcapLoadPermissionManagementTableView.md)

## 获取权限名称列表（LcapGetPermissionNameList）

- **关联文档**：[权限中心-获取权限名称列表（LcapGetPermissionNameList）](specs/001-bootdo-management-system/plan/backend/logic-LcapGetPermissionNameList.md)

## 获取未关联的权限资源列表（LcapGetPermissionResourseNotRelated）

- **关联文档**：[权限中心-获取未关联的权限资源列表（LcapGetPermissionResourseNotRelated）](specs/001-bootdo-management-system/plan/backend/logic-LcapGetPermissionResourseNotRelated.md)

## 获取权限已关联资源列表（LcapGetPermissionResourceRelated）

- **关联文档**：[权限中心-获取权限已关联资源列表（LcapGetPermissionResourceRelated）](specs/001-bootdo-management-system/plan/backend/logic-LcapGetPermissionResourceRelated.md)

## 根据权限ID获取权限资源映射列表（LcapGetPerResMappingByPermissionId）

- **关联文档**：[权限中心-根据权限ID获取权限资源映射列表（LcapGetPerResMappingByPermissionId）](specs/001-bootdo-management-system/plan/backend/logic-LcapGetPerResMappingByPermissionId.md)

## 保存个人工作台布局配置（savePersonalWorkspaceLayout）

- **关联文档**：[办公自动化-保存个人工作台布局配置（savePersonalWorkspaceLayout）](specs/001-bootdo-management-system/plan/backend/logic-savePersonalWorkspaceLayout.md)

## 获取个人工作台数据（getPersonalWorkspaceData）

- **关联文档**：[通用领域服务-获取个人工作台数据（getPersonalWorkspaceData）](specs/001-bootdo-management-system/plan/backend/logic-getPersonalWorkspaceData.md)

## 重置个人工作台配置（resetPersonalWorkspaceConfig）

- **关联文档**：[办公自动化-重置个人工作台配置（resetPersonalWorkspaceConfig）](specs/001-bootdo-management-system/plan/backend/logic-resetPersonalWorkspaceConfig.md)

## 分包商人员管理（subcontractorPersonnelManagement）

- **关联文档**：[分包商管理-分包商人员管理（subcontractorPersonnelManagement）](specs/001-bootdo-management-system/plan/backend/logic-subcontractorPersonnelManagement.md)

## 获取流程定义列表（getProcessDefinitionList）

- **关联文档**：[工作流引擎-获取流程定义列表（getProcessDefinitionList）](specs/001-bootdo-management-system/plan/backend/logic-getProcessDefinitionList.md)

## 创建流程定义（createProcessDefinition）

- **关联文档**：[工作流引擎-创建流程定义（createProcessDefinition）](specs/001-bootdo-management-system/plan/backend/logic-createProcessDefinition.md)

## 更新流程定义（updateProcessDefinition）

- **关联文档**：[工作流引擎-更新流程定义（updateProcessDefinition）](specs/001-bootdo-management-system/plan/backend/logic-updateProcessDefinition.md)

## 删除流程定义（deleteProcessDefinition）

- **关联文档**：[工作流引擎-删除流程定义（deleteProcessDefinition）](specs/001-bootdo-management-system/plan/backend/logic-deleteProcessDefinition.md)

## 导入流程定义（importProcessDefinition）

- **关联文档**：[工作流引擎-导入流程定义（importProcessDefinition）](specs/001-bootdo-management-system/plan/backend/logic-importProcessDefinition.md)

## 查询流程实例列表（queryProcessInstances）

- **关联文档**：[工作流引擎-查询流程实例列表（queryProcessInstances）](specs/001-bootdo-management-system/plan/backend/logic-queryProcessInstances.md)

## 获取流程实例详情（getProcessInstanceDetail）

- **关联文档**：[工作流引擎-获取流程实例详情（getProcessInstanceDetail）](specs/001-bootdo-management-system/plan/backend/logic-getProcessInstanceDetail.md)

## 终止流程实例（terminateProcessInstance）

- **关联文档**：[工作流引擎-终止流程实例（terminateProcessInstance）](specs/001-bootdo-management-system/plan/backend/logic-terminateProcessInstance.md)

## 重新分配任务节点（reassignTaskNode）

- **关联文档**：[工作流引擎-重新分配任务节点（reassignTaskNode）](specs/001-bootdo-management-system/plan/backend/logic-reassignTaskNode.md)

## 导出流程实例数据（exportProcessInstanceData）

- **关联文档**：[工作流引擎-导出流程实例数据（exportProcessInstanceData）](specs/001-bootdo-management-system/plan/backend/logic-exportProcessInstanceData.md)

## 批量操作流程实例（batchOperateProcessInstances）

- **关联文档**：[工作流引擎-批量操作流程实例（batchOperateProcessInstances）](specs/001-bootdo-management-system/plan/backend/logic-batchOperateProcessInstances.md)

## 获取工作流统计信息（getWorkflowStatistics）

- **关联文档**：[工作流引擎-获取流程统计信息（getWorkflowStatistics）](specs/001-bootdo-management-system/plan/backend/logic-getWorkflowStatistics.md)

## 获取流程监控列表（getProcessMonitoringList）

- **关联文档**：[工作流引擎-获取流程监控列表（getProcessMonitoringList）](specs/001-bootdo-management-system/plan/backend/logic-getProcessMonitoringList.md)

## 导出流程监控报表（exportProcessMonitoringReport）

- **关联文档**：[通用领域服务-导出流程监控报告（exportProcessMonitoringReport）](specs/001-bootdo-management-system/plan/backend/logic-exportProcessMonitoringReport.md)

## 加载项目分配列表（loadProjectAssignmentList）

- **关联文档**：[分包商管理-加载项目分配列表（loadProjectAssignmentList）](specs/001-bootdo-management-system/plan/backend/logic-loadProjectAssignmentList.md)

## 加载分包商选择列表（loadSubcontractorForSelect）

- **关联文档**：[分包商管理-加载分包商选择列表（loadSubcontractorForSelect）](specs/001-bootdo-management-system/plan/backend/logic-loadSubcontractorForSelect.md)

## 查询分包商资质证书列表（querySubcontractorQualificationCertificates）

- **关联文档**：[分包商管理-查询分包商资质证书列表（querySubcontractorQualificationCertificates）](specs/001-bootdo-management-system/plan/backend/logic-querySubcontractorQualificationCertificates.md)

## 创建分包商资质证书（createSubcontractorQualificationCertificate）

- **关联文档**：[分包商管理-创建分包商资质证书（createSubcontractorQualificationCertificate）](specs/001-bootdo-management-system/plan/backend/logic-createSubcontractorQualificationCertificate.md)

## 更新分包商资质证书（updateSubcontractorQualificationCertificate）

- **关联文档**：[分包商管理-更新分包商资质证书（updateSubcontractorQualificationCertificate）](specs/001-bootdo-management-system/plan/backend/logic-updateSubcontractorQualificationCertificate.md)

## 删除分包商资质证书（deleteSubcontractorQualificationCertificate）

- **关联文档**：[分包商管理-删除分包商资质证书（deleteSubcontractorQualificationCertificate）](specs/001-bootdo-management-system/plan/backend/logic-deleteSubcontractorQualificationCertificate.md)

## 创建质量指标（createQualityIndicator）

- **关联文档**：[质量管理-创建质量指标（createQualityIndicator）](specs/001-bootdo-management-system/plan/backend/logic-createQualityIndicator.md)

## 更新质量指标（updateQualityIndicator）

- **关联文档**：[质量管理-更新质量指标（updateQualityIndicator）](specs/001-bootdo-management-system/plan/backend/logic-updateQualityIndicator.md)

## 删除质量指标（deleteQualityIndicator）

- **关联文档**：[质量管理-删除质量指标（deleteQualityIndicator）](specs/001-bootdo-management-system/plan/backend/logic-deleteQualityIndicator.md)

## 查询质量指标列表（queryQualityIndicators）

- **关联文档**：[质量管理-查询质量指标列表（queryQualityIndicators）](specs/001-bootdo-management-system/plan/backend/logic-queryQualityIndicators.md)

## 获取质量问题列表（queryQualityIssues）

- **关联文档**：[质量管理-获取质量问题列表（queryQualityIssues）](specs/001-bootdo-management-system/plan/backend/logic-queryQualityIssues.md)

## 获取质量检验列表（getQualityInspectionList）

- **关联文档**：[质量管理-获取质量检验列表（getQualityInspectionList）](specs/001-bootdo-management-system/plan/backend/logic-getQualityInspectionList.md)

## 获取质量检验详情（getQualityInspectionDetail）

- **关联文档**：[质量管理-获取质量检验详情（getQualityInspectionDetail）](specs/001-bootdo-management-system/plan/backend/logic-getQualityInspectionDetail.md)

## 创建质量检验记录（createQualityInspection）

- **关联文档**：[质量管理-创建质量检验（createQualityInspection）](specs/001-bootdo-management-system/plan/backend/logic-createQualityInspection.md)

## 更新质量检验记录（updateQualityInspection）

- **关联文档**：[质量管理-更新质量检验（updateQualityInspection）](specs/001-bootdo-management-system/plan/backend/logic-updateQualityInspection.md)

## 删除质量检验记录（deleteQualityInspection）

- **关联文档**：[质量管理-删除质量检验（deleteQualityInspection）](specs/001-bootdo-management-system/plan/backend/logic-deleteQualityInspection.md)

## 获取质量问题列表（getQualityIssueList）

- **关联文档**：[质量管理-获取质量问题列表（getQualityIssueList）](specs/001-bootdo-management-system/plan/backend/logic-getQualityIssueList.md)

## 创建质量问题（createQualityIssue）

- **关联文档**：[质量管理-创建质量问题（createQualityIssue）](specs/001-bootdo-management-system/plan/backend/logic-createQualityIssue.md)

## 更新质量问题（updateQualityIssue）

- **关联文档**：[质量管理-更新质量问题（updateQualityIssue）](specs/001-bootdo-management-system/plan/backend/logic-updateQualityIssue.md)

## 删除质量问题（deleteQualityIssue）

- **关联文档**：[质量管理-删除质量问题（deleteQualityIssue）](specs/001-bootdo-management-system/plan/backend/logic-deleteQualityIssue.md)

## 上传质量问题附件（uploadQualityIssueAttachment）

- **关联文档**：[质量管理-上传质量问题附件（uploadQualityIssueAttachment）](specs/001-bootdo-management-system/plan/backend/logic-uploadQualityIssueAttachment.md)

## 创建整改措施（createRectificationMeasure）

- **关联文档**：[环保管理-创建整改措施（createRectificationMeasure）](specs/001-bootdo-management-system/plan/backend/logic-createRectificationMeasure.md)

## 更新整改措施（updateRectificationMeasure）

- **关联文档**：[环保管理-更新整改措施（updateRectificationMeasure）](specs/001-bootdo-management-system/plan/backend/logic-updateRectificationMeasure.md)

## 删除整改措施（deleteRectificationMeasure）

- **关联文档**：[环保管理-删除整改措施（deleteRectificationMeasure）](specs/001-bootdo-management-system/plan/backend/logic-deleteRectificationMeasure.md)

## 查询整改措施列表（queryRectificationMeasures）

- **关联文档**：[环保管理-查询整改措施列表（queryRectificationMeasures）](specs/001-bootdo-management-system/plan/backend/logic-queryRectificationMeasures.md)

## 获取整改措施详情（getRectificationMeasureDetail）

- **关联文档**：[环保管理-获取整改措施详情（getRectificationMeasureDetail）](specs/001-bootdo-management-system/plan/backend/logic-getRectificationMeasureDetail.md)

## 同步整改任务数据（syncRectificationTaskData）

- **关联文档**：[质量管理-同步整改任务数据（syncRectificationTaskData）](specs/001-bootdo-management-system/plan/backend/logic-syncRectificationTaskData.md)

## 查询整改进度列表（queryRectificationProgressList）

- **关联文档**：[质量管理-查询整改进度列表（queryRectificationProgressList）](specs/001-bootdo-management-system/plan/backend/logic-queryRectificationProgressList.md)

## 获取整改进度详情（getRectificationProgressDetail）

- **关联文档**：[质量管理-获取整改进度详情（getRectificationProgressDetail）](specs/001-bootdo-management-system/plan/backend/logic-getRectificationProgressDetail.md)

## 删除整改进度记录（deleteRectificationProgress）

- **关联文档**：[质量管理-删除整改进度（deleteRectificationProgress）](specs/001-bootdo-management-system/plan/backend/logic-deleteRectificationProgress.md)

## 导出整改进度数据（exportRectificationProgressData）

- **关联文档**：[质量管理-导出整改进度数据（exportRectificationProgressData）](specs/001-bootdo-management-system/plan/backend/logic-exportRectificationProgressData.md)

## 查询整改任务列表（loadRectificationTaskList）

- **关联文档**：[质量管理-加载整改任务列表（loadRectificationTaskList）](specs/001-bootdo-management-system/plan/backend/logic-loadRectificationTaskList.md)

## 分配整改任务（assignRectificationTask）

- **关联文档**：[质量管理-分配整改任务（assignRectificationTask）](specs/001-bootdo-management-system/plan/backend/logic-assignRectificationTask.md)

## 更新整改进度（updateRectificationProgress）

- **关联文档**：[质量管理-更新整改进度（updateRectificationProgress）](specs/001-bootdo-management-system/plan/backend/logic-updateRectificationProgress.md)

## 获取整改任务列表（getRectificationTaskList）

- **关联文档**：[质量管理-获取整改任务列表（getRectificationTaskList）](specs/001-bootdo-management-system/plan/backend/logic-getRectificationTaskList.md)

## 删除整改任务（deleteRectificationTask）

- **关联文档**：[质量管理-删除整改任务（deleteRectificationTask）](specs/001-bootdo-management-system/plan/backend/logic-deleteRectificationTask.md)

## 导出整改任务数据（exportRectificationTaskData）

- **关联文档**：[质量管理-导出整改任务数据（exportRectificationTaskData）](specs/001-bootdo-management-system/plan/backend/logic-exportRectificationTaskData.md)

## 查询回收记录列表（queryRecyclingRecords）

- **关联文档**：[通用领域服务-查询回收记录列表（queryRecyclingRecords）](specs/001-bootdo-management-system/plan/backend/logic-queryRecyclingRecords.md)

## 保存回收记录（saveRecyclingRecord）

- **关联文档**：[环保管理-保存回收记录（saveRecyclingRecord）](specs/001-bootdo-management-system/plan/backend/logic-saveRecyclingRecord.md)

## 删除回收记录（deleteRecyclingRecord）

- **关联文档**：[通用领域服务-删除回收站记录（deleteRecyclingRecord）](specs/001-bootdo-management-system/plan/backend/logic-deleteRecyclingRecord.md)

## 导出回收记录（exportRecyclingRecords）

- **关联文档**：[通用领域服务-导出回收记录（exportRecyclingRecords）](specs/001-bootdo-management-system/plan/backend/logic-exportRecyclingRecords.md)

## 获取报表格式列表（getReportFormatList）

- **关联文档**：[预算管理-获取报表格式列表（getReportFormatList）](specs/001-bootdo-management-system/plan/backend/logic-getReportFormatList.md)

## 创建报表格式（createReportFormat）

- **关联文档**：[预算管理-创建报表格式（createReportFormat）](specs/001-bootdo-management-system/plan/backend/logic-createReportFormat.md)

## 更新报表格式（updateReportFormat）

- **关联文档**：[预算管理-更新报表格式（updateReportFormat）](specs/001-bootdo-management-system/plan/backend/logic-updateReportFormat.md)

## 删除报表格式（deleteReportFormat）

- **关联文档**：[预算管理-删除报表格式（deleteReportFormat）](specs/001-bootdo-management-system/plan/backend/logic-deleteReportFormat.md)

## 获取报表格式详情（getReportFormatDetail）

- **关联文档**：[预算管理-获取报表格式详情（getReportFormatDetail）](specs/001-bootdo-management-system/plan/backend/logic-getReportFormatDetail.md)

## 提交环境报告（submitEnvironmentalReport）

- **关联文档**：[环保管理-提交环境报告（submitEnvironmentalReport）](specs/001-bootdo-management-system/plan/backend/logic-submitEnvironmentalReport.md)

## 获取环境报告列表（getEnvironmentalReportList）

- **关联文档**：[环保管理-获取环境报告列表（getEnvironmentalReportList）](specs/001-bootdo-management-system/plan/backend/logic-getEnvironmentalReportList.md)

## 删除环境报告（deleteEnvironmentalReport）

- **关联文档**：[环保管理-删除环境监测报告（deleteEnvironmentalReport）](specs/001-bootdo-management-system/plan/backend/logic-deleteEnvironmentalReport.md)

## 获取环境报告详情（getEnvironmentalReportDetail）

- **关联文档**：[环保管理-获取环境报告详情（getEnvironmentalReportDetail）](specs/001-bootdo-management-system/plan/backend/logic-getEnvironmentalReportDetail.md)

## 获取资源消耗统计数据（getResourceConsumptionStatistics）

- **关联文档**：[环保管理-获取资源消耗统计数据（getResourceConsumptionStatistics）](specs/001-bootdo-management-system/plan/backend/logic-getResourceConsumptionStatistics.md)

## 导出资源消耗报表（exportResourceConsumptionReport）

- **关联文档**：[环保管理-导出资源消耗报表（exportResourceConsumptionReport）](specs/001-bootdo-management-system/plan/backend/logic-exportResourceConsumptionReport.md)

## 环境风险评估分析（environmentalRiskAssessmentAnalysis）

- **关联文档**：[环保管理-环境风险评估分析（environmentalRiskAssessmentAnalysis）](specs/001-bootdo-management-system/plan/backend/logic-environmentalRiskAssessmentAnalysis.md)

## 风险等级评估计算（riskLevelAssessmentCalculation）

- **关联文档**：[通用领域服务-风险等级评估计算（riskLevelAssessmentCalculation）](specs/001-bootdo-management-system/plan/backend/logic-riskLevelAssessmentCalculation.md)

## 风险监控预警配置（riskMonitoringAlertConfiguration）

- **关联文档**：[通用领域服务-风险监控告警配置（riskMonitoringAlertConfiguration）](specs/001-bootdo-management-system/plan/backend/logic-riskMonitoringAlertConfiguration.md)

## 加载角色管理表格视图数据（LcapLoadRoleManagementTableView）

- **关联文档**：[权限中心-加载角色管理表格视图数据（LcapLoadRoleManagementTableView）](specs/001-bootdo-management-system/plan/backend/logic-LcapLoadRoleManagementTableView.md)

## 根据角色ID获取权限（LcapGetPermissionByRoleId）

- **关联文档**：[权限中心-根据角色ID获取权限（LcapGetPermissionByRoleId）](specs/001-bootdo-management-system/plan/backend/logic-LcapGetPermissionByRoleId.md)

## 获取用户资源（LcapGetUserResources）

- **关联文档**：[权限中心-获取用户资源（LcapGetUserResources）](specs/001-bootdo-management-system/plan/backend/logic-LcapGetUserResources.md)

## 加载用户角色映射表格视图数据（LcapLoadUserRoleMappingTableView）

- **关联文档**：[权限中心-加载用户角色映射表格视图数据（LcapLoadUserRoleMappingTableView）](specs/001-bootdo-management-system/plan/backend/logic-LcapLoadUserRoleMappingTableView.md)

## 根据角色与权限关系删除映射（LcapGetMappingDeleteByRoleIdAndPermissionId）

- **关联文档**：[权限中心-根据角色与权限关系删除映射（LcapGetMappingDeleteByRoleIdAndPermissionId）](specs/001-bootdo-management-system/plan/backend/logic-LcapGetMappingDeleteByRoleIdAndPermissionId.md)

## 加载角色可添加权限列表（LcapLoadAddRolePermissionTableView）

- **关联文档**：[权限中心-加载角色可添加权限列表（LcapLoadAddRolePermissionTableView）](specs/001-bootdo-management-system/plan/backend/logic-LcapLoadAddRolePermissionTableView.md)

## 加载角色可添加用户列表（LcapLoadAddRoleUserTableView）

- **关联文档**：[权限中心-加载角色可添加用户列表（LcapLoadAddRoleUserTableView）](specs/001-bootdo-management-system/plan/backend/logic-LcapLoadAddRoleUserTableView.md)

## 获取角色名称列表（LcapGetRoleNameList）

- **关联文档**：[权限中心-获取角色名称列表（LcapGetRoleNameList）](specs/001-bootdo-management-system/plan/backend/logic-LcapGetRoleNameList.md)

## 根据用户ID列表获取用户信息（LcapGetUserByUserIds）

- **关联文档**：[权限中心-根据用户ID列表获取用户信息（LcapGetUserByUserIds）](specs/001-bootdo-management-system/plan/backend/logic-LcapGetUserByUserIds.md)

## 调整薪资（adjustSalary）

- **关联文档**：[薪资管理-调整薪资（adjustSalary）](specs/001-bootdo-management-system/plan/backend/logic-adjustSalary.md)

## 审批薪资（approveSalary）

- **关联文档**：[薪资管理-审批薪资（approveSalary）](specs/001-bootdo-management-system/plan/backend/logic-approveSalary.md)

## 驳回薪资（rejectSalary）

- **关联文档**：[薪资管理-驳回薪资（rejectSalary）](specs/001-bootdo-management-system/plan/backend/logic-rejectSalary.md)

## 更新薪资记录（updateSalaryRecord）

- **关联文档**：[薪资管理-更新薪资记录（updateSalaryRecord）](specs/001-bootdo-management-system/plan/backend/logic-updateSalaryRecord.md)

## 删除薪资记录（deleteSalaryRecord）

- **关联文档**：[薪资管理-删除薪资记录（deleteSalaryRecord）](specs/001-bootdo-management-system/plan/backend/logic-deleteSalaryRecord.md)

## 加载薪资详情（loadSalaryDetail）

- **关联文档**：[薪资管理-加载薪资详情（loadSalaryDetail）](specs/001-bootdo-management-system/plan/backend/logic-loadSalaryDetail.md)

## 验证薪资数据（validateSalary）

- **关联文档**：[薪资管理-验证薪资数据（validateSalary）](specs/001-bootdo-management-system/plan/backend/logic-validateSalary.md)

## 批量处理薪资（batchProcessSalary）

- **关联文档**：[薪资管理-批量处理薪资（batchProcessSalary）](specs/001-bootdo-management-system/plan/backend/logic-batchProcessSalary.md)

## 查询薪资报表列表（loadSalaryReports）

- **关联文档**：[薪资管理-加载薪资报表（loadSalaryReports）](specs/001-bootdo-management-system/plan/backend/logic-loadSalaryReports.md)

## 获取薪资报表详情（getSalaryReportDetail）

- **关联文档**：[薪资管理-获取薪资报表详情（getSalaryReportDetail）](specs/001-bootdo-management-system/plan/backend/logic-getSalaryReportDetail.md)

## 批量审核薪资报表（batchApproveSalaryReports）

- **关联文档**：[通用领域服务-批量审核薪资报表（batchApproveSalaryReports）](specs/001-bootdo-management-system/plan/backend/logic-batchApproveSalaryReports.md)

## 获取薪资数据汇总（getSalaryDataSummary）

- **关联文档**：[薪资管理-获取薪资数据汇总（getSalaryDataSummary）](specs/001-bootdo-management-system/plan/backend/logic-getSalaryDataSummary.md)

## 获取部门列表（loadDepartments）

- **关联文档**：[权限中心-加载部门数据（loadDepartments）](specs/001-bootdo-management-system/plan/backend/logic-loadDepartments.md)

## 获取岗位列表（loadPositions）

- **关联文档**：[权限中心-获取岗位列表（loadPositions）](specs/001-bootdo-management-system/plan/backend/logic-loadPositions.md)

## 查询薪资结构列表（querySalaryStructureList）

- **关联文档**：[薪资管理-查询薪资结构列表（querySalaryStructureList）](specs/001-bootdo-management-system/plan/backend/logic-querySalaryStructureList.md)

## 保存薪资结构项（saveSalaryStructureItem）

- **关联文档**：[薪资管理-保存薪资结构项（saveSalaryStructureItem）](specs/001-bootdo-management-system/plan/backend/logic-saveSalaryStructureItem.md)

## 删除薪资结构项（deleteSalaryStructureItem）

- **关联文档**：[薪资管理-删除薪资结构项（deleteSalaryStructureItem）](specs/001-bootdo-management-system/plan/backend/logic-deleteSalaryStructureItem.md)

## 检查薪资结构项引用（checkSalaryStructureItemReference）

- **关联文档**：[薪资管理-检查薪资结构项引用（checkSalaryStructureItemReference）](specs/001-bootdo-management-system/plan/backend/logic-checkSalaryStructureItemReference.md)

## 获取日程列表（getScheduleList）

- **关联文档**：[办公自动化-获取日程列表（getScheduleList）](specs/001-bootdo-management-system/plan/backend/logic-getScheduleList.md)

## 获取共享日程列表（getSharedScheduleList）

- **关联文档**：[办公自动化-获取共享日程列表（getSharedScheduleList）](specs/001-bootdo-management-system/plan/backend/logic-getSharedScheduleList.md)

## 设置日程提醒（setScheduleReminder）

- **关联文档**：[通用领域服务-设置日程提醒（setScheduleReminder）](specs/001-bootdo-management-system/plan/backend/logic-setScheduleReminder.md)

## 管理个人日程（managePersonalSchedule）

- **关联文档**：[办公自动化-管理个人日程（managePersonalSchedule）](specs/001-bootdo-management-system/plan/backend/logic-managePersonalSchedule.md)

## 保存SEO配置（saveSeoConfiguration）

- **关联文档**：[内容管理-保存SEO配置（saveSeoConfiguration）](specs/001-bootdo-management-system/plan/backend/logic-saveSeoConfiguration.md)

## 获取SEO配置（getSeoConfiguration）

- **关联文档**：[内容管理-获取SEO配置（getSeoConfiguration）](specs/001-bootdo-management-system/plan/backend/logic-getSeoConfiguration.md)

## 预览SEO效果（previewSeoEffect）

- **关联文档**：[内容管理-预览SEO效果（previewSeoEffect）](specs/001-bootdo-management-system/plan/backend/logic-previewSeoEffect.md)

## 获取分包商列表（getSubcontractorList）

- **关联文档**：[通用领域服务-获取分包商列表（getSubcontractorList）](specs/001-bootdo-management-system/plan/backend/logic-getSubcontractorList.md)

## 导出分包商数据（exportSubcontractorData）

- **关联文档**：[分包商管理-导出分包商数据（exportSubcontractorData）](specs/001-bootdo-management-system/plan/backend/logic-exportSubcontractorData.md)

## 加载系统配置列表（loadSystemConfigurations）

- **关联文档**：[系统管理-加载系统配置列表（loadSystemConfigurations）](specs/001-bootdo-management-system/plan/backend/logic-loadSystemConfigurations.md)

## 刷新系统配置缓存（refreshSystemConfigurationCache）

- **关联文档**：[通用领域服务-刷新系统配置缓存（refreshSystemConfigurationCache）](specs/001-bootdo-management-system/plan/backend/logic-refreshSystemConfigurationCache.md)

## 管理系统参数配置（manageSystemParameters）

- **关联文档**：[系统管理-管理系统参数配置（manageSystemParameters）](specs/001-bootdo-management-system/plan/backend/logic-manageSystemParameters.md)

## 刷新系统缓存（refreshSystemCache）

- **关联文档**：[通用领域服务-刷新系统缓存（refreshSystemCache）](specs/001-bootdo-management-system/plan/backend/logic-refreshSystemCache.md)

## 批量导入导出配置（batchImportExportConfigurations）

- **关联文档**：[通用领域服务-批量导入导出配置（batchImportExportConfigurations）](specs/001-bootdo-management-system/plan/backend/logic-batchImportExportConfigurations.md)

## 查询任务列表（queryTaskList）

- **关联文档**：[工作流引擎-查询任务列表（queryTaskList）](specs/001-bootdo-management-system/plan/backend/logic-queryTaskList.md)

## 获取任务详情（getTaskDetail）

- **关联文档**：[通用领域服务-获取任务详情（getTaskDetail）](specs/001-bootdo-management-system/plan/backend/logic-getTaskDetail.md)

## 更新任务状态（updateTaskStatus）

- **关联文档**：[工作流引擎-更新任务状态（updateTaskStatus）](specs/001-bootdo-management-system/plan/backend/logic-updateTaskStatus.md)

## 批量更新任务（batchUpdateTasks）

- **关联文档**：[工作流引擎-批量更新任务（batchUpdateTasks）](specs/001-bootdo-management-system/plan/backend/logic-batchUpdateTasks.md)

## 计算个人所得税（calculatePersonalIncomeTax）

- **关联文档**：[薪资管理-计算个人所得税（calculatePersonalIncomeTax）](specs/001-bootdo-management-system/plan/backend/logic-calculatePersonalIncomeTax.md)

## 获取税务计算明细（getTaxCalculationDetails）

- **关联文档**：[薪资管理-获取税务计算明细（getTaxCalculationDetails）](specs/001-bootdo-management-system/plan/backend/logic-getTaxCalculationDetails.md)

## 批量重新计算税务（batchRecalculateTax）

- **关联文档**：[通用领域服务-批量重新计算税务（batchRecalculateTax）](specs/001-bootdo-management-system/plan/backend/logic-batchRecalculateTax.md)

## 导出税务计算报表（exportTaxCalculationReport）

- **关联文档**：[薪资管理-导出税务计算报表（exportTaxCalculationReport）](specs/001-bootdo-management-system/plan/backend/logic-exportTaxCalculationReport.md)

## 获取待办任务列表（getTodoTaskList）

- **关联文档**：[通用领域服务-获取待办任务列表（getTodoTaskList）](specs/001-bootdo-management-system/plan/backend/logic-getTodoTaskList.md)

## 创建待办任务（createTodoTask）

- **关联文档**：[办公自动化-创建待办任务（createTodoTask）](specs/001-bootdo-management-system/plan/backend/logic-createTodoTask.md)

## 更新待办任务（updateTodoTask）

- **关联文档**：[办公自动化-更新待办任务（updateTodoTask）](specs/001-bootdo-management-system/plan/backend/logic-updateTodoTask.md)

## 删除待办任务（deleteTodoTask）

- **关联文档**：[办公自动化-删除待办任务（deleteTodoTask）](specs/001-bootdo-management-system/plan/backend/logic-deleteTodoTask.md)

## 获取用户列表（getUserList）

- **关联文档**：[权限中心-获取用户列表（getUserList）](specs/001-bootdo-management-system/plan/backend/logic-getUserList.md)

## 查询用户组列表（queryUserGroupList）

- **关联文档**：[系统管理-查询用户组列表（queryUserGroupList）](specs/001-bootdo-management-system/plan/backend/logic-queryUserGroupList.md)

## 获取用户组详情（getUserGroupDetail）

- **关联文档**：[工作流引擎-获取用户组详情（getUserGroupDetail）](specs/001-bootdo-management-system/plan/backend/logic-getUserGroupDetail.md)

## 创建用户组（createUserGroup）

- **关联文档**：[通用领域服务-创建用户组（createUserGroup）](specs/001-bootdo-management-system/plan/backend/logic-createUserGroup.md)

## 更新用户组（updateUserGroup）

- **关联文档**：[工作流引擎-更新用户组（updateUserGroup）](specs/001-bootdo-management-system/plan/backend/logic-updateUserGroup.md)

## 删除用户组（deleteUserGroup）

- **关联文档**：[工作流引擎-删除用户组（deleteUserGroup）](specs/001-bootdo-management-system/plan/backend/logic-deleteUserGroup.md)

## 查询可选用户列表（queryAvailableUsers）

- **关联文档**：[权限中心-查询可用用户（queryAvailableUsers）](specs/001-bootdo-management-system/plan/backend/logic-queryAvailableUsers.md)

## 添加用户组成员（addUserGroupMembers）

- **关联文档**：[系统管理-添加用户组成员（addUserGroupMembers）](specs/001-bootdo-management-system/plan/backend/logic-addUserGroupMembers.md)

## 移除用户组成员（removeUserGroupMembers）

- **关联文档**：[系统管理-移除用户组成员（removeUserGroupMembers）](specs/001-bootdo-management-system/plan/backend/logic-removeUserGroupMembers.md)

## 查询用户组列表（queryUserGroups）

- **关联文档**：[系统管理-查询用户组列表（queryUserGroups）](specs/001-bootdo-management-system/plan/backend/logic-queryUserGroups.md)

## 查询用户组成员（queryUserGroupMembers）

- **关联文档**：[工作流引擎-查询用户组成员列表（queryUserGroupMembers）](specs/001-bootdo-management-system/plan/backend/logic-queryUserGroupMembers.md)

## 获取用户表格视图（LcapGetUserTableView）

- **关联文档**：[权限中心-获取用户表格视图数据（LcapGetUserTableView）](specs/001-bootdo-management-system/plan/backend/logic-LcapGetUserTableView.md)

## 创建普通用户（LcapCreateNormalUser）

- **关联文档**：[权限中心-创建普通用户（LcapCreateNormalUser）](specs/001-bootdo-management-system/plan/backend/logic-LcapCreateNormalUser.md)

## 更新普通用户（LcapUpdateNormalUser）

- **关联文档**：[权限中心-更新普通用户（LcapUpdateNormalUser）](specs/001-bootdo-management-system/plan/backend/logic-LcapUpdateNormalUser.md)

## 获取用户名列表（LcapGetUserNameList）

- **关联文档**：[权限中心-获取用户名列表（LcapGetUserNameList）](specs/001-bootdo-management-system/plan/backend/logic-LcapGetUserNameList.md)

## 加载用户管理直属主管选择列表（LcapLoadUserManagementSelect）

- **关联文档**：[权限中心-加载用户管理直属主管选择列表（LcapLoadUserManagementSelect）](specs/001-bootdo-management-system/plan/backend/logic-LcapLoadUserManagementSelect.md)

## 根据用户ID获取用户名（LcapGetUserNameByUserId）

- **关联文档**：[权限中心-根据用户ID获取用户名（LcapGetUserNameByUserId）](specs/001-bootdo-management-system/plan/backend/logic-LcapGetUserNameByUserId.md)

## 获取用户订阅列表（getUserSubscriptions）

- **关联文档**：[内容管理-获取用户订阅（getUserSubscriptions）](specs/001-bootdo-management-system/plan/backend/logic-getUserSubscriptions.md)

## 创建用户订阅（createUserSubscription）

- **关联文档**：[办公自动化-创建用户订阅（createUserSubscription）](specs/001-bootdo-management-system/plan/backend/logic-createUserSubscription.md)

## 删除用户订阅（deleteUserSubscription）

- **关联文档**：[内容管理-删除用户订阅（deleteUserSubscription）](specs/001-bootdo-management-system/plan/backend/logic-deleteUserSubscription.md)

## 获取可订阅栏目列表（getAvailableColumnsForSubscription）

- **关联文档**：[内容管理-获取可订阅栏目（getAvailableColumnsForSubscription）](specs/001-bootdo-management-system/plan/backend/logic-getAvailableColumnsForSubscription.md)

## 获取可订阅文章列表（getAvailableArticlesForSubscription）

- **关联文档**：[内容管理-获取可用于订阅的文章（getAvailableArticlesForSubscription）](specs/001-bootdo-management-system/plan/backend/logic-getAvailableArticlesForSubscription.md)

