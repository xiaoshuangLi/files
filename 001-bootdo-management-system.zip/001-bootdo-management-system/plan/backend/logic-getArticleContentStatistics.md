# 内容管理-获取文章统计数据（getArticleContentStatistics）

- **生成时间**：2026-03-25

## 获取文章统计数据（getArticleContentStatistics）

### 功能概述

获取文章统计数据服务端逻辑用于查询和返回内容管理系统中特定文章的各项统计指标数据，包括文章的浏览量、评论数量、分享次数等关键用户互动指标。该逻辑支持按文章ID精确查询统计数据，并可结合时间范围进行历史数据检索，为内容创作者和管理员提供全面的数据洞察。通过该逻辑，系统能够实时展示文章的受欢迎程度、用户参与度和传播效果，帮助优化内容策略、改进内容质量和提升用户体验。统计数据来源于内容统计实体，确保数据的准确性和一致性。

### 功能要点

- **文章统计指标查询**：根据文章ID查询对应的文章统计数据，包括浏览量、评论数、分享数等核心指标。该功能为内容管理页面提供数据支持，使用户能够直观了解文章的表现情况。系统会返回最新的统计数据记录，确保数据的时效性。对于不存在统计数据的文章，系统会返回默认值（所有计数器为0），保证接口的稳定性和一致性。此功能是文章管理页面"查看文章统计"交互操作的核心支撑，满足用户对内容数据分析的基本需求。

### 逻辑签名

```naturalts path="app.logics.getArticleContentStatistics.ts"
$Logic({
    description: '获取文章统计数据',
    directory: 'content_management(内容管理)'
})
export declare function getArticleContentStatistics(articleId: Integer): { viewCount: Integer, commentCount: Integer, shareCount: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| articleId | 文章ID | Integer | 要查询统计数据的文章主键ID |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| viewCount | 浏览量 | Integer | 文章被查看的总次数 |
| commentCount | 评论数 | Integer | 文章收到的评论总数 |
| shareCount | 分享数 | Integer | 文章被分享的总次数 |

### 被前端调用

- **文章管理（articleContent）**：在文章管理页面中，用户点击"查看文章统计"功能时调用此服务端逻辑，获取指定文章的浏览量、评论数、分享数等统计指标，并在页面上以可视化方式展示，帮助用户了解文章的内容表现和用户参与度。

### 依赖的枚举、实体

- **数据建模-实体-文章内容**：[内容管理-实体-文章内容（ArticleContent）](specs/001-bootdo-management-system/plan/data-model/entity-ArticleContent.md)
- **数据建模-实体-内容统计**：[内容管理-实体-内容统计（ContentStatistics）](specs/001-bootdo-management-system/plan/data-model/entity-ContentStatistics.md)

### 依赖的外部能力

无匹配内容

