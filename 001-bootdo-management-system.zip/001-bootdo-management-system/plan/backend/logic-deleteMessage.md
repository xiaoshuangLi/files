# 通用领域服务-删除消息（deleteMessage）

- **生成时间**：2026-03-25

## 删除消息（deleteMessage）

### 功能概述

删除消息功能允许系统用户删除不需要的消息记录，包括通知公告、系统消息等。该功能支持单条消息删除和批量消息删除操作，确保用户能够有效管理自己的消息中心内容。删除操作会进行权限验证，确保用户只能删除自己有权限删除的消息，并记录相应的操作日志用于审计追踪。

### 功能要点

- **消息删除权限控制**：系统根据用户角色和消息所有权进行权限验证，普通用户只能删除自己接收的消息或自己发布的通知，管理员可以删除其管辖范围内的所有消息。删除操作前必须验证用户是否具有删除目标消息的权限，防止越权操作导致数据安全问题。

### 逻辑签名

```naturalts path="app.logics.deleteMessage.ts"
$Logic({
    description: '删除消息',
    directory: 'message_management(消息管理)'
})
export declare function deleteMessage(messageIds: List&lt;app.dataSources.defaultDS.entities.NoticeAnnouncement['id']&gt;, userId: app.dataSources.defaultDS.entities.SystemAccount['id']): { success: Boolean, deletedCount: Integer, failedMessages: List&lt;app.dataSources.defaultDS.entities.NoticeAnnouncement['id']&gt; };
```

### 被前端调用

- **通知公告（noticeAnnouncement）**：管理员在通知公告列表页面选择一条或多条通知进行删除操作，调用此服务端逻辑实现批量删除功能。
- **个人门户（personalWorkspace）**：普通用户在个人工作台的消息中心删除已读或不需要的消息，调用此服务端逻辑实现单条或批量消息删除。

### 依赖的枚举、实体

- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)
- **数据建模-实体-通知公告**：[办公自动化-实体-通知公告（NoticeAnnouncement）](specs/001-bootdo-management-system/plan/data-model/entity-NoticeAnnouncement.md)
- **数据建模-实体-操作记录**：[系统管理-实体-操作记录（OperationRecord）](specs/001-bootdo-management-system/plan/data-model/entity-OperationRecord.md)

### 依赖的外部能力

[文件内部已经提供，无需进行生成。如果文件内部已经有 `依赖的外部能力` 内容，禁止修改或删除文件内的 `依赖的外部能力` 内容]