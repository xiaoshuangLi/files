# 系统管理-搜索在线用户（searchOnlineUsers）

- **生成时间**：2026-03-25

## 搜索在线用户（searchOnlineUsers）

### 功能概述

搜索在线用户服务端逻辑提供对系统当前所有在线用户会话的查询功能，支持通过用户名等条件进行筛选。该逻辑基于在线会话实体（OnlineSession）和系统账户实体（SystemAccount）的数据，实现对活跃用户会话的精确检索。系统管理员可以通过此逻辑快速定位特定用户的在线状态，包括会话ID、登录时间、最后活跃时间、IP地址等关键信息，从而有效监控系统安全状况并识别异常登录行为。该逻辑是在线用户管理功能页面的核心数据支撑，确保管理员能够实时掌握系统用户活动情况。

### 功能要点

- **在线用户条件查询**：系统管理员可以通过输入用户名等条件参数，对当前所有在线用户会话进行精确筛选，系统将返回匹配条件的在线用户列表及其详细会话信息，包括用户身份、登录时间、最后活跃时间、IP地址和会话活跃状态等关键数据，帮助管理员快速定位特定用户并监控其活动情况。

### 逻辑签名

```naturalts path="app.logics.searchOnlineUsers.ts"
$Logic({
    description: '搜索在线用户会话',
    directory: 'system_management(系统管理)'
})
export declare function searchOnlineUsers(username: String): { list: List<{ onlineSession: app.dataSources.defaultDS.entities.OnlineSession, systemAccount: app.dataSources.defaultDS.entities.SystemAccount }>, total: Integer };
```

### 被前端调用

- **在线用户管理（onlineUserManagement）**：在线用户管理页面使用此服务端逻辑实现按用户名搜索特定在线用户的功能，管理员输入用户名后调用此逻辑获取匹配的在线用户会话列表，并在表格中展示用户会话详情。

### 依赖的枚举、实体

- **数据建模-实体-在线会话**：[系统管理-实体-在线会话（OnlineSession）](specs/001-bootdo-management-system/plan/data-model/entity-OnlineSession.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无匹配内容

