# 环保管理-加载环境监测下拉选项（loadEnvironmentalMonitoringForSelect）

- **生成时间**：2026-03-25

## 加载环境监测下拉选项（loadEnvironmentalMonitoringForSelect）

### 功能概述

加载环境监测下拉选项服务端逻辑用于获取系统中环境监测记录的简化列表，专门用于前端下拉选择组件的数据填充。该逻辑根据指定的过滤条件（如监测位置、时间范围等）查询环境监测数据，并返回包含ID和显示名称的精简数据结构，支持前端在表单、筛选器等场景中快速选择环境监测记录。通过此接口，用户可以在需要关联环境监测数据的功能页面中，便捷地从下拉列表中选择合适的监测记录，提高数据录入效率和准确性。

### 功能要点

- **下拉选项数据查询**：根据前端传入的过滤条件（主要是监测位置关键词），查询符合条件的环境监测记录，并返回精简的数据结构，仅包含ID和用于显示的文本信息（监测位置+监测时间）。该功能点确保下拉选项数据的相关性和实用性，避免返回过多无关数据影响用户体验。系统支持按监测位置进行模糊匹配，使用户能够通过部分关键词快速定位到目标监测记录。

### 逻辑签名

```naturalts path="app.logics.loadEnvironmentalMonitoringForSelect.ts"
$Logic({
    description: '加载环境监测下拉选项',
    directory: 'environmental_management(环保管理)'
})
export declare function loadEnvironmentalMonitoringForSelect(location?: String): List<{ id: Integer, displayText: String }>;
```

### 被前端调用

- **排放控制（emissionControl）**：在排放控制功能页面的表单中，当用户需要选择关联的环境监测记录时，前端会调用此服务端逻辑获取环境监测下拉选项列表，用户可以从下拉列表中选择合适的监测记录进行关联。
- **合规检查（complianceInspection）**：在合规检查功能页面中，用户创建或编辑合规检查记录时，需要关联相关的环境监测数据，此时会调用此服务端逻辑获取环境监测下拉选项，便于用户快速选择。

### 依赖的枚举、实体

- **数据建模-实体-环境监测**：[环保管理-实体-环境监测（EnvironmentalMonitoring）](specs/001-bootdo-management-system/plan/data-model/entity-EnvironmentalMonitoring.md)

### 依赖的外部能力

无