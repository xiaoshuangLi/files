# 内容管理-加载内容权限列表（loadContentPermissionList）

- **生成时间**：2026-03-25

## 加载内容权限列表（loadContentPermissionList）

### 功能概述

加载内容权限列表服务端逻辑用于查询和获取系统中所有内容权限配置的详细信息，支持按角色名称进行条件筛选。该逻辑从内容权限实体（ContentPermission）中检索数据，并关联用户角色实体（UserRole）以获取完整的角色信息，包括角色ID、角色名称等关键字段。返回的数据结构包含权限配置的完整信息，如内容类型、各项操作权限（可创建、可读取、可更新、可删除）以及关联的角色信息，为前端权限控制页面的表格展示提供数据支撑。该服务确保管理员能够全面了解当前系统中的内容权限分配情况，便于进行权限审计和管理。

### 功能要点

- **权限列表查询与展示**：系统根据前端请求参数（主要是角色名称关键词）查询内容权限配置列表，支持模糊匹配搜索。查询结果包含完整的权限配置信息，包括角色ID、角色名称、内容类型以及各项操作权限状态（可创建、可读取、可更新、可删除）。返回的数据经过格式化处理，直接适用于前端表格组件的渲染，确保权限管理界面能够清晰展示当前所有内容权限配置的状态和详情。

### 逻辑签名

```naturalts path="app.logics.loadContentPermissionList.ts"
$Logic({
    description: '加载内容权限列表',
    directory: 'content_management(内容管理)'
})
export declare function loadContentPermissionList(page: Integer, size: Integer, roleName?: String): { list: List<{ contentPermission: app.dataSources.defaultDS.entities.ContentPermission, userRole: app.dataSources.defaultDS.entities.UserRole }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 当前页码，从1开始 |
| size | 每页条数 | Integer | 每页显示的记录数量 |
| roleName | 角色名称 | String | 角色名称关键词，用于模糊搜索（可选） |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 权限列表 | List<{ contentPermission: app.dataSources.defaultDS.entities.ContentPermission, userRole: app.dataSources.defaultDS.entities.UserRole }> | 权限列表，每个元素包含内容权限实体和关联的用户角色实体 |
| total | 总条数 | Integer | 符合条件的总记录数 |

### 被前端调用

- **权限控制（contentPermission）**：权限控制页面在初始化时调用此服务端逻辑加载所有内容权限配置列表，并在用户执行角色名称搜索操作时再次调用，传入搜索关键词以获取筛选后的权限列表。该逻辑为页面表格提供了完整的数据源，支持权限配置的查看和管理功能。

### 依赖的枚举、实体

- **数据建模-实体-内容权限**：[内容管理-实体-内容权限（ContentPermission）](specs/001-bootdo-management-system/plan/data-model/entity-ContentPermission.md)
- **数据建模-实体-用户角色**：[系统管理-实体-用户角色（UserRole）](specs/001-bootdo-management-system/plan/data-model/entity-UserRole.md)

### 依赖的外部能力

无匹配内容

