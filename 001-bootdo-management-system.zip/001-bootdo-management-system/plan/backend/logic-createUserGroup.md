# 通用领域服务-创建用户组（createUserGroup）

- **生成时间**：2026-03-25

## 创建用户组（createUserGroup）

### 功能概述

创建用户组服务端逻辑用于在系统中新增一个用户组，包括设置用户组的基本信息。该功能是工作流引擎用户管理的核心组成部分，支持管理员根据业务需求灵活创建不同类型的用户组，如部门团队、项目小组或职能角色组，从而实现精细化的权限管理和任务分配。

### 功能要点

- **用户组基本信息管理**：支持创建包含用户组名称和描述等基本信息的用户组实体。用户组名称必须唯一且符合命名规范，描述信息可详细说明用户组的用途和职责范围。系统会自动记录创建时间和创建人信息，并为新用户组分配唯一标识符，确保数据完整性和可追溯性。用户组默认处于激活状态，可以立即用于工作流任务分配和权限管理。

### 逻辑签名

```naturalts path="app.logics.createUserGroup.ts"
$Logic({
    description: '创建用户组',
    directory: 'user_group_management(用户组管理)'
})
export declare function createUserGroup(userGroup: app.dataSources.defaultDS.entities.UserGroup): app.dataSources.defaultDS.entities.UserGroup;
```

### 被前端调用

- **用户和组管理（userGroupManagement）**：在用户和组管理页面中，管理员可以通过创建用户组功能来建立新的用户组，设置用户组基本信息，实现工作流中用户分组的灵活管理。

### 依赖的枚举、实体

- **数据建模-实体-用户组**：[系统管理-实体-用户组（UserGroup）](specs/001-bootdo-management-system/plan/data-model/entity-UserGroup.md)

### 依赖的外部能力

无