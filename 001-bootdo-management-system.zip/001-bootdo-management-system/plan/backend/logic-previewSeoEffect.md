# 内容管理-预览SEO效果（previewSeoEffect）

- **生成时间**：2026-03-25

## 预览SEO效果（previewSeoEffect）

### 功能概述

预览SEO效果服务端逻辑用于根据提供的SEO配置参数，生成模拟搜索引擎结果页面的预览数据。该逻辑接收文章ID和SEO配置参数（包括自定义URL、Meta标题、Meta描述、关键词等），结合文章的实际内容信息，构建出在主流搜索引擎（如Google、Bing）中可能显示的搜索结果卡片样式。通过此逻辑，内容管理员可以在保存SEO配置前直观地预览优化效果，确保配置的准确性和有效性，从而提升网站内容在搜索引擎中的展示质量和点击率。

### 功能要点

- **SEO效果实时预览**：根据传入的文章ID和SEO配置参数，系统能够实时生成搜索引擎结果页面的预览数据，包括标题、URL路径和描述的完整展示效果。预览功能支持不同搜索引擎的显示规则差异，如Google对标题长度（约60字符）和描述长度（约160字符）的限制，确保预览效果与实际搜索结果保持一致。系统还会根据SEO最佳实践提供优化建议，如标题是否包含关键词、描述是否具有吸引力等，帮助内容管理员做出更好的SEO决策。

- **多搜索引擎适配**：预览功能支持多种主流搜索引擎的显示规则，包括Google、Bing、百度等，每种搜索引擎在标题长度、描述长度、URL显示方式等方面都有细微差异。系统会根据用户选择的搜索引擎类型，自动调整预览参数，确保预览效果的准确性。这种多引擎适配能力使内容管理员能够针对不同目标市场和用户群体进行精准的SEO优化，最大化内容的搜索曝光效果。

### 逻辑签名

```naturalts path="app.logics.previewSeoEffect.ts"
$Logic({
    description: '预览SEO效果',
    directory: 'content_management(内容管理)'
})
export declare function previewSeoEffect(
    articleId: Integer,
    seoConfig: app.dataSources.defaultDS.entities.SeoOptimization
): {
    titlePreview: String,
    urlPreview: String,
    descriptionPreview: String,
    searchEngine: String,
    characterCount: { title: Integer, description: Integer },
    optimizationSuggestions: List<String>
};
```

### 被前端调用

- **SEO优化（seoOptimization）**：SEO优化页面在内容管理员配置SEO参数时，会实时调用此服务端逻辑生成预览效果。当用户输入或修改自定义URL、Meta标题、Meta描述等参数时，前端会将当前配置传递给此逻辑，获取对应的预览数据并在SEO预览组件中展示，帮助用户直观了解SEO配置的实际效果。

### 依赖的枚举、实体

- **数据建模-实体-SEO优化**：[内容管理-实体-SeoOptimization（SeoOptimization）](specs/001-bootdo-management-system/plan/data-model/entity-SeoOptimization.md)
- **数据建模-实体-文章内容**：[内容管理-实体-文章内容（ArticleContent）](specs/001-bootdo-management-system/plan/data-model/entity-ArticleContent.md)

### 依赖的外部能力

无