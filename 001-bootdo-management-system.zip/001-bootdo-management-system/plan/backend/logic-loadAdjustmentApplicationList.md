# 预算管理-分页查询调整申请列表（loadAdjustmentApplicationList）

- **生成时间**：2026-03-25

## 分页查询调整申请列表（loadAdjustmentApplicationList）

### 功能概述

分页查询调整申请列表服务端逻辑是预算管理模块的核心数据查询接口，专门用于支持调整申请功能页面的数据展示需求。该逻辑提供高效的分页查询能力，能够根据多种筛选条件（如预算分配、申请人、审批状态、申请时间范围等）检索调整申请记录，并返回包含完整关联信息的结果集。通过与工作流引擎的深度集成，该逻辑能够准确反映每个调整申请的当前审批状态（草稿、已提交、审核中、已批准、已驳回），确保用户在前端页面能够实时查看申请的处理进度。同时，该逻辑还支持按指定字段进行排序，满足用户对数据展示顺序的个性化需求，为预算管理人员提供全面、准确、实时的调整申请数据视图。

### 功能要点

- **分页查询与筛选功能**：支持标准的分页参数（页码、每页条数）和多维度筛选条件，包括预算分配ID、申请人ID、审批状态、申请时间范围等，能够高效地从大量调整申请记录中检索出符合条件的数据子集，确保系统在大数据量场景下的查询性能和响应速度。
- **关联数据加载**：在查询调整申请列表的同时，自动加载关联的预算分配信息和申请人账户信息，避免前端多次请求造成的数据不一致和性能问题。返回的数据结构包含完整的调整申请实体以及其关联的预算分配和系统账户实体，为前端提供一站式的数据服务。
- **状态管理与排序**：准确维护和返回调整申请的审批状态信息，支持基于审批状态枚举值的精确筛选。同时提供灵活的排序功能，允许用户按调整ID、新金额、申请时间等关键字段进行升序或降序排列，提升用户体验和数据可读性。

### 逻辑签名

```naturalts path="app.logics.loadAdjustmentApplicationList.ts"
$Logic({
    description: '分页查询调整申请列表',
    directory: 'budget_management(预算管理)'
})
export declare function loadAdjustmentApplicationList(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.AdjustmentApplication): { list: List<{ adjustmentApplication: app.dataSources.defaultDS.entities.AdjustmentApplication, budgetAllocation: app.dataSources.defaultDS.entities.BudgetAllocation, systemAccount: app.dataSources.defaultDS.entities.SystemAccount }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 查询的页码，从1开始 |
| size | 每页条数 | Integer | 每页显示的记录数量 |
| sort | 排序字段 | String | 用于排序的字段名称 |
| order | 排序顺序 | String | 排序顺序，'ascending'表示升序，'descending'表示降序 |
| filter | 过滤条件 | app.dataSources.defaultDS.entities.AdjustmentApplication | 包含预算分配ID、申请人ID、审批状态、申请时间范围等筛选条件的调整申请实体 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 调整申请列表 | List<{ adjustmentApplication: app.dataSources.defaultDS.entities.AdjustmentApplication, budgetAllocation: app.dataSources.defaultDS.entities.BudgetAllocation, systemAccount: app.dataSources.defaultDS.entities.SystemAccount }> | 调整申请列表，每个列表项包含调整申请实体、关联的预算分配实体和申请人系统账户实体 |
| total | 总条数 | Integer | 符合筛选条件的调整申请总记录数 |

### 被前端调用

- **调整申请（adjustmentApplication）**：在调整申请页面中，该服务端逻辑被用于加载分页的调整申请列表数据。页面初始化时调用此逻辑获取第一页数据，默认每页20条记录。当用户执行筛选查询（基于预算分配、申请人、审批状态、申请时间范围等条件）或切换分页时，重新调用此逻辑获取相应的数据子集，并在表格中展示调整ID、预算分配、申请人、新金额、调整原因、审批状态、申请时间等关键字段信息。

### 依赖的枚举、实体

- **数据建模-枚举-审批状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-调整申请**：[预算管理-实体-调整申请（AdjustmentApplication）](specs/001-bootdo-management-system/plan/data-model/entity-AdjustmentApplication.md)
- **数据建模-实体-预算分配**：[预算管理-实体-预算分配（BudgetAllocation）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetAllocation.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无匹配内容

