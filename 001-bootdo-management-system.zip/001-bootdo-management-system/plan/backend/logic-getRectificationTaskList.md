# 质量管理-获取整改任务列表（getRectificationTaskList）

- **生成时间**：2026-03-25

## 获取整改任务列表（getRectificationTaskList）

### 功能概述

获取整改任务列表服务端逻辑是质量管理模块的核心功能之一，专门用于查询和筛选系统中的整改任务数据。该逻辑支持根据多种条件进行任务筛选，包括任务状态、分配人员、关联的质量问题ID、创建时间范围等关键参数。通过此接口，前端页面能够高效地获取符合特定条件的整改任务列表，并以分页形式展示，确保用户界面的响应速度和数据加载效率。该逻辑还支持对查询结果进行排序，允许用户按创建时间、更新时间或任务状态等字段进行升序或降序排列。此外，接口返回的数据包含完整的整改任务信息，包括任务基本信息、关联的质量问题详情、分配人员信息以及任务当前状态等，为质量问题跟踪和管理提供全面的数据支持。

### 功能要点

- **多条件筛选功能**：支持根据任务状态（待处理、处理中、已完成、已取消）、分配人员ID、关联质量问题ID、创建时间范围等多个维度进行精确筛选，帮助用户快速定位所需的整改任务。筛选条件采用灵活的组合方式，用户可以根据实际需求选择一个或多个条件进行查询，系统会自动构建相应的查询语句并返回匹配的结果集。
- **分页与排序功能**：实现高效的分页查询机制，支持指定页码和每页显示数量，避免一次性加载大量数据导致的性能问题。同时提供多种排序选项，包括按创建时间、更新时间、任务状态等字段进行升序或降序排列，确保用户能够按照自己的偏好查看整改任务列表，提升用户体验和操作效率。
- **关联数据整合功能**：在返回整改任务列表的同时，自动关联并整合相关的关键数据，包括关联的质量问题基本信息（如问题描述、报告时间等）、分配人员的账户信息（如用户名、部门等）以及任务状态的详细说明。这种数据整合减少了前端多次请求的需要，提高了数据获取效率，为用户提供更加完整和直观的任务视图。

### 逻辑签名

```naturalts path="app.logics.getRectificationTaskList.ts"
$Logic({
    description: "获取整改任务列表",
    directory: "quality_management(质量管理)"
})
export declare function getRectificationTaskList(
    page: Integer,
    size: Integer,
    sort: String,
    order: String,
    status?: app.enums.TaskStatusEnum,
    assigneeId?: Integer,
    qualityIssueId?: Integer,
    createdTimeStart?: DateTime,
    createdTimeEnd?: DateTime
): { list: List<app.dataSources.defaultDS.entities.RectificationTask>, total: Integer };
```

### 被前端调用

- **整改任务分配（rectificationTask）**：在整改任务分配页面的整改列表界面中，通过调用此服务端逻辑获取所有整改任务的列表数据，支持用户查看、搜索和筛选整改任务。页面根据返回的数据渲染整改任务表格，并提供分页导航功能。
- **问题跟踪（issueTracking）**：在问题跟踪页面中，当需要查看与特定质量问题关联的所有整改任务时，通过调用此服务端逻辑并传入qualityIssueId参数，获取该质量问题下的所有整改任务列表，用于展示整改任务的执行情况和进度。

### 依赖的枚举、实体

- **数据建模-枚举-任务状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-整改任务**：[质量管理-实体-整改任务（RectificationTask）](specs/001-bootdo-management-system/plan/data-model/entity-RectificationTask.md)
- **数据建模-实体-质量问题**：[质量管理-实体-质量问题（QualityIssue）](specs/001-bootdo-management-system/plan/data-model/entity-QualityIssue.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无外部能力依赖