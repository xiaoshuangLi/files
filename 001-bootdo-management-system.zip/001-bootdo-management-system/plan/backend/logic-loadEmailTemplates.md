# 办公自动化-加载邮件模板（loadEmailTemplates）

- **生成时间**：2026-03-25

## 加载邮件模板（loadEmailTemplates）

### 功能概述

加载邮件模板服务端逻辑提供分页查询系统中邮件模板的功能，支持按模板名称、消息类型、启用状态等条件进行过滤，并支持按指定字段和顺序进行排序。该逻辑返回符合条件的邮件模板列表及其总数，用于在邮件集成功能页面中展示可用的邮件模板，方便用户在撰写邮件时选择合适的模板。通过该逻辑，系统能够高效地管理和检索邮件模板，提升用户使用邮件功能的体验。

### 功能要点

- **分页查询功能**：支持分页查询邮件模板，通过page和size参数控制返回结果的页码和每页条数，避免一次性加载过多数据导致性能问题。系统会根据传入的分页参数计算并返回对应页的数据以及总记录数，确保前端能够正确显示分页控件。
- **多条件过滤功能**：支持按模板名称、消息类型、启用状态等多个条件组合过滤邮件模板。用户可以通过模板名称模糊匹配查找特定模板，通过消息类型筛选出仅适用于邮件的模板，通过启用状态过滤出当前可用的模板，提高模板查找的精准度。
- **排序功能**：支持按任意字段（如创建时间、模板名称等）进行升序或降序排序，确保返回的邮件模板列表按照用户期望的顺序排列。系统会根据传入的sort和order参数动态构建排序规则，满足不同场景下的排序需求。
- **邮件模板数据结构**：返回的邮件模板数据包含完整的模板信息，包括模板ID、模板名称、模板编码、消息类型、模板标题、模板内容、启用状态和备注信息等。这些信息为前端提供了足够的数据来展示和使用邮件模板。

### 逻辑签名

```naturalts path="app.logics.loadEmailTemplates.ts"
$Logic({
    description: '加载邮件模板',
    directory: 'office_automation(办公自动化)'
})
export declare function loadEmailTemplates(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.MessageTemplateEntity): { list: List<app.dataSources.defaultDS.entities.MessageTemplateEntity>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 查询的页码，从1开始 |
| size | 每页条数 | Integer | 每页返回的记录数 |
| sort | 排序字段 | String | 用于排序的字段名 |
| order | 排序顺序 | String | 排序顺序，'asc'表示升序，'desc'表示降序 |
| filter | 过滤条件 | app.dataSources.defaultDS.entities.MessageTemplateEntity | 邮件模板过滤条件，支持模板名称、消息类型、启用状态等字段的过滤 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 邮件模板列表 | List<app.dataSources.defaultDS.entities.MessageTemplateEntity> | 符合条件的邮件模板列表 |
| total | 总条数 | Integer | 符合条件的邮件模板总数量 |

### 被前端调用

- **邮件集成（emailIntegration）**：在邮件集成功能页面中，当用户需要选择邮件模板时，系统会调用此服务端逻辑加载可用的邮件模板列表。用户可以在模板选择界面中浏览、搜索和筛选邮件模板，并选择合适的模板应用到当前正在撰写的邮件中。

### 依赖的枚举、实体

- **数据建模-枚举-消息类型**：[系统管理-枚举-消息类型（MessageTypeEnum）](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-消息模板**：[系统管理-实体-消息模板（MessageTemplateEntity）](specs/001-bootdo-management-system/plan/data-model/entity-MessageTemplateEntity.md)

### 依赖的外部能力
