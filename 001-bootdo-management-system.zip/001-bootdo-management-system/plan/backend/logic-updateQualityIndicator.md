# 质量管理-更新质量指标（updateQualityIndicator）

- **生成时间**：2026-03-25

## 更新质量指标（updateQualityIndicator）

### 功能概述

更新质量指标服务端逻辑用于修改已存在的质量指标记录，支持质量管理员对质量指标的各项属性进行编辑和更新。该逻辑接收包含质量指标ID和更新字段的请求参数，验证数据的有效性后，将变更持久化到数据库中。更新操作会自动记录操作时间和操作人信息，并确保与关联的质量问题保持一致性。通过此逻辑，系统能够维护质量指标数据的准确性和时效性，为质量管理决策提供可靠的数据支持。

### 功能要点

- **质量指标数据更新**：质量管理员可以通过此逻辑更新质量指标的指标名称、单位、目标值、实际值、测量时间等关键属性。系统会验证所有必填字段的完整性，并确保数值类型字段的格式正确。更新操作会保留原有的质量问题关联关系，但允许在必要时重新指定关联的质量问题。更新成功后，系统会自动记录更新时间和更新人信息，确保数据变更的可追溯性。

### 逻辑签名

```naturalts path="app.logics.updateQualityIndicator.ts"
$Logic({
    description: '更新质量指标',
    directory: 'quality_management(质量管理)'
})
export declare function updateQualityIndicator(qualityIndicator: app.dataSources.defaultDS.entities.QualityIndicator): app.dataSources.defaultDS.entities.QualityIndicator;
```

### 被前端调用

- **质量指标（qualityIndicator）**：质量管理员在质量指标管理页面点击编辑按钮后，系统会加载质量指标详情并填充到表单中，管理员修改相关信息后点击保存按钮，前端会调用此服务端逻辑提交更新请求，完成质量指标记录的修改。

### 依赖的枚举、实体

- **质量管理-实体-质量指标**：[质量管理-实体-质量指标（QualityIndicator）](specs/001-bootdo-management-system/plan/data-model/entity-QualityIndicator.md)
- **质量管理-实体-质量问题**：[质量管理-实体-质量问题（QualityIssue）](specs/001-bootdo-management-system/plan/data-model/entity-QualityIssue.md)

### 依赖的外部能力

无外部能力依赖。