# 办公自动化-创建待办任务（createTodoTask）

- **生成时间**：2026-03-25

## 创建待办任务（createTodoTask）

### 功能概述

创建待办任务服务端逻辑是办公自动化模块的核心功能之一，用于在系统中创建新的待办任务记录。该逻辑接收包含任务标题、描述、分配用户ID、截止日期等信息的任务实体，验证必填字段的完整性，并将任务状态默认设置为"待处理"，然后将任务数据持久化到数据库中。创建成功后返回完整的任务实体信息，包括系统自动生成的主键ID、创建时间、更新时间等元数据。该逻辑确保任务分配的有效性，通过外键约束验证分配用户的合法性，并支持与其他办公自动化功能（如日程安排、邮件通知）的后续集成，为用户提供全面的任务管理体验。

### 功能要点

- **任务创建与验证**：该功能点负责接收前端传入的待办任务数据，验证任务标题和分配用户ID等必填字段是否已提供，确保任务数据的完整性和有效性。系统会自动填充任务状态为"待处理"（Pending），并验证分配的用户ID在系统账户表中是否存在，防止无效的用户分配。创建过程中还会自动记录任务的创建时间和创建人信息，确保数据的可追溯性。

### 逻辑签名

```naturalts path="app.logics.createTodoTask.ts"
$Logic({
    description: '创建待办任务',
    directory: 'office_automation(办公自动化)',
    transactional: true
})
export declare function createTodoTask(todoTask: app.dataSources.defaultDS.entities.TodoTask): app.dataSources.defaultDS.entities.TodoTask;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| todoTask | 待办任务实体 | app.dataSources.defaultDS.entities.TodoTask | 包含任务标题、描述、分配用户ID、截止日期等信息的待办任务实体，任务状态将默认设置为待处理 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 创建结果 | app.dataSources.defaultDS.entities.TodoTask | 补充了ID、创建时间、更新时间等系统字段的完整待办任务实体 |

### 被前端调用

- **待办事项（todoTask）**：在待办事项页面中，用户点击"新建任务"按钮时，系统会调用此服务端逻辑来创建新的待办任务。该逻辑实现了任务创建的核心业务功能，包括验证必填字段、设置默认状态、保存任务数据等。

### 依赖的枚举、实体

- **数据建模-枚举-任务状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-待办任务**：[办公自动化-实体-待办任务（TodoTask）](specs/001-bootdo-management-system/plan/data-model/entity-TodoTask.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无