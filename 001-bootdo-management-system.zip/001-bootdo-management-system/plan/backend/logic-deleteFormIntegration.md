# 工作流引擎-删除表单集成（deleteFormIntegration）

- **生成时间**：2026-03-25

## 删除表单集成（deleteFormIntegration）

### 功能概述

删除表单集成服务端逻辑负责从系统中移除指定的表单集成记录。该功能确保在工作流管理过程中，用户可以安全地删除不再需要的表单数据，同时维护数据的一致性和完整性。删除操作会验证表单集成记录的存在性，并检查当前用户是否具有执行删除操作的权限。成功删除后，相关的表单数据将从系统中永久移除，且无法恢复。此功能对于清理测试数据、处理错误提交或撤销不必要的表单集成至关重要，是工作流引擎表单管理功能的重要组成部分。

### 功能要点

- **安全删除验证**：在执行删除操作前，系统会验证待删除的表单集成记录是否存在，并检查当前用户是否具有删除该记录的权限。如果记录不存在或用户无权限，系统将返回相应的错误信息，防止非法删除操作。
- **数据一致性保障**：删除操作会确保与表单集成相关的所有数据都被正确清理，包括表单数据内容和关联的元数据。系统会维护数据库的引用完整性，确保删除操作不会破坏其他相关实体的数据一致性。
- **操作审计记录**：每次删除操作都会被记录在操作日志中，包含操作时间、操作用户、被删除的表单集成ID等关键信息，便于后续的审计和问题追踪。

### 逻辑签名

```naturalts path="app.logics.deleteFormIntegration.ts"
$Logic({
    description: '删除表单集成记录',
    directory: 'workflow_engine(工作流引擎)',
    transactional: true
})
export declare function deleteFormIntegration(id: Integer): Boolean;
```

### 被前端调用

- **通用业务模块-表单集成（formIntegration）**：在表单集成管理页面中，用户可以通过点击删除按钮来调用此服务端逻辑，实现删除选中的表单集成记录。该操作会经过二次确认，确保用户明确知晓删除操作的不可逆性。

### 依赖的枚举、实体

- **工作流引擎-实体-表单集成**：[工作流引擎-实体-表单集成（FormIntegration）](specs/001-bootdo-management-system/plan/data-model/entity-FormIntegration.md)
- **工作流引擎-实体-流程实例**：[工作流引擎-实体-流程实例（ProcessInstance）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessInstance.md)

### 依赖的外部能力

无