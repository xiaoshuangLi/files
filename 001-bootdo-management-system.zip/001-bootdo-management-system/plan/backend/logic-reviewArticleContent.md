# 内容管理-审核文章（reviewArticleContent）

- **生成时间**：2026-03-25

## 审核文章（reviewArticleContent）

### 功能概述

审核文章服务端逻辑实现了内容管理系统中文章审核的核心业务功能，支持具有审核权限的用户对提交的文章进行审批决策。该逻辑处理文章从"待审核"状态到"已发布"或"草稿"状态的转换流程，确保内容质量和合规性。审核过程中，系统会验证审核人的权限、记录审核操作日志，并根据审核结果更新文章状态。该逻辑还支持审核意见的记录和传递，为内容创作者提供明确的修改指导。

### 功能要点

- **审核权限验证**：系统在执行审核操作前，必须验证当前用户是否具有审核指定文章的权限。权限验证基于用户的角色分配和文章所属栏目的权限配置，确保只有授权用户才能执行审核操作，防止未授权的内容发布。
- **审核状态转换**：根据审核结果（批准或驳回），系统自动更新文章的状态。批准时将文章状态从"待审核"变更为"已发布"，并设置发布时间；驳回时将文章状态变更为"草稿"，允许作者重新编辑修改。状态转换过程确保数据一致性，防止非法状态流转。
- **审核意见记录**：支持审核人员填写详细的审核意见，包括内容修改建议、格式调整要求等。审核意见与文章关联存储，供作者参考修改，并作为内容质量控制的历史记录，便于后续的质量分析和改进。
- **操作日志记录**：系统自动记录审核操作的详细日志，包括审核人、审核时间、审核结果和审核意见等信息。操作日志为内容审核流程提供完整的审计跟踪，确保审核过程的透明性和可追溯性。

### 逻辑签名

```naturalts path="app.logics.reviewArticleContent.ts"
$Logic({
    description: '审核文章内容',
    directory: 'content_management(内容管理)',
    transactional: true
})
export declare function reviewArticleContent(articleId: Integer, reviewResult: app.enums.ApprovalStatusEnum, reviewComment?: String): app.dataSources.defaultDS.entities.ArticleContent;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| articleId | 文章ID | Integer | 需要审核的文章主键ID |
| reviewResult | 审核结果 | app.enums.ApprovalStatusEnum | 审核结果，可选值为Approved（已批准）或Rejected（已驳回） |
| reviewComment | 审核意见 | String? | 可选的审核意见，用于向作者提供修改建议 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 审核后的文章 | app.dataSources.defaultDS.entities.ArticleContent | 更新后的文章实体，包含最新的状态和相关信息 |

### 被前端调用

- **文章管理（articleContent）**：在文章管理页面的待审核文章列表中，具有审核权限的用户点击"审核"按钮后，系统调用此服务端逻辑来处理文章的审核操作。该逻辑实现了文章状态的转换、审核意见的记录以及操作日志的记录，确保内容审核流程的完整性和规范性。

### 依赖的枚举、实体

- **数据建模-枚举-审批状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-文章内容**：[内容管理-实体-文章内容（ArticleContent）](specs/001-bootdo-management-system/plan/data-model/entity-ArticleContent.md)

### 依赖的外部能力

无匹配内容

