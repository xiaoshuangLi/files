# 环保管理-获取检查员列表（getInspectorList）

- **生成时间**：2026-03-25

## 获取检查员列表（getInspectorList）

### 功能概述

获取检查员列表服务端逻辑用于为合规检查功能提供可用的检查员数据。该逻辑从系统账户实体中筛选出具有检查员角色的用户，并返回包含用户ID、全名、邮箱等基本信息的列表，供前端在创建或编辑合规检查记录时选择合适的检查员。此逻辑确保只有具备相应权限的用户才能被选为检查员，同时支持按用户名或全名进行模糊搜索，提高用户体验和操作效率。

### 功能要点

- **检查员筛选功能**：根据用户角色权限筛选出可作为检查员的系统账户，确保只有具备环保检查相关权限的用户才能出现在检查员列表中。系统通过查询用户角色映射关系，识别具有"环保检查员"或类似权限角色的用户，并将其纳入可选检查员范围。此功能保证了合规检查工作的专业性和权威性，防止无权限人员被错误分配检查任务。

### 逻辑签名

```naturalts path="app.logics.getInspectorList.ts"
$Logic({
    description: "获取检查员列表",
    directory: "environmental_management(环保管理)"
})
export declare function getInspectorList(
    searchKeyword?: String
): Array<{
    id: Integer;
    fullName: String;
    email: String;
    username: String;
}>;
```

### 被前端调用

- **合规检查（complianceInspection）**：在合规检查页面的新增和编辑表单中，通过下拉选择框调用此服务端逻辑获取可选的检查员列表，用户可以选择合适的检查员来执行合规检查任务。

### 依赖的枚举、实体

- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无