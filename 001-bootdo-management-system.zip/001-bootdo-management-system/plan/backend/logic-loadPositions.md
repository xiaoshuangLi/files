# 权限中心-获取岗位列表（loadPositions）

- **生成时间**：2026-03-25

## 获取岗位列表（loadPositions）

### 功能概述

获取岗位列表服务端逻辑用于查询和获取系统中所有岗位信息的分页列表，支持按岗位名称、所属部门等条件进行筛选，并提供排序功能。该逻辑是权限中心用户管理模块的重要数据支撑，为前端用户创建和编辑页面中的岗位选择器提供数据源。通过关联查询组织部门实体，返回的岗位数据包含完整的岗位信息以及所属部门的详细信息，确保用户能够准确选择合适的岗位进行分配。该服务支持灵活的查询条件组合，满足不同场景下的岗位数据检索需求。

### 功能要点

- **岗位分页查询与筛选**：支持标准的分页查询机制，通过page和size参数控制返回结果的页码和每页条数，避免一次性加载过多数据导致性能问题。同时支持按岗位名称进行模糊匹配搜索，以及按所属部门ID进行精确筛选，用户可以根据实际需求组合不同的查询条件，快速定位到目标岗位数据。

- **岗位数据关联查询**：在返回岗位列表的同时，自动关联查询岗位所属的组织部门信息，包括部门ID、部门名称等关键字段。这种关联查询减少了前端的多次请求开销，提高了数据展示的完整性和用户体验，确保用户在选择岗位时能够清晰了解岗位的组织归属关系。

- **动态排序功能**：支持按岗位名称、创建时间等字段进行升序或降序排列，通过sort和order参数控制排序规则。默认按岗位名称升序排列，但允许用户根据业务需求调整排序方式，便于在大量岗位数据中快速找到所需信息。

### 逻辑签名

```naturalts path="app.logics.loadPositions.ts"
$Logic({
    description: '获取岗位列表',
    directory: 'permission_center(权限中心)'
})
export declare function loadPositions(page: Integer, size: Integer, sort: String, order: String, positionName?: String, departmentId?: Integer): { list: List<{ id: Integer, positionName: String, departmentId: Integer, departmentName: String, description: String, createdTime: DateTime }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 分页查询的页码，从1开始计数 |
| size | 每页条数 | Integer | 每页返回的记录数量 |
| sort | 排序字段 | String | 排序的字段名，如"positionName"、"createdTime"等 |
| order | 排序顺序 | String | 排序方向，"asc"表示升序，"desc"表示降序 |
| positionName | 岗位名称 | String | 岗位名称关键词，用于模糊搜索（可选） |
| departmentId | 部门ID | Integer | 所属部门ID，用于精确筛选（可选） |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 岗位列表 | List<{ id: Integer, positionName: String, departmentId: Integer, departmentName: String, description: String, createdTime: DateTime }> | 岗位列表，每个列表项包含岗位ID、岗位名称、所属部门ID、部门名称、描述和创建时间 |
| total | 总条数 | Integer | 符合筛选条件的总记录数，用于分页计算 |

### 被前端调用

- **用户管理页（userManagement）**：在用户创建和编辑页面中，当用户需要为新用户或现有用户分配岗位时，前端会调用此服务端逻辑获取可用的岗位列表。该逻辑支持岗位名称搜索和部门筛选功能，帮助用户快速找到并选择合适的岗位进行分配。

### 依赖的枚举、实体

- **数据建模-实体-组织部门**：[系统管理-实体-组织部门（OrganizationDepartment）](specs/001-bootdo-management-system/plan/data-model/entity-OrganizationDepartment.md)

### 依赖的外部能力

无匹配内容

