# 预算管理-更新报表格式（updateReportFormat）

- **生成时间**：2026-03-25

## 更新报表格式（updateReportFormat）

### 功能概述

该服务端逻辑负责更新预算执行报表的格式配置，允许系统管理员或具有相应权限的用户自定义报表的展示样式、数据字段、排序方式和分组规则。通过此功能，用户可以根据不同的业务需求和分析目的，灵活调整报表的呈现方式，提高预算执行数据的可读性和分析效率。报表格式更新后将立即生效，影响所有使用该报表模板的用户视图。

### 功能要点

- **报表格式自定义配置**：支持用户对预算执行报表的格式进行全面自定义，包括选择需要显示的数据字段（如预算项目、实际支出、预算余额、执行率等）、设置字段的显示顺序、定义数值的格式化方式（如货币符号、小数位数）、配置条件格式（如超支项目高亮显示）以及设置默认的排序和分组规则。用户可以保存多个报表格式模板，并在不同场景下快速切换使用。

### 逻辑签名

```naturalts path="app.logics.updateReportFormat.ts"
$Logic({
    description: '更新报表格式',
    directory: 'budget_management(预算管理)',
    transactional: true
})
export declare function updateReportFormat(reportFormat: app.dataSources.defaultDS.entities.ReportFormat): app.dataSources.defaultDS.entities.ReportFormat;
```

### 被前端调用

- **报表格式（reportFormat）**：在报表格式页面中，用户可以通过报表格式编辑功能调用此服务端逻辑，更新已有的报表格式配置，实现报表样式的自定义调整。

### 依赖的枚举、实体

- **数据建模-实体-报表格式**：[预算管理-实体-报表格式（ReportFormat）](specs/001-bootdo-management-system/plan/data-model/entity-ReportFormat.md)
- **数据建模-实体-更新结果**：[系统管理-实体-更新结果（UpdateResult）](specs/001-bootdo-management-system/plan/data-model/entity-UpdateResult.md)

### 依赖的外部能力
