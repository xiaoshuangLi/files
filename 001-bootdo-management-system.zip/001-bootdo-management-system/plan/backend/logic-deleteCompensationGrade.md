# 薪资管理-删除薪酬档级（deleteCompensationGrade）

- **生成时间**：2026-03-25

## 删除薪酬档级（deleteCompensationGrade）

### 功能概述

删除薪酬档级服务端逻辑用于安全地移除系统中的薪酬档级记录。该功能确保在删除操作前进行必要的业务验证，防止删除已被引用的档级数据，从而维护数据完整性和业务连续性。当HR管理员或系统管理员尝试删除某个薪酬档级时，系统会先检查该档级是否已被薪资结构调整、员工薪资分配等业务流程所引用，如果存在引用关系则拒绝删除并返回具体错误信息；如果无引用关系，则执行删除操作并记录操作日志。此逻辑还支持事务处理，确保删除操作的原子性，并在删除成功后触发相关缓存更新，保证系统数据的一致性。

### 功能要点

- **引用检查与删除保护**：在执行删除操作前，系统必须检查目标薪酬档级是否已被其他业务实体引用，包括但不限于薪资结构调整记录、员工薪资分配记录等。如果发现存在引用关系，系统必须拒绝删除操作并向调用方返回明确的错误信息"该薪酬档级已被引用，无法删除"，同时提供具体的引用来源详情，帮助用户了解为何无法删除该档级。这种保护机制确保了薪资体系的稳定性和数据完整性，防止因误删关键档级数据而导致薪资计算错误或业务流程中断。

### 逻辑签名

```naturalts path="app.logics.deleteCompensationGrade.ts"
$Logic({
    description: '删除薪酬档级',
    directory: 'salary_management(薪资管理)'
})
export declare function deleteCompensationGrade(id: Integer): { success: Boolean, message: String };
```

### 被前端调用

- **薪酬档级（compensationGrade）**：在薪酬档级管理页面中，当用户点击列表中的"删除"按钮并确认删除操作后，前端会调用此服务端逻辑来执行实际的删除操作。该逻辑负责验证删除条件、执行删除事务并返回操作结果，前端根据返回结果决定是否从列表中移除对应记录并显示相应的成功或失败提示信息。

### 依赖的枚举、实体

- **薪资管理-实体-薪酬档级**：[薪资管理-实体-薪酬档级（plan/data-model/entity-CompensationGrade.md）](specs/001-bootdo-management-system/plan/data-model/entity-CompensationGrade.md)
- **薪资管理-实体-薪资结构**：[薪资管理-实体-薪资结构（plan/data-model/entity-SalaryStructure.md）](specs/001-bootdo-management-system/plan/data-model/entity-SalaryStructure.md)

### 依赖的外部能力

无