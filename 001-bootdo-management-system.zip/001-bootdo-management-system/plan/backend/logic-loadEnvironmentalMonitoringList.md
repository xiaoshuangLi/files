# 环保管理-加载环境监测列表（loadEnvironmentalMonitoringList）

- **生成时间**：2026-03-25

## 加载环境监测列表（loadEnvironmentalMonitoringList）

### 功能概述

加载环境监测列表服务端逻辑用于分页查询系统中的环境监测数据，支持按监测位置、监测时间范围等条件进行过滤，并支持按指定字段和顺序进行排序。该逻辑返回符合条件的环境监测记录列表及其总数，为前端环境监测页面提供数据支撑。通过该逻辑，用户可以高效地浏览、筛选和分析各监测点的环境指标数据，包括温度、湿度、空气质量指数等关键参数，及时发现环境异常情况并采取相应措施。

### 功能要点

- **分页查询与排序功能**：提供标准的分页查询接口，支持指定页码(page)和每页条数(size)参数，同时支持按任意字段(sort)和排序方向(order)进行结果排序。该功能确保前端能够高效加载大量环境监测数据，避免一次性加载过多数据导致性能问题，并允许用户根据需要对监测数据进行排序查看，提升用户体验和数据分析效率。

- **多条件过滤功能**：支持通过监测位置、监测时间范围等多个维度对环境监测数据进行精确筛选。用户可以根据实际需求组合不同的过滤条件，快速定位到关注的监测记录，提高数据查询的准确性和效率。过滤条件通过EnvironmentalMonitoring实体对象传递，确保查询条件与数据模型保持一致。

- **关联数据查询**：在查询环境监测记录的同时，自动关联获取相关的资源消耗和排放控制数据，提供更全面的环境状况视图。这种关联查询减少了前端的多次请求，提高了数据展示的完整性和用户体验，便于用户综合分析环境指标与资源消耗、排放控制之间的关系。

### 逻辑签名

```naturalts path="app.logics.loadEnvironmentalMonitoringList.ts"
$Logic({
    description: '分页查询环境监测列表',
    directory: 'environmental_management(环保管理)'
})
export declare function loadEnvironmentalMonitoringList(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.EnvironmentalMonitoring): { list: List<{ environmentalMonitoring: app.dataSources.defaultDS.entities.EnvironmentalMonitoring, resourceConsumption: app.dataSources.defaultDS.entities.ResourceConsumption, emissionControl: app.dataSources.defaultDS.entities.EmissionControl }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 查询的页码，从1开始 |
| size | 每页条数 | Integer | 每页显示的记录数量 |
| sort | 排序字段 | String | 用于排序的字段名称 |
| order | 排序顺序 | String | 排序顺序，'asc'表示升序，'desc'表示降序 |
| filter | 过滤条件 | app.dataSources.defaultDS.entities.EnvironmentalMonitoring | 过滤条件，包含监测位置、监测时间等可选过滤字段 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 环境监测列表 | List<{ environmentalMonitoring: app.dataSources.defaultDS.entities.EnvironmentalMonitoring, resourceConsumption: app.dataSources.defaultDS.entities.ResourceConsumption, emissionControl: app.dataSources.defaultDS.entities.EmissionControl }> | 环境监测记录列表，每项包含环境监测实体和关联的资源消耗、排放控制实体 |
| total | 总记录数 | Integer | 符合过滤条件的总记录数 |

### 被前端调用

- **环境监测（environmentalMonitoring）**：环境监测功能页面使用此服务端逻辑加载环境监测数据列表，支持用户进行查询、筛选、排序等操作，展示各监测点的环境指标数据，包括温度、湿度、空气质量指数等关键参数。

### 依赖的枚举、实体

- **数据建模-实体-环境监测**：[环保管理-实体-环境监测（EnvironmentalMonitoring）](specs/001-bootdo-management-system/plan/data-model/entity-EnvironmentalMonitoring.md)
- **数据建模-实体-资源消耗**：[环保管理-实体-资源消耗（ResourceConsumption）](specs/001-bootdo-management-system/plan/data-model/entity-ResourceConsumption.md)
- **数据建模-实体-排放控制**：[环保管理-实体-排放控制（EmissionControl）](specs/001-bootdo-management-system/plan/data-model/entity-EmissionControl.md)

### 依赖的外部能力

无