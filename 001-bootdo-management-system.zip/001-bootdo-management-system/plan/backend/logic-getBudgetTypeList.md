# 通用领域服务-获取预算类型列表（getBudgetTypeList）

- **生成时间**：2026-03-25

## 获取预算类型列表（getBudgetTypeList）

### 功能概述

该服务端逻辑用于获取系统中所有可用的预算类型列表，支持前端页面展示和选择。预算类型包括年度预算、月度预算、部门预算和项目预算等多种类型，为预算编制、审批和执行监控等业务流程提供基础数据支撑。该接口返回完整的预算类型信息，包括类型标识、名称、描述和适用场景等关键属性。

### 功能要点

- **预算类型数据查询**：从系统数据存储中查询所有已定义的预算类型记录，确保返回的数据完整性和准确性。预算类型作为系统基础数据字典的一部分，包含了年度、月度、部门和项目等不同维度的预算分类，为后续的预算管理业务提供必要的类型选择支持。该功能需要保证查询性能，即使在预算类型数据量较大的情况下也能快速响应。

### 逻辑签名

```naturalts path="app.logics.getBudgetTypeList.ts"
$Logic({
    description: '获取预算类型列表',
    directory: 'budget_management(预算管理)'
})
export declare function getBudgetTypeList(): { list: List<app.dataSources.defaultDS.entities.BudgetType> };
```

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 预算类型列表 | List<app.dataSources.defaultDS.entities.BudgetType> | 预算类型列表，包含所有已定义的预算类型实体 |

### 被前端调用

- **预算类型管理（budgetType）**：在预算类型管理页面中，用户需要查看和管理所有预算类型，该页面通过调用getBudgetTypeList接口获取完整的预算类型列表，用于展示和后续的操作（如编辑、删除等）。

### 依赖的枚举、实体

- **数据建模-实体-预算类型**：[预算管理-实体-预算类型（BudgetType）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetType.md)

### 依赖的外部能力

无