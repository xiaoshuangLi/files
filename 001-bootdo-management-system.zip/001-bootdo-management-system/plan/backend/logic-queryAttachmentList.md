# 内容管理-查询附件列表（queryAttachmentList）

- **生成时间**：2026-03-25

## 查询附件列表（queryAttachmentList）

### 功能概述

查询附件列表服务端逻辑提供内容管理系统中附件资源的查询功能，支持根据文章ID、文件名关键词等条件进行筛选，并返回分页的附件列表数据。该逻辑确保用户能够高效地检索和浏览系统中的附件资源，支持附件管理页面的列表展示、搜索过滤、分页浏览等核心功能。通过与附件资源实体的关联查询，该逻辑能够返回完整的附件元数据信息，包括文件名、文件类型、文件大小、上传时间等关键属性，为前端提供准确的数据支撑。

### 功能要点

- **附件列表查询功能**：根据传入的文章ID参数（可选）和文件名搜索关键词（可选），从数据库中查询匹配的附件记录，并按照上传时间倒序排列。当提供articleId参数时，只返回该文章关联的附件；当提供fileName关键词时，对文件名进行模糊匹配搜索；支持同时使用两个条件进行复合查询，满足附件管理页面的多样化查询需求。
- **分页数据返回功能**：支持分页查询机制，接收当前页码（page）和每页记录数（pageSize）参数，返回指定范围内的附件记录以及总记录数。该功能确保在附件数量较多时，系统能够高效地处理和传输数据，避免一次性加载过多数据导致性能问题，同时为前端提供完整的分页控制所需的信息。
- **附件元数据完整返回功能**：查询结果包含附件的所有关键元数据信息，包括附件ID、文件名、文件路径、文件类型、文件大小、上传时间以及关联的文章ID。这些数据完全对应附件管理页面表格展示所需的字段，确保前端能够正确渲染附件列表并支持后续的下载、删除等操作。

### 逻辑签名

```naturalts path="app.logics.queryAttachmentList.ts"
$Logic({
    description: "查询附件列表",
    directory: "content_management(内容管理)"
})
export declare function queryAttachmentList(
    articleId?: Integer,
    fileName?: String,
    page: Integer,
    pageSize: Integer
): {
    attachments: List<app.dataSources.defaultDS.entities.AttachmentResource>,
    total: Integer,
    currentPage: Integer,
    pageSize: Integer
};
```

### 被前端调用

- **附件管理（attachmentResource）**：附件管理页面调用此服务端逻辑来获取附件列表数据，用于在页面上以表格形式展示所有附件记录。该逻辑支持页面的初始加载、搜索过滤、分页浏览等功能，为用户提供完整的附件查询和管理体验。

### 依赖的枚举、实体

- **数据建模-实体-附件资源**：[内容管理-实体-附件资源（AttachmentResource）](specs/001-bootdo-management-system/plan/data-model/entity-AttachmentResource.md)
- **数据建模-实体-文章内容**：[内容管理-实体-文章内容（ArticleContent）](specs/001-bootdo-management-system/plan/data-model/entity-ArticleContent.md)

### 依赖的外部能力

无匹配内容

