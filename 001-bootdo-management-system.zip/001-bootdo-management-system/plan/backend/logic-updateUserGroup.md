# 工作流引擎-更新用户组（updateUserGroup）

- **生成时间**：2026-03-25

## 更新用户组（updateUserGroup）

### 功能概述

更新用户组服务端逻辑用于修改系统中已存在的用户组信息，包括用户组名称、描述和激活状态等基本信息。该功能支持工作流引擎中的用户组管理需求，允许系统管理员根据组织架构变化或业务需求调整用户组配置。通过此逻辑，可以确保用户组信息的准确性和时效性，为基于用户组的任务分配和权限管理提供可靠的数据基础。

### 功能要点

- **用户组基本信息更新**：支持修改用户组的核心属性，包括组名称、描述信息和激活状态。组名称作为用户组的唯一标识符，在更新时需要进行唯一性校验，确保系统中不存在同名的用户组。描述信息可以为空，用于提供用户组的详细说明。激活状态控制用户组是否可以参与工作流任务分配和权限授予，非激活状态的用户组将无法被选择用于新的任务分配。

### 逻辑签名

```naturalts path="app.logics.updateUserGroup.ts"
$Logic({
    description: '更新用户组信息',
    directory: 'workflow_engine(工作流引擎)',
    transactional: true
})
export declare function updateUserGroup(userGroup: app.dataSources.defaultDS.entities.UserGroup): app.dataSources.defaultDS.entities.UserGroup;
```

### 被前端调用

- **用户和组管理（userGroupManagement）**：在用户和组管理页面中，当用户点击编辑按钮并提交修改后的用户组信息时，前端会调用此服务端逻辑来更新用户组数据。该逻辑负责验证输入数据的有效性，执行数据库更新操作，并返回更新结果供前端显示反馈信息。

### 依赖的枚举、实体

- **数据建模-实体-用户组**：[系统管理-实体-用户组（UserGroup）](specs/001-bootdo-management-system/plan/data-model/entity-UserGroup.md)

### 依赖的外部能力

无外部能力依赖