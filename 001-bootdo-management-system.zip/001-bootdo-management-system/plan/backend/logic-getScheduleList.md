# 办公自动化-获取日程列表（getScheduleList）

- **生成时间**：2026-03-25

## 获取日程列表（getScheduleList）

### 功能概述

获取日程列表服务端逻辑为用户提供查询个人日程安排的核心功能，支持按多种条件筛选和分页获取日程数据。该逻辑根据用户提供的查询参数（如时间范围、日程标题关键词等）从数据库中检索符合条件的日程记录，并返回结构化的日程列表数据。系统会自动过滤出当前用户有权限查看的日程（包括个人日程和被授权查看的共享日程），确保数据安全性和隐私保护。返回的数据包含日程的基本信息（标题、描述、时间范围、是否全天事件等）以及关联的用户信息，为前端日历视图和列表视图提供完整的数据支持。

### 功能要点

- **多条件筛选查询**：支持按开始时间范围、结束时间范围、日程标题关键词等多种条件组合筛选日程数据，用户可以根据实际需求灵活查询特定时间段或特定主题的日程安排，提高查询效率和准确性。
- **分页数据加载**：实现高效的分页机制，避免一次性加载大量日程数据导致性能问题，系统根据前端传递的分页参数（页码、每页数量）返回对应的数据集，确保在大数据量场景下仍能保持良好的响应速度。
- **权限控制与数据过滤**：严格实施数据权限控制，仅返回当前登录用户有权查看的日程数据，包括用户的个人日程以及被明确授权共享的日程，防止未授权访问他人日程信息，保障用户数据隐私安全。
- **数据格式标准化**：返回的日程数据遵循统一的数据格式规范，包含完整的日程属性信息（ID、标题、描述、开始时间、结束时间、是否全天事件、所有者信息等），便于前端组件直接使用，减少额外的数据处理开销。

### 逻辑签名

```naturalts path="app.logics.getScheduleList.ts"
$Logic({
    description: '获取日程列表',
    directory: 'office_automation(办公自动化)'
})
export declare function getScheduleList(
  userId?: Integer,
  startTime?: DateTime,
  endTime?: DateTime,
  title?: String,
  page?: Integer,
  size?: Integer
): { list: List<app.dataSources.defaultDS.entities.ScheduleArrangement>, total: Integer };
```

### 被前端调用

- **日程管理（scheduleArrangement）**：在日程管理页面中，当用户执行查询操作或首次加载页面时，前端调用此服务端逻辑获取用户的日程列表数据，用于填充日历视图和列表视图，支持按时间范围、日程标题等条件进行筛选展示。

### 依赖的枚举、实体

- **数据建模-实体-日程安排**：[办公自动化-实体-日程安排（ScheduleArrangement）](specs/001-bootdo-management-system/plan/data-model/entity-ScheduleArrangement.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无外部能力依赖