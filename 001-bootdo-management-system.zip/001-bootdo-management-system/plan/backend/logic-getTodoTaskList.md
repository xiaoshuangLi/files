# 通用领域服务-获取待办任务列表（getTodoTaskList）

- **生成时间**：2026-03-25

## 获取待办任务列表（getTodoTaskList）

### 功能概述

该服务端逻辑用于获取当前用户的待办任务列表，支持按任务状态、优先级、创建时间等条件进行筛选和排序。系统会根据用户的角色权限和所属部门，返回相应的待办任务数据，确保数据的安全性和相关性。待办任务包括任务标题、描述、截止日期、优先级、状态、创建人、分配人等详细信息，为用户提供全面的任务管理视图。

### 功能要点

- **任务筛选与排序**：支持根据任务状态（待处理、处理中、已完成）、优先级（高、中、低）、创建时间范围等多维度条件进行筛选，并可按截止日期、创建时间等字段进行升序或降序排列，帮助用户快速定位关键任务。
- **权限控制与数据隔离**：根据用户的角色权限（系统管理员、部门管理员、普通用户）和所属部门，严格控制可访问的待办任务数据范围，确保用户只能查看自己有权限处理的任务，保障数据安全。
- **任务详情展示**：返回完整的任务详情信息，包括任务基本信息（标题、描述、截止日期）、任务属性（优先级、状态）、人员信息（创建人、分配人、处理人）以及相关的业务上下文信息，为用户提供全面的任务处理依据。

### 逻辑签名

```naturalts path="app.logics.getTodoTaskList.ts"
$Logic({
    description: '获取当前用户的待办任务列表',
    directory: 'personal_workspace(个人工作台)'
})
export declare function getTodoTaskList(page: Integer, size: Integer, sort: String, order: String, status: app.enums.TodoTaskStatus, priority: app.enums.TaskPriority, createdTimeStart: DateTime, createdTimeEnd: DateTime): { list: List<app.dataSources.defaultDS.entities.TodoTask>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 分页查询的页码，从1开始 |
| size | 每页条数 | Integer | 每页返回的任务数量 |
| sort | 排序字段 | String | 排序的字段名，如"deadline"、"createdTime"、"priority" |
| order | 排序顺序 | String | 排序顺序，"asc"表示升序，"desc"表示降序 |
| status | 任务状态 | app.enums.TodoTaskStatus | 任务状态过滤条件，可选值：PENDING(待处理)、IN_PROGRESS(处理中)、COMPLETED(已完成) |
| priority | 任务优先级 | app.enums.TaskPriority | 任务优先级过滤条件，可选值：HIGH(高)、MEDIUM(中)、LOW(低) |
| createdTimeStart | 创建时间开始 | DateTime | 任务创建时间范围的开始时间 |
| createdTimeEnd | 创建时间结束 | DateTime | 任务创建时间范围的结束时间 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 待办任务列表 | List<app.dataSources.defaultDS.entities.TodoTask> | 符合查询条件的待办任务列表 |
| total | 总条数 | Integer | 符合查询条件的待办任务总数量 |

### 被前端调用

- **个人工作台（personalWorkspace）**：在个人工作台页面中调用此服务端逻辑，获取当前用户的所有待办任务列表，展示在工作台的任务面板中，方便用户快速查看和处理待办事项。
- **待办任务（todoTask）**：在专门的待办任务管理页面中调用此服务端逻辑，提供完整的任务筛选、排序和分页功能，让用户能够高效地管理和跟踪所有待办任务。

### 依赖的枚举、实体

- **数据建模-枚举-待办任务状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-枚举-任务优先级**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-待办任务**：[办公自动化-实体-待办任务（TodoTask）](specs/001-bootdo-management-system/plan/data-model/entity-TodoTask.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

[文件内部已经提供，无需进行生成。如果文件内部已经有 `依赖的外部能力` 内容，禁止修改或删除文件内的 `依赖的外部能力` 内容]