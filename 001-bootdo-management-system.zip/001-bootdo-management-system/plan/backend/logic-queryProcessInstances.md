# 工作流引擎-查询流程实例列表（queryProcessInstances）

- **生成时间**：2026-03-25

## 查询流程实例列表（queryProcessInstances）

### 功能概述

查询流程实例列表服务端逻辑提供对工作流引擎中所有流程实例的分页查询功能，支持按流程定义ID、启动用户ID、当前状态、启动时间范围等多个维度进行条件筛选，并支持按指定字段和顺序进行排序。该逻辑返回包含完整流程实例信息的分页结果，包括实例ID、关联的流程定义ID、启动用户ID、启动时间、结束时间、当前状态等关键字段，为前端流程实例管理页面提供全面的数据支撑。通过灵活的查询条件组合，用户可以精确获取所需的流程实例数据子集，便于进行流程监控、状态跟踪和数据分析，同时分页机制确保了在处理大量流程实例时的系统性能和用户体验。

### 功能要点

- **分页查询与性能优化**：支持标准的分页参数（页码、每页条数），能够高效处理大量流程实例数据的查询请求，避免一次性加载过多数据导致的内存溢出或响应延迟问题。系统默认每页显示20条记录，但允许前端根据实际需求调整每页显示数量，最大不超过100条，确保查询性能和用户体验的平衡。
- **多维度条件筛选**：提供基于流程实例实体（ProcessInstance）的完整筛选能力，支持按流程定义ID、启动用户ID、当前状态、启动时间范围等多个字段进行精确匹配或范围查询。用户可以根据业务需求灵活组合不同的筛选条件，快速定位到特定的流程实例集合，提高数据查询的精准度和效率。
- **动态排序功能**：支持按任意字段（如启动时间、结束时间、当前状态等）进行升序（'asc'）或降序（'desc'）排序，通过sort参数指定排序字段，order参数指定排序方向。默认按启动时间（startedAt）降序排列，确保最新的流程实例优先显示，满足用户对数据展示顺序的不同需求。
- **完整数据结构返回**：返回完整的流程实例实体信息，包括主键ID、实例ID、定义ID、启动用户ID、启动时间、结束时间、当前状态以及创建和更新时间戳等所有必要字段，确保前端能够获得足够的数据来展示流程实例的完整状态和历史信息。

### 逻辑签名

```naturalts path="app.logics.queryProcessInstances.ts"
$Logic({
    description: '查询流程实例列表',
    directory: 'workflow_engine(工作流引擎)'
})
export declare function queryProcessInstances(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.ProcessInstance): { list: List<app.dataSources.defaultDS.entities.ProcessInstance>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 分页查询的页码，从1开始计数 |
| size | 每页条数 | Integer | 每页返回的记录数量，建议范围1-100 |
| sort | 排序字段 | String | 排序的字段名，如"startedAt"、"endedAt"、"currentStatus"等 |
| order | 排序顺序 | String | 排序方向，"asc"表示升序，"desc"表示降序 |
| filter | 过滤条件 | app.dataSources.defaultDS.entities.ProcessInstance | 流程实例实体作为过滤条件，支持各字段的精确匹配 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 流程实例列表 | List<app.dataSources.defaultDS.entities.ProcessInstance> | 当前页的流程实例实体列表 |
| total | 总记录数 | Integer | 符合查询条件的流程实例总数量 |

### 被前端调用

- **流程实例管理（processInstance）**：流程实例管理页面使用此服务端逻辑加载流程实例列表数据，支持用户进行分页浏览、条件筛选和排序操作。页面通过分页、筛选和排序参数调用此接口，获取符合业务需求的流程实例数据，并在表格中展示实例ID、流程名称、启动用户、启动时间、当前状态等关键信息，便于用户监控和管理所有流程实例的执行情况。

### 依赖的枚举、实体

- **数据建模-实体-流程实例**：[工作流引擎-实体-流程实例（ProcessInstance）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessInstance.md)

### 依赖的外部能力

无