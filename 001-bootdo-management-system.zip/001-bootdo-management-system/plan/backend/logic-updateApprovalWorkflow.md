# 通用领域服务-更新审批流程（updateApprovalWorkflow）

- **生成时间**：2026-03-25

## 更新审批流程（updateApprovalWorkflow）

### 功能概述

更新审批流程服务端逻辑负责处理预算管理模块中审批流程配置的修改操作。该逻辑接收包含完整审批流程信息的实体对象，包括工作流ID、工作流名称、关联的流程定义ID、工作流规则和启用状态等字段，并将这些信息持久化到数据库中。通过此逻辑，系统管理员可以灵活调整现有的审批流程配置，以适应不断变化的预算管理需求。更新操作确保数据的一致性和完整性，同时记录操作日志用于审计追踪。该逻辑还支持与工作流引擎的集成，在审批流程更新后能够正确同步到相关的工作流实例。

### 功能要点

- **审批流程基本信息更新**：支持修改审批流程的工作流名称、工作流ID等基本信息，确保流程标识的准确性和可读性。用户可以在审批流程编辑界面中修改这些字段，提交后通过该逻辑将变更保存到数据库，保持审批流程配置的最新状态。
- **流程定义关联更新**：支持重新关联不同的流程定义，允许用户根据业务需求将审批流程切换到其他BPMN流程模板。该功能通过外键约束确保关联的流程定义存在且有效，避免无效引用导致的系统错误。
- **审批规则配置更新**：支持修改审批流程的具体规则和条件配置，这些规则以字符串形式存储，包含了审批节点、审批人指定、条件判断等详细信息。更新后的规则将直接影响后续基于该审批流程创建的流程实例的行为。
- **启用状态控制**：支持启用或禁用审批流程，通过isEnabled字段控制流程的可用性。禁用的审批流程不会被新的预算申请所使用，但不影响已经存在的流程实例，确保系统的稳定性和向后兼容性。

### 逻辑签名

```naturalts path="app.logics.updateApprovalWorkflow.ts"
$Logic({
    description: '更新审批流程配置',
    directory: 'budget_management(预算管理)',
    transactional: true
})
export declare function updateApprovalWorkflow(approvalWorkflow: app.dataSources.defaultDS.entities.ApprovalWorkflow): app.dataSources.defaultDS.entities.ApprovalWorkflow;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| approvalWorkflow | 审批流程实体 | app.dataSources.defaultDS.entities.ApprovalWorkflow | 包含完整审批流程配置信息的实体对象，包含工作流ID、名称、流程定义ID、规则和启用状态等字段 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 更新结果 | app.dataSources.defaultDS.entities.ApprovalWorkflow | 更新后的审批流程实体，包含数据库生成的时间戳和操作人信息 |

### 被前端调用

- **审批流程（approvalWorkflow）**：在审批流程编辑功能中，用户修改审批流程配置后提交表单，前端调用此服务端逻辑将更新后的审批流程信息保存到数据库，实现审批流程配置的持久化更新。

### 依赖的枚举、实体

- **数据建模-实体-审批流程**：[预算管理-实体-审批流程（ApprovalWorkflow）](specs/001-bootdo-management-system/plan/data-model/entity-ApprovalWorkflow.md)
- **数据建模-实体-流程定义**：[工作流引擎-实体-流程定义（ProcessDefinition）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessDefinition.md)

### 依赖的外部能力

无匹配内容

