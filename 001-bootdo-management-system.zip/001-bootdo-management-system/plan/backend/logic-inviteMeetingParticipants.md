# 办公自动化-邀请参会人员（inviteMeetingParticipants）

- **生成时间**：2026-03-25

## 邀请参会人员（inviteMeetingParticipants）

### 功能概述

邀请参会人员服务端逻辑负责处理会议预约中的参会人员邀请功能，支持向指定用户发送会议通知并管理参会确认状态。该逻辑实现了完整的参会人员管理流程，包括添加参会人员、移除参会人员、发送会议邀请通知、跟踪参会确认状态等功能。通过与系统账户实体的关联，确保邀请的参会人员都是系统中的有效用户，并能获取其联系方式（如邮箱）用于发送通知。该逻辑还支持批量邀请操作，提高会议组织效率，并提供参会状态的实时更新和查询能力，帮助会议组织者掌握参会情况。

### 功能要点

- **参会人员管理**：支持为已创建的会议预约添加和移除参会人员，系统会验证参会人员是否为有效的系统账户用户，并建立会议与参会人员之间的关联关系。添加参会人员时，系统自动记录邀请时间和初始状态；移除参会人员时，系统会保留历史记录但标记为已取消邀请状态，确保数据的完整性和可追溯性。

- **会议通知发送**：当向参会人员发送会议邀请时，系统会根据参会人员的联系方式（主要是邮箱）自动发送会议通知，包含会议标题、时间、地点、议程等关键信息。通知发送支持多种渠道，包括站内信、邮件等，具体渠道根据系统配置和用户偏好确定。系统还会记录通知发送状态，便于后续跟踪和重发。

- **参会状态跟踪**：系统提供参会确认状态的跟踪功能，参会人员可以对会议邀请进行接受、拒绝或待定的操作，这些状态会实时更新到会议记录中。会议组织者可以随时查看所有参会人员的确认状态，了解会议的参与情况，并根据需要进行后续的协调工作。

### 逻辑签名

```naturalts path="app.logics.inviteMeetingParticipants.ts"
$Logic({
    description: "邀请参会人员",
    directory: "office_automation(办公自动化)"
})
export declare function inviteMeetingParticipants(
    meetingId: Integer,
    participantIds: List<Integer>,
    action: String
): {
    success: Boolean,
    message: String,
    updatedParticipants: List<{
        id: Integer,
        fullName: String,
        email: String,
        status: String,
        invitedTime: DateTime
    }>
};
```

### 被前端调用

- **会议管理（meetingManagement）**：在会议详情页面，用户可以通过"邀请参会人员"功能调用此服务端逻辑，选择系统中的用户作为参会人员并发送会议邀请。该功能支持批量选择参会人员，并允许用户执行邀请、取消邀请等操作，实现会议参会人员的动态管理。

### 依赖的枚举、实体

- **数据建模-枚举-用户状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-枚举-消息类型**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)
- **数据建模-实体-会议预约**：[办公自动化-实体-会议预约（MeetingReservation）](specs/001-bootdo-management-system/plan/data-model/entity-MeetingReservation.md)

### 依赖的外部能力

#### 邮件服务（EmailService） 【当前业务功能相关】

- 关联文档：[邮件服务（EmailService）](specs/001-bootdo-management-system/plan/integration/retrieval-EmailService.md)