# 权限中心-查询可用用户（queryAvailableUsers）

- **生成时间**：2026-03-25

## 查询可用用户（queryAvailableUsers）

### 功能概述

查询可用用户服务端逻辑用于在权限管理和组织架构相关功能中获取系统中符合条件的用户列表。该逻辑支持分页查询、多条件筛选和排序功能，能够根据用户名、邮箱、部门归属、用户状态等条件进行精确或模糊匹配查询。返回的数据包含完整的用户基本信息以及关联的部门信息，为前端用户选择器、部门成员管理、角色分配等功能提供数据支撑。通过该逻辑，系统管理员和部门管理员可以高效地查找和选择合适的用户进行各种管理操作。

### 功能要点

- **分页查询与筛选功能**：支持标准的分页参数（页码、每页条数）和多维度筛选条件，包括用户名模糊匹配、邮箱精确匹配、部门ID精确匹配、用户状态精确匹配等。系统能够根据传入的筛选条件动态构建查询语句，返回符合条件的用户列表及其总数，确保前端能够高效加载和展示大量用户数据，同时提供灵活的搜索和过滤能力。

- **部门关联查询**：在返回用户列表的同时，自动关联查询用户所属的部门信息，包括部门名称和部门层级关系。这种关联查询通过OrganizationDepartmentMapping中间表实现，支持用户属于多个部门的场景，确保返回的部门信息完整准确，满足前端在用户选择时显示部门归属的需求。

- **用户状态过滤**：默认只返回状态为"正常"的用户，排除已被禁用或删除的用户账户。系统支持通过status参数覆盖此默认行为，允许在特殊场景下查询所有状态的用户，但常规的用户选择操作应遵循默认的正常状态过滤规则，确保用户体验的一致性和数据的安全性。

- **排序与性能优化**：支持按用户名、创建时间等字段进行升序或降序排序，默认按用户名升序排列。系统对常用查询条件建立了适当的数据库索引，确保在大数据量场景下仍能保持良好的查询性能，避免因查询延迟影响用户操作体验。

### 逻辑签名

```naturalts path="app.logics.queryAvailableUsers.ts"
$Logic({
    description: '查询可用用户',
    directory: 'permission_center(权限中心)'
})
export declare function queryAvailableUsers(page: Integer, size: Integer, sort: String, order: String, filter: { username?: String, email?: String, departmentId?: Integer, status?: app.enums.UserStatusEnum }): { list: List<{ systemAccount: app.dataSources.defaultDS.entities.SystemAccount, departments: List<app.dataSources.defaultDS.entities.OrganizationDepartment> }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 分页查询的页码，从1开始计数 |
| size | 每页条数 | Integer | 每页返回的记录数量，建议范围1-100 |
| sort | 排序字段 | String | 排序的字段名，如"username"、"createdTime"等 |
| order | 排序顺序 | String | 排序方向，"asc"表示升序，"desc"表示降序 |
| filter | 过滤条件 | { username?: String, email?: String, departmentId?: Integer, status?: app.enums.UserStatusEnum } | 用户筛选条件，支持用户名模糊匹配、邮箱精确匹配、部门ID精确匹配、用户状态精确匹配 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 用户列表 | List<{ systemAccount: app.dataSources.defaultDS.entities.SystemAccount, departments: List<app.dataSources.defaultDS.entities.OrganizationDepartment> }> | 用户列表，每个列表项包含系统账户实体及其关联的部门列表 |
| total | 总条数 | Integer | 符合筛选条件的总记录数，用于分页计算 |

### 被前端调用

- **用户管理页（userManagement）**：在用户管理页面的用户选择器或批量操作功能中，调用此服务端逻辑获取可用用户列表，支持管理员在分配角色、设置权限等操作时选择目标用户。
- **部门管理页（departmentManagement）**：在部门管理页面的添加部门成员功能中，调用此服务端逻辑获取可添加到当前部门的用户列表，支持部门管理员选择合适的用户加入部门，并显示用户的部门归属信息。

### 依赖的枚举、实体

- **数据建模-枚举-用户状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)
- **数据建模-实体-组织部门**：[系统管理-实体-组织部门（OrganizationDepartment）](specs/001-bootdo-management-system/plan/data-model/entity-OrganizationDepartment.md)

### 依赖的外部能力

无