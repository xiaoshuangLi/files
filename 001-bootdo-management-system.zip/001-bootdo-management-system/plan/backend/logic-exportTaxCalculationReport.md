# 薪资管理-导出税务计算报表（exportTaxCalculationReport）

- **生成时间**：2026-03-25

## 导出税务计算报表（exportTaxCalculationReport）

### 功能概述

导出税务计算报表功能允许系统管理员或薪资管理人员根据指定条件生成并导出个人所得税计算的详细报表。该报表包含员工基本信息、收入明细、扣除项目、应纳税所得额、适用税率、速算扣除数以及最终应缴税额等关键数据。报表支持按部门、时间段、员工类型等多种筛选条件进行定制化导出，满足不同场景下的税务申报和审计需求。导出的报表格式支持Excel和PDF两种主流格式，确保数据的可读性和专业性，同时保证数据的安全性和准确性。

### 功能要点

- **多维度筛选与导出**：系统支持按部门、薪资周期、员工类型等多个维度进行筛选，用户可以根据实际需求灵活组合筛选条件，生成针对性的税务计算报表。筛选结果将包含所有符合条件的员工税务计算详情，确保报表数据的完整性和准确性，满足不同层级管理人员的查看和分析需求。

### 逻辑签名

```naturalts path="app.logics.exportTaxCalculationReport.ts"
$Logic({
    description: '导出税务计算报表',
    directory: 'salary_management(薪资管理)'
})
export declare function exportTaxCalculationReport(
  departmentId?: Text,
  salaryCycle?: Text,
  employeeType?: Text,
  format: "Excel" | "PDF" = "Excel"
): FileStream;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| departmentId | 部门ID | Text | 可选，用于筛选特定部门的员工 |
| salaryCycle | 薪资周期 | Text | 可选，用于筛选特定薪资周期的数据 |
| employeeType | 员工类型 | Text | 可选，用于筛选特定类型的员工 |
| format | 导出格式 | "Excel" \| "PDF" | 导出格式，默认为Excel |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 报表文件流 | FileStream | 生成的税务计算报表文件流 |

### 被前端调用

- **薪资报表（salaryReport）**：在薪资报表页面中，用户可以通过设置筛选条件并选择导出格式，调用此服务端逻辑生成并下载税务计算报表，用于内部审核、税务申报或存档。

### 依赖的枚举、实体

- **数据建模-枚举-导出格式类型**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-员工信息**：[系统管理-实体-员工信息（EmployeeInformation）](specs/001-bootdo-management-system/plan/data-model/entity-EmployeeInformation.md)
- **数据建模-实体-薪资结构**：[薪资管理-实体-薪资结构（SalaryStructure）](specs/001-bootdo-management-system/plan/data-model/entity-SalaryStructure.md)
- **数据建模-实体-税务计算**：[薪资管理-实体-税务计算（TaxCalculation）](specs/001-bootdo-management-system/plan/data-model/entity-TaxCalculation.md)

### 依赖的外部能力

无