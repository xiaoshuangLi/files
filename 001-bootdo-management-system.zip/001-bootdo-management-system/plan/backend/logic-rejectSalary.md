# 薪资管理-驳回薪资（rejectSalary）

- **生成时间**：2026-03-25

## 驳回薪资（rejectSalary）

### 功能概述

驳回薪资服务端逻辑是BootDo管理系统薪资管理模块的核心业务功能，用于处理薪资调整申请的驳回操作。该逻辑支持审批人员在审核过程中拒绝不符合条件或存在问题的薪资调整申请，并记录驳回原因和相关意见。系统会自动更新薪资调整申请的审批状态为"已驳回"，并关联工作流引擎中的流程实例状态，确保整个审批流程的完整性和可追溯性。同时，该逻辑还会触发相应的通知机制，向申请人发送驳回通知，包含具体的驳回原因和审批意见，以便申请人了解驳回详情并进行后续处理。

### 功能要点

- **薪资调整申请驳回处理**：当审批人员决定驳回薪资调整申请时，系统必须接收驳回请求，包含薪资调整ID、驳回原因（文本输入框，必填，最大长度500字符）、审批意见（文本输入框，非必填，最大长度1000字符）等关键参数。系统验证参数完整性后，更新薪资调整申请的审批状态为"已驳回"（Rejected），并记录驳回时间和驳回人信息，确保审批流程的规范性和可追溯性。

- **工作流状态同步**：当薪资调整申请被驳回时，系统必须自动同步更新关联的工作流引擎中流程实例的当前状态为"已驳回"，确保工作流引擎与业务数据的一致性。通过关联ProcessInstance实体的instanceId字段，系统能够准确定位并更新对应的流程实例状态，实现业务流程与工作流引擎的无缝集成。

- **驳回通知触发**：当薪资调整申请被成功驳回后，系统必须自动触发通知机制，向原申请人发送驳回通知。通知内容包含驳回原因、审批意见、驳回时间和审批人信息等关键信息，确保申请人能够及时了解驳回详情。系统通过与消息通知服务集成，支持多种通知渠道（如站内信、邮件等），提高通知的及时性和有效性。

### 逻辑签名

```naturalts path="app.logics.rejectSalary.ts"
$Logic({
    description: '驳回薪资调整申请',
    directory: 'salary_management(薪资管理)'
})
export declare function rejectSalary(salaryAdjustmentId: Integer, rejectionReason: String, approvalComment: String): app.dataSources.defaultDS.entities.SalaryAdjustment;
```

### 被前端调用

- **薪资调整审批（salaryAdjustment）**：在薪资调整审批页面，审批人员可以执行驳回操作，填写驳回原因和审批意见，调用rejectSalary服务端逻辑完成薪资调整申请的驳回处理，并更新申请状态和触发通知。

### 依赖的枚举、实体

- **数据建模-枚举-审批状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-薪资调整**：[薪资管理-实体-薪资调整（SalaryAdjustment）](specs/001-bootdo-management-system/plan/data-model/entity-SalaryAdjustment.md)
- **数据建模-实体-流程实例**：[工作流引擎-实体-流程实例（ProcessInstance）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessInstance.md)

### 依赖的外部能力

#### 邮件服务（EmailService） 【当前业务功能相关】

- 关联文档：[邮件服务（EmailService）](specs/001-bootdo-management-system/plan/integration/retrieval-EmailService.md)