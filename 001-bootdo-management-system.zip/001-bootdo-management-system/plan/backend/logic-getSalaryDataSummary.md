# 薪资管理-获取薪资数据汇总（getSalaryDataSummary）

- **生成时间**：2026-03-25

## 获取薪资数据汇总（getSalaryDataSummary）

### 功能概述

该服务端逻辑用于获取企业薪资数据的汇总信息，包括月工资总额、年薪总额统计、各部门薪资分布、不同薪酬档级人员数量等关键指标。系统会根据用户权限范围（如系统管理员可查看全公司数据，部门管理员仅能查看本部门数据）返回相应的薪资汇总数据，支持按时间周期（月度、年度）、部门、薪酬档级等维度进行筛选和聚合分析，为管理层提供薪资决策支持。

### 功能要点

- **多维度薪资汇总**：系统能够根据不同的查询条件（如时间周期、部门、薪酬档级等）对薪资数据进行汇总计算，生成包含月工资总额、年薪总额、平均薪资、最高/最低薪资等关键指标的汇总报告。汇总数据将严格按照用户权限范围进行过滤，确保数据安全性和合规性，同时支持导出为标准报表格式供进一步分析使用。

### 逻辑签名

```naturalts path="app.logics.getSalaryDataSummary.ts"
$Logic({
    description: '获取薪资数据汇总信息',
    directory: 'salary_management(薪资管理)'
})
export declare function getSalaryDataSummary(
  timeCycle?: String,
  departmentId?: String,
  compensationGrade?: String,
  startDate?: Date,
  endDate?: Date
): {
  monthlySalaryTotal: Decimal;
  annualSalaryTotal: Decimal;
  averageSalary: Decimal;
  highestSalary: Decimal;
  lowestSalary: Decimal;
  departmentDistribution: List<{
    departmentId: String;
    departmentName: String;
    totalAmount: Decimal;
    employeeCount: Integer;
  }>;
  gradeDistribution: List<{
    grade: String;
    employeeCount: Integer;
    averageAmount: Decimal;
  }>;
};
```

### 被前端调用

- **薪资报表（salaryReport）**：薪资报表页面调用此服务端逻辑获取汇总数据，用于展示企业整体或特定部门的薪资分布情况、趋势分析和对比图表，帮助HR和管理层了解薪资结构合理性并做出调整决策。

### 依赖的枚举、实体

- **数据建模-枚举-预算周期**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-薪资结构**：[薪资管理-实体-薪资结构（SalaryStructure）](specs/001-bootdo-management-system/plan/data-model/entity-SalaryStructure.md)
- **数据建模-实体-组织部门**：[系统管理-实体-组织部门（OrganizationDepartment）](specs/001-bootdo-management-system/plan/data-model/entity-OrganizationDepartment.md)

### 依赖的外部能力

[文件内部已经提供，无需进行生成。如果文件内部已经有 `依赖的外部能力` 内容，禁止修改或删除文件内的 `依赖的外部能力` 内容]