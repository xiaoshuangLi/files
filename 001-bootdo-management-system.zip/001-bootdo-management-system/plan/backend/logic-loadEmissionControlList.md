# 环保管理-加载排放控制列表（loadEmissionControlList）

- **生成时间**：2026-03-25

## 加载排放控制列表（loadEmissionControlList）

### 功能概述

该服务端逻辑用于分页查询排放控制列表数据，支持按污染物类型、环境监测ID、记录时间范围等条件进行过滤，并支持按指定字段排序。逻辑返回包含排放控制记录列表和总记录数的分页结果，每条记录包含完整的排放控制信息以及关联的环境监测数据。此逻辑为前端排放控制管理页面提供数据支持，使用户能够高效地浏览、筛选和分析企业的污染物排放情况，及时发现潜在的环保合规问题。

### 功能要点

- **分页查询功能**：支持标准的分页参数（页码、每页条数），能够高效处理大量排放控制数据，避免一次性加载过多数据导致系统性能问题。分页查询结果包含当前页的数据列表和总记录数，便于前端实现完整的分页控件。
- **多条件过滤功能**：支持通过污染物类型、环境监测ID、记录时间范围等多个维度对排放控制数据进行精确筛选。用户可以根据实际需求组合不同的过滤条件，快速定位到关注的排放记录，提高数据查询的准确性和效率。
- **排序功能**：支持按任意字段进行升序或降序排列，用户可以根据排放量、记录时间等关键指标对结果进行排序，便于识别排放量最大或最新的记录，辅助环保管理决策。
- **关联数据查询**：在查询排放控制记录的同时，自动关联获取对应的环境监测数据，包括监测位置、监测时间等信息。这种关联查询减少了前端的多次请求，提高了数据展示的完整性和用户体验。

### 逻辑签名

```naturalts path="app.logics.loadEmissionControlList.ts"
$Logic({
    description: '分页查询排放控制列表',
    directory: 'environmental_management(环保管理)'
})
export declare function loadEmissionControlList(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.EmissionControl): { list: List<{ emissionControl: app.dataSources.defaultDS.entities.EmissionControl, environmentalMonitoring: app.dataSources.defaultDS.entities.EnvironmentalMonitoring }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 查询的页码，从1开始 |
| size | 每页条数 | Integer | 每页显示的记录数量 |
| sort | 排序字段 | String | 用于排序的字段名称 |
| order | 排序顺序 | String | 排序顺序，'asc'表示升序，'desc'表示降序 |
| filter | 过滤条件 | app.dataSources.defaultDS.entities.EmissionControl | 过滤条件，包含污染物类型、环境监测ID、记录时间等可选过滤字段 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 排放控制列表 | List<{ emissionControl: app.dataSources.defaultDS.entities.EmissionControl, environmentalMonitoring: app.dataSources.defaultDS.entities.EnvironmentalMonitoring }> | 排放控制记录列表，每项包含排放控制实体和关联的环境监测实体 |
| total | 总记录数 | Integer | 符合过滤条件的总记录数 |

### 被前端调用

- **排放控制（emissionControl）**：排放控制功能页面使用此服务端逻辑加载排放控制数据列表，支持用户进行查询、筛选、排序等操作，展示污染物排放的详细信息及关联的环境监测数据。

### 依赖的枚举、实体

- **数据建模-实体-排放控制**：[环保管理-实体-排放控制（EmissionControl）](specs/001-bootdo-management-system/plan/data-model/entity-EmissionControl.md)
- **数据建模-实体-环境监测**：[环保管理-实体-环境监测（EnvironmentalMonitoring）](specs/001-bootdo-management-system/plan/data-model/entity-EnvironmentalMonitoring.md)

### 依赖的外部能力

无