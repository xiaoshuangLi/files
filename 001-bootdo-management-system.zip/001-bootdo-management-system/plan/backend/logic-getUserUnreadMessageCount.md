# 通用领域服务-获取用户未读消息数量（getUserUnreadMessageCount）

- **生成时间**：2026-03-25

## 获取用户未读消息数量（getUserUnreadMessageCount）

### 功能概述

该服务端逻辑用于查询当前登录用户的未读消息总数，包括系统通知、公告、待办任务提醒等各类消息。系统会根据用户的身份和权限范围，统计所有未被用户标记为已读的消息数量，并返回一个汇总的数字。此功能主要用于在用户界面顶部导航栏或个人门户中显示未读消息提示，帮助用户及时了解系统中的新信息和待处理事项。

### 功能要点

- **消息类型统计**：系统需要支持多种消息类型的未读计数，包括通知公告、待办任务、邮件通信、日程提醒等。每种消息类型都有独立的存储表和状态标识，服务端需要分别查询各类消息表中属于当前用户且状态为未读的记录数量，然后进行汇总计算，确保统计结果的准确性和完整性。

### 逻辑签名

```naturalts path="app.logics.getUserUnreadMessageCount.ts"
$Logic({
    description: '获取用户未读消息数量',
    directory: 'message_center(消息中心)'
})
export declare function getUserUnreadMessageCount(userId: String): Integer;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| userId | 用户ID | String | 当前登录用户的唯一标识 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 未读消息总数 | Integer | 用户所有未读消息的汇总数量 |

### 被前端调用

- **个人门户（personalWorkspace）**：在个人门户页面顶部显示用户的未读消息总数，用于提醒用户查看新的系统通知、待办任务和其他重要信息。
- **通知公告（noticeAnnouncement）**：在通知公告模块的入口处显示未读公告数量，帮助用户快速识别是否有新的公告需要查看。

### 依赖的枚举、实体

- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)
- **数据建模-实体-通知公告**：[办公自动化-实体-通知公告（NoticeAnnouncement）](specs/001-bootdo-management-system/plan/data-model/entity-NoticeAnnouncement.md)
- **数据建模-实体-待办事项**：[办公自动化-实体-待办任务（TodoTask）](specs/001-bootdo-management-system/plan/data-model/entity-TodoTask.md)
- **数据建模-实体-在线用户管理**：[系统管理-实体-在线会话（OnlineSession）](specs/001-bootdo-management-system/plan/data-model/entity-OnlineSession.md)

### 依赖的外部能力

无