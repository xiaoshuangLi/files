# 办公自动化-加载通知公告详情（loadMessageDetail）

- **生成时间**：2026-03-25

## 加载通知公告详情（loadMessageDetail）

### 功能概述

加载通知公告详情服务端逻辑用于根据通知ID查询并返回完整的通知公告详细信息，包括通知标题、内容、发送者、接收者类型、通知类型、优先级、是否已读等核心数据。该逻辑是通知公告功能页面的通知详情查看接口，确保用户能够查看特定通知公告的完整内容。通过关联查询系统账户实体获取发送者的详细信息，该逻辑提供了一个包含所有必要上下文信息的完整数据视图，支持前端展示通知的详细内容，并为后续可能的操作（如标记已读）提供基础数据。

### 功能要点

- **通知详情查询与展示**：根据提供的通知ID参数，从数据库中精确查询对应的NotificationMessageEntity记录，返回完整的通知详细信息。查询结果包含通知的基本属性（标题、内容）、发送者关联信息、接收者信息、通知状态（是否已读）以及时间戳信息（创建时间、发送时间、阅读时间等）。系统确保返回的数据结构完整且符合前端展示需求，支持通知公告详情页面的所有显示元素，包括富文本内容的正确渲染和通知元数据的完整展示.

### 逻辑签名

```naturalts path="app.logics.loadMessageDetail.ts"
$Logic({
    description: '加载通知公告详情',
    directory: 'office_automation(办公自动化)'
})
export declare function loadMessageDetail(
    messageId: Integer
): {
    notification: app.dataSources.defaultDS.entities.NotificationMessageEntity;
    sender: app.dataSources.defaultDS.entities.SystemAccount;
};
```

### 被前端调用

- **通知公告（noticeAnnouncement）**：在通知公告详情页面中，当用户点击某条公告标题时，前端调用此服务端逻辑获取完整的公告详情数据，用于展示公告的详细内容，包括标题、富文本内容、发布人信息、发布时间、是否置顶等核心数据。该逻辑为公告详情页面提供了完整的数据支撑.

### 依赖的枚举、实体

- **数据建模-实体-通知消息**：[办公自动化-实体-通知消息（NotificationMessageEntity）](specs/001-bootdo-management-system/plan/data-model/entity-NotificationMessageEntity.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

#### 邮件服务（EmailService） 【当前业务功能相关】

- 关联文档：[邮件服务（EmailService）](specs/001-bootdo-management-system/plan/integration/retrieval-EmailService.md)