# 环保管理-删除环境监测报告（deleteEnvironmentalReport）

- **生成时间**：2026-03-25

## 删除环境监测报告（deleteEnvironmentalReport）

### 功能概述

删除环境监测报告功能是环保管理模块的重要组成部分，专门用于处理已提交但尚未获得批准的环境报告的删除操作。该功能确保用户能够及时清理错误提交或需要重新编制的环境报告，维护系统数据的准确性和有效性。系统在执行删除操作前会进行严格的权限验证和状态检查，仅允许报告提交人或具有相应管理权限的用户删除处于"未批准"状态的报告。删除操作采用软删除机制，保留必要的审计日志，同时彻底移除报告内容以保护敏感数据。该功能还支持批量删除操作，提高用户处理多份报告的效率，并提供友好的确认提示，防止误操作导致的数据丢失。

### 功能要点

- **安全删除机制**：系统实现安全的环境报告删除机制，仅允许删除状态为"未批准"的报告，已批准的报告不可删除以确保合规性。删除操作前会验证当前用户是否为报告提交人或具有相应管理权限，防止越权操作。系统采用软删除方式，在数据库中标记删除状态而非物理删除，保留必要的审计追踪信息，同时清除敏感的报告内容数据。删除操作完成后，系统会自动更新相关统计信息，并触发相应的通知机制告知相关人员。

### 逻辑签名

```naturalts path="app.logics.deleteEnvironmentalReport.ts"
$Logic({
    description: '删除环境监测报告',
    directory: 'environmental_management(环保管理)'
})
export declare function deleteEnvironmentalReport(reportId: Integer): Boolean;
```

### 被前端调用

- **报告提交（reportSubmission）**：在报告列表页面，用户可以选择未批准的环境报告并执行删除操作，系统调用此服务端逻辑完成删除请求，删除成功后刷新报告列表。

### 依赖的枚举、实体

- **数据建模-实体-报告提交**：[环保管理-实体-报告提交（ReportSubmission）](specs/001-bootdo-management-system/plan/data-model/entity-ReportSubmission.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无