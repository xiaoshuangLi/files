# 内容管理-更新栏目结构（updateColumnStructure）

- **生成时间**：2026-03-25

## 更新栏目结构（updateColumnStructure）

### 功能概述

更新栏目结构服务端逻辑负责处理内容管理系统中栏目信息的修改操作。该逻辑允许系统管理员对现有栏目进行属性更新，包括栏目名称、父级栏目关系、描述信息和排序值等关键属性。通过此逻辑，管理员可以灵活调整网站或应用的内容组织架构，优化用户体验。该逻辑在执行更新前会验证栏目名称的唯一性（确保同级栏目不重名），并检查父级栏目ID的有效性，防止形成无效的栏目层级结构。更新操作完成后，系统会自动记录操作日志，并触发相关的缓存更新机制，确保前端展示的栏目结构与数据库保持一致。

### 功能要点

- **栏目基本信息更新**：支持更新栏目的核心属性，包括栏目名称（必填）、描述信息（可选）和排序值（数值，默认为0）。系统会验证栏目名称是否为空，并确保同级栏目名称的唯一性，防止出现重复命名导致的导航混乱。
- **栏目层级结构调整**：允许修改栏目的父级栏目关系，实现栏目在树形结构中的位置调整。系统会验证目标父级栏目的存在性和有效性，并防止形成循环引用（如A栏目不能成为自己的子栏目），确保栏目树形结构的完整性。
- **数据一致性保障**：在更新操作过程中，系统会自动维护相关联的数据一致性，包括更新时间戳、操作人信息等审计字段。同时，系统会检查栏目下是否存在关联的文章内容，如果存在则确保这些文章仍能正确归属于更新后的栏目结构中。

### 逻辑签名

```naturalts path="app.logics.updateColumnStructure.ts"
$Logic({
    description: '更新栏目结构信息',
    directory: 'content_management(内容管理)',
    transactional: true
})
export declare function updateColumnStructure(columnStructure: app.dataSources.defaultDS.entities.ColumnStructure): app.dataSources.defaultDS.entities.ColumnStructure;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| columnStructure | 栏目结构实体 | app.dataSources.defaultDS.entities.ColumnStructure | 包含要更新的栏目完整信息，包括ID、栏目名称、父栏目ID、描述和排序值等字段 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 更新后的栏目结构 | app.dataSources.defaultDS.entities.ColumnStructure | 返回更新后的完整栏目结构实体，包含自动生成的更新时间和更新人信息 |

### 被前端调用

- **栏目管理（columnStructure）**：栏目管理页面通过调用此服务端逻辑实现栏目信息的编辑功能。当管理员在栏目编辑表单中修改栏目名称、父级关系、描述或排序值并提交时，前端会将完整的栏目实体数据传递给此逻辑，完成栏目信息的更新操作。

### 依赖的枚举、实体

- **数据建模-实体-栏目结构**：[内容管理-实体-栏目结构（ColumnStructure）](specs/001-bootdo-management-system/plan/data-model/entity-ColumnStructure.md)

### 依赖的外部能力

无外部能力依赖。