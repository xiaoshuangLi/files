# 办公自动化-查询会议列表（queryMeetingList）

- **生成时间**：2026-03-25

## 查询会议列表（queryMeetingList）

### 功能概述

查询会议列表服务端逻辑提供分页查询系统中会议预约记录的功能，支持按会议标题、组织者、时间范围、地点等条件进行过滤，并支持按指定字段和顺序进行排序。该逻辑返回符合条件的会议列表及其总数，用于在会议管理页面中展示会议安排情况。通过关联查询系统账户实体获取组织者的详细信息，确保前端能够完整展示会议的基本信息和组织者身份。此服务是办公自动化模块会议管理功能的核心数据支撑接口，为用户提供高效、灵活的会议查询能力。

### 功能要点

- **分页查询与排序功能**：支持标准的分页参数（页码page、每页条数size）控制返回数据量，避免一次性加载过多数据导致性能问题。同时支持按任意字段（如会议标题、开始时间、结束时间等）进行升序或降序排序，通过sort和order参数动态构建排序规则，满足用户对会议列表的不同排序需求。默认按会议开始时间降序排列，确保最新的会议安排优先显示。

- **多条件组合过滤功能**：提供基于会议预约实体（MeetingReservation）的完整过滤能力，支持按会议标题模糊匹配、组织者ID精确匹配、时间范围（开始时间和结束时间之间）、地点关键词等多种条件进行组合查询。过滤条件通过MeetingReservation实体对象传递，确保查询条件与数据模型保持一致，提高查询的准确性和灵活性。

- **关联数据自动加载**：在返回会议列表的同时，自动关联加载组织者的系统账户信息，包括用户名、全名、邮箱等关键字段，减少前端多次请求的开销。这种关联查询通过外键关系实现，确保数据的一致性和完整性，为前端提供完整的会议展示数据。

- **时间冲突检测支持**：虽然主要功能是查询，但返回的会议数据包含完整的开始时间和结束时间信息，为前端实现会议室时间冲突检测提供基础数据支持。用户可以根据返回的会议时间信息判断是否存在时间重叠的情况，辅助会议安排决策。

### 逻辑签名

```naturalts path="app.logics.queryMeetingList.ts"
$Logic({
    description: '分页查询会议列表',
    directory: 'office_automation(办公自动化)'
})
export declare function queryMeetingList(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.MeetingReservation): { list: List<{ meeting: app.dataSources.defaultDS.entities.MeetingReservation, organizer: app.dataSources.defaultDS.entities.SystemAccount }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 分页查询的页码，从1开始计数 |
| size | 每页条数 | Integer | 每页返回的记录数量，建议范围1-100 |
| sort | 排序字段 | String | 排序的字段名，如"title"、"startTime"、"endTime"等 |
| order | 排序顺序 | String | 排序方向，"asc"表示升序，"desc"表示降序 |
| filter | 过滤条件 | app.dataSources.defaultDS.entities.MeetingReservation | 会议预约实体作为过滤条件，支持各字段的精确或模糊匹配 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 会议列表 | List<{ meeting: app.dataSources.defaultDS.entities.MeetingReservation, organizer: app.dataSources.defaultDS.entities.SystemAccount }> | 会议列表，每个列表项包含会议预约实体和关联的组织者系统账户信息 |
| total | 总条数 | Integer | 符合筛选条件的总记录数，用于分页计算 |

### 被前端调用

- **会议管理（meetingManagement）**：会议管理页面使用此服务端逻辑加载会议列表数据，支持用户查看、筛选和管理会议预约记录。页面通过分页、筛选和排序参数调用此接口，获取符合业务需求的会议数据，并在表格中展示会议标题、时间、地点、组织者等关键信息。

### 依赖的枚举、实体

- **数据建模-实体-会议预约**：[办公自动化-实体-会议预约（MeetingReservation）](specs/001-bootdo-management-system/plan/data-model/entity-MeetingReservation.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力