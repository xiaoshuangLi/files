# 内容管理-创建栏目结构（createColumnStructure）

- **生成时间**：2026-03-25

## 创建栏目结构（createColumnStructure）

### 功能概述

该服务端逻辑负责处理多级栏目树形结构的创建操作，支持用户在内容管理系统中建立层次化的栏目组织架构。系统允许管理员定义栏目的基本信息、层级关系、访问权限和显示属性，从而构建灵活的内容分类体系。创建过程中会验证栏目名称的唯一性、父级栏目的有效性以及用户权限，并自动处理栏目路径的生成和缓存更新。

### 功能要点

- **多级栏目创建**：支持创建无限层级的栏目树形结构，每个栏目可以指定父级栏目形成完整的层级关系。系统会自动计算并存储栏目的完整路径信息，便于后续的导航和权限控制。创建时需要验证父级栏目的存在性和有效性，确保不会形成循环引用或无效的层级结构，同时保证栏目名称在同一层级下的唯一性。

### 逻辑签名

```naturalts path="app.logics.createColumnStructure.ts"
$Logic({
    description: '创建栏目结构',
    directory: 'content_management(内容管理)',
    transactional: true
})
export declare function createColumnStructure(name: String, parentId: String?, description: String, enabled: Boolean, sortOrder: Integer, seoTitle: String, seoKeywords: String, seoDescription: String): app.dataSources.defaultDS.entities.ColumnStructure;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| name | 栏目名称 | String | 栏目名称 |
| parentId | 父级栏目ID | String? | 父级栏目ID，根栏目为空值 |
| description | 栏目描述 | String | 栏目描述 |
| enabled | 是否启用 | Boolean | 是否启用 |
| sortOrder | 显示顺序 | Integer | 显示顺序 |
| seoTitle | SEO标题 | String | SEO标题 |
| seoKeywords | SEO关键词 | String | SEO关键词 |
| seoDescription | SEO描述 | String | SEO描述 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 创建结果 | app.dataSources.defaultDS.entities.ColumnStructure | 创建成功的栏目结构实体 |

### 被前端调用

- **栏目管理（columnStructure）**：在栏目管理页面中，用户通过点击"新增栏目"按钮打开创建表单，填写栏目基本信息后调用此服务端逻辑完成栏目的创建操作，实现多级栏目树形结构的构建和维护。

### 依赖的枚举、实体

- **数据建模-实体-栏目结构**：[内容管理-实体-栏目结构（ColumnStructure）](specs/001-bootdo-management-system/plan/data-model/entity-ColumnStructure.md)

### 依赖的外部能力

无