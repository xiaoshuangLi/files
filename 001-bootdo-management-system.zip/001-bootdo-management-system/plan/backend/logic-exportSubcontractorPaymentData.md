# 分包商管理-导出分包商付款数据（exportSubcontractorPaymentData）

- **生成时间**：2026-03-25

## 导出分包商付款数据（exportSubcontractorPaymentData）

### 功能概述

导出分包商付款数据服务端逻辑负责将分包商付款管理模块中的付款记录数据导出为Excel文件格式，支持用户对分包商付款数据进行离线分析、存档和财务审计。该逻辑根据前端传递的查询条件（如分包商ID、付款状态、付款日期范围等）筛选符合条件的付款记录，并将包含分包商基本信息、付款金额、付款方式、付款日期、发票号和付款状态等完整字段的数据转换为结构化的Excel报表。导出功能确保了数据的完整性和准确性，支持企业对分包商付款情况的全面统计分析和合规性检查，是分包商财务管理的重要工具。

### 功能要点

- **数据筛选与导出**：根据用户在前端页面设置的查询条件（包括分包商ID、付款状态、付款日期范围等参数），从数据库中检索符合条件的分包商付款记录，并将这些记录的所有相关字段信息（包括分包商公司名称、联系人、付款金额、付款方式、付款日期、发票号、付款状态等）完整地导出到Excel文件中，确保导出数据的准确性和完整性，满足用户对分包商付款数据进行离线分析和财务审计的需求。

### 逻辑签名

```naturalts path="app.logics.exportSubcontractorPaymentData.ts"
$Logic({
    description: '导出分包商付款数据为Excel文件',
    directory: 'subcontractor_management(分包商管理)'
})
export declare function exportSubcontractorPaymentData(
  subcontractorId?: Integer,
  status?: String,
  paymentDateStart?: Date,
  paymentDateEnd?: Date
): FileExportResult;

### 被前端调用

- **付款管理（paymentManagement）**：当用户在付款管理页面点击导出按钮时，系统调用此服务端逻辑，将当前显示的付款记录列表数据导出为Excel文件，包含所有字段信息以便离线分析和存档。

### 依赖的枚举、实体

- **数据建模-实体-付款管理**：[分包商管理-实体-付款管理（PaymentManagement）](specs/001-bootdo-management-system/plan/data-model/entity-PaymentManagement.md)
- **数据建模-实体-分包商信息**：[分包商管理-实体-分包商信息（SubcontractorInformation）](specs/001-bootdo-management-system/plan/data-model/entity-SubcontractorInformation.md)

### 依赖的外部能力

无