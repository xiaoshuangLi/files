# 质量管理-更新质量问题（updateQualityIssue）

- **生成时间**：2026-03-25

## 更新质量问题（updateQualityIssue）

### 功能概述

更新质量问题服务端逻辑用于修改已存在的质量问题记录，支持对质量问题的标题、描述、状态等关键信息进行更新。该逻辑确保质量问题在整个生命周期中的信息准确性和一致性，允许质量管理员根据问题处理进展及时更新问题状态和相关信息。通过此逻辑，系统能够维护质量问题的完整历史记录，并支持与整改任务、质量检验等相关业务实体的关联更新，实现质量问题的全流程闭环管理。

### 功能要点

- **质量问题信息更新**：支持更新质量问题的基本信息，包括问题标题、详细描述、问题状态等核心字段。当质量问题的状态发生变化时（如从"已报告"变为"已分配"或"整改中"），系统会自动记录状态变更的时间戳，并触发相应的业务流程。该功能确保质量问题信息的实时性和准确性，为后续的质量分析和改进提供可靠的数据基础。

### 逻辑签名

```naturalts path="app.logics.updateQualityIssue.ts"
$Logic({
    description: '更新质量问题',
    directory: 'quality_management(质量管理)',
    transactional: true
})
export declare function updateQualityIssue(
  qualityIssueId: Integer,
  updateData: {
    title?: String;
    description?: String;
    status?: app.enums.QualityIssueStatusEnum;
  }
): app.dataSources.defaultDS.entities.QualityIssue;
```

### 被前端调用

- **质量问题登记（qualityIssueRegistration）**：质量管理员在质量问题登记页面编辑已存在的质量问题时，通过调用此服务端逻辑提交更新后的质量问题信息，包括修改问题标题、描述或更新问题状态，确保质量问题记录的准确性和时效性。

### 依赖的枚举、实体

- **数据建模-枚举-质量问题状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-质量问题**：[质量管理-实体-质量问题（QualityIssue）](specs/001-bootdo-management-system/plan/data-model/entity-QualityIssue.md)

### 依赖的外部能力

无外部能力依赖