# 办公自动化-同步邮件（syncEmails）

- **生成时间**：2026-03-25

## 同步邮件（syncEmails）

### 功能概述

同步邮件服务端逻辑负责从外部邮件服务器或第三方邮件服务中拉取邮件数据，并将其同步到系统内部的邮件通信模块中。该功能支持多种邮件协议（如IMAP、POP3）的连接配置，允许用户设置外部邮箱账户的认证信息、服务器地址、端口等参数。系统会定期或按需执行邮件同步任务，将新收到的邮件、已发送的邮件以及相关元数据（如发件人、收件人、主题、时间戳、附件等）完整地导入到本地数据库中，确保用户能够在系统内统一管理所有邮件通信。同步过程中还会处理邮件状态的映射和转换，维护邮件的已读/未读状态，并支持增量同步以避免重复数据。

### 功能要点

- **外部邮件账户配置与验证**：系统支持用户配置多个外部邮件账户，包括邮箱地址、密码（或授权码）、服务器类型（IMAP/POP3）、服务器地址、端口、SSL/TLS加密设置等必要参数。在保存配置前，系统会自动尝试连接并验证账户凭据的有效性，确保后续同步操作能够正常执行。配置信息会安全存储在系统中，并支持随时修改或删除。

- **邮件数据同步与转换**：同步过程会从外部邮件服务器拉取指定文件夹（如收件箱、发件箱、草稿箱等）中的邮件数据，包括邮件头信息（发件人、收件人、抄送、主题、日期）、邮件正文内容（纯文本和HTML格式）、附件列表及其元数据。系统会将这些数据按照内部邮件通信实体的结构进行转换和映射，确保数据格式的一致性和完整性。

- **增量同步与状态维护**：为提高同步效率并避免数据重复，系统采用增量同步机制。每次同步时会记录上次同步的时间戳或邮件UID，仅拉取新增或更新的邮件。同时，系统会维护邮件的已读/未读状态、重要标记等元数据，确保用户在外部客户端和系统内看到的邮件状态保持一致。

### 逻辑签名

```naturalts path="app.logics.syncEmails.ts"
$Logic({
    description: '同步外部邮件到系统内部',
    directory: 'office_automation(办公自动化)'
})
export declare function syncEmails(
  emailAccountId: Integer,
  folder: Optional<String>,
  since: Optional<DateTime>,
  includeAttachments: Optional<Boolean>,
  markAsRead: Optional<Boolean>
): {
  totalSynced: Integer;
  newEmails: Integer;
  updatedEmails: Integer;
  failedCount: Integer;
  syncTime: DateTime;
};
```

### 被前端调用

- **邮件集成（emailIntegration）**：在邮件集成功能页面中，用户可以通过"同步邮件"按钮触发此服务端逻辑，将配置的外部邮件账户中的邮件数据同步到系统内部。该功能支持手动触发同步和自动定时同步两种模式，确保用户能够及时获取最新的邮件信息。

### 依赖的枚举、实体

- **数据建模-实体-邮件通信**：[办公自动化-实体-邮件通信（EmailCommunication）](specs/001-bootdo-management-system/plan/data-model/entity-EmailCommunication.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

#### 邮件服务（EmailService） 【当前业务功能相关】

- 关联文档：[邮件服务（EmailService）](specs/001-bootdo-management-system/plan/integration/retrieval-EmailService.md)