# 内容管理-删除栏目结构（deleteColumnStructure）

- **生成时间**：2026-03-25

## 删除栏目结构（deleteColumnStructure）

### 功能概述

删除栏目结构服务端逻辑负责安全地删除内容管理系统中的栏目。该逻辑在执行删除操作前会进行严格的验证检查，确保被删除的栏目不包含任何子栏目或关联的文章内容，以维护数据完整性和系统稳定性。如果栏目下存在子栏目或关联文章，系统将拒绝删除操作并返回相应的错误信息，提示用户先处理相关联的内容。此逻辑还负责在成功删除栏目后清理与该栏目相关的用户订阅记录，确保系统数据的一致性。

### 功能要点

- **安全删除验证**：在执行删除操作前，系统必须验证目标栏目是否为空（即不包含任何子栏目和关联文章）。如果栏目下存在子栏目或关联文章，系统应拒绝删除操作并返回明确的错误信息，提示用户需要先处理这些关联内容。这种验证机制确保了内容管理系统的数据完整性，防止因误操作导致的数据丢失或引用断裂。

### 逻辑签名

```naturalts path="app.logics.deleteColumnStructure.ts"
$Logic({
    description: '删除栏目结构',
    directory: 'content_management(内容管理)'
})
export declare function deleteColumnStructure(columnId: Integer): Boolean;
```

### 被前端调用

- **栏目管理（columnStructure）**：在栏目管理页面中，当系统管理员选择某个栏目并点击删除按钮时，前端会调用此服务端逻辑来执行删除操作。该逻辑负责验证栏目是否可以安全删除（无子栏目和关联文章），并在验证通过后执行实际的删除操作，同时清理相关的用户订阅记录。

### 依赖的枚举、实体

- **数据建模-实体-栏目结构**：[内容管理-实体-栏目结构（ColumnStructure）](specs/001-bootdo-management-system/plan/data-model/entity-ColumnStructure.md)
- **数据建模-实体-文章内容**：[内容管理-实体-文章内容（ArticleContent）](specs/001-bootdo-management-system/plan/data-model/entity-ArticleContent.md)
- **数据建模-实体-用户订阅**：[办公自动化-实体-用户订阅（UserSubscription）](specs/001-bootdo-management-system/plan/data-model/entity-UserSubscription.md)

### 依赖的外部能力

无