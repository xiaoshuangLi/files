# 环保管理-获取资源消耗统计数据（getResourceConsumptionStatistics）

- **生成时间**：2026-03-25

## 获取资源消耗统计数据（getResourceConsumptionStatistics）

### 功能概述

获取资源消耗统计数据服务端逻辑负责提供企业各类能源资源消耗情况的统计分析功能，支持对电力消耗、水资源消耗、燃料消耗、原材料消耗等不同类型的能源资源用量数据进行聚合计算和趋势分析。该逻辑能够根据指定的时间范围、资源类型、部门ID等筛选条件，从资源消耗实体中提取相关数据，进行汇总统计，并返回结构化的统计结果。通过关联组织部门实体，系统可以按部门维度进行资源消耗统计和分析，支持部门级能耗考核和管理。此服务为环保合规检查、环境风险评估和节能减排措施制定提供基础数据支撑，帮助企业履行环保责任，降低环境风险。

### 功能要点

- **多维度资源消耗统计**：系统支持根据时间范围（开始日期和结束日期）、资源类型（电力、水资源、燃料、原材料等）、部门ID等多个维度对资源消耗数据进行筛选和统计，能够灵活满足不同场景下的数据分析需求。统计结果包括总消耗量、日均消耗量、同比环比增长率等关键指标，帮助用户全面了解资源使用情况和变化趋势。

### 逻辑签名

```naturalts path="app.logics.getResourceConsumptionStatistics.ts"
$Logic({
    description: '获取资源消耗统计数据',
    directory: 'environmental_management(环保管理)'
})
export declare function getResourceConsumptionStatistics(
    resourceType?: String,
    startDate?: Date,
    endDate?: Date,
    departmentId?: Integer
): {
    totalConsumption: Decimal,
    dailyAverage: Decimal,
    consumptionTrend: Array<{
        date: Date,
        amount: Decimal,
        unit: String
    }>,
    departmentBreakdown: Array<{
        departmentId: Integer,
        departmentName: String,
        consumptionAmount: Decimal,
        unit: String
    }>
};
```

### 被前端调用

- **资源消耗（resourceConsumption）**：资源消耗功能页面调用此服务端逻辑获取能源资源消耗的统计数据，用于在页面上展示多维度的资源消耗趋势图表和汇总信息，支持用户进行数据分析和决策。

### 依赖的枚举、实体

- **数据建模-实体-资源消耗**：[环保管理-实体-资源消耗（ResourceConsumption）](specs/001-bootdo-management-system/plan/data-model/entity-ResourceConsumption.md)
- **数据建模-实体-组织部门**：[系统管理-实体-组织部门（OrganizationDepartment）](specs/001-bootdo-management-system/plan/data-model/entity-OrganizationDepartment.md)

### 依赖的外部能力

无外部能力依赖。该服务端逻辑完全基于系统内部的数据模型和业务逻辑实现，不依赖任何外部系统或第三方服务。