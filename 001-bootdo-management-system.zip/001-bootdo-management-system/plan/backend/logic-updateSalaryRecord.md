# 薪资管理-更新薪资记录（updateSalaryRecord）

- **生成时间**：2026-03-25

## 更新薪资记录（updateSalaryRecord）

### 功能概述

更新薪资记录功能用于修改已存在的月度薪资计算结果，包括税前金额、税后金额等关键数据。该功能支持薪资管理人员在发现薪资计算错误或需要调整特定员工薪资时，对已生成的薪资记录进行修正。系统会自动重新计算相关税务信息，并保持薪资历史记录的完整性和可追溯性。更新操作会记录操作日志，确保所有变更都有据可查，同时支持与发放记录的同步更新，保证薪资数据的一致性。

### 功能要点

- **薪资数据修正**：当发现月度薪资计算存在错误时，具有相应权限的薪资管理人员可以修改薪资记录中的税前金额、税后金额等关键数据。系统会自动验证修改后的数据合理性，并重新计算相关税务信息，确保薪资数据的准确性和合规性。此功能对于处理特殊情况下的薪资调整至关重要，如补发工资、扣除违规罚款等场景。

### 逻辑签名

```naturalts path="app.logics.updateSalaryRecord.ts"
$Logic({
    description: '更新薪资记录',
    directory: 'salary_management(薪资管理)',
    transactional: true
})
export declare function updateSalaryRecord(salaryRecord: app.dataSources.defaultDS.entities.MonthlySalaryAmount): app.dataSources.defaultDS.entities.MonthlySalaryAmount;
```

### 被前端调用

- **月工资额计算（monthlySalaryAmount）**：在月工资额计算页面中，用户可以通过编辑操作调用此服务端逻辑来更新已存在的薪资记录，修改税前金额、税后金额等数据，并保存变更。

### 依赖的枚举、实体

- **数据建模-实体-月工资额**：[薪资管理-实体-月工资额（MonthlySalaryAmount）](specs/001-bootdo-management-system/plan/data-model/entity-MonthlySalaryAmount.md)

### 依赖的外部能力

无匹配内容

