# 质量管理-加载整改任务列表（loadRectificationTaskList）

- **生成时间**：2026-03-25

## 加载整改任务列表（loadRectificationTaskList）

### 功能概述

加载整改任务列表服务端逻辑用于分页查询系统中的整改任务数据，支持按质量问题ID、分配用户ID、整改状态、创建时间范围等条件进行过滤，并支持按指定字段和排序方向进行结果排序。该逻辑返回包含整改任务列表和总记录数的分页结果，每条记录包含完整的整改任务信息以及关联的质量问题和分配用户信息。此逻辑为前端整改任务管理页面提供数据支持，使质量管理人员能够高效地浏览、筛选和监控所有整改任务的执行情况，确保质量问题得到及时有效的处理。

### 功能要点

- **分页查询与过滤功能**：支持标准的分页参数（页码、每页条数）和多维度过滤条件，包括质量问题ID、分配用户ID、整改状态（待处理、处理中、已完成、已取消）、创建时间范围等。用户可以根据实际需求组合不同的过滤条件，快速定位到关注的整改任务，提高数据查询的准确性和效率。分页查询结果包含当前页的数据列表和总记录数，便于前端实现完整的分页控件。

- **动态排序功能**：支持按任意字段（如创建时间、分配时间、完成时间等）进行升序或降序排列，用户可以根据任务紧急程度或时间顺序对结果进行排序，便于识别需要优先处理的任务或查看最新的整改进展，辅助质量管理决策。

- **关联数据加载**：在查询整改任务记录的同时，自动关联获取对应的质量问题详情和分配用户的账户信息，包括问题标题、问题描述、用户姓名等关键信息。这种关联查询减少了前端的多次请求，提高了数据展示的完整性和用户体验，使质量管理人员能够在一个视图中获得整改任务的全部上下文信息。

### 逻辑签名

```naturalts path="app.logics.loadRectificationTaskList.ts"
$Logic({
    description: '分页查询整改任务列表',
    directory: 'quality_management(质量管理)'
})
export declare function loadRectificationTaskList(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.RectificationTask): { list: List<{ rectificationTask: app.dataSources.defaultDS.entities.RectificationTask, qualityIssue: app.dataSources.defaultDS.entities.QualityIssue, assignee: app.dataSources.defaultDS.entities.SystemAccount }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 查询的页码，从1开始 |
| size | 每页条数 | Integer | 每页显示的记录数量 |
| sort | 排序字段 | String | 用于排序的字段名称 |
| order | 排序顺序 | String | 排序顺序，'asc'表示升序，'desc'表示降序 |
| filter | 过滤条件 | app.dataSources.defaultDS.entities.RectificationTask | 过滤条件，包含质量问题ID、分配用户ID、整改状态等可选过滤字段 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 整改任务列表 | List<{ rectificationTask: app.dataSources.defaultDS.entities.RectificationTask, qualityIssue: app.dataSources.defaultDS.entities.QualityIssue, assignee: app.dataSources.defaultDS.entities.SystemAccount }> | 整改任务记录列表，每项包含整改任务实体、关联的质量问题实体和分配用户实体 |
| total | 总记录数 | Integer | 符合过滤条件的总记录数 |

### 被前端调用

- **整改任务分配（rectificationTask）**：整改任务分配页面使用此服务端逻辑加载整改任务数据列表，支持用户进行查询、筛选、排序等操作，展示整改任务的详细信息及关联的质量问题和分配用户信息。

### 依赖的枚举、实体

- **数据建模-枚举-任务状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-整改任务**：[质量管理-实体-整改任务（RectificationTask）](specs/001-bootdo-management-system/plan/data-model/entity-RectificationTask.md)
- **数据建模-实体-质量问题**：[质量管理-实体-质量问题（QualityIssue）](specs/001-bootdo-management-system/plan/data-model/entity-QualityIssue.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无