# 分包商管理-更新分包商资质证书（updateSubcontractorQualificationCertificate）

- **生成时间**：2026-03-25

## 更新分包商资质证书（updateSubcontractorQualificationCertificate）

### 功能概述

该服务端逻辑用于更新分包商的资质证书信息，包括证书类型、证书编号、颁发机构、有效期、证书状态等关键信息。系统管理员或相关部门负责人可以通过此功能维护分包商的资质证书数据，确保证书信息的准确性和时效性。更新操作会验证证书的有效期是否合理，并记录操作日志以便审计追踪。此功能对于确保分包商持续符合项目要求的资质标准至关重要，是分包商管理体系中的核心环节。

### 功能要点

- **资质证书信息更新**：支持更新分包商资质证书的完整信息，包括证书类型、证书编号、颁发机构、发证日期、有效期至、证书扫描件等。系统会验证必填字段的完整性，并对证书有效期进行合理性检查，防止过期或无效日期的录入。更新后的证书信息将立即生效，并可用于后续的分包商评估和项目分配决策。

### 逻辑签名

```naturalts path="app.logics.updateSubcontractorQualificationCertificate.ts"
$Logic({
    description: '更新分包商资质证书',
    directory: 'subcontractor_management(分包商管理)',
    transactional: true
})
export declare function updateSubcontractorQualificationCertificate(
  certificateId: String,
  subcontractorId: String,
  certificateType: String,
  certificateNumber: String,
  issuingAuthority: String,
  issueDate: Date,
  expiryDate: Date,
  certificateStatus: app.enums.QualificationCertificateStatus,
  certificateFile?: String,
  remarks?: String
): app.dataSources.defaultDS.entities.QualificationCertificate;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| certificateId | 证书ID | String | 资质证书的唯一标识 |
| subcontractorId | 分包商ID | String | 分包商的唯一标识 |
| certificateType | 证书类型 | String | 资质证书的类型 |
| certificateNumber | 证书编号 | String | 资质证书的编号 |
| issuingAuthority | 颁发机构 | String | 证书的颁发机构 |
| issueDate | 发证日期 | Date | 证书的颁发日期 |
| expiryDate | 有效期至 | Date | 证书的有效期截止日期 |
| certificateStatus | 证书状态 | app.enums.QualificationCertificateStatus | 证书的状态（有效、过期、待审核、已撤销） |
| certificateFile | 证书文件 | String | 证书扫描件的文件路径（可选） |
| remarks | 备注 | String | 附加备注信息（可选） |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 更新结果 | app.dataSources.defaultDS.entities.QualificationCertificate | 更新后的资质证书实体 |

### 被前端调用

- **资质管理（qualificationCertificate）**：在分包商资质管理页面中，管理员可以点击编辑资质证书按钮，调用此服务端逻辑来更新分包商的资质证书信息，确保分包商资质数据的准确性和时效性。

### 依赖的枚举、实体

- **数据建模-枚举-资质证书状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-资质证书**：[分包商管理-实体-资质证书（QualificationCertificate）](specs/001-bootdo-management-system/plan/data-model/entity-QualificationCertificate.md)

### 依赖的外部能力

无