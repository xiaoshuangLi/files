# 办公自动化-保存个人工作台布局配置（savePersonalWorkspaceLayout）

- **生成时间**：2026-03-25

## 保存个人工作台布局配置（savePersonalWorkspaceLayout）

### 功能概述

该服务端逻辑负责保存用户的个性化工作台布局配置，支持用户根据自身工作习惯和业务需求定制专属的工作环境。系统接收用户ID和布局配置数据，将配置信息持久化存储到个人工作台实体中。布局配置采用JSON格式存储，包含工作台的模块排列、快捷入口设置、默认视图偏好等个性化参数。该逻辑确保用户的个性化配置能够被正确保存，并在用户下次访问时加载应用，从而提升工作效率和使用体验。

### 功能要点

- **个性化布局保存**：支持保存用户自定义的工作台模块布局，包括模块的位置、大小和显示/隐藏状态，确保用户可以根据个人工作习惯调整界面布局
- **快捷入口配置存储**：保存用户设置的常用功能快捷入口，记录用户选择的功能模块和排序信息，便于用户快速访问高频使用的业务功能
- **跨设备配置同步**：确保用户的个人工作台配置能够在不同设备间保持一致，无论用户从哪个终端登录系统，都能获得相同的个性化工作环境
- **权限范围适配**：根据用户的部门角色和权限范围，验证并保存符合权限控制要求的布局配置，确保个性化配置与系统权限体系的一致性

### 逻辑签名

```naturalts path="app.logics.savePersonalWorkspaceLayout.ts"
$Logic({
    description: '保存个人工作台布局配置',
    directory: 'office_automation(办公自动化)',
    transactional: true
})
export declare function savePersonalWorkspaceLayout(userId: Integer, layoutConfig: String): app.dataSources.defaultDS.entities.PersonalWorkspace;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| userId | 用户ID | Integer | 当前用户的唯一标识，用于关联个人工作台配置 |
| layoutConfig | 布局配置 | String | 用户个性化工作台布局配置，采用JSON格式存储 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 保存结果 | app.dataSources.defaultDS.entities.PersonalWorkspace | 保存后的个人工作台实体，包含完整的配置信息 |

### 被前端调用

- **个人门户（personalWorkspace）**：个人门户页面调用此服务端逻辑保存用户的个性化工作台布局配置，当用户完成布局调整后，系统将配置数据提交至此逻辑进行持久化存储

### 依赖的枚举、实体

- **数据建模-实体-个人工作台**：[办公自动化-实体-个人工作台（PersonalWorkspace）](specs/001-bootdo-management-system/plan/data-model/entity-PersonalWorkspace.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无外部能力依赖。