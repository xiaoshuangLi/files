# 工作流引擎-批量更新任务（batchUpdateTasks）

- **生成时间**：2026-03-25

## 批量更新任务（batchUpdateTasks）

### 功能概述

批量更新任务服务端逻辑是工作流引擎模块的核心功能之一，用于支持用户对多个任务节点进行统一的操作处理。该逻辑允许用户一次性选择多个任务节点，并对这些任务执行相同的操作，如批量更新任务状态（将多个任务同时标记为已完成、处理中或已取消）或批量删除任务（软删除）。此功能显著提高了用户在处理大量任务时的工作效率，避免了逐个操作的繁琐过程。批量更新任务逻辑严格遵循权限控制原则，确保用户只能操作自己有权限处理的任务，并在操作过程中保持数据的一致性和完整性。系统会记录每次批量操作的详细日志，包括操作用户、操作时间、影响的任务数量等信息，便于后续的审计和追踪。

### 功能要点

- **批量状态更新**：支持用户选择多个任务节点，统一更新它们的状态为指定值（待处理、处理中、已完成或已取消）。系统会验证目标状态的有效性，并确保状态转换符合业务规则，例如已完成的任务不能再次更新为待处理状态。操作成功后，所有选中的任务状态将同步更新，并触发相应的业务事件通知。

- **批量删除操作**：支持用户选择多个任务节点进行批量删除（软删除），删除操作会将任务标记为已删除状态而非物理删除，保留历史数据以供审计。系统会在执行删除前验证用户的删除权限，并检查任务是否处于可删除状态（如未完成的任务可能不允许删除）。删除操作会记录详细的日志信息，包括被删除的任务ID列表和操作时间戳。

- **权限与数据一致性保障**：批量操作过程中严格实施权限控制，确保用户只能操作分配给自己或有权限管理的任务节点。系统采用事务机制保证批量操作的原子性，要么全部成功，要么全部回滚，避免部分成功导致的数据不一致问题。同时，操作过程中会对任务状态进行实时校验，防止非法状态转换。

### 逻辑签名

```naturalts path="app.logics.batchUpdateTasks.ts"
$Logic({
    description: '批量更新任务节点',
    directory: 'workflow_engine(工作流引擎)',
    transactional: true
})
export declare function batchUpdateTasks(
  taskIds: List<Integer>,
  updateType: 'STATUS_UPDATE' | 'DELETE',
  newStatus?: app.enums.TaskStatusEnum
): {
  successCount: Integer;
  failedTaskIds: List<Integer>;
  message: String;
};
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| taskIds | 任务ID列表 | List&lt;Integer&gt; | 需要更新的任务ID列表 |
| updateType | 更新类型 | 'STATUS_UPDATE' \| 'DELETE' | 更新类型，可选值：STATUS_UPDATE（状态更新）或DELETE（删除） |
| newStatus | 新的任务状态 | app.enums.TaskStatusEnum | 新的任务状态，仅当updateType为STATUS_UPDATE时需要 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| successCount | 成功数量 | Integer | 成功更新的任务数量 |
| failedTaskIds | 失败任务ID列表 | List&lt;Integer&gt; | 更新失败的任务ID列表 |
| message | 操作消息 | String | 操作结果的消息描述 |

### 被前端调用

- **任务管理（taskManagement）**：在任务管理页面中，用户可以通过勾选多个任务节点，然后选择批量操作（如批量更新状态或批量删除），此时前端会调用batchUpdateTasks服务端逻辑来执行批量操作，提高任务处理效率。

### 依赖的枚举、实体

- **数据建模-枚举-任务状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-任务节点**：[工作流引擎-实体-任务节点（TaskNode）](specs/001-bootdo-management-system/plan/data-model/entity-TaskNode.md)

### 依赖的外部能力

无