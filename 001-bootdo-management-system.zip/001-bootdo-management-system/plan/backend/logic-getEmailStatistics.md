# 办公自动化-获取邮件统计信息（getEmailStatistics）

- **生成时间**：2026-03-25

## 获取邮件统计信息（getEmailStatistics）

### 功能概述

获取邮件统计信息服务端逻辑提供企业内部邮件通信的全面统计分析功能。该逻辑能够按不同维度（如时间范围、用户、部门等）统计邮件收发数量、阅读率、响应时间等关键指标，帮助管理者了解组织内部沟通效率和邮件使用情况。统计结果可用于优化邮件沟通策略、识别沟通瓶颈、评估团队协作效率，并为办公自动化系统的持续改进提供数据支持。该逻辑支持灵活的过滤条件，允许用户自定义统计维度和时间范围，确保统计数据的准确性和实用性。

### 功能要点

- **邮件收发量统计**：统计指定时间范围内系统内邮件的发送和接收总量，支持按日、周、月等不同时间粒度进行聚合分析，帮助管理者了解邮件通信的整体活跃度和趋势变化。
- **用户邮件行为分析**：分析特定用户或用户组的邮件收发行为，包括平均每日邮件数量、最活跃时间段、主要通信对象等，为个人工作效率评估和团队沟通模式分析提供数据基础。
- **邮件阅读率统计**：计算已发送邮件的阅读率指标，即被收件人打开查看的邮件占总发送邮件的比例，帮助评估重要信息的传达效果和收件人的响应积极性。
- **部门间邮件流量分析**：统计不同部门之间的邮件往来频率和数量，识别跨部门协作的热点区域和潜在的沟通障碍，为组织架构优化和流程改进提供参考依据。

### 逻辑签名

```naturalts path="app.logics.getEmailStatistics.ts"
$Logic({
    description: '获取邮件统计信息',
    directory: 'office_automation(办公自动化)'
})
export declare function getEmailStatistics(startDate: DateTime, endDate: DateTime, userId?: Integer, departmentId?: Integer, emailType?: String): { totalSent: Integer, totalReceived: Integer, readRate: Decimal, averageResponseTime: Integer, departmentStats: List<{ departmentId: Integer, departmentName: String, sentCount: Integer, receivedCount: Integer }> };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| startDate | 统计开始时间 | DateTime | 统计的时间范围开始时间 |
| endDate | 统计结束时间 | DateTime | 统计的时间范围结束时间 |
| userId | 用户ID | Integer | 可选，指定统计特定用户的邮件数据 |
| departmentId | 部门ID | Integer | 可选，指定统计特定部门的邮件数据 |
| emailType | 邮件类型 | String | 可选，指定统计特定类型的邮件 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| totalSent | 总发送量 | Integer | 统计期间内的邮件总发送数量 |
| totalReceived | 总接收量 | Integer | 统计期间内的邮件总接收数量 |
| readRate | 阅读率 | Decimal | 已读邮件占总发送邮件的比例（0-1之间的小数） |
| averageResponseTime | 平均响应时间 | Integer | 收件人平均回复邮件所需的时间（以分钟为单位） |
| departmentStats | 部门统计 | List<{ departmentId: Integer, departmentName: String, sentCount: Integer, receivedCount: Integer }> | 各部门的邮件收发统计详情列表 |

### 被前端调用

- **Dashboard（dashboard）**：在系统仪表盘页面中展示邮件通信的关键统计指标，包括今日邮件收发量、本周阅读率趋势、部门间邮件流量热力图等，为用户提供全局的邮件使用概览。
- **邮件集成（emailCommunication）**：在邮件集成功能页面的统计分析模块中，提供详细的邮件行为分析报告，支持用户按不同维度筛选和查看个性化的邮件统计数据。

### 依赖的枚举、实体

- **数据建模-实体-邮件通信**：[办公自动化-实体-邮件通信（EmailCommunication）](specs/001-bootdo-management-system/plan/data-model/entity-EmailCommunication.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)
- **数据建模-实体-组织部门**：[系统管理-实体-组织部门（OrganizationDepartment）](specs/001-bootdo-management-system/plan/data-model/entity-OrganizationDepartment.md)

### 依赖的外部能力

无