# 预算管理-获取预算类型详情（getBudgetTypeDetail）

- **生成时间**：2026-03-25

## 获取预算类型详情（getBudgetTypeDetail）

### 功能概述

获取预算类型详情功能用于查询并返回指定预算类型的完整信息，包括类型名称、描述以及系统自动生成的元数据（如创建时间、更新时间、创建人等）。该功能是预算类型管理模块的核心查询接口，为前端预算类型详情页面提供数据支持，确保用户能够查看特定预算类型的全部属性信息。通过该接口，系统能够实现对预算类型数据的精确检索，为预算分配、执行监控等后续业务操作提供准确的基础数据参考。

### 功能要点

- **预算类型详情查询**：根据提供的预算类型ID参数，从数据库中精确检索对应的预算类型记录，并返回包含所有字段的完整数据对象。系统需验证ID参数的有效性，对于不存在的ID应返回适当的错误提示，确保数据查询的安全性和准确性。

### 逻辑签名

```naturalts path="app.logics.budgetManagement.getBudgetTypeDetail.ts"
$Logic({
    title: "获取预算类型详情",
    directory: "budget_management(预算管理)"
})
export declare function getBudgetTypeDetail(budgetTypeId: Integer): BudgetType;
```

### 被前端调用

- **预算类型管理（budgetType）**：在预算类型管理页面中，当用户点击某条预算类型记录的"详情"按钮时，前端会调用此服务端逻辑，传入预算类型ID参数，获取该预算类型的完整信息并在详情页面展示，包括类型名称、描述、创建人、创建时间、更新时间等系统字段。

### 依赖的枚举、实体

- **数据建模-实体-预算类型**：[预算管理-实体-预算类型（BudgetType）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetType.md)

### 依赖的外部能力

无