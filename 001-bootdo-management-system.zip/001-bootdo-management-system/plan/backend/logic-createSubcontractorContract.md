# 分包商管理-创建分包商合同（createSubcontractorContract）

- **生成时间**：2026-03-25

## 创建分包商合同（createSubcontractorContract）

### 功能概述

创建分包商合同功能是分包商管理模块的核心业务逻辑之一，用于在系统中创建和维护分包商与其签订的各类合同的完整信息。该逻辑接收包含合同编号、合同条款内容、签署日期、合同有效期以及合同价值等关键业务数据的输入参数，通过验证数据完整性和有效性后，将合同信息持久化存储到数据库中，并与对应的分包商信息建立关联关系。此功能确保了合同数据的规范性、一致性和可追溯性，为企业的分包商管理和成本控制提供可靠的数据支撑，同时支持后续的合同状态跟踪、到期提醒和合同价值统计分析等业务需求。

### 功能要点

- **合同基本信息创建**：创建分包商合同时，系统必须接收并验证合同的基本信息，包括合同编号（唯一标识）、合同条款（详细内容）、签署日期、开始日期、结束日期和合同价值（金额）等必填字段。这些字段构成了合同的核心数据，确保合同信息的完整性和规范性，为后续的合同管理和执行提供基础数据支撑。

### 逻辑签名

```naturalts path="app.logics.createSubcontractorContract.ts"
$Logic({
    description: '创建分包商合同',
    directory: 'subcontractor_management(分包商管理)',
    transactional: true
})
export declare function createSubcontractorContract(contract: app.dataSources.defaultDS.entities.ContractAssociation): app.dataSources.defaultDS.entities.ContractAssociation;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| contract | 合同信息 | app.dataSources.defaultDS.entities.ContractAssociation | 包含合同编号、合同条款、签署日期、开始日期、结束日期、合同价值等字段的合同实体 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 创建结果 | app.dataSources.defaultDS.entities.ContractAssociation | 补充了主键ID和其他系统字段的完整合同实体 |

### 被前端调用

- **合同关联（contractAssociation）**：在合同关联页面中，当用户点击"新建合同"按钮并填写完合同信息后，系统调用此服务端逻辑来创建新的分包商合同记录，实现合同数据的持久化存储。

### 依赖的枚举、实体

- **数据建模-实体-合同关联**：[分包商管理-实体-合同关联（ContractAssociation）](specs/001-bootdo-management-system/plan/data-model/entity-ContractAssociation.md)
- **数据建模-实体-分包商信息**：[分包商管理-实体-分包商信息（SubcontractorInformation）](specs/001-bootdo-management-system/plan/data-model/entity-SubcontractorInformation.md)

### 依赖的外部能力

无