# 环保管理-获取环境报告列表（getEnvironmentalReportList）

- **生成时间**：2026-03-25

## 获取环境报告列表（getEnvironmentalReportList）

### 功能概述

获取环境报告列表服务端逻辑用于查询和检索系统中已提交的各类环境报告数据，包括月度环境报告、季度环境报告和年度环境报告等。该逻辑支持按报告类型、提交时间范围、提交人等多种条件进行筛选查询，并返回分页的报告列表数据。通过该服务端逻辑，用户可以在报告提交页面查看自己或部门提交的所有环境报告记录，了解报告的提交状态、审核进度和历史变更情况，为环保合规管理和环境决策提供数据支持。

### 功能要点

- **环境报告查询功能**：支持按报告类型（月度、季度、年度）、提交时间范围、提交人、审核状态等多种条件组合查询环境报告列表，满足不同场景下的数据检索需求。系统会根据用户权限自动过滤可查看的报告数据，确保数据安全性和隐私保护。查询结果以分页形式返回，包含报告基本信息、提交状态和关键指标摘要，便于用户快速浏览和定位所需报告。

### 逻辑签名

```naturalts path="app.logics.getEnvironmentalReportList.ts"
$Logic({
    description: '获取环境报告列表',
    directory: 'environmental_management(环保管理)'
})
export declare function getEnvironmentalReportList(
    page: Integer,
    size: Integer,
    reportType?: String,
    startTime?: DateTime,
    endTime?: DateTime,
    submitterId?: Integer,
    isApproved?: Boolean
): { list: Array<{ environmentalReport: app.dataSources.defaultDS.entities.ReportSubmission, submitter: app.dataSources.defaultDS.entities.SystemAccount }>, total: Integer };
```

### 被前端调用

- **报告提交（reportSubmission）**：在报告提交页面中，通过调用此服务端逻辑获取用户已提交的环境报告列表，展示报告类型、提交时间、提交人和审核状态等信息，支持用户对历史报告进行查询和管理。

### 依赖的枚举、实体

- **环保管理-实体-报告提交**：[环保管理-实体-报告提交（ReportSubmission）](specs/001-bootdo-management-system/plan/data-model/entity-ReportSubmission.md)
- **系统管理-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无匹配内容

