# 权限中心-批量删除部门（LcapBatchDeleteDepartment）

## 批量删除部门（LcapBatchDeleteDepartment）

### 功能概述

批量删除部门服务端逻辑用于安全地删除系统中的一个或多个部门记录。该逻辑在执行删除操作前会进行严格的业务验证，确保被删除的部门不包含任何子部门且没有关联的用户，从而维护组织架构的完整性和数据一致性。只有当所有验证条件都满足时，才会执行实际的删除操作，并返回操作结果状态。

### 功能要点

- **安全删除验证**：在执行删除操作前，系统会检查待删除的部门是否包含子部门。如果存在子部门，则阻止删除操作并返回错误提示"请先删除子部门"，确保组织架构的层级完整性不被破坏。
- **用户关联检查**：系统会验证待删除的部门是否有关联的用户。如果部门下存在用户，则阻止删除操作并返回错误提示"请先移除该部门下用户"，确保用户数据不会因部门删除而丢失归属。
- **批量处理支持**：支持同时删除多个部门ID，提高管理效率，适用于需要批量清理测试数据或重构组织架构的场景。
- **事务性操作**：整个删除过程作为一个原子操作执行，要么全部成功，要么全部失败，确保数据的一致性。
- **错误处理机制**：提供明确的错误信息反馈，帮助管理员理解删除失败的原因，并指导后续操作。

### 逻辑签名

```naturalts path="app.logics.LcapBatchDeleteDepartment.ts"
$Logic({
    description: '安全地删除系统中的一个或多个部门记录，确保被删除的部门不包含任何子部门且没有关联的用户',
    directory: 'permission_center(权限中心)',
})
export declare function LcapBatchDeleteDepartment(ids: List<Integer>): String;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| ids | 部门ID列表 | List<Integer> | 要删除的部门ID列表 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 操作结果 | String | 操作结果状态码或错误信息，成功返回"200"，失败返回具体错误信息 |

### 被前端调用

- **部门管理页（departmentManagement）**：在部门管理页面中，当管理员点击部门记录的"删除"链接时，系统会调用此服务端逻辑来执行删除操作。该逻辑负责验证部门是否可以被安全删除（无子部门、无关联用户），并在验证通过后执行实际的删除操作，确保组织架构数据的完整性。

### 依赖的枚举、实体、数据结构

- **数据建模-实体-部门**：[权限中心-实体-部门（LcapDepartment）](specs/001-bootdo-management-system/plan/data-model/entity-LcapDepartment.md)
- **数据建模-实体-用户与部门映射**：[权限中心-实体-用户与部门映射（LcapUserDeptMapping）](specs/001-bootdo-management-system/plan/data-model/entity-LcapUserDeptMapping.md)

