# 工作流引擎-查询用户组成员列表（queryUserGroupMembers）

- **生成时间**：2026-03-25

## 查询用户组成员列表（queryUserGroupMembers）

### 功能概述

该服务端逻辑用于查询指定用户组中的所有成员信息，支持分页查询和条件过滤。系统管理员、部门管理员或具有相应权限的用户可以通过此接口获取用户组的成员列表，包括成员的基本信息、角色信息以及在用户组中的状态。此功能是工作流引擎中用户和组管理的核心组成部分，为流程审批、任务分配等业务场景提供用户数据支持。

### 功能要点

- **用户组成员查询功能**：根据用户组ID查询该用户组下的所有成员，支持按用户名、角色、状态等条件进行过滤，并提供分页功能以处理大量数据。查询结果包含成员的用户ID、用户名、真实姓名、邮箱、所属部门、角色信息以及在用户组中的加入时间和状态等详细信息，确保前端能够完整展示用户组成员的组织结构和权限分配情况。

### 逻辑签名

```naturalts path="app.logics.queryUserGroupMembers.ts"
$Logic({
    description: '查询用户组成员列表',
    directory: 'workflow_engine(工作流引擎)'
})
export declare function queryUserGroupMembers(userGroupId: String, username: String, roleName: String, status: app.enums.UserStatus, page: Integer, size: Integer): { list: List<{ user: app.dataSources.defaultDS.entities.SystemAccount, userGroup: app.dataSources.defaultDS.entities.UserGroup }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| userGroupId | 用户组ID | String | 要查询的用户组ID |
| username | 用户名 | String | 用户名过滤条件 |
| roleName | 角色名称 | String | 角色名称过滤条件 |
| status | 用户状态 | app.enums.UserStatus | 用户状态过滤条件 |
| page | 页码 | Integer | 分页查询的页码 |
| size | 每页条数 | Integer | 分页查询每页显示的条数 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 成员列表 | List<{ user: app.dataSources.defaultDS.entities.SystemAccount, userGroup: app.dataSources.defaultDS.entities.UserGroup }> | 用户组成员列表，包含用户信息和用户组信息 |
| total | 总条数 | Integer | 符合条件的总成员数量 |

### 被前端调用

- **用户和组管理（userGroupManagement）**：在用户组详情页面中，通过调用此服务端逻辑获取用户组的成员列表，用于展示当前用户组的所有成员信息，并支持管理员对成员进行管理操作，如添加新成员、移除现有成员或修改成员角色。

### 依赖的枚举、实体

- **数据建模-枚举-用户状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-用户组**：[系统管理-实体-用户组（UserGroup）](specs/001-bootdo-management-system/plan/data-model/entity-UserGroup.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力