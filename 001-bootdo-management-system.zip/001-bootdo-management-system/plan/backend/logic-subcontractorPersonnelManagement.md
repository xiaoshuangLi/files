# 分包商管理-分包商人员管理（subcontractorPersonnelManagement）

- **生成时间**：2026-03-25

## 分包商人员管理（subcontractorPersonnelManagement）

### 功能概述

分包商人员管理服务端逻辑是分包商管理模块的核心功能之一，专门用于对分包商的人员配置信息进行全生命周期管理。该逻辑支持对分包商人员的增删改查操作，包括员工姓名、职位、联系信息、雇佣日期、终止日期等关键业务数据的维护。通过该服务端逻辑，系统能够确保分包商人员数据的完整性、一致性和准确性，为后续的薪资计算、项目分配和绩效评估等业务流程提供可靠的数据基础。该逻辑与分包商信息实体建立关联关系，确保每个人员记录都能准确对应到特定的分包商，并支持人员雇佣状态的有效性验证，防止业务数据异常。

### 功能要点

- **人员信息维护**：支持分包商人员基本信息的完整维护，包括员工姓名、职位、联系信息、雇佣日期和终止日期等字段的增删改查操作，确保人员配置数据的完整性和准确性，为薪资计算和项目分配提供基础数据支撑。
- **分包商关联管理**：实现人员与分包商的关联关系管理，确保每个人员记录都归属于特定的分包商，支持按分包商ID查询对应的人员列表，便于分包商维度的人员信息管理和统计分析。
- **雇佣状态验证**：在人员信息保存时自动验证雇佣状态的有效性，确保终止日期不能早于雇佣日期，防止业务逻辑错误，保证人员配置数据的合理性和一致性。
- **数据完整性保障**：强制要求员工姓名和分包商ID等关键字段的非空约束，确保人员配置数据的基本完整性，避免因关键信息缺失导致的业务处理异常。

### 逻辑签名

```naturalts path="app.logics.subcontractorPersonnelManagement.ts"
$Logic({
    description: '分包商人员管理',
    directory: 'subcontractor_management(分包商管理)'
})
export declare function subcontractorPersonnelManagement(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.PersonnelConfiguration): { list: List<app.dataSources.defaultDS.entities.PersonnelConfiguration>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 分页查询的页码 |
| size | 每页条数 | Integer | 分页查询的每页记录数 |
| sort | 排序字段 | String | 排序的字段名称 |
| order | 排序顺序 | String | 排序顺序，升序或降序 |
| filter | 过滤条件 | app.dataSources.defaultDS.entities.PersonnelConfiguration | 人员配置实体作为过滤条件 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 人员列表 | List<app.dataSources.defaultDS.entities.PersonnelConfiguration> | 分包商人员配置实体列表 |
| total | 总条数 | Integer | 符合条件的总记录数 |

### 被前端调用

- **人员管理（personnelConfiguration）**：人员管理页面使用此服务端逻辑来加载分包商的人员列表，支持分页、排序和过滤功能，实现对分包商人员信息的全面管理。

### 依赖的枚举、实体

- **数据建模-实体-人员配置**：[分包商管理-实体-人员配置（PersonnelConfiguration）](specs/001-bootdo-management-system/plan/data-model/entity-PersonnelConfiguration.md)
- **数据建模-实体-分包商信息**：[分包商管理-实体-分包商信息（SubcontractorInformation）](specs/001-bootdo-management-system/plan/data-model/entity-SubcontractorInformation.md)

### 依赖的外部能力

无外部能力依赖