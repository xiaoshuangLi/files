# 办公自动化-管理个人日程（managePersonalSchedule）

- **生成时间**：2026-03-25

## 管理个人日程（managePersonalSchedule）

### 功能概述

管理个人日程服务端逻辑为用户提供完整的个人日程管理功能，包括创建、编辑、查询、删除和共享日程事件的能力。该逻辑支持处理精确到分钟的时间范围日程以及全天事件，并允许用户为日程设置详细的描述信息和提醒配置。系统确保每个日程都正确关联到其所有者账户，并提供灵活的查询筛选功能，支持按时间范围、日程标题等条件进行过滤。同时，该逻辑还支持日程的共享功能，允许用户将个人日程分享给团队成员或部门，促进团队协作和时间协调。通过与通知提醒系统的集成，该逻辑能够在日程开始前自动触发提醒通知，帮助用户有效管理时间并避免错过重要事件。

### 功能要点

- **日程创建与编辑功能**：支持用户创建新的日程事件，包括设置日程标题（必填）、描述、开始时间（必填）、结束时间（必填）、是否为全天事件（必填）等核心属性。同时支持对现有日程进行编辑修改，系统会验证时间范围的有效性（结束时间必须晚于开始时间），并确保所有必填字段都已正确填写。创建和编辑操作都会记录完整的审计信息，包括创建人、创建时间、更新人和更新时间。

- **日程查询与筛选功能**：提供灵活的日程查询接口，支持按所有者ID、时间范围（开始时间和结束时间）、日程标题关键词、是否全天事件等多个维度进行组合筛选。查询结果支持分页返回，避免一次性加载过多数据导致性能问题。系统还支持按日程类型（个人日程或共享日程）进行分类查询，满足不同场景下的数据展示需求。

- **日程删除与状态管理**：支持安全删除日程事件，删除操作会进行权限验证，确保只有日程所有者或具有相应权限的管理员才能执行删除操作。删除前系统会检查是否存在相关的依赖数据（如提醒设置、共享关系等），并在必要时进行级联处理。同时，系统支持日程的状态管理，包括标记为已完成、取消等状态变更操作。

- **日程共享与协作功能**：支持将个人日程分享给指定的用户、用户组或部门，实现团队间的日程透明化和协作。共享设置包括共享权限级别（只读或可编辑）、共享有效期等配置选项。系统会维护完整的共享关系记录，并在查询共享日程时进行权限验证，确保数据安全性和隐私保护。

### 逻辑签名

```naturalts path="app.logics.managePersonalSchedule.ts"
$Logic({
    description: '管理个人日程',
    directory: 'office_automation(办公自动化)'
})
export declare function managePersonalSchedule(
    action: String,
    scheduleData: app.dataSources.defaultDS.entities.ScheduleArrangement,
    shareSettings?: { 
        shareType: String, 
        targetIds: List<Integer>, 
        permissionLevel: String, 
        validUntil: DateTime 
    }
): { 
    success: Boolean, 
    resultMessage: String, 
    scheduleId: Integer,
    sharedWith: List<{ userId: Integer, permissionLevel: String }> 
};
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| action | 操作类型 | String | 执行的操作类型，如'create'、'update'、'delete'、'share'等 |
| scheduleData | 日程数据 | app.dataSources.defaultDS.entities.ScheduleArrangement | 完整的日程安排实体数据，包含所有必要的字段信息 |
| shareSettings | 共享设置 | { shareType: String, targetIds: List<Integer>, permissionLevel: String, validUntil: DateTime } | 可选的共享配置参数，仅在执行共享操作时需要提供 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| success | 操作成功标志 | Boolean | 标识操作是否成功执行 |
| resultMessage | 操作结果消息 | String | 操作结果的详细描述信息，包括成功或失败的具体原因 |
| scheduleId | 日程ID | Integer | 操作涉及的日程记录ID，用于后续引用或查询 |
| sharedWith | 共享对象列表 | List<{ userId: Integer, permissionLevel: String }> | 日程共享的对象列表及其对应的权限级别 |

### 被前端调用

- **日程管理（scheduleArrangement）**：日程管理页面通过调用此服务端逻辑实现个人日程的完整管理功能。当用户执行创建、编辑、删除日程操作时，前端传递相应的操作类型和日程数据；当用户设置日程共享时，前端额外传递共享配置参数。该逻辑为日程管理页面提供了统一的数据操作接口，简化了前端的业务逻辑处理。

### 依赖的枚举、实体

- **数据建模-实体-日程安排**：[办公自动化-实体-日程安排（ScheduleArrangement）](specs/001-bootdo-management-system/plan/data-model/entity-ScheduleArrangement.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无