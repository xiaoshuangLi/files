# 分包商管理-创建分包商资质证书（createSubcontractorQualificationCertificate）

- **生成时间**：2026-03-25

## 创建分包商资质证书（createSubcontractorQualificationCertificate）

### 功能概述

该服务端逻辑用于创建分包商的资质证书信息，支持对分包商各类专业资质、许可证、认证证书等进行数字化管理。系统允许管理员或相关部门人员录入分包商的资质证书详细信息，包括证书名称、证书编号、发证机构、有效期限、资质等级等关键属性，并与对应的分包商信息进行关联绑定，确保资质信息的准确性和可追溯性。

### 功能要点

- **资质证书信息录入**：提供完整的资质证书信息录入功能，包括证书的基本信息（名称、编号）、发证详情（发证机构、发证日期）、有效期管理（开始日期、结束日期）、资质等级分类等核心字段，确保能够全面记录分包商的各类资质证明文件信息，为后续的资质审核和合规检查提供数据基础。

### 逻辑签名

```naturalts path="app.logics.createSubcontractorQualificationCertificate.ts"
$Logic({
    description: '创建分包商资质证书',
    directory: 'subcontractor_management(分包商管理)',
    transactional: true
})
export declare function createSubcontractorQualificationCertificate(qualificationCertificate: app.dataSources.defaultDS.entities.QualificationCertificate): app.dataSources.defaultDS.entities.QualificationCertificate;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| qualificationCertificate | 资质证书信息 | app.dataSources.defaultDS.entities.QualificationCertificate | 包含分包商ID、证书名称、证书编号、颁发机构、颁发日期、过期日期等完整资质证书信息 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 创建结果 | app.dataSources.defaultDS.entities.QualificationCertificate | 补充了id的资质证书实体 |

### 被前端调用

- **资质管理（qualificationCertificate）**：在资质管理页面中，通过该服务端逻辑实现新增资质证书的功能，用户可以为选定的分包商添加各类专业资质证书信息，完善分包商的资质档案。

### 依赖的枚举、实体

- **数据建模-实体-分包商信息**：[分包商管理-实体-分包商信息（SubcontractorInformation）](specs/001-bootdo-management-system/plan/data-model/entity-SubcontractorInformation.md)
- **数据建模-实体-资质证书**：[分包商管理-实体-资质证书（QualificationCertificate）](specs/001-bootdo-management-system/plan/data-model/entity-QualificationCertificate.md)

### 依赖的外部能力

无