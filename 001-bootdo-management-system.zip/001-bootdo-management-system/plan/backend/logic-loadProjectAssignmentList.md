# 分包商管理-加载项目分配列表（loadProjectAssignmentList）

- **生成时间**：2026-03-25

## 加载项目分配列表（loadProjectAssignmentList）

### 功能概述

加载项目分配列表服务端逻辑用于分页查询系统中的项目分配记录，支持按项目名称、分包商信息、分配时间范围等条件进行过滤，并支持按指定字段和顺序进行排序。该逻辑返回符合条件的项目分配列表及其总数，每条记录包含完整的项目分配信息以及关联的分包商详细信息。此服务为前端项目分配管理页面提供数据支撑，使用户能够高效地浏览、筛选和管理分包商的项目分配情况，确保项目资源的合理分配和跟踪。

### 功能要点

- **分页查询与排序功能**：支持标准的分页查询机制，通过page和size参数控制返回结果的页码和每页条数，避免一次性加载过多数据导致性能问题。系统默认每页显示20条记录，但允许前端根据实际需求调整每页显示数量。同时支持按任意字段（如分配时间、完成期限、项目名称等）进行升序或降序排序，确保返回的项目分配列表按照用户期望的顺序排列，满足不同场景下的数据浏览需求。
- **多条件过滤功能**：提供基于项目分配实体(ProjectAssignment)的完整筛选能力，支持按项目名称模糊匹配、分包商ID精确匹配、分配时间范围、完成期限范围等多个维度进行组合查询。用户可以根据实际业务需求灵活设置查询条件，快速定位到关注的项目分配记录，提高数据查询的精准度和效率。
- **关联数据加载**：在返回项目分配列表的同时，自动加载关联的分包商信息(SubcontractorInformation)的详细数据，包括公司名称、联系人、联系电话等关键字段。这种关联查询减少了前端的多次请求开销，提供了完整的上下文信息，便于用户在项目分配列表中直接查看分包商的基本情况，提升用户体验和工作效率。

### 逻辑签名

```naturalts path="app.logics.loadProjectAssignmentList.ts"
$Logic({
    description: '分页查询项目分配列表',
    directory: 'subcontractor_management(分包商管理)'
})
export declare function loadProjectAssignmentList(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.ProjectAssignment): { list: List<{ projectAssignment: app.dataSources.defaultDS.entities.ProjectAssignment, subcontractor: app.dataSources.defaultDS.entities.SubcontractorInformation }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 查询的页码，从1开始计数 |
| size | 每页条数 | Integer | 每页返回的记录数量，建议范围1-100 |
| sort | 排序字段 | String | 排序的字段名，如"assignedAt"、"projectName"等 |
| order | 排序顺序 | String | 排序方向，"ascending"表示升序，"descending"表示降序 |
| filter | 过滤条件 | app.dataSources.defaultDS.entities.ProjectAssignment | 项目分配实体作为过滤条件，支持各字段的精确匹配或模糊匹配 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 项目分配列表 | List<{ projectAssignment: app.dataSources.defaultDS.entities.ProjectAssignment, subcontractor: app.dataSources.defaultDS.entities.SubcontractorInformation }> | 项目分配列表，每个列表项包含项目分配实体及其关联的分包商信息 |
| total | 总条数 | Integer | 符合筛选条件的总记录数，用于分页计算 |

### 被前端调用

- **项目分配（projectAssignment）**：项目分配管理页面使用此服务端逻辑加载项目分配列表数据，支持用户进行分页浏览、条件筛选、排序等操作。页面通过分页、筛选和排序参数调用此接口，获取符合业务需求的项目分配数据，并在表格中展示项目名称、关联分包商、分配时间、完成期限等关键信息，为项目分配的管理和跟踪提供完整的数据支持。

### 依赖的枚举、实体

- **数据建模-实体-项目分配**：[分包商管理-实体-项目分配（ProjectAssignment）](specs/001-bootdo-management-system/plan/data-model/entity-ProjectAssignment.md)
- **数据建模-实体-分包商信息**：[分包商管理-实体-分包商信息（SubcontractorInformation）](specs/001-bootdo-management-system/plan/data-model/entity-SubcontractorInformation.md)

### 依赖的外部能力

无匹配内容

