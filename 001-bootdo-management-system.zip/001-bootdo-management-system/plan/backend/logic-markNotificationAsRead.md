# 通用领域服务-标记通知为已读（markNotificationAsRead）

- **生成时间**：2026-03-25

## 标记通知为已读（markNotificationAsRead）

### 功能概述

标记通知为已读服务端逻辑用于将用户的通知公告标记为已读状态，支持单个或批量操作。该逻辑通过通知ID列表作为输入参数，更新对应通知记录的已读状态，并记录操作时间和操作人信息。此功能是通知公告模块的核心交互功能之一，确保用户能够有效管理自己的通知列表，区分已读和未读通知，提升信息处理效率。系统会验证当前用户对通知的访问权限，确保只能标记属于自己的通知为已读状态。

### 功能要点

- **通知状态更新**：根据提供的通知ID列表，系统将对应的通知公告记录的已读状态更新为true，并记录更新时间戳和操作用户ID。该功能支持单个通知或批量通知的状态更新，提高用户操作效率。系统会验证每个通知ID的有效性，并确保当前用户有权访问这些通知，防止越权操作导致的数据安全问题。

### 逻辑签名

```naturalts path="app.logics.markNotificationAsRead.ts"
$Logic({
    description: '标记通知为已读',
    directory: 'general_domain_service(通用领域服务)'
})
export declare function markNotificationAsRead(notificationIds: List<Integer>): { success: Boolean, message: String };
```

### 被前端调用

- **通知公告（noticeAnnouncement）**：在通知公告页面中，当用户点击通知列表中的"标记为已读"按钮或执行批量标记操作时，前端会调用此服务端逻辑，传入需要标记的通知ID列表。该逻辑执行后会更新通知状态，并在前端界面中实时反映已读状态的变化，帮助用户有效管理通知信息。

### 依赖的枚举、实体

- **数据建模-实体-通知公告**：[办公自动化-实体-通知公告（NoticeAnnouncement）](specs/001-bootdo-management-system/plan/data-model/entity-NoticeAnnouncement.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无匹配内容

