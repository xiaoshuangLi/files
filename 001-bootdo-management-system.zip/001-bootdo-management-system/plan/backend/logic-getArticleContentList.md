# 内容管理-获取文章内容列表（getArticleContentList）

- **生成时间**：2026-03-25

## 获取文章内容列表（getArticleContentList）

### 功能概述

获取文章内容列表服务端逻辑提供内容管理系统中文章数据的查询功能，支持按多种条件进行筛选、分页和排序。该逻辑允许前端页面根据用户需求动态获取文章列表，包括按文章状态（草稿、待审核、已发布、已归档）、作者、标题关键词、创建时间范围等条件进行过滤。系统会返回包含文章基本信息的分页结果集，每条记录包含文章ID、标题、作者、状态、创建时间、更新时间等关键字段，同时支持关联查询作者详细信息。该逻辑还实现了权限控制，确保用户只能查看其有权限访问的文章内容，满足内容管理系统的安全性和灵活性需求。

### 功能要点

- **分页查询与性能优化**：实现高效的分页查询机制，支持大数量级文章数据的快速检索，通过数据库索引优化和查询条件预处理，确保在高并发场景下仍能保持良好的响应性能。系统采用游标分页或偏移分页策略，避免深度分页带来的性能问题，并对查询结果进行缓存以提高重复查询的效率。
- **多维度筛选条件**：支持丰富的筛选条件组合，包括文章状态（ArticleStatusEnum）、作者ID、标题模糊匹配、创建时间范围、更新时间范围等。用户可以根据业务需求灵活组合这些条件，精确获取所需的文章列表。系统会对输入参数进行严格校验，防止SQL注入等安全风险，并对无效参数进行友好处理。
- **权限控制与数据隔离**：实现细粒度的权限控制机制，确保不同角色的用户只能访问其权限范围内的文章数据。系统管理员可以查看所有文章，部门管理员只能查看本部门用户创建的文章，普通用户只能查看自己创建的文章以及已发布的公开文章。这种数据隔离机制保障了内容管理系统的安全性和数据隐私。

### 逻辑签名

```naturalts path="app.logics.getArticleContentList.ts"
$Logic({
    description: '获取文章内容列表',
    directory: 'content_management(内容管理)'
})
export declare function getArticleContentList(
    page: Integer,
    size: Integer,
    sort: String,
    order: String,
    status?: app.enums.ArticleStatusEnum,
    authorId?: Integer,
    titleKeyword?: String,
    createdTimeStart?: DateTime,
    createdTimeEnd?: DateTime
): { list: List<app.dataSources.defaultDS.entities.ArticleContent>, total: Integer };
```

### 被前端调用

- **文章管理（articleManagement）**：在文章管理页面中，通过调用此服务端逻辑获取文章列表数据，支持用户按状态、作者、标题等条件筛选文章，并实现分页展示。该页面使用此逻辑来加载初始文章列表以及处理用户的筛选和分页操作。
- **文章管理（articleContent）**：在文章内容管理页面中，调用此服务端逻辑获取特定条件下的文章列表，用于展示用户可编辑或审核的文章内容。该页面利用此逻辑实现文章的批量管理和状态跟踪功能。

### 依赖的枚举、实体

- **数据建模-枚举-文章状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-文章内容**：[内容管理-实体-文章内容（ArticleContent）](specs/001-bootdo-management-system/plan/data-model/entity-ArticleContent.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无