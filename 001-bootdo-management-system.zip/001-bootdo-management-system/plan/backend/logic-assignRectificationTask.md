# 质量管理-分配整改任务（assignRectificationTask）

- **生成时间**：2026-03-25

## 分配整改任务（assignRectificationTask）

### 功能概述

分配整改任务服务端逻辑是质量管理模块的核心业务功能，专门用于处理质量问题的整改任务分配操作。该逻辑接收包含质量问题ID、分配用户ID、整改措施描述等关键信息的输入参数，创建并保存新的整改任务记录到系统中。通过该逻辑，质量管理员能够将发现的质量问题系统化地分配给指定的责任人进行处理，确保每个质量问题都有明确的整改责任人和具体的整改措施。该逻辑还负责设置任务的初始状态为"待处理"，记录任务分配时间，并与相关联的质量问题实体建立关联关系，为后续的整改进度跟踪和任务状态更新提供基础数据支持。

### 功能要点

- **整改任务创建与分配**：该功能要点实现了整改任务的完整创建和分配流程。当质量管理员在前端页面提交整改任务分配表单时，系统调用此服务端逻辑，将表单中的质量问题ID、分配用户ID、整改措施描述等信息封装成整改任务实体对象。逻辑会验证输入参数的有效性，确保质量问题ID和分配用户ID对应的数据在系统中存在，然后创建新的整改任务记录，设置任务状态为"待处理"(Pending)，记录当前时间为分配时间，并将任务与指定的质量问题关联。这一过程确保了整改任务的规范化创建和准确分配，为质量问题的闭环管理奠定了基础。

### 逻辑签名

```naturalts path="app.logics.assignRectificationTask.ts"
$Logic({
    description: '分配整改任务',
    directory: 'quality_management(质量管理)',
    transactional: true
})
export declare function assignRectificationTask(qualityIssueId: Integer, assigneeId: Integer, description: String): app.dataSources.defaultDS.entities.RectificationTask;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| qualityIssueId | 质量问题ID | Integer | 关联的质量问题主键ID，必须对应系统中已存在的质量问题记录 |
| assigneeId | 分配用户ID | Integer | 负责执行整改的用户ID，必须对应系统中已存在的系统账户 |
| description | 整改措施 | String | 具体的整改方案和措施描述，不能为空 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 创建结果 | app.dataSources.defaultDS.entities.RectificationTask | 成功创建的整改任务实体，包含完整的任务信息和自动生成的主键ID |

### 被前端调用

- **整改任务分配（rectificationTaskAssignment）**：该功能页面使用分配整改任务服务端逻辑来创建新的整改任务分配记录。当质量管理员在整改任务分配页面填写完关联质量问题、分配人、整改措施等信息并点击保存按钮时，前端会调用此服务端逻辑，传入相应的参数完成整改任务的创建和分配。
- **整改任务分配（rectificationTask）**：该功能页面在创建新的整改任务时使用分配整改任务服务端逻辑。当质量管理员在整改输入界面填写完整改任务的基本信息并点击提交按钮时，前端会调用此服务端逻辑，将整改描述、分配人员等信息传递给后端，完成整改任务的创建。

### 依赖的枚举、实体

- **数据建模-枚举-任务状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-整改任务**：[质量管理-实体-整改任务（RectificationTask）](specs/001-bootdo-management-system/plan/data-model/entity-RectificationTask.md)
- **数据建模-实体-质量问题**：[质量管理-实体-质量问题（QualityIssue）](specs/001-bootdo-management-system/plan/data-model/entity-QualityIssue.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无外部能力依赖。分配整改任务服务端逻辑完全基于系统内部的实体和枚举实现，不依赖任何外部系统或第三方服务。