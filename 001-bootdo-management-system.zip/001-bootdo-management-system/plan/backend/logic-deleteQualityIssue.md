# 质量管理-删除质量问题（deleteQualityIssue）

- **生成时间**：2026-03-25

## 删除质量问题（deleteQualityIssue）

### 功能概述

该服务端逻辑用于处理系统中已登记的质量问题的删除操作。当质量问题被错误登记或不再需要跟踪时，授权用户可以通过此功能将其从系统中永久移除。删除操作会同时清理与该质量问题关联的所有整改任务、检验记录和跟踪信息，确保数据一致性。系统会在执行删除前验证用户权限，并记录操作日志以满足审计要求。此功能对于维护质量管理模块的数据准确性和系统性能至关重要，避免无效数据积累影响系统运行效率和决策分析准确性。

### 功能要点

- **权限验证与安全删除**：在执行删除操作前，系统会严格验证当前用户是否具有删除质量问题的权限。只有系统管理员、部门管理员或质量问题的创建者才能执行删除操作。删除过程采用软删除机制，先标记记录状态再进行物理删除，确保数据安全。同时，系统会检查质量问题是否已被关联到其他业务流程中，如存在关联则提示用户先解除关联再执行删除，防止数据不一致。

### 逻辑签名

```naturalts path="app.logics.deleteQualityIssue.ts"
$Logic({
    description: '删除质量问题',
    directory: 'quality_management(质量管理)'
})
export declare function deleteQualityIssue(qualityIssueId: Integer, operatorId: String): Boolean;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| qualityIssueId | 质量问题ID | Integer | 要删除的质量问题的唯一标识符 |
| operatorId | 操作人ID | String | 执行删除操作的用户ID |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 删除结果 | Boolean | 删除操作是否成功，true表示成功，false表示失败 |

### 被前端调用

- **通用业务模块-质量问题登记（qualityIssue）**：在质量问题列表页面，用户可以选择特定的质量问题并执行删除操作。该功能页面通过调用deleteQualityIssue服务端逻辑，实现对选中质量问题的安全删除，并在删除成功后刷新列表显示，确保用户界面与数据状态同步。

### 依赖的枚举、实体

- **数据建模-实体-质量问题**：[质量管理-实体-质量问题（QualityIssue）](specs/001-bootdo-management-system/plan/data-model/entity-QualityIssue.md)
- **数据建模-实体-整改任务**：[质量管理-实体-整改任务（RectificationTask）](specs/001-bootdo-management-system/plan/data-model/entity-RectificationTask.md)
- **数据建模-实体-质量检验**：[质量管理-实体-质量检验（QualityInspection）](specs/001-bootdo-management-system/plan/data-model/entity-QualityInspection.md)

### 依赖的外部能力

[文件内部已经提供，无需进行生成。如果文件内部已经有 `依赖的外部能力` 内容，禁止修改或删除文件内的 `依赖的外部能力` 内容]