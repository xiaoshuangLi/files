# 环保管理-获取合规检查列表（getComplianceInspectionList）

- **生成时间**：2026-03-25

## 获取合规检查列表（getComplianceInspectionList）

### 功能概述

获取合规检查列表服务端逻辑用于查询和筛选环保法规合规检查记录，支持分页、排序和多条件筛选功能。该逻辑根据前端传递的查询参数（如检查员ID、检查时间范围、合规状态等）从数据库中检索符合条件的合规检查记录，并以分页形式返回结果。每次查询都会返回合规检查的基本信息，包括检查员信息、检查发现描述、合规状态、检查时间和解决时间等关键字段。该服务端逻辑是合规检查管理功能的核心数据支撑，为前端提供高效、准确的数据查询能力，确保环保管理人员能够快速定位和查看特定条件下的合规检查记录。

### 功能要点

- **多条件筛选功能**：支持根据检查员ID、检查时间范围（开始时间和结束时间）、合规状态等多种条件进行组合筛选，帮助用户精准定位所需的合规检查记录。系统会根据传入的筛选条件动态构建查询语句，确保查询结果的准确性和相关性，同时优化查询性能避免全表扫描。
- **分页与排序功能**：提供标准的分页查询支持，包括当前页码、每页记录数等参数，并支持按检查时间、创建时间等字段进行升序或降序排序。分页机制有效控制单次查询的数据量，提升系统响应速度和用户体验，特别适用于合规检查记录数量庞大的场景。
- **关联数据加载**：在返回合规检查列表的同时，自动关联加载检查员的详细信息（如姓名、部门等），避免前端多次请求获取关联数据。这种预加载机制减少了网络请求次数，提高了页面加载效率，为用户提供更流畅的操作体验。

### 逻辑签名

```naturalts path="app.logics.getComplianceInspectionList.ts"
$Logic({
    description: '获取合规检查列表',
    directory: 'environmental_management(环保管理)'
})
export declare function getComplianceInspectionList(page: Integer, size: Integer, sort: String, order: String, inspectorId: Integer, inspectedAfter: DateTime, inspectedBefore: DateTime, status: app.enums.ComplianceStatusEnum): { list: List<{ complianceInspection: app.dataSources.defaultDS.entities.ComplianceInspection, inspector: app.dataSources.defaultDS.entities.SystemAccount }>, total: Integer };
```

### 被前端调用

- **合规检查（complianceInspection）**：在合规检查功能页面的列表展示区域，通过调用此服务端逻辑获取分页的合规检查数据，支持用户按检查员、检查时间范围、合规状态等条件进行筛选查询，并在表格中展示检查结果。

### 依赖的枚举、实体

- **数据建模-枚举-环保合规状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-合规检查**：[环保管理-实体-合规检查（ComplianceInspection）](specs/001-bootdo-management-system/plan/data-model/entity-ComplianceInspection.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无