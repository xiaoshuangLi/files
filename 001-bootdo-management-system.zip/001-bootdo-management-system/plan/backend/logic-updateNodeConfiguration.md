# 工作流引擎-更新节点配置（updateNodeConfiguration）

- **生成时间**：2026-03-25

## 更新节点配置（updateNodeConfiguration）

### 功能概述

更新节点配置服务端逻辑是工作流引擎模块的核心功能之一，负责处理系统管理员对工作流任务节点配置参数的修改请求。该逻辑接收包含节点ID和新配置属性的输入数据，验证数据的有效性和权限，然后更新数据库中对应的节点配置记录。此功能支持动态调整工作流节点的行为特性，包括节点处理规则、表单字段映射、审批条件、通知设置等关键参数，确保工作流能够按照最新的业务需求执行。通过此逻辑，系统实现了工作流节点配置的灵活管理，无需修改底层代码即可适应不断变化的业务流程需求，大大提升了系统的可维护性和适应性。

### 功能要点

- **节点配置更新**：系统管理员可以通过此逻辑更新工作流任务节点的具体配置参数。逻辑接收包含taskId（任务节点ID）和nodeProperties（节点属性JSON字符串）的输入数据，首先验证当前用户是否具有更新权限，然后检查taskId对应的节点是否存在，接着验证nodeProperties的格式和内容是否符合预定义的配置规范。验证通过后，逻辑将更新NodeConfiguration实体中的相关字段，包括nodeProperties、configuredAt（配置时间）、updatedTime（更新时间）和updatedBy（更新人），确保配置变更被正确记录并生效。

### 逻辑签名

```naturalts path="app.logics.updateNodeConfiguration.ts"
$Logic({
    description: "更新工作流任务节点的配置参数",
    directory: "workflow_engine(工作流引擎)"
})
export declare function updateNodeConfiguration(
    taskId: Integer,
    nodeProperties: String
): {
    id: Integer;
    taskId: Integer;
    nodeProperties: String;
    configuredAt: DateTime;
    updatedTime: DateTime;
    updatedBy: String;
};
```

### 被前端调用

- **节点配置（nodeConfiguration）**：在节点配置编辑页面，系统管理员完成节点属性修改后点击保存按钮，前端调用此服务端逻辑提交更新请求，将修改后的节点配置参数保存到系统中，实现工作流节点行为的动态调整。

### 依赖的枚举、实体

- **数据建模-实体-节点配置**：[工作流引擎-实体-节点配置（NodeConfiguration）](specs/001-bootdo-management-system/plan/data-model/entity-NodeConfiguration.md)
- **数据建模-实体-任务节点**：[工作流引擎-实体-任务节点（TaskNode）](specs/001-bootdo-management-system/plan/data-model/entity-TaskNode.md)

### 依赖的外部能力

无匹配内容

