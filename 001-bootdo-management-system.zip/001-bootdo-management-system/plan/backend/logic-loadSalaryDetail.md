# 薪资管理-加载薪资详情（loadSalaryDetail）

- **生成时间**：2026-03-25

## 加载薪资详情（loadSalaryDetail）

### 功能概述

加载薪资详情服务端逻辑用于根据月工资额ID查询并返回完整的薪资详细信息，包括员工基本信息、薪资结构组成、税前税后金额、支付月份等核心数据。该逻辑是薪资报表和薪资管理页面的数据支撑接口，确保用户能够查看特定薪资记录的完整详情。通过关联查询系统账户、薪资结构等关联实体，该逻辑提供了一个包含所有必要上下文信息的完整数据视图，支持前端展示薪资详情的全部内容，并为薪资审核、导出等后续操作提供基础数据。

### 功能要点

- **薪资详情查询**：根据提供的月工资额ID，从数据库中精确查询对应的薪资记录。该功能点确保系统能够准确获取指定ID的薪资数据，避免数据混淆或错误。查询过程需要验证ID的有效性，并处理不存在记录的情况，保证系统的健壮性和用户体验的一致性。
- **关联数据加载**：在返回薪资详情的同时，自动加载关联的员工账户信息（SystemAccount）和薪资结构信息（SalaryStructure），包括员工姓名、部门、岗位以及基本工资、奖金、津贴等薪资组成部分。这种关联查询减少了前端的多次请求，提高了数据展示的完整性和用户体验。
- **薪资计算明细展示**：返回的数据包含完整的薪资计算明细，包括税前金额（grossAmount）、税后金额（netAmount）、支付月份（paymentMonth）等关键字段，确保薪资详情页面能够清晰展示薪资构成和计算结果，满足财务审计和员工查询的需求.

### 逻辑签名

```naturalts path="app.logics.loadSalaryDetail.ts"
$Logic({
    description: '加载薪资详情',
    directory: 'salary_management(薪资管理)'
})
export declare function loadSalaryDetail(id: Integer): { 
  monthlySalaryAmount: app.dataSources.defaultDS.entities.MonthlySalaryAmount, 
  employee: app.dataSources.defaultDS.entities.SystemAccount,
  salaryStructure: app.dataSources.defaultDS.entities.SalaryStructure 
};
```

### 被前端调用

- **薪资报表（salaryReport）**：在薪资报表详情页面中，当用户点击某条薪资记录时，前端调用此服务端逻辑获取完整的薪资详情数据，用于展示员工的薪资构成明细，包括基本工资、奖金、津贴、税前金额、税后金额等详细信息.

### 依赖的枚举、实体

- **数据建模-实体-月工资额**：[薪资管理-实体-月工资额（MonthlySalaryAmount）](specs/001-bootdo-management-system/plan/data-model/entity-MonthlySalaryAmount.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)
- **数据建模-实体-薪资结构**：[薪资管理-实体-薪资结构（SalaryStructure）](specs/001-bootdo-management-system/plan/data-model/entity-SalaryStructure.md)

### 依赖的外部能力

无匹配内容

