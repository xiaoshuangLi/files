# 环保管理-创建合规检查（createComplianceInspection）

- **生成时间**：2026-03-25

## 创建合规检查（createComplianceInspection）

### 功能概述

该服务端逻辑用于创建环保法规合规检查记录，支持用户录入检查基本信息、关联环境监测数据、记录排放控制情况，并生成合规检查报告。系统会自动验证检查数据的完整性，确保符合环保法规要求，并将检查结果与相关整改措施关联，形成完整的环保合规管理闭环。

### 功能要点

- **合规检查创建与验证**：系统提供创建合规检查的完整功能，包括检查日期、检查类型、检查人员、被检查单位等基本信息录入。同时，系统会自动验证检查数据的完整性，确保必填字段不为空，并对检查结果进行合规性验证，确保符合国家和地方环保法规要求。检查完成后，系统自动生成唯一的合规检查编号，并记录创建时间和创建人信息，保证检查记录的可追溯性。

### 逻辑签名

```naturalts path="app.logics.createComplianceInspection.ts"
$Logic({
    description: '创建环保法规合规检查记录',
    directory: 'environmental_management(环保管理)'
})
export declare function createComplianceInspection(
  inspectionDate: DateTime,
  inspectionType: String,
  inspector: String,
  inspectedUnit: String,
  monitoringData: List<app.dataSources.defaultDS.entities.EnvironmentalMonitoring>,
  emissionData: List<app.dataSources.defaultDS.entities.EmissionControl>,
  findings: List<String>
): String;
```

### 被前端调用

- **合规检查（complianceInspection）**：在合规检查页面中，用户可以通过表单填写合规检查的各项信息，包括检查日期、类型、人员、被检查单位等基本信息，以及关联的环境监测数据和排放控制数据。提交表单时，前端调用此服务端逻辑创建合规检查记录，并在成功后显示检查编号和创建结果。

### 依赖的枚举、实体

- **数据建模-实体-环境监测**：[环保管理-实体-环境监测（EnvironmentalMonitoring）](specs/001-bootdo-management-system/plan/data-model/entity-EnvironmentalMonitoring.md)
- **数据建模-实体-排放控制**：[环保管理-实体-排放控制（EmissionControl）](specs/001-bootdo-management-system/plan/data-model/entity-EmissionControl.md)

### 依赖的外部能力

[文件内部已经提供，无需进行生成。如果文件内部已经有 `依赖的外部能力` 内容，禁止修改或删除文件内的 `依赖的外部能力` 内容]