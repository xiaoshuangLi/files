# 工作流引擎-获取表单集成列表（getFormIntegrationList）

- **生成时间**：2026-03-25

## 获取表单集成列表（getFormIntegrationList）

### 功能概述

该服务端逻辑用于获取系统中所有已配置的表单集成列表，支持分页查询和条件筛选。表单集成是工作流引擎与业务表单之间的桥梁，通过该接口可以获取到所有可用的表单集成配置信息，包括表单名称、关联流程、数据映射关系等关键信息，为工作流表单管理提供数据支撑。

### 功能要点

- **表单集成数据查询**：根据分页参数（页码、每页数量）和可选的筛选条件（如表单名称、关联流程ID等），从数据库中查询符合条件的表单集成记录，并返回完整的分页结果集，包含总记录数、当前页数据等信息，确保前端能够正确展示和处理分页数据。

### 逻辑签名

```naturalts path="app.logics.getFormIntegrationList.ts"
$Logic({
    description: '获取表单集成列表',
    directory: 'workflow_engine(工作流引擎)'
})
export declare function getFormIntegrationList(page: Integer, size: Integer, formName?: String, processId?: String): { list: List<app.dataSources.defaultDS.entities.FormIntegration>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 当前页码，从1开始 |
| size | 每页条数 | Integer | 每页记录数 |
| formName | 表单名称 | String | 表单名称筛选条件（可选） |
| processId | 关联流程ID | String | 关联流程ID筛选条件（可选） |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 表单集成列表 | List<app.dataSources.defaultDS.entities.FormIntegration> | 当前页数据列表 |
| total | 总记录数 | Integer | 总记录数 |

### 被前端调用

- **表单集成（formIntegration）**：在表单集成功能页面中，通过调用此服务端逻辑获取所有表单集成的列表数据，用于展示表单集成的配置信息，并支持用户进行筛选、分页查看等操作。

### 依赖的枚举、实体

- **数据建模-实体-表单集成**：[工作流引擎-实体-表单集成（FormIntegration）](specs/001-bootdo-management-system/plan/data-model/entity-FormIntegration.md)
- **数据建模-实体-流程定义**：[工作流引擎-实体-流程定义（ProcessDefinition）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessDefinition.md)