# 薪资管理-验证薪资数据（validateSalary）

- **生成时间**：2026-03-25

## 验证薪资数据（validateSalary）

### 功能概述

验证薪资数据服务端逻辑负责对薪资调整申请中的各项数据进行完整性和准确性验证，确保提交的薪资信息符合系统业务规则和数据格式要求。该逻辑在薪资调整审批流程中扮演关键角色，通过严格的验证机制防止无效或错误的薪资数据进入审批流程。验证内容包括薪资金额的合理性检查（如调整后标准月工资额必须为正数且不超过系统设定的最大值）、学历字段的有效性验证（必须在预设选项范围内）、年薪总额与月工资额的逻辑一致性校验等。该服务还支持对编辑状态下的薪资申请进行增量验证，确保修改后的数据仍然符合业务规则，并为前端提供详细的验证错误信息，帮助用户快速定位和修正问题。

### 功能要点

- **薪资数据完整性验证**：验证薪资调整申请中的必填字段是否已完整填写，包括调整原因、调整后标准月工资额、学历、现行标准年薪总额等关键字段。系统会检查每个必填字段是否存在空值或仅包含空白字符的情况，确保提交的数据具有完整的业务信息。对于缺失必填字段的申请，系统将返回具体的字段名称和验证失败原因，指导用户补充完整信息。

- **薪资金额格式与范围验证**：对薪资调整申请中的数字字段进行严格的格式和范围验证，确保调整后标准月工资额、现行标准年薪总额等金额数据符合业务规则。验证内容包括：金额必须为正数、小数点后最多保留两位、不超过系统设定的最大值限制（如月工资额不超过100万元）。系统还会检查金额字段是否包含非法字符（如字母、特殊符号等），确保数据的纯净性和可计算性。

- **学历与岗位选项有效性验证**：验证学历和岗位字段的值是否在系统预设的有效选项范围内。学历选项包括博士、硕士、本科、大专、高中及以下；岗位选项包括管理岗、技术岗、销售岗、生产岗、行政岗。系统会严格比对用户输入的值与预设选项，防止因手动输入错误或恶意篡改导致的数据不一致问题，确保薪资调整申请的规范性和标准化。

- **薪资数据逻辑一致性验证**：验证薪资调整申请中各字段之间的逻辑关系是否合理，特别是月工资额与年薪总额的一致性。系统会检查现行标准年薪总额是否约等于调整后标准月工资额乘以12（允许一定的四舍五入误差），确保薪资数据的内部一致性。此外，还会验证调整原因的长度是否在允许范围内（最大500字符），以及各类文本字段是否包含敏感或不当内容。

### 逻辑签名

```naturalts path="app.logics.validateSalary.ts"
$Logic({
    description: '验证薪资调整申请数据的完整性和准确性',
    directory: 'salary_management(薪资管理)'
})
export declare function validateSalary(
  adjustmentReason: String,
  adjustedMonthlySalary: Decimal,
  educationLevel: String,
  currentAnnualSalary: Decimal,
  opinion?: String,
  monthlyIncrease?: Decimal,
  leadershipOpinion?: String,
  position?: String
): {
  isValid: Boolean;
  errors: List<{
    fieldName: String;
    errorMessage: String;
  }>;
};
```

### 被前端调用

- **薪资调整审批（salaryAdjustment）**：在薪资调整审批页面，当用户提交或编辑薪资调整申请时，前端会调用validateSalary逻辑对表单数据进行验证。该逻辑确保所有必填字段已填写、数字字段格式正确、选项字段值有效，并验证月工资额与年薪总额的逻辑一致性。验证结果会实时反馈给用户，指导其修正错误数据。

### 依赖的枚举、实体

- **数据建模-实体-薪资结构**：[薪资管理-实体-薪资结构（SalaryStructure）](specs/001-bootdo-management-system/plan/data-model/entity-SalaryStructure.md)
- **数据建模-实体-月工资额**：[薪资管理-实体-月工资额（MonthlySalaryAmount）](specs/001-bootdo-management-system/plan/data-model/entity-MonthlySalaryAmount.md)
- **数据建模-实体-税务计算**：[薪资管理-实体-税务计算（TaxCalculation）](specs/001-bootdo-management-system/plan/data-model/entity-TaxCalculation.md)

### 依赖的外部能力

无