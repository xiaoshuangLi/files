# 系统管理-查询字典列表（queryDictionaryList）

- **生成时间**：2026-03-25

## 查询字典列表（queryDictionaryList）

### 功能概述

查询字典列表服务端逻辑提供分页查询系统中数据字典记录的功能，支持按字典类型、标签名等条件进行过滤，并支持按指定字段和顺序进行排序。该逻辑返回符合条件的数据字典列表及其总数，用于在字典管理功能页面中展示所有可用的字典项，方便系统管理员进行数据字典的维护和管理。通过该逻辑，系统能够高效地检索和展示各类分类数据和配置项，确保数据字典服务为整个应用提供一致的数据引用标准。

### 功能要点

- **分页查询功能**：支持标准的分页查询机制，通过页码(page)和每页条数(size)参数控制返回结果的页码和每页条数，避免一次性加载过多数据导致性能问题。系统会根据传入的分页参数计算并返回对应页的数据以及总记录数，确保前端能够正确显示分页控件，默认每页显示10条记录。
- **多条件过滤功能**：支持按字典类型(dictType)、标签名(dictLabel)等多个条件组合过滤数据字典。用户可以通过字典类型精确匹配特定分类的字典项，通过标签名模糊匹配查找特定显示名称的字典项，提高字典查找的精准度和效率。
- **排序功能**：支持按任意字段（如创建时间、字典类型、标签名等）进行升序或降序排序，确保返回的数据字典列表按照用户期望的顺序排列。系统会根据传入的sort和order参数动态构建排序规则，默认按创建时间(createdTime)降序排列，确保最新的字典项优先显示。
- **字典数据结构**：返回的数据字典包含完整的字典信息，包括主键ID、字典类型、标签名、数据值、类型描述以及创建和更新的元数据信息。这些信息为前端提供了足够的数据来展示和管理数据字典项。

### 逻辑签名

```naturalts path="app.logics.queryDictionaryList.ts"
$Logic({
    description: '查询字典列表',
    directory: 'system_management(系统管理)'
})
export declare function queryDictionaryList(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.DataDictionary): { list: List<app.dataSources.defaultDS.entities.DataDictionary>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 查询的页码，从1开始 |
| size | 每页条数 | Integer | 每页返回的记录数 |
| sort | 排序字段 | String | 用于排序的字段名 |
| order | 排序顺序 | String | 排序顺序，'asc'表示升序，'desc'表示降序 |
| filter | 过滤条件 | app.dataSources.defaultDS.entities.DataDictionary | 数据字典过滤条件，支持字典类型、标签名等字段的过滤 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 字典列表 | List<app.dataSources.defaultDS.entities.DataDictionary> | 符合条件的数据字典列表 |
| total | 总条数 | Integer | 符合条件的数据字典总数量 |

### 被前端调用

- **字典管理（dictionaryManagement）**：在字典管理页面中，系统初始化时调用此服务端逻辑加载所有数据字典列表，并在用户执行字典类型或标签名搜索操作时再次调用，传入搜索关键词以获取筛选后的字典列表。该逻辑为页面表格提供了完整的数据源，支持字典项的查看、编辑和删除等管理功能。

### 依赖的枚举、实体

- **数据建模-实体-数据字典**：[系统管理-实体-数据字典（DataDictionary）](specs/001-bootdo-management-system/plan/data-model/entity-DataDictionary.md)

### 依赖的外部能力