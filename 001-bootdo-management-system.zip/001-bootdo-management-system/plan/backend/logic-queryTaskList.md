# 工作流引擎-查询任务列表（queryTaskList）

- **生成时间**：2026-03-25

## 查询任务列表（queryTaskList）

### 功能概述

查询任务列表服务端逻辑负责从工作流引擎中检索任务节点数据，支持分页、排序和多条件筛选功能。该逻辑为前端任务管理页面提供数据支撑，允许用户根据流程实例ID、分配用户ID、任务状态等条件查询相关任务，并返回包含任务详细信息的分页结果。通过此逻辑，系统能够高效地展示当前用户需要处理或已处理的任务列表，支持任务的实时监控和管理，确保业务流程的顺畅执行。

### 功能要点

- **分页查询与排序**：支持标准的分页参数（页码、每页条数）和排序参数（排序字段、排序顺序），确保大量任务数据的高效加载和展示，用户可以根据任务名称、创建时间等字段进行升序或降序排列，提升数据浏览体验。
- **多条件筛选**：支持基于流程实例ID、分配用户ID、任务状态等多种条件的组合筛选，用户可以精确查找特定流程中的任务、指定用户的任务或特定状态的任务，满足不同场景下的查询需求。
- **关联数据获取**：在返回任务列表的同时，自动关联获取相关的流程实例信息和分配用户信息，减少前端多次请求的开销，提供完整的任务上下文数据，便于用户理解任务的业务背景。
- **权限控制集成**：查询结果会根据当前用户的权限进行过滤，确保用户只能查看自己有权限访问的任务数据，保障系统的数据安全性和权限隔离性。
- **性能优化**：针对大数据量场景进行查询性能优化，采用数据库索引和合理的查询策略，确保在高并发情况下仍能快速响应查询请求，提供流畅的用户体验。

### 逻辑签名

```naturalts path="app.logics.queryTaskList.ts"
$Logic({
    description: '查询任务列表',
    directory: 'workflow_engine(工作流引擎)'
})
export declare function queryTaskList(page: Integer, size: Integer, sort: String, order: String, processInstanceId?: Integer, assigneeId?: Integer, taskStatus?: app.enums.TaskStatusEnum): { list: List<{ taskNode: app.dataSources.defaultDS.entities.TaskNode, processInstance: app.dataSources.defaultDS.entities.ProcessInstance, assignee: app.dataSources.defaultDS.entities.SystemAccount }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 当前页码，从1开始 |
| size | 每页条数 | Integer | 每页显示的任务数量 |
| sort | 排序字段 | String | 排序的字段名，如'createdTime'、'taskName'等 |
| order | 排序顺序 | String | 排序顺序，'asc'表示升序，'desc'表示降序 |
| processInstanceId | 流程实例ID | Integer | 可选，用于筛选特定流程实例的任务 |
| assigneeId | 分配用户ID | Integer | 可选，用于筛选分配给特定用户的任务 |
| taskStatus | 任务状态 | app.enums.TaskStatusEnum | 可选，用于筛选特定状态的任务 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 任务列表 | List<{ taskNode: app.dataSources.defaultDS.entities.TaskNode, processInstance: app.dataSources.defaultDS.entities.ProcessInstance, assignee: app.dataSources.defaultDS.entities.SystemAccount }> | 任务列表，每个列表项包含任务节点实体、关联的流程实例实体和分配用户实体 |
| total | 总条数 | Integer | 符合查询条件的任务总数 |

### 被前端调用

- **任务管理（taskManagement）**：任务管理页面通过调用此服务端逻辑获取任务列表数据，支持分页展示、排序和多条件筛选功能，为用户提供完整的任务处理界面。

### 依赖的枚举、实体

- **办公自动化-枚举-任务状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **工作流引擎-实体-任务节点**：[工作流引擎-实体-任务节点（TaskNode）](specs/001-bootdo-management-system/plan/data-model/entity-TaskNode.md)
- **工作流引擎-实体-流程实例**：[工作流引擎-实体-流程实例（ProcessInstance）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessInstance.md)
- **系统管理-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无外部能力依赖