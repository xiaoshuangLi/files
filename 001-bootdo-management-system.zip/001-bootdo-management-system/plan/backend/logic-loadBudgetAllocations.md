# 预算管理-加载预算分配列表（loadBudgetAllocations）

- **生成时间**：2026-03-25

## 加载预算分配列表（loadBudgetAllocations）

### 功能概述

加载预算分配列表功能是预算管理模块的核心查询接口，用于分页获取系统中的预算分配记录。该功能支持前端页面展示预算分配数据，并提供灵活的筛选、排序和分页能力。通过此接口，用户可以按预算类型、预算周期、目标部门、预算状态等条件进行组合查询，获取符合特定业务需求的预算分配列表数据。接口返回的数据包含完整的预算分配信息以及关联的预算类型、预算周期和分配人信息，为预算分配管理页面提供全面的数据支持。

### 功能要点

- **分页查询功能**：支持标准的分页查询机制，通过页码(page)和每页条数(size)参数控制返回数据量，避免一次性加载过多数据导致性能问题。系统默认每页显示20条记录，但允许前端根据实际需求调整每页显示数量，最大不超过100条。
- **多条件筛选功能**：提供基于预算分配实体(BudgetAllocation)的完整筛选能力，支持按预算类型ID、预算周期ID、分配金额范围、预算状态、分配人ID等多个维度进行精确或模糊匹配查询。筛选条件通过BudgetAllocation实体对象传递，确保查询条件与数据模型保持一致。
- **动态排序功能**：支持按任意字段进行升序('ascending')或降序('descending')排序，通过sort参数指定排序字段，order参数指定排序方向。默认按分配时间(allocationAt)降序排列，确保最新的预算分配记录优先显示。
- **关联数据加载**：在返回预算分配列表的同时，自动加载关联的预算类型(BudgetType)、预算周期(BudgetCycle)和分配人(SystemAccount)的详细信息，减少前端多次请求的开销，提升用户体验。

### 逻辑签名

```naturalts path="app.logics.loadBudgetAllocations.ts"
$Logic({
    description: '分页查询预算分配列表',
    directory: 'budget_management(预算管理)'
})
export declare function loadBudgetAllocations(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.BudgetAllocation): { list: List<{ budgetAllocation: app.dataSources.defaultDS.entities.BudgetAllocation, budgetType: app.dataSources.defaultDS.entities.BudgetType, budgetCycle: app.dataSources.defaultDS.entities.BudgetCycle, allocatedBy: app.dataSources.defaultDS.entities.SystemAccount }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 分页查询的页码，从1开始计数 |
| size | 每页条数 | Integer | 每页返回的记录数量，建议范围1-100 |
| sort | 排序字段 | String | 排序的字段名，如"allocatedAt"、"amount"等 |
| order | 排序顺序 | String | 排序方向，"ascending"表示升序，"descending"表示降序 |
| filter | 过滤条件 | app.dataSources.defaultDS.entities.BudgetAllocation | 预算分配实体作为过滤条件，支持各字段的精确匹配 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 预算分配列表 | List<{ budgetAllocation: app.dataSources.defaultDS.entities.BudgetAllocation, budgetType: app.dataSources.defaultDS.entities.BudgetType, budgetCycle: app.dataSources.defaultDS.entities.BudgetCycle, allocatedBy: app.dataSources.defaultDS.entities.SystemAccount }> | 预算分配列表，每个列表项包含预算分配实体及其关联的预算类型、预算周期和分配人信息 |
| total | 总条数 | Integer | 符合筛选条件的总记录数，用于分页计算 |

### 被前端调用

- **预算分配（budgetAllocation）**：预算分配管理页面使用此服务端逻辑加载预算分配列表数据，支持用户查看、筛选和管理预算分配记录。页面通过分页、筛选和排序参数调用此接口，获取符合业务需求的预算分配数据，并在表格中展示预算类型、预算周期、分配金额、预算状态等关键信息。

### 依赖的枚举、实体

- **数据建模-枚举-预算状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-预算分配**：[预算管理-实体-预算分配（BudgetAllocation）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetAllocation.md)
- **数据建模-实体-预算类型**：[预算管理-实体-预算类型（BudgetType）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetType.md)
- **数据建模-实体-预算周期**：[预算管理-实体-预算周期（BudgetCycle）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetCycle.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无