# 分包商管理-导出分包商评估记录（exportSubcontractorEvaluationRecords）

- **生成时间**：2026-03-25

## 导出分包商评估记录（exportSubcontractorEvaluationRecords）

### 功能概述

该服务端逻辑提供将分包商绩效评估记录导出为标准格式文件的功能，支持按条件筛选特定时间段、特定分包商或特定项目相关的评估记录。导出的文件包含完整的评估信息，如评估日期、评估人员、评估分数、评估详情、整改建议等，便于后续的数据分析、审计和报告生成。系统支持多种导出格式，包括Excel、CSV和PDF，满足不同场景下的使用需求。

### 功能要点

- **条件筛选导出**：支持根据多种条件组合筛选需要导出的评估记录，包括分包商名称、评估时间范围、项目名称、评估状态等。用户可以在前端界面设置筛选条件，服务端根据这些条件查询数据库并导出符合条件的记录，确保导出数据的准确性和相关性，避免导出大量无关数据造成资源浪费。

### 逻辑签名

```naturalts path="app.logics.exportSubcontractorEvaluationRecords.ts"
$Logic({
    description: '导出分包商评估记录',
    directory: 'subcontractor_management(分包商管理)'
})
export declare function exportSubcontractorEvaluationRecords(subcontractorId?: String, projectId?: String, startDate?: Date, endDate?: Date, evaluationStatus?: app.enums.EvaluationStatusEnum, exportFormat: app.enums.ExportFormatEnum): { fileName: String, fileContent: String, fileSize: Integer, downloadUrl: String };
```

### 被前端调用

- **通用业务模块-评估记录（evaluationRecord）**：在评估记录页面中，用户可以通过点击"导出"按钮，选择导出条件和文件格式，调用此服务端逻辑将筛选后的评估记录导出为指定格式的文件，用于离线查看、数据分析或存档。

### 依赖的枚举、实体

- **数据建模-枚举-评估状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-枚举-导出格式**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-分包商信息**：[分包商管理-实体-分包商信息（SubcontractorInformation）](specs/001-bootdo-management-system/plan/data-model/entity-SubcontractorInformation.md)
- **数据建模-实体-评估记录**：[分包商管理-实体-评估记录（EvaluationRecord）](specs/001-bootdo-management-system/plan/data-model/entity-EvaluationRecord.md)

### 依赖的外部能力

[文件内部已经提供，无需进行生成。如果文件内部已经有 `依赖的外部能力` 内容，禁止修改或删除文件内的 `依赖的外部能力` 内容]