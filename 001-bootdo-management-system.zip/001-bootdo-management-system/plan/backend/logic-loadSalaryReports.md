# 薪资管理-加载薪资报表（loadSalaryReports）

- **生成时间**：2026-03-25

## 加载薪资报表（loadSalaryReports）

### 功能概述

加载薪资报表服务端逻辑用于分页查询系统中的薪资报表数据，支持按部门、岗位、时间范围、员工姓名等多个维度进行组合筛选，并提供灵活的排序功能。该逻辑是薪资报表管理页面的核心数据支撑接口，能够根据前端传递的筛选条件返回符合条件的薪资报表列表及其总数。通过关联查询月工资额、薪资结构和系统账户等关联实体，该逻辑提供了一个包含完整薪资信息的数据视图，包括员工基本信息、薪资构成明细、发放状态等关键数据，为薪资数据分析和管理提供全面的数据支持。

### 功能要点

- **多维度分页查询功能**：支持标准的分页查询机制，通过页码(page)和每页条数(size)参数控制返回数据量，避免一次性加载过多数据导致性能问题。系统默认每页显示20条记录，但允许前端根据实际需求调整每页显示数量。同时支持按任意字段进行升序或降序排序，确保用户能够按照关注的指标（如薪资金额、发放时间等）对结果进行排序查看。

- **组合筛选功能**：提供基于多个业务维度的组合筛选能力，支持按部门ID、岗位ID、时间范围（支付月份）、员工姓名等条件进行精确或模糊匹配查询。用户可以根据实际业务需求灵活组合不同的筛选条件，快速定位到关注的薪资报表数据，提高数据查询的准确性和效率。

- **关联数据加载**：在返回薪资报表列表的同时，自动加载关联的月工资额(MonthlySalaryAmount)、薪资结构(SalaryStructure)和系统账户(SystemAccount)的详细信息。这种关联查询减少了前端的多次请求开销，确保返回的数据包含完整的薪资构成明细（基本工资、奖金、津贴、税前金额、税后金额等）和员工基本信息，为前端展示提供全面的数据支持。

- **数据安全与权限控制**：在查询过程中实施严格的数据权限控制，确保用户只能访问其权限范围内的薪资数据。系统会根据当前用户的角色和部门权限自动过滤查询结果，防止敏感薪资信息的越权访问，保障企业薪酬数据的安全性。

### 逻辑签名

```naturalts path="app.logics.loadSalaryReports.ts"
$Logic({
    description: '分页查询薪资报表列表',
    directory: 'salary_management(薪资管理)'
})
export declare function loadSalaryReports(page: Integer, size: Integer, sort: String, order: String, departmentId?: Integer, positionId?: Integer, timeRange?: { startMonth: String, endMonth: String }, employeeName?: String): { list: List<{ salaryReport: app.dataSources.defaultDS.entities.SalaryReport, monthlySalaryAmount: app.dataSources.defaultDS.entities.MonthlySalaryAmount, salaryStructure: app.dataSources.defaultDS.entities.SalaryStructure, employee: app.dataSources.defaultDS.entities.SystemAccount }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 分页查询的页码，从1开始计数 |
| size | 每页条数 | Integer | 每页返回的记录数量，建议范围1-100 |
| sort | 排序字段 | String | 排序的字段名，如"netAmount"、"generatedAt"等 |
| order | 排序顺序 | String | 排序方向，"asc"表示升序，"desc"表示降序 |
| departmentId | 部门ID | Integer | 筛选指定部门的薪资数据（可选） |
| positionId | 岗位ID | Integer | 筛选指定岗位的薪资数据（可选） |
| timeRange | 时间范围 | { startMonth: String, endMonth: String } | 筛选指定时间范围的薪资数据，月份格式为YYYY-MM（可选） |
| employeeName | 员工姓名 | String | 筛选指定员工的薪资数据，支持模糊匹配（可选） |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 薪资报表列表 | List<{ salaryReport: app.dataSources.defaultDS.entities.SalaryReport, monthlySalaryAmount: app.dataSources.defaultDS.entities.MonthlySalaryAmount, salaryStructure: app.dataSources.defaultDS.entities.SalaryStructure, employee: app.dataSources.defaultDS.entities.SystemAccount }> | 薪资报表列表，每个列表项包含薪资报表实体及其关联的月工资额、薪资结构和员工信息 |
| total | 总条数 | Integer | 符合筛选条件的总记录数，用于分页计算 |

### 被前端调用

- **薪资报表（salaryReport）**：薪资报表管理页面使用此服务端逻辑加载薪资报表列表数据，支持用户通过部门、岗位、时间范围、员工姓名等多维度筛选条件进行查询，并在表格中展示员工姓名、部门、岗位、薪资构成、发放状态等关键信息。页面通过分页、筛选和排序参数调用此接口，获取符合业务需求的薪资数据。

### 依赖的枚举、实体

- **数据建模-实体-薪资报表**：[薪资管理-实体-薪资报表（SalaryReport）](specs/001-bootdo-management-system/plan/data-model/entity-SalaryReport.md)
- **数据建模-实体-月工资额**：[薪资管理-实体-月工资额（MonthlySalaryAmount）](specs/001-bootdo-management-system/plan/data-model/entity-MonthlySalaryAmount.md)
- **数据建模-实体-薪资结构**：[薪资管理-实体-薪资结构（SalaryStructure）](specs/001-bootdo-management-system/plan/data-model/entity-SalaryStructure.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无