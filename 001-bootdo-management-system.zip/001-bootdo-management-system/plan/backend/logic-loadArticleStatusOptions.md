# 内容管理-加载文章状态选项（loadArticleStatusOptions）

- **生成时间**：2026-03-25

## 加载文章状态选项（loadArticleStatusOptions）

### 功能概述

加载文章状态选项服务端逻辑提供文章管理功能中所需的文章状态下拉选项数据。该逻辑从系统预定义的文章状态枚举中获取所有可用的状态选项，包括草稿、待审核、已发布、已归档等状态，并以键值对的形式返回给前端，用于在文章创建和编辑表单中的状态选择下拉框。此逻辑确保前端能够正确显示和选择文章的生命周期状态，支持内容管理的规范化流程。

### 功能要点

- **文章状态选项加载**：当用户在文章管理页面访问文章创建或编辑表单时，系统需要动态加载文章状态选项。该逻辑从ArticleStatusEnum枚举中提取所有状态值及其对应的中文标题，构建适合前端下拉组件使用的选项数据结构。返回的数据包含状态标识（如'Draft'、'PendingReview'等）作为选项的标识符，以及对应的中文标题（如'草稿'、'待审核'等）作为选项的显示文本，确保用户界面的友好性和一致性。

### 逻辑签名

```naturalts path="app.logics.contentManagement.loadArticleStatusOptions.ts"
$Logic({
    description: "加载文章状态选项",
    directory: "content_management(内容管理)"
})
export declare function loadArticleStatusOptions(): { articleStatusOptions: Array<{ optionIdentifier: app.enums.ArticleStatusEnum, displayText: Text }> };
```

### 被前端调用

- **文章管理（articleManagement）**：在文章管理页面的文章创建和编辑表单中，当用户需要选择文章状态时，前端调用此服务端逻辑获取可用的文章状态选项列表，用于填充状态选择下拉框，确保用户能够选择正确的文章生命周期状态。

### 依赖的枚举、实体

- **数据建模-枚举-文章状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)

### 依赖的外部能力

无匹配内容

