# 通用领域服务-获取个人工作台数据（getPersonalWorkspaceData）

- **生成时间**：2026-03-25

## 获取个人工作台数据（getPersonalWorkspaceData）

### 功能概述

该服务端逻辑负责获取当前登录用户的个人工作台数据，包括待办任务、通知公告、日程安排、邮件通信等个性化信息。系统会根据用户的角色权限和订阅偏好，动态聚合相关业务模块的数据，为用户提供统一的工作入口视图。此功能是实现个性化工作门户的核心服务，确保用户能够快速访问与其工作相关的关键信息和操作入口。

### 功能要点

- **个性化数据聚合**：根据用户身份和权限级别，从多个业务模块（如待办任务、通知公告、日程安排、邮件通信等）聚合相关数据，形成统一的个人工作台视图。系统会智能筛选与用户相关的数据，避免信息过载，同时确保关键信息不被遗漏。数据聚合过程考虑用户的部门归属、角色权限和个性化设置，确保展示内容的相关性和安全性。

### 逻辑签名

```naturalts path="app.logics.getPersonalWorkspaceData.ts"
$Logic({
    description: '获取当前用户的个人工作台数据',
    directory: 'personal_workspace(个人门户)'
})
export declare function getPersonalWorkspaceData(userId: String): {
  todoTasks: List<app.dataSources.defaultDS.entities.TodoTask>,
  noticeAnnouncements: List<app.dataSources.defaultDS.entities.NoticeAnnouncement>,
  scheduleArrangements: List<app.dataSources.defaultDS.entities.ScheduleArrangement>,
  emailCommunications: List<app.dataSources.defaultDS.entities.EmailCommunication>,
  personalWorkspace: app.dataSources.defaultDS.entities.PersonalWorkspace
};
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| userId | 用户ID | String | 当前登录用户的唯一标识 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| todoTasks | 待办任务列表 | List<app.dataSources.defaultDS.entities.TodoTask> | 用户相关的待办任务列表 |
| noticeAnnouncements | 通知公告列表 | List<app.dataSources.defaultDS.entities.NoticeAnnouncement> | 用户相关的通知公告列表 |
| scheduleArrangements | 日程安排列表 | List<app.dataSources.defaultDS.entities.ScheduleArrangement> | 用户的日程安排列表 |
| emailCommunications | 邮件通信列表 | List<app.dataSources.defaultDS.entities.EmailCommunication> | 用户的邮件通信列表 |
| personalWorkspace | 个人工作台配置 | app.dataSources.defaultDS.entities.PersonalWorkspace | 用户的个人工作台个性化配置 |

### 被前端调用

- **个人门户（personalWorkspace）**：在用户登录后进入个人门户页面时，调用此服务端逻辑获取所有个性化工作数据，包括待办任务列表、最新通知公告、近期日程安排和重要邮件通信，为用户提供一站式工作入口。

### 依赖的枚举、实体

- **数据建模-实体-待办任务**：[办公自动化-实体-待办任务（TodoTask）](specs/001-bootdo-management-system/plan/data-model/entity-TodoTask.md)
- **数据建模-实体-通知公告**：[办公自动化-实体-通知公告（NoticeAnnouncement）](specs/001-bootdo-management-system/plan/data-model/entity-NoticeAnnouncement.md)
- **数据建模-实体-日程安排**：[办公自动化-实体-日程安排（ScheduleArrangement）](specs/001-bootdo-management-system/plan/data-model/entity-ScheduleArrangement.md)
- **数据建模-实体-邮件通信**：[办公自动化-实体-邮件通信（EmailCommunication）](specs/001-bootdo-management-system/plan/data-model/entity-EmailCommunication.md)
- **数据建模-实体-个人工作台**：[办公自动化-实体-个人工作台（PersonalWorkspace）](specs/001-bootdo-management-system/plan/data-model/entity-PersonalWorkspace.md)

### 依赖的外部能力

无