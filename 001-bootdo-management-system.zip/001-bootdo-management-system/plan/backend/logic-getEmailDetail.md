# 办公自动化-获取邮件详情（getEmailDetail）

- **生成时间**：2026-03-25

## 获取邮件详情（getEmailDetail）

### 功能概述

获取邮件详情服务端逻辑提供查询单封邮件完整信息的功能，包括邮件的基本信息（如邮件ID、主题、发送时间）、发件人信息、收件人列表、邮件正文内容以及附件信息等。该逻辑通过邮件唯一标识符（emailId）查询数据库中的邮件记录，并关联获取发件人的系统账户信息，确保返回的数据完整且准确。同时，该逻辑会自动更新邮件的已读状态，标记为已读，以便在前端界面正确显示邮件阅读状态。

### 功能要点

- **邮件详情查询与状态更新**：根据提供的邮件ID参数，从数据库中精确查询对应的邮件记录，获取完整的邮件信息包括主题、正文、发送时间、发件人ID等字段。同时，系统会检查当前用户是否为该邮件的收件人之一，如果是，则自动将邮件的isRead字段更新为true，标记为已读状态。此操作确保了邮件系统的阅读状态跟踪功能正常工作，让用户能够清晰区分已读和未读邮件，提升邮件管理效率。此外，该逻辑还会关联查询发件人的系统账户信息，返回发件人的姓名等基本信息，便于用户识别邮件来源。

### 逻辑签名

```naturalts path="app.logics.getEmailDetail.ts"
$Logic({
    description: '获取邮件详情',
    directory: 'office_automation(办公自动化)'
})
export declare function getEmailDetail(
    emailId: String
): app.dataSources.defaultDS.entities.EmailCommunication;
```

### 被前端调用

- **邮件集成（emailCommunication）**：在邮件列表中点击任意邮件时，前端会调用此服务端逻辑获取邮件的完整详情信息，包括发件人、收件人、主题、正文、附件等，并在详情页面展示。同时，该调用会触发邮件已读状态的更新，确保用户界面正确反映邮件阅读状态。

### 依赖的枚举、实体

- **数据建模-实体-邮件通信**：[办公自动化-实体-邮件通信（EmailCommunication）](specs/001-bootdo-management-system/plan/data-model/entity-EmailCommunication.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)