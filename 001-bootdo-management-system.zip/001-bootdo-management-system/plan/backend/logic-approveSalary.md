# 薪资管理-审批薪资（approveSalary）

- **生成时间**：2026-03-25

## 审批薪资（approveSalary）

### 功能概述

审批薪资服务端逻辑是BootDo管理系统薪资管理模块的核心业务功能，负责处理薪资调整申请的审批操作。该逻辑接收审批人员提交的审批意见和决策，更新薪资调整申请的审批状态，并在审批通过后自动触发后续的薪资结构更新和薪资计算流程。系统通过与工作流引擎的深度集成，确保审批流程的规范化、透明化和可追溯性，支持多级审批场景下的状态流转和权限控制。审批操作包含对薪资调整申请的详细审核，包括原薪资水平、期望新薪资金额、调整原因的合理性评估，以及审批人员补充意见的记录，如月增资额度、岗位分类、集团主要领导意见等关键信息。审批完成后，系统会自动更新相关员工的薪资结构数据，并生成相应的薪资发放记录，确保薪酬管理的准确性和合规性。

### 功能要点

- **审批状态更新**：审批薪资逻辑负责将薪资调整申请的审批状态从"审核中"更新为"已批准"或"已驳回"，并记录审批时间和审批人信息。系统会验证当前用户是否具有审批权限，确保只有授权的审批人员才能执行审批操作。审批状态的更新会触发工作流引擎的状态流转，确保整个审批流程的连贯性和一致性。

- **薪资结构调整**：当薪资调整申请被批准后，审批薪资逻辑会自动调用薪资结构更新服务，将员工的薪资结构从原薪资水平调整为新的薪资标准。系统会精确计算调整后的月工资额和年薪总额，并设置调整生效日期，确保薪资计算的准确性。薪资结构调整操作会同时更新员工的薪酬档级信息，保持薪酬体系的一致性。

- **审批意见记录**：审批薪资逻辑支持审批人员填写详细的审批意见，包括月增资额度、岗位分类、集团主要领导意见等补充信息。这些意见会被完整记录在薪资调整申请中，为后续的薪资管理和审计提供完整的决策依据。系统会对审批意见进行格式验证和内容完整性检查，确保审批信息的质量和可用性。

### 逻辑签名

```naturalts path="app.logics.approveSalary.ts"
$Logic({
    description: '审批薪资调整申请',
    directory: 'salary_management(薪资管理)',
    transactional: true
})
export declare function approveSalary(salaryAdjustmentId: Integer, approvalDecision: app.enums.ApprovalStatusEnum, approvalComments: String, monthlyIncrease: Decimal, positionCategory: String): app.dataSources.defaultDS.entities.SalaryAdjustment
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| salaryAdjustmentId | 薪资调整申请ID | Integer | 需要审批的薪资调整申请的唯一标识符 |
| approvalDecision | 审批决策 | app.enums.ApprovalStatusEnum | 审批结果，必须为Approved（已批准）或Rejected（已驳回） |
| approvalComments | 审批意见 | String | 审批人员填写的详细审批意见，最大长度1000字符 |
| monthlyIncrease | 月增资 | Decimal | 审批通过后的月度薪资增加额度，单位：元 |
| positionCategory | 岗位分类 | String | 员工的岗位分类，如管理岗、技术岗、销售岗等 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 审批结果 | app.dataSources.defaultDS.entities.SalaryAdjustment | 更新后的薪资调整申请实体，包含最新的审批状态和相关信息 |

### 被前端调用

- **薪资调整审批（salaryAdjustment）**：薪资调整审批页面调用审批薪资逻辑来处理审批人员提交的审批决策。当审批人员在薪资调整表单中填写完审批意见、月增资额度、岗位分类等信息并点击审批按钮时，前端会调用此服务端逻辑，传入薪资调整申请ID、审批决策（批准或驳回）、审批意见、月增资额度和岗位分类等参数，完成薪资调整申请的审批流程。

### 依赖的枚举、实体

- **数据建模-枚举-审批状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-薪资调整**：[薪资管理-实体-薪资调整（SalaryAdjustment）](specs/001-bootdo-management-system/plan/data-model/entity-SalaryAdjustment.md)

### 依赖的外部能力