# 内容管理-保存SEO配置（saveSeoConfiguration）

- **生成时间**：2026-03-25

## 保存SEO配置（saveSeoConfiguration）

### 功能概述

保存SEO配置服务端逻辑负责处理内容管理系统中文章搜索引擎优化配置的保存操作。该逻辑接收前端传递的SEO参数，包括自定义URL路径、Meta标题、Meta描述和关键词等核心SEO元素，并将这些配置信息持久化存储到数据库中。系统会验证输入参数的有效性，确保URL格式正确、Meta标题和描述长度符合搜索引擎最佳实践要求。保存成功后，系统会更新SEO配置的优化时间戳，并记录操作日志。该逻辑还支持为不同文章创建独立的SEO配置，或更新现有配置，确保内容能够获得最佳的搜索引擎可见性和排名效果。

### 功能要点

- **SEO参数验证与保存**：系统接收前端提交的SEO配置参数，包括自定义URL、Meta标题、Meta描述和关键词。首先验证URL路径的格式有效性，确保不包含非法字符；检查Meta标题长度不超过60个字符，Meta描述长度不超过160个字符，符合主流搜索引擎的最佳实践。验证通过后，将配置信息保存到SeoOptimization实体中，关联对应的文章ID，并更新优化时间戳。如果文章已存在SEO配置，则执行更新操作；否则创建新的SEO配置记录。

### 逻辑签名

```naturalts path="app.logics.saveSeoConfiguration.ts"
$Logic({
    description: '保存文章的SEO配置信息',
    directory: 'content_management(内容管理)'
})
export declare function saveSeoConfiguration(
  articleId: Integer,
  seoConfig: {
    customUrl: String;
    metaTitle: String;
    metaDescription: String;
    keywords: String;
  }
): app.dataSources.defaultDS.entities.SeoOptimization;
```

### 被前端调用

- **SEO优化（seoOptimization）**：在SEO优化功能页面中，当内容管理员编辑完SEO参数并点击保存按钮时，前端调用此服务端逻辑将配置信息保存到数据库，实现SEO配置的持久化存储。

### 依赖的枚举、实体

- **数据建模-实体-SEO优化**：[内容管理-实体-SeoOptimization（SeoOptimization）](specs/001-bootdo-management-system/plan/data-model/entity-SeoOptimization.md)
- **数据建模-实体-文章内容**：[内容管理-实体-文章内容（ArticleContent）](specs/001-bootdo-management-system/plan/data-model/entity-ArticleContent.md)

### 依赖的外部能力

无