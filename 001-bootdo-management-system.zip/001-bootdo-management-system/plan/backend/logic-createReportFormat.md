# 预算管理-创建报表格式（createReportFormat）

- **生成时间**：2026-03-25

## 创建报表格式（createReportFormat）

### 功能概述

创建报表格式服务端逻辑用于在系统中新增一个预算分析报告的标准化模板。该逻辑接收包含报表格式名称和模板内容的完整信息，验证数据的有效性后将其持久化存储到数据库中。通过此逻辑，用户可以定义符合企业财务规范的预算报表格式，包括预算执行对比表、部门预算汇总表、项目预算明细表等多种类型。创建成功后，系统会返回完整的报表格式实体信息，包含自动生成的主键ID和其他元数据，确保新创建的报表格式能够被其他功能模块正确引用和使用。

### 功能要点

- **报表格式创建与验证**：接收用户提交的报表格式信息，包括必填的格式名称和模板内容，对输入数据进行完整性验证，确保格式名称不为空且模板内容符合预设的结构要求。系统会对重复的格式名称进行检查，防止创建重复的报表格式模板，保证报表格式的唯一性和可识别性。

### 逻辑签名

```naturalts path="app.logics.createReportFormat.ts"
$Logic({
    description: '创建报表格式',
    directory: 'budget_management(预算管理)',
    transactional: true
})
export declare function createReportFormat(reportFormat: app.dataSources.defaultDS.entities.ReportFormat): app.dataSources.defaultDS.entities.ReportFormat;
```

### 被前端调用

- **报表格式（reportFormat）**：在报表格式管理页面中，当用户点击"新增"按钮并填写完报表格式信息后，前端会调用此服务端逻辑来创建新的报表格式记录，实现报表模板的标准化定义和存储。

### 依赖的枚举、实体

- **数据建模-实体-报表格式**：[预算管理-实体-报表格式（ReportFormat）](specs/001-bootdo-management-system/plan/data-model/entity-ReportFormat.md)

### 依赖的外部能力

无