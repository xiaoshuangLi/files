# 权限中心-设置部门负责人（LcapSetDeptLeader）

## 设置部门负责人（LcapSetDeptLeader）

### 功能概述

该服务端逻辑用于在权限中心子域中设置指定部门的负责人。通过传入部门ID和用户ID，系统会自动更新用户与部门映射关系，将指定用户设置为该部门的负责人，同时取消该部门原有的负责人标识。此功能支持部门管理页面中的部门负责人设置操作，确保每个部门有且仅有一个负责人，为系统提供准确的组织架构支撑。

### 功能要点

- **部门负责人唯一性保证**：系统在设置新的部门负责人时，会自动查找并取消该部门当前已有的负责人标识，确保每个部门在同一时间只能有一个负责人，避免多负责人导致的权限混乱和业务流程冲突。
- **用户部门归属验证**：在设置部门负责人前，系统会验证指定用户是否属于该部门，只有已经是该部门成员的用户才能被设置为部门负责人，确保组织架构数据的一致性和完整性。
- **原子性操作保障**：整个设置过程采用原子性操作，包括取消原负责人标识和设置新负责人标识两个步骤，确保在并发场景下不会出现部门无负责人或多个负责人的情况，保证数据的准确性和系统稳定性。
- **权限控制集成**：该逻辑与系统的权限控制机制紧密集成，只有具有部门管理权限的用户才能执行此操作，防止未授权用户随意更改部门负责人，确保系统安全性和数据隔离性。

### 逻辑签名

```naturalts path="app.logics.LcapSetDeptLeader.ts"
$Logic({
    description: '设置指定部门的负责人，确保每个部门有且仅有一个负责人',
    directory: 'permission_center(权限中心)',
})
export declare function LcapSetDeptLeader(deptId: String, userId: String): Boolean;
```

### 被前端调用

- **部门管理页（departmentManagement）**：在部门管理页面中，管理员可以通过部门成员管理功能设置某个部门的负责人。当管理员选择一个部门成员并将其设置为负责人时，前端会调用此服务端逻辑，传入部门ID和用户ID，完成部门负责人的设置操作，并在操作成功后刷新部门成员列表，显示更新后的负责人状态。

### 依赖的枚举、实体、数据结构

- **数据建模-实体-用户与部门映射**：[权限中心-实体-用户与部门映射（LcapUserDeptMapping）](specs/001-bootdo-management-system/plan/data-model/entity-LcapUserDeptMapping.md)
- **数据建模-实体-用户**：[权限中心-实体-用户（LcapUser）](specs/001-bootdo-management-system/plan/data-model/entity-LcapUser.md)
- **数据建模-实体-部门**：[权限中心-实体-部门（LcapDepartment）](specs/001-bootdo-management-system/plan/data-model/entity-LcapDepartment.md)

