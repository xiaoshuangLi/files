# 内容管理-获取用户订阅（getUserSubscriptions）

- **生成时间**：2026-03-25

## 获取用户订阅（getUserSubscriptions）

### 功能概述

该服务端逻辑用于获取当前登录用户的订阅信息，包括用户已订阅的栏目和文章更新通知设置。系统会根据用户ID查询其在订阅表中的记录，并返回完整的订阅列表，包含订阅的栏目ID、订阅类型（栏目订阅或文章更新订阅）、订阅状态（启用/禁用）以及创建时间等信息。此功能为用户提供个性化的信息推送服务，确保用户能够及时获取所关注内容的更新通知。

### 功能要点

- **查询用户订阅列表**：根据当前登录用户的唯一标识符，从数据库中检索该用户的所有有效订阅记录。系统需要支持按订阅类型（栏目订阅或文章更新订阅）进行筛选，并能够返回订阅的详细信息，包括订阅目标ID、订阅状态、创建时间和最后更新时间。此功能确保用户能够在个人门户页面查看和管理自己的所有订阅项。

### 逻辑签名

```naturalts path="app.logics.getUserSubscriptions.ts"
$Logic({
    description: '获取用户订阅信息',
    directory: 'content_management(内容管理)'
})
export declare function getUserSubscriptions(userId: String): List<app.dataSources.defaultDS.entities.UserSubscription>;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| userId | 用户ID | String | 当前登录用户的唯一标识符 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 订阅列表 | List<app.dataSources.defaultDS.entities.UserSubscription> | 用户的所有订阅记录列表 |

### 被前端调用

- **个人门户（personalWorkspace）**：在个人门户页面中调用此服务端逻辑，获取用户当前的订阅列表，用于展示用户已订阅的栏目和文章更新设置，方便用户进行订阅管理。

### 依赖的枚举、实体

- **数据建模-实体-用户订阅**：[办公自动化-实体-用户订阅（UserSubscription）](specs/001-bootdo-management-system/plan/data-model/entity-UserSubscription.md)