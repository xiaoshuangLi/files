# 系统管理-删除操作日志（deleteOperationLog）

- **生成时间**：2026-03-25

## 删除操作日志（deleteOperationLog）

### 功能概述

该服务端逻辑提供删除系统操作日志的功能，允许授权用户清理不再需要的操作记录。操作日志记录了系统用户的各类操作行为，包括登录、数据修改、权限变更等关键活动。通过此功能，管理员可以定期清理过期日志，释放存储空间，同时保持系统审计追踪的有效性。删除操作将永久移除指定的操作记录，不可恢复，因此需要严格的权限控制和操作确认机制。

### 功能要点

- **权限控制与验证**：删除操作日志功能仅对具有系统管理员权限的用户开放。在执行删除操作前，系统会验证当前用户是否拥有SystemAdministrator角色，确保只有授权人员能够执行此敏感操作。此外，系统还会记录删除操作本身作为新的操作日志，形成完整的审计链条，防止恶意删除行为逃避追踪。

### 逻辑签名

```naturalts path="app.logics.deleteOperationLog.ts"
$Logic({
    description: '删除操作日志',
    directory: 'system_management(系统管理)'
})
export declare function deleteOperationLog(logIds: List<String>): Boolean;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| logIds | 要删除的操作日志ID列表 | List<String> | 要删除的操作日志ID列表 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 操作结果 | Boolean | 删除操作是否成功 |

### 被前端调用

- **通用业务模块-日志管理（logManagement）**：在日志管理页面中，用户可以选择一条操作记录，然后点击删除按钮调用此服务端逻辑，实现删除选中的操作日志记录。

### 依赖的枚举、实体

- **数据建模-实体-操作记录**：[系统管理-实体-操作记录（OperationRecord）](specs/001-bootdo-management-system/plan/data-model/entity-OperationRecord.md)

### 依赖的外部能力

无