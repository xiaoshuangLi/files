# 质量管理-获取质量问题列表（getQualityIssueList）

- **生成时间**：2026-03-25

## 获取质量问题列表（getQualityIssueList）

### 功能概述

获取质量问题列表服务端逻辑提供分页查询系统中质量问题记录的功能，支持按问题状态、报告人、报告时间范围等条件进行过滤，并支持按指定字段和顺序进行排序。该逻辑返回符合条件的质量问题列表及其总数，用于在质量问题登记页面中展示质量问题数据，方便用户查看、筛选和管理各类质量问题。通过该逻辑，系统能够高效地检索和展示质量问题信息，包括问题标题、描述、状态、报告人等关键属性，并支持与整改任务、质量检验等关联数据的加载，为质量管理提供全面的数据支持。

### 功能要点

- **分页查询功能**：支持标准的分页查询机制，通过页码(page)和每页条数(size)参数控制返回数据量，避免一次性加载过多数据导致性能问题。系统默认每页显示20条记录，但允许前端根据实际需求调整每页显示数量，最大不超过100条，确保用户体验和系统性能的平衡。
- **多条件筛选功能**：提供基于质量问题实体(QualityIssue)的完整筛选能力，支持按问题状态(status)、报告人ID(reporterId)、报告时间范围(reportedAt)等多个维度进行精确或模糊匹配查询。筛选条件通过QualityIssue实体对象传递，确保查询条件与数据模型保持一致，提高查询的准确性和灵活性。
- **动态排序功能**：支持按任意字段进行升序('ascending')或降序('descending')排序，通过sort参数指定排序字段，order参数指定排序方向。默认按报告时间(reportedAt)降序排列，确保最新的质量问题优先显示，便于用户及时处理最新发现的问题。
- **关联数据加载**：在返回质量问题列表的同时，自动加载关联的报告人(SystemAccount)详细信息，包括用户名、真实姓名等关键字段，减少前端多次请求的开销，提升用户体验和数据展示的完整性。

### 逻辑签名

```naturalts path="app.logics.getQualityIssueList.ts"
$Logic({
    description: '分页查询质量问题列表',
    directory: 'quality_management(质量管理)'
})
export declare function getQualityIssueList(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.QualityIssue): { list: List<{ qualityIssue: app.dataSources.defaultDS.entities.QualityIssue, reporter: app.dataSources.defaultDS.entities.SystemAccount }>, total: Integer };
```

### 被前端调用

- **质量问题登记（qualityIssue）**：质量问题登记页面使用此服务端逻辑加载质量问题列表数据，支持用户查看、筛选和管理质量问题记录。页面通过分页、筛选和排序参数调用此接口，获取符合业务需求的质量问题数据，并在表格中展示问题标题、状态、报告人、报告时间等关键信息。

### 依赖的枚举、实体

- **数据建模-枚举-质量问题状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-质量问题**：[质量管理-实体-质量问题（QualityIssue）](specs/001-bootdo-management-system/plan/data-model/entity-QualityIssue.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

#### 邮件服务（EmailService） 【当前业务功能相关】

- 关联文档：[邮件服务（EmailService）](specs/001-bootdo-management-system/plan/integration/retrieval-EmailService.md)