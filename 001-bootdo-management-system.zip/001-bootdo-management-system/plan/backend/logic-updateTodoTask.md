# 办公自动化-更新待办任务（updateTodoTask）

- **生成时间**：2026-03-25

## 更新待办任务（updateTodoTask）

### 功能概述

更新待办任务服务端逻辑用于修改系统中已存在的待办任务信息。该功能允许用户或系统管理员更新任务的标题、描述、分配用户、截止日期以及任务状态等关键属性。通过此逻辑，系统确保任务信息的实时性和准确性，支持任务生命周期的动态管理。更新操作会验证任务的存在性、分配用户的有效性，并记录任务的更新时间和更新人信息，保证数据的完整性和可追溯性。该逻辑还支持任务状态的变更，如从"待处理"变更为"处理中"或"已完成"，从而反映任务的实际进展。

### 功能要点

- **任务信息更新**：支持更新待办任务的核心属性，包括任务标题（必填）、任务描述、分配给的用户（必填）、截止日期和任务状态。系统会验证所有必填字段是否已提供，并确保分配的用户ID在系统账户实体中存在。更新操作会自动记录updatedTime和updatedBy字段，确保数据变更的可追溯性。

- **任务状态管理**：支持任务状态的变更，包括"待处理"（Pending）、"处理中"（InProgress）、"已完成"（Completed）和"已取消"（Cancelled）四种状态。当任务状态变更为"已完成"时，系统会自动记录完成时间（completedAt）；当状态从"已完成"变更为其他状态时，系统会清除完成时间。这种状态管理机制确保任务进度的准确跟踪。

- **权限与数据验证**：系统会验证当前操作用户是否有权限更新指定的任务。通常，任务的创建者、分配的用户以及具有相应管理权限的用户可以更新任务。同时，系统会验证分配的用户ID是否有效（存在于SystemAccount实体中），并确保截止日期不早于当前日期（除非是历史任务的修正）。这些验证机制保证了数据的一致性和业务规则的正确执行。

### 逻辑签名

```naturalts path="app.logics.updateTodoTask.ts"
$Logic({
    description: "更新待办任务",
    directory: "office_automation(办公自动化)",
    transactional: true
})
export declare function updateTodoTask(todoTask: app.dataSources.defaultDS.entities.TodoTask): app.dataSources.defaultDS.entities.TodoTask;
```

### 被前端调用

- **待办事项（todoTask）**：在待办事项页面中，用户通过编辑表单修改任务信息时调用此服务端逻辑。该逻辑支持更新任务的标题、描述、分配用户、截止日期和任务状态，实现任务信息的动态维护和状态跟踪。

### 依赖的枚举、实体

- **数据建模-枚举-任务状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-待办任务**：[办公自动化-实体-待办任务（TodoTask）](specs/001-bootdo-management-system/plan/data-model/entity-TodoTask.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无外部能力依赖