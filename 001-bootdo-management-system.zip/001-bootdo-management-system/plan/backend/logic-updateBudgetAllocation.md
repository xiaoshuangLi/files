# 预算管理-更新预算分配（updateBudgetAllocation）

- **生成时间**：2026-03-25

## 更新预算分配（updateBudgetAllocation）

### 功能概述

更新预算分配功能用于修改已存在的预算分配记录，支持财务管理人员对预算分配的金额、状态和说明等信息进行调整。该功能确保预算分配数据的准确性和时效性，满足企业在预算执行过程中因业务变化而需要调整预算额度的实际需求。通过此功能，用户可以在预算分配列表中选择特定记录进行编辑，系统会验证修改后的数据有效性，并在保存时更新数据库中的预算分配信息，同时保持完整的审计跟踪记录。

### 功能要点

- **预算分配数据编辑**：当财务管理人员在预算分配列表页面点击编辑按钮时，系统应打开包含预算周期、预算类型、目标部门、分配金额、预算状态和分配说明字段的预算分配编辑表单，表单中应预填充原始数据。用户可以修改分配金额（必须为正数且不超过可用预算额度）和预算状态（从计划中、已批准、执行中、已完成、已调整中选择），系统在保存时验证数据有效性并更新数据库记录。

### 逻辑签名

```naturalts path="app.logics.updateBudgetAllocation.ts"
$Logic({
    description: '更新预算分配记录',
    directory: 'budget_management(预算管理)',
    transactional: true
})
export declare function updateBudgetAllocation(budgetAllocation: app.dataSources.defaultDS.entities.BudgetAllocation): app.dataSources.defaultDS.entities.BudgetAllocation;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| budgetAllocation | 预算分配实体 | app.dataSources.defaultDS.entities.BudgetAllocation | 包含更新后的预算分配信息，包括id、budgetTypeId、budgetCycleId、amount、allocatedById、status、allocatedAt等字段 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 更新结果 | app.dataSources.defaultDS.entities.BudgetAllocation | 更新后的预算分配实体，包含完整的字段信息和更新时间戳 |

### 被前端调用

- **预算分配（budgetAllocation）**：在预算分配页面中，当用户点击编辑按钮并提交修改后的表单时，前端调用此服务端逻辑来更新预算分配记录，实现预算分配数据的编辑功能。

### 依赖的枚举、实体

- **数据建模-枚举-预算状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-预算分配**：[预算管理-实体-预算分配（BudgetAllocation）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetAllocation.md)
- **数据建模-实体-预算类型**：[预算管理-实体-预算类型（BudgetType）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetType.md)
- **数据建模-实体-预算周期**：[预算管理-实体-预算周期（BudgetCycle）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetCycle.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无匹配内容

