# 通用领域服务-查询回收记录列表（queryRecyclingRecords）

- **生成时间**：2026-03-25

## 查询回收记录列表（queryRecyclingRecords）

### 功能概述

查询回收记录列表服务端逻辑提供环保管理模块中回收记录数据的分页查询功能，支持用户根据多种条件筛选和排序回收记录。该功能允许用户按回收物品类型、回收日期范围、部门ID和合规状态等维度进行精确查询，并支持按回收数量、回收日期等字段进行排序。系统会根据用户提供的查询条件从数据库中检索符合条件的回收记录，并以分页形式返回结果，每页包含指定数量的记录。返回的数据包括回收记录的基本信息，如回收物品类型、回收数量、回收日期、处理方式、回收单位、合规状态等关键字段，以及关联的环境监测数据，为用户提供全面的回收活动视图。

### 功能要点

- **多条件组合查询与分页**：支持用户根据回收物品类型、回收日期范围（起始日期和结束日期）、部门ID以及合规状态等多种条件组合筛选回收记录数据。系统采用高效的数据库查询机制，确保在大数据量场景下的查询性能。查询结果以分页形式返回，支持自定义每页记录数和当前页码，避免一次性加载过多数据导致的性能问题。同时支持按回收数量、回收日期等关键字段进行升序或降序排序，满足用户不同的数据分析需求。

### 逻辑签名

```naturalts path="app.logics.queryRecyclingRecords.ts"
@Operation({
    title: "查询回收记录列表",
    directory: "environmental_management(环保管理)"
})
export declare function queryRecyclingRecords(
    /**
     * 部门ID，用于筛选特定部门的回收记录
     */
    departmentId?: Integer,
    
    /**
     * 回收物品类型，用于按类型筛选回收记录
     */
    wasteType?: String,
    
    /**
     * 回收日期范围起始时间，用于按时间范围查询
     */
    startDate?: Date,
    
    /**
     * 回收日期范围结束时间，用于按时间范围查询
     */
    endDate?: Date,
    
    /**
     * 合规状态，用于筛选不同合规状态的回收记录
     */
    complianceStatus?: app.enums.ComplianceStatusEnum,
    
    /**
     * 分页参数 - 当前页码
     */
    page?: Integer = 1,
    
    /**
     * 分页参数 - 每页记录数
     */
    pageSize?: Integer = 10,
    
    /**
     * 排序字段
     */
    sortBy?: String = "createdTime",
    
    /**
     * 排序方向 (asc/descending)
     */
    sortDirection?: String = "descending"
): { 
    /**
     * 回收记录列表
     */
    records: List<{
        /**
         * 回收记录ID
         */
        id: Integer,
        
        /**
         * 回收物品类型
         */
        wasteType: String,
        
        /**
         * 回收数量
         */
        quantity: Decimal,
        
        /**
         * 回收日期
         */
        recyclingDate: Date,
        
        /**
         * 处理方式
         */
        treatmentMethod: String,
        
        /**
         * 回收单位
         */
        recyclingUnit: String,
        
        /**
         * 合规状态
         */
        complianceStatus: app.enums.ComplianceStatusEnum,
        
        /**
         * 关联的环境监测ID
         */
        monitoringId: Integer,
        
        /**
         * 创建时间
         */
        createdTime: DateTime,
        
        /**
         * 更新时间
         */
        updatedTime: DateTime
    }>,
    
    /**
     * 总记录数
     */
    total: Integer,
    
    /**
     * 当前页码
     */
    currentPage: Integer,
    
    /**
     * 总页数
     */
    totalPages: Integer 
};
```

### 被前端调用

- **回收记录（recyclingRecord）**：在回收记录功能页面中，用户进入页面或执行查询操作时调用此服务端逻辑，根据用户输入的查询条件（包括回收物品类型、回收日期范围、部门ID和合规状态）以及分页参数获取回收记录列表数据，并在页面表格中展示，实现回收记录的浏览和筛选功能。

### 依赖的枚举、实体

- **数据建模-枚举-环保合规状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-WasteManagement**：[环保管理-实体-废水管理（WasteManagement）](specs/001-bootdo-management-system/plan/data-model/entity-WasteManagement.md)
- **数据建模-实体-EnvironmentalMonitoring**：[环保管理-实体-环境监测（EnvironmentalMonitoring）](specs/001-bootdo-management-system/plan/data-model/entity-EnvironmentalMonitoring.md)
- **数据建模-实体-OrganizationDepartment**：[系统管理-实体-组织部门（OrganizationDepartment）](specs/001-bootdo-management-system/plan/data-model/entity-OrganizationDepartment.md)

### 依赖的外部能力

无外部能力依赖