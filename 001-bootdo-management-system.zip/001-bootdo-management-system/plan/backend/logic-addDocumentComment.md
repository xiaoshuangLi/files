# 内容管理-添加文档评论（addDocumentComment）

- **生成时间**：2026-03-25

## 添加文档评论（addDocumentComment）

### 功能概述

添加文档评论功能为内容管理系统提供用户对文章内容发表评论的能力。该服务端逻辑接收用户提交的评论内容、关联的文章ID以及评论者身份信息，将评论数据持久化存储到评论互动实体中，并设置初始审核状态为未审核。系统会自动记录评论的创建时间、更新时间和操作者信息，确保评论数据的完整性和可追溯性。该功能支持富文本格式的评论内容，允许用户在评论中使用基本的文本格式化功能，同时与文章内容实体和系统账户实体建立关联关系，保证数据的一致性和完整性。

### 功能要点

- **评论内容验证与存储**：系统接收用户提交的评论请求，首先验证评论内容是否为空或仅包含空白字符，确保评论内容的有效性。验证通过后，系统将评论内容、文章ID、评论者ID等信息封装成评论互动实体对象，并设置初始审核状态为false（未审核），然后将数据持久化存储到数据库中。系统会自动生成唯一的评论ID，并记录评论的创建时间、更新时间以及操作者信息，确保评论数据的完整性和可追溯性。

### 逻辑签名

```naturalts path="app.logics.addDocumentComment.ts"
$Logic({
    description: '添加文档评论',
    directory: 'content_management(内容管理)',
    transactional: true
})
export declare function addDocumentComment(
  articleId: Integer,
  commentContent: String,
  commenterId: Integer
): CommentInteraction;
```

### 被前端调用

- **文章管理（articleContent）**：用户在文章详情页面查看文章内容时，可以通过评论区域提交对文章的评论。系统调用addDocumentComment服务端逻辑，将用户输入的评论内容与当前文章ID、用户ID关联，创建新的评论记录并存储到数据库中。
- **评论管理（commentInteraction）**：系统管理员在评论管理页面点击"添加"按钮时，系统跳转到评论添加表单页面，管理员可以填写系统回复内容并关联到指定文章。提交表单时，系统调用addDocumentComment服务端逻辑创建系统回复评论。

### 依赖的枚举、实体

- **数据建模-实体-评论互动**：[内容管理-实体-评论互动（CommentInteraction）](specs/001-bootdo-management-system/plan/data-model/entity-CommentInteraction.md)
- **数据建模-实体-文章内容**：[内容管理-实体-文章内容（ArticleContent）](specs/001-bootdo-management-system/plan/data-model/entity-ArticleContent.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无