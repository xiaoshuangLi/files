# 内容管理-获取SEO配置（getSeoConfiguration）

- **生成时间**：2026-03-25

## 获取SEO配置（getSeoConfiguration）

### 功能概述

获取SEO配置服务端逻辑用于从数据库中查询指定内容的搜索引擎优化配置信息。该逻辑支持根据内容ID和内容类型检索对应的SEO参数，包括自定义URL路径、Meta标题、Meta描述和关键词等核心SEO元素。通过此逻辑，前端页面能够获取到已保存的SEO配置数据，用于展示当前配置状态或进行编辑操作。逻辑还支持处理不存在SEO配置的情况，返回默认的空配置对象，确保前端界面的正常渲染和交互。

### 功能要点

- **SEO配置查询**：根据内容ID和内容类型精确查询对应的SEO配置记录，确保返回的数据与请求的内容完全匹配。当指定内容存在SEO配置时，返回完整的配置信息；当不存在配置时，返回包含默认空值的配置对象，保证前端界面的一致性体验。
- **内容类型支持**：支持多种内容类型的SEO配置查询，包括文章、栏目等不同内容实体。逻辑能够正确识别内容类型，并从相应的关联关系中获取正确的SEO配置数据，确保不同类型内容的SEO参数都能被准确检索。
- **性能优化**：通过数据库索引优化查询性能，确保在大量内容数据的情况下仍能快速响应SEO配置查询请求。逻辑采用高效的查询策略，只加载必要的字段数据，减少不必要的数据传输和处理开销。

### 逻辑签名

```naturalts path="app.logics.getSeoConfiguration.ts"
$Logic({
    description: '获取指定内容的SEO配置信息',
    directory: 'content_management(内容管理)'
})
export declare function getSeoConfiguration(contentId: Integer, contentType: String): app.dataSources.defaultDS.entities.SeoOptimization;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| contentId | 内容ID | Integer | 要查询SEO配置的内容ID |
| contentType | 内容类型 | String | 内容类型，如文章、栏目等 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | SEO配置 | app.dataSources.defaultDS.entities.SeoOptimization | 指定内容的SEO配置信息，包含自定义URL、Meta标题、Meta描述和关键词等字段 |

### 被前端调用

- **SEO优化（seoOptimization）**：在SEO优化页面加载时，前端调用此服务端逻辑获取指定内容的当前SEO配置信息，用于填充配置表单和显示预览效果。

### 依赖的枚举、实体

- **数据建模-实体-SEO优化**：[内容管理-实体-SeoOptimization（SeoOptimization）](specs/001-bootdo-management-system/plan/data-model/entity-SeoOptimization.md)
- **数据建模-实体-文章内容**：[内容管理-实体-文章内容（ArticleContent）](specs/001-bootdo-management-system/plan/data-model/entity-ArticleContent.md)

### 依赖的外部能力
