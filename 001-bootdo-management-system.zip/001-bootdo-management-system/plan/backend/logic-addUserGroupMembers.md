# 系统管理-添加用户组成员（addUserGroupMembers）

- **生成时间**：2026-03-25

## 添加用户组成员（addUserGroupMembers）

### 功能概述

添加用户组成员服务端逻辑用于将一个或多个系统账户用户批量添加到指定的用户组中。该功能支持权限中心的用户组管理模块，允许管理员高效地为用户组分配成员，实现基于团队的权限管理和工作流任务分配。通过此接口，系统能够建立用户与用户组之间的多对多关联关系，为后续的批量操作、权限继承和团队协作提供基础支持。该逻辑确保添加过程的数据一致性，验证用户和用户组的有效性，并记录完整的操作审计信息。

### 功能要点

- **批量成员添加功能**：支持一次性将多个系统账户用户添加到指定的用户组中，提高管理员操作效率。系统会验证每个待添加用户的ID是否有效，确保只添加存在的活跃用户。同时验证目标用户组的存在性和激活状态，防止向无效或非激活的用户组添加成员。添加过程中会自动跳过已经存在于该用户组中的用户，避免重复添加，保证数据的唯一性。操作完成后，系统会返回成功添加的用户数量和详细信息，便于管理员确认操作结果。

### 逻辑签名

```naturalts path="app.logics.addUserGroupMembers.ts"
$Logic({
    description: '添加用户组成员',
    directory: 'system_management(系统管理)',
    transactional: true
})
export declare function addUserGroupMembers(
  groupId: Integer,
  userIds: List<Integer>
): {
  successCount: Integer;
  addedUsers: List<app.dataSources.defaultDS.entities.SystemAccount>;
};
```

### 被前端调用

- **用户组管理页（userGroupManagement）**：在用户组详情页面中，管理员可以通过成员管理功能选择多个用户并批量添加到当前用户组，实现高效的团队组建和权限分配。

### 依赖的枚举、实体

- **数据建模-实体-用户组**：[系统管理-实体-用户组（UserGroup）](specs/001-bootdo-management-system/plan/data-model/entity-UserGroup.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无