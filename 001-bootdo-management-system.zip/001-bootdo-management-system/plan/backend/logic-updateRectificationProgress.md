# 质量管理-更新整改进度（updateRectificationProgress）

- **生成时间**：2026-03-25

## 更新整改进度（updateRectificationProgress）

### 功能概述

更新整改进度服务端逻辑负责处理整改任务进度信息的修改和更新操作。该逻辑允许授权用户对已存在的整改进度记录进行编辑，包括更新完成百分比、添加或修改进度备注等关键信息。通过此逻辑，系统能够确保整改任务的执行状态得到实时准确的反映，为质量管理人员提供可靠的进度跟踪数据。更新操作会自动记录操作时间和操作人信息，并触发相关的业务规则验证，确保数据的完整性和一致性。此外，该逻辑还支持与整改任务状态的联动更新，当整改进度达到100%时，可以自动将关联的整改任务状态更新为"已完成"，实现业务流程的自动化处理。

### 功能要点

- **整改进度信息更新**：支持对整改进度记录的核心字段进行更新，包括完成百分比（0-100之间的整数）和进度备注（文本描述）。完成百分比的更新必须符合业务规则，不能超过100%或低于0%，确保数据的有效性。进度备注字段支持富文本格式，允许用户详细描述当前整改的具体进展、遇到的问题或下一步计划，为后续的质量分析提供详细依据。

- **数据完整性与一致性保障**：在更新整改进度时，系统会自动维护创建时间、更新时间、创建人和更新人等审计字段，确保数据的可追溯性。同时，系统会验证整改任务ID的有效性，确保更新的整改进度记录确实关联到一个存在的整改任务。如果关联的整改任务状态为"已取消"，则禁止更新其整改进度，防止无效数据的产生。

- **业务流程自动化联动**：当整改进度的完成百分比被更新为100%时，系统会自动检查关联的整改任务状态。如果整改任务状态不是"已完成"或"已取消"，则自动将其状态更新为"已完成"，并记录完成时间。这种自动化联动机制减少了人工操作，提高了业务流程的执行效率，确保整改任务能够及时闭环。

### 逻辑签名

```naturalts path="app.logics.updateRectificationProgress.ts"
$Logic({
    description: '更新整改进度',
    directory: 'quality_management(质量管理)',
    transactional: true
})
export declare function updateRectificationProgress(rectificationProgress: app.dataSources.defaultDS.entities.RectificationProgress): app.dataSources.defaultDS.entities.RectificationProgress;
```

### 被前端调用

- **整改进度（rectificationProgress）**：在整改进度页面中，用户可以通过编辑按钮进入整改进度编辑表单，修改完成百分比和进度备注信息。提交表单后，前端调用此服务端逻辑来更新整改进度记录，并在更新成功后刷新页面显示最新的进度信息。

### 依赖的枚举、实体

- **数据建模-实体-整改进度**：[质量管理-实体-整改进度（RectificationProgress）](specs/001-bootdo-management-system/plan/data-model/entity-RectificationProgress.md)
- **数据建模-实体-整改任务**：[质量管理-实体-整改任务（RectificationTask）](specs/001-bootdo-management-system/plan/data-model/entity-RectificationTask.md)
- **数据建模-枚举-任务状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)

### 依赖的外部能力

无