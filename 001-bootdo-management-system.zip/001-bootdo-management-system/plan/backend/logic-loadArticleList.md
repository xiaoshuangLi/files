# 内容管理-加载文章列表（loadArticleList）

- **生成时间**：2026-03-25

## 加载文章列表（loadArticleList）

### 功能概述

加载文章列表服务端逻辑提供博客文章的分页查询功能，支持按标题、作者、文章状态等条件进行过滤搜索，并返回文章列表及其关联的作者信息。该逻辑是文章管理页面的核心数据支撑，确保用户能够高效地浏览、搜索和管理所有文章内容。系统支持完整的分页机制，包括页码、每页条数、排序字段和排序顺序的控制，满足大规模文章数据的展示需求。通过与系统账户实体的关联，返回的文章列表包含完整的作者信息，便于在前端展示。

### 功能要点

- **分页查询功能**：支持标准的分页参数（页码、每页条数），能够高效处理大量文章数据的分页展示，避免一次性加载过多数据导致性能问题。系统根据传入的分页参数计算总记录数和当前页的数据列表，确保分页导航的准确性。
- **多条件搜索过滤**：支持基于文章标题、作者姓名和文章状态的复合条件搜索。用户可以在前端输入关键词，系统会在标题、作者和内容字段中进行模糊匹配，同时结合文章状态进行精确过滤，提供精准的搜索结果。
- **排序控制**：支持按指定字段（如创建时间、更新时间、标题等）和排序方向（升序或降序）对文章列表进行排序，满足用户不同的浏览习惯和业务需求。
- **关联数据获取**：在返回文章列表的同时，自动关联获取作者的详细信息（来自系统账户实体），减少前端多次请求的开销，提升用户体验。

### 逻辑签名

```naturalts path="app.logics.loadArticleList.ts"
$Logic({
    description: '加载文章列表',
    directory: 'content_management(内容管理)'
})
export declare function loadArticleList(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.ArticleContent): { list: List<{ article: app.dataSources.defaultDS.entities.ArticleContent, author: app.dataSources.defaultDS.entities.SystemAccount }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 当前页码，从1开始 |
| size | 每页条数 | Integer | 每页显示的文章数量 |
| sort | 排序字段 | String | 排序的字段名，如"createdTime"、"title"等 |
| order | 排序顺序 | String | 排序顺序，"asc"表示升序，"desc"表示降序 |
| filter | 过滤条件 | app.dataSources.defaultDS.entities.ArticleContent | 过滤条件对象，包含标题、作者ID、状态等搜索条件 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 文章列表 | List<{ article: app.dataSources.defaultDS.entities.ArticleContent, author: app.dataSources.defaultDS.entities.SystemAccount }> | 文章列表，每个列表项包含文章实体和对应的作者实体 |
| total | 总条数 | Integer | 符合过滤条件的文章总数 |

### 被前端调用

- **文章管理（articleManagement）**：文章管理页面在初始化时调用此服务端逻辑加载文章列表，支持分页、搜索和排序功能。用户在搜索框中输入关键词或选择筛选条件后，页面会重新调用此逻辑获取匹配的文章数据，并在表格中展示标题、作者、类型、状态、创建时间等信息。

### 依赖的枚举、实体

- **数据建模-枚举-文章状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-文章内容**：[内容管理-实体-文章内容（ArticleContent）](specs/001-bootdo-management-system/plan/data-model/entity-ArticleContent.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无匹配内容

