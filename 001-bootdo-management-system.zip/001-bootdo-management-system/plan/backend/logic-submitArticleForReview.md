# 内容管理-提交文章审核（submitArticleForReview）

- **生成时间**：2026-03-25

## 提交文章审核（submitArticleForReview）

### 功能概述

提交文章审核服务端逻辑实现内容管理系统中文章从草稿状态变更为待审核状态的核心业务功能。该逻辑负责验证文章当前状态是否为草稿、更新文章状态为待审核、记录状态变更时间戳，并触发后续的审核工作流流程。通过此逻辑，内容创作者可以将完成撰写的文章提交给具有审核权限的用户进行内容质量、合规性和准确性审查，确保发布内容符合企业标准和规范要求。

### 功能要点

- **状态验证与转换**：严格验证文章当前状态必须为草稿（Draft）状态，防止对已处于审核中、已发布或已归档状态的文章重复提交审核。成功验证后，将文章状态原子性地更新为待审核（PendingReview）状态，确保状态转换的一致性和完整性。
- **审核流程触发**：在文章状态成功更新为待审核后，自动触发工作流引擎的审核流程，将审核任务分配给预设的审核角色或用户组。系统会根据文章所属栏目、内容类型等属性智能匹配相应的审核策略和审批路径。
- **通知机制集成**：通过邮件服务向相关审核人员发送文章审核通知，包含文章标题、作者信息、提交时间等关键信息，并提供直接跳转到审核页面的链接。同时，系统也会向文章作者发送提交成功的确认通知，提升用户体验。
- **审计日志记录**：完整记录文章状态变更的操作日志，包括操作用户、操作时间、原状态、新状态等信息，为后续的内容审计和问题追溯提供数据支持。所有状态变更都遵循不可逆原则，确保内容管理的合规性。

### 逻辑签名

```naturalts path="app.logics.submitArticleForReview.ts"
$Logic({
    description: '提交文章进行审核',
    directory: 'content_management(内容管理)',
    transactional: true
})
export declare function submitArticleForReview(articleId: Integer): app.dataSources.defaultDS.entities.ArticleContent;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| articleId | 文章ID | Integer | 需要提交审核的文章主键ID |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 更新后的文章实体 | app.dataSources.defaultDS.entities.ArticleContent | 状态已更新为待审核的文章实体，包含完整的文章信息 |

### 被前端调用

- **文章管理（articleContent）**：在文章编辑页面，用户点击"提交审核"按钮时调用此服务端逻辑，将文章状态从草稿变更为待审核，触发工作流引擎的审核流程。

### 依赖的枚举、实体

- **数据建模-枚举-文章状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-文章内容**：[内容管理-实体-文章内容（ArticleContent）](specs/001-bootdo-management-system/plan/data-model/entity-ArticleContent.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无匹配内容

