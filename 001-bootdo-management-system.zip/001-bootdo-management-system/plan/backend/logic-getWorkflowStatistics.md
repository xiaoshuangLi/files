# 工作流引擎-获取流程统计信息（getWorkflowStatistics）

- **生成时间**：2026-03-25

## 获取流程统计信息（getWorkflowStatistics）

### 功能概述

获取流程统计信息服务端逻辑提供对工作流引擎中流程实例执行情况的全面统计分析能力。该逻辑能够根据指定的时间范围、流程定义ID等条件，计算并返回各类关键指标数据，包括流程实例总数、已完成实例数、进行中实例数、平均处理时长、超时实例比例等。这些统计数据为管理员评估流程效率、识别瓶颈环节、优化业务流程提供了数据支撑。同时，该逻辑还支持按部门、用户角色等维度进行分组统计，满足不同层级管理者的分析需求，帮助提升整体工作流管理水平和业务运营效率。

### 功能要点

- **多维度统计分析**：支持按时间范围、流程定义、部门、用户角色等多个维度对流程实例执行情况进行统计分析，提供灵活的数据查询能力。系统能够根据用户指定的筛选条件，自动聚合相关数据并计算各项关键指标，包括流程实例总数、状态分布、处理效率等，为管理者提供全面的流程运行视图。
- **关键指标计算**：自动计算流程执行的关键性能指标，包括平均处理时长、超时实例比例、节点流转效率等。这些指标基于流程实例的实际执行数据进行精确计算，能够客观反映流程的执行效率和健康状况，帮助识别潜在的流程瓶颈和优化点。
- **实时数据更新**：确保统计数据的实时性和准确性，每次调用都会基于最新的流程实例数据进行计算。系统会自动同步工作流引擎中的最新状态变更，保证统计结果能够真实反映当前的流程执行情况，为决策提供可靠依据。

### 逻辑签名

```naturalts path="app.logics.getWorkflowStatistics.ts"
$Logic({
    description: '获取流程统计信息',
    directory: 'workflow_engine(工作流引擎)'
})
export declare function getWorkflowStatistics(startDate?: DateTime, endDate?: DateTime, definitionId?: Integer, departmentId?: Integer, roleId?: Integer): { 
  totalInstances: Integer,
  completedInstances: Integer,
  activeInstances: Integer,
  averageProcessingTime: Decimal,
  timeoutRate: Decimal,
  instanceDistribution: List<{ status: String, count: Integer }>
};
```

### 被前端调用

- **通用业务模块-流程监控（processMonitoring）**：流程监控页面调用此服务端逻辑获取流程统计信息，用于展示流程实例的整体运行状况和关键性能指标。页面通过传递时间范围、流程定义ID等参数，获取对应的统计数据并在图表和表格中进行可视化展示，帮助管理员全面了解工作流执行效率。

### 依赖的枚举、实体

- **工作流引擎-实体-流程实例**：[工作流引擎-实体-流程实例（ProcessInstance）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessInstance.md)
- **系统管理-实体-组织部门**：[系统管理-实体-组织部门（OrganizationDepartment）](specs/001-bootdo-management-system/plan/data-model/entity-OrganizationDepartment.md)
- **系统管理-实体-用户角色**：[系统管理-实体-用户角色（UserRole）](specs/001-bootdo-management-system/plan/data-model/entity-UserRole.md)

### 依赖的外部能力

无