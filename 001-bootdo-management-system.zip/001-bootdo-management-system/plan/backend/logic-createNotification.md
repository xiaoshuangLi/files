# 办公自动化-创建通知（createNotification）

- **生成时间**：2026-03-25

## 创建通知（createNotification）

### 功能概述

创建通知服务端逻辑用于在系统中创建和发送各类通知消息，包括系统公告、业务提醒、审批通知等。该逻辑支持向指定用户、部门或角色发送消息，并允许设置消息的优先级、有效期、置顶状态等属性。通过调用此逻辑，系统可以自动或由管理员手动触发消息的创建和分发流程，确保重要信息能够及时传达给目标接收者。消息内容支持富文本格式和附件关联，满足不同场景的信息传达需求。创建成功后，该逻辑会返回完整的通知消息实体，包含系统自动生成的ID和其他元数据信息。

### 功能要点

- **消息创建与分发**：支持创建包含标题、内容、发送者、接收者等完整信息的通知消息，并根据接收者类型（用户、部门、角色）进行精准分发。系统会自动处理接收者的解析和消息的批量创建，确保每个目标接收者都能收到独立的消息实例，便于后续的阅读状态跟踪和管理。
- **消息属性配置**：允许灵活配置消息的各种属性，包括消息类型（如系统公告、业务提醒、审批通知等）、优先级（影响展示顺序和提醒方式）、是否置顶、有效时间范围等。这些属性确保消息能够按照业务需求进行分类管理和差异化展示，提升用户体验和消息处理效率。
- **状态跟踪与回执**：创建的消息默认设置为未读状态，并记录发送时间。系统会自动跟踪消息的阅读状态，当接收者查看消息时更新已读状态和阅读时间。这种状态跟踪机制帮助管理者确认消息的接收效果，确保重要信息不会被遗漏。

### 逻辑签名

```naturalts path="app.logics.createNotification.ts"
$Logic({
    description: '创建通知消息',
    directory: 'office_automation(办公自动化)',
    transactional: true
})
export declare function createNotification(notification: app.dataSources.defaultDS.entities.NotificationMessageEntity): app.dataSources.defaultDS.entities.NotificationMessageEntity;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| notification | 通知消息实体 | app.dataSources.defaultDS.entities.NotificationMessageEntity | 包含消息标题、内容、发送者、接收者类型、接收者ID、消息类型、优先级等完整信息的通知消息实体 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 创建结果 | app.dataSources.defaultDS.entities.NotificationMessageEntity | 补充了id、创建时间等系统字段的完整通知消息实体 |

### 被前端调用

- **通知公告（noticeAnnouncement）**：在通知公告页面中，管理员使用此服务端逻辑创建新的系统公告或业务通知，设置接收范围、优先级和有效期等属性，实现消息的精准推送。
- **个人门户（personalWorkspace）**：在个人门户中，系统自动调用此服务端逻辑创建待办任务提醒、审批状态变更通知等个人相关消息，确保用户能够及时获知重要业务动态。
- **审批流程（approvalWorkflow）**：在审批流程模块中，当审批状态发生变化时，系统调用此服务端逻辑向相关审批人或申请人发送审批通知，保持审批流程的透明度和及时性。

### 依赖的枚举、实体

- **数据建模-实体-通知消息**：[办公自动化-实体-通知消息（NotificationMessageEntity）](specs/001-bootdo-management-system/plan/data-model/entity-NotificationMessageEntity.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无