# 内容管理-删除用户订阅（deleteUserSubscription）

- **生成时间**：2026-03-25

## 删除用户订阅（deleteUserSubscription）

### 功能概述

删除用户订阅功能允许系统用户取消对特定栏目或文章更新的订阅。该功能主要用于内容管理系统中，使用户能够管理自己的订阅列表，避免接收到不感兴趣的内容更新通知。系统会验证用户身份和订阅权限，确保只有订阅者本人或具有相应管理权限的用户才能执行删除操作，并在成功删除后更新用户的订阅状态。

### 功能要点

- **订阅验证与权限控制**：系统首先验证请求删除订阅的用户身份，确认其是否为该订阅的所有者或具有相应管理权限（如系统管理员、部门管理员）。对于普通用户，只能删除自己创建的订阅；对于管理员，可以删除其管辖范围内的任何用户订阅。系统会检查用户的角色权限，确保操作符合权限控制策略，防止越权操作导致的数据安全问题。

### 逻辑签名

```naturalts path="app.logics.deleteUserSubscription.ts"
$Logic({
    description: '删除用户订阅',
    directory: 'content_management(内容管理)'
})
export declare function deleteUserSubscription(
  subscriptionId: String,
  requesterUserId: String
): Boolean;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| subscriptionId | 订阅ID | String | 要删除的订阅记录ID |
| requesterUserId | 请求用户ID | String | 发起删除请求的用户ID |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 删除结果 | Boolean | 删除操作是否成功 |

### 被前端调用

- **用户订阅（userSubscription）**：用户在订阅管理页面中可以查看自己的所有订阅列表，并通过点击"取消订阅"按钮调用此服务端逻辑来删除不再需要的订阅，实现对个人订阅内容的有效管理。

### 依赖的枚举、实体

- **数据建模-实体-用户订阅**：[办公自动化-实体-用户订阅（UserSubscription）](specs/001-bootdo-management-system/plan/data-model/entity-UserSubscription.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无