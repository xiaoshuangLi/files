# 工作流引擎-更新流程定义（updateWorkflow）

- **生成时间**：2026-03-25

## 更新流程定义（updateWorkflow）

### 功能概述

更新流程定义服务端逻辑提供对现有审批流程配置的修改能力，允许系统管理员在审批流程管理界面中编辑流程的基本信息和详细配置。该逻辑接收包含完整流程定义数据的实体对象，验证数据完整性后更新数据库中的对应记录，并同步更新关联的审批流程实体。通过此逻辑，系统能够确保审批流程配置的实时性和准确性，支持业务流程的动态调整和优化。更新操作会保留原有的流程ID和历史版本信息，同时记录操作审计日志，便于后续的变更追踪和问题排查。

### 功能要点

- **流程配置更新**：系统管理员可以在审批流程编辑界面修改流程名称、描述、BPMN XML定义等核心配置信息，提交后调用此服务端逻辑将更新后的配置持久化到数据库中，确保流程定义的准确性和完整性。
- **数据验证与完整性检查**：在执行更新操作前，服务端逻辑会对输入的流程定义数据进行严格的验证，包括必填字段检查、BPMN XML格式验证、流程名称唯一性校验等，防止无效或错误的数据被保存到系统中。
- **关联数据同步**：当流程定义更新成功后，服务端逻辑会自动同步更新关联的审批流程实体中的相关信息，如流程名称等显示字段，确保前端展示数据的一致性。
- **操作审计与版本控制**：每次更新操作都会记录详细的审计日志，包括操作人、操作时间、变更内容等信息，同时保留历史版本的流程定义，支持版本回溯和对比分析。

### 逻辑签名

```naturalts path="app.logics.updateWorkflow.ts"
$Logic({
    description: '更新流程定义',
    directory: 'workflow_engine(工作流引擎)',
    transactional: true
})
export declare function updateWorkflow(processDefinition: app.dataSources.defaultDS.entities.ProcessDefinition): app.dataSources.defaultDS.entities.ProcessDefinition;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| processDefinition | 流程定义实体 | app.dataSources.defaultDS.entities.ProcessDefinition | 包含更新后的流程定义完整信息的实体对象，必须包含主键ID |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 更新结果 | app.dataSources.defaultDS.entities.ProcessDefinition | 更新后的流程定义实体，包含完整的字段信息 |

### 被前端调用

- **审批流程（approvalProcess）**：系统管理员在审批流程列表中点击编辑按钮后，跳转到审批流程编辑页面，加载现有流程的详细信息并允许修改，提交后调用此服务端逻辑更新审批流程配置。

### 依赖的枚举、实体

- **工作流引擎-实体-流程定义**：[工作流引擎-实体-流程定义（ProcessDefinition）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessDefinition.md)

### 依赖的外部能力

无匹配内容

