# 内容管理-获取可用于订阅的文章（getAvailableArticlesForSubscription）

- **生成时间**：2026-03-25

## 获取可用于订阅的文章（getAvailableArticlesForSubscription）

### 功能概述

该服务端逻辑用于获取系统中可供用户订阅的文章列表。根据用户的订阅偏好和权限设置，筛选出符合条件的文章内容，包括已发布的文章以及用户有权限查看的待审核文章。该功能支持按栏目、发布时间、文章状态等条件进行过滤，并提供分页查询能力，确保在大量文章数据场景下的性能表现。返回结果包含文章的基本信息、作者信息、栏目归属以及是否已被当前用户订阅的状态标识，为前端订阅界面提供完整的数据支持。

### 功能要点

- **文章筛选与过滤**：根据用户ID、栏目ID、文章状态等条件筛选可订阅的文章，确保只返回用户有权限查看且符合订阅条件的文章内容。系统会自动排除草稿状态的文章，除非当前用户是文章作者或具有特殊权限。对于已发布的文章，所有用户均可查看并订阅；对于待审核状态的文章，仅对作者和审核人员可见。筛选逻辑还会考虑用户订阅历史，避免重复推荐已订阅的文章，提升用户体验。

### 逻辑签名

```naturalts path="app.logics.getAvailableArticlesForSubscription.ts"
$Logic({
    description: '获取可用于订阅的文章列表',
    directory: 'content_management(内容管理)'
})
export declare function getAvailableArticlesForSubscription(userId: Integer, page: Integer, size: Integer, columnId?: Integer, status?: List<app.enums.ArticleStatusEnum>): { list: List<{ article: app.dataSources.defaultDS.entities.ArticleContent, author: app.dataSources.defaultDS.entities.SystemAccount, column?: app.dataSources.defaultDS.entities.ColumnStructure, isSubscribed: Boolean }>, total: Integer };
```

### 被前端调用

- **用户订阅（userSubscription）**：在用户订阅页面中，通过调用此服务端逻辑获取可供订阅的文章列表，用户可以从中选择感兴趣的文章进行订阅操作。该功能实现了文章发现和订阅的核心业务流程，提升了用户的内容获取体验。

### 依赖的枚举、实体

- **数据建模-枚举-文章状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-文章内容**：[内容管理-实体-文章内容（ArticleContent）](specs/001-bootdo-management-system/plan/data-model/entity-ArticleContent.md)
- **数据建模-实体-用户订阅**：[办公自动化-实体-用户订阅（UserSubscription）](specs/001-bootdo-management-system/plan/data-model/entity-UserSubscription.md)
- **数据建模-实体-栏目结构**：[内容管理-实体-栏目结构（ColumnStructure）](specs/001-bootdo-management-system/plan/data-model/entity-ColumnStructure.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无