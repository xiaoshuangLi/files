# 权限中心-加载部门数据（loadDepartments）

- **生成时间**：2026-03-25

## 加载部门数据（loadDepartments）

### 功能概述

加载部门数据服务端逻辑用于获取系统中的组织部门信息，支持分页查询、排序和过滤功能。该逻辑是权限中心部门管理模块的基础数据支撑，能够根据不同的查询条件返回部门列表及其总数，满足前端页面对部门数据的展示需求。通过该逻辑，系统可以高效地检索和展示组织架构中的部门信息，包括部门名称、父部门关系等关键属性，并支持按部门名称进行模糊搜索，为用户提供灵活的数据查询能力。

### 功能要点

- **分页查询与排序功能**：提供标准的分页查询接口，支持指定页码(page)和每页条数(size)参数，同时支持按任意字段(sort)和排序方向(order)进行结果排序。该功能确保前端能够高效加载大量部门数据，避免一次性加载过多数据导致性能问题，并允许用户根据需要对部门列表进行排序查看，提升用户体验和数据浏览效率。

### 逻辑签名

```naturalts path="app.logics.loadDepartments.ts"
$Logic({
    description: '加载部门数据',
    directory: 'permission_center(权限中心)'
})
export declare function loadDepartments(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.OrganizationDepartment): { list: List<app.dataSources.defaultDS.entities.OrganizationDepartment>, total: Integer };
```

### 被前端调用

- **部门管理页（departmentManagement）**：部门管理页面通过调用此服务端逻辑获取部门列表数据，用于在页面上以树形或表格形式展示所有部门信息。该逻辑支持分页、排序和过滤功能，使用户能够高效浏览和查找特定部门，是部门管理页面数据展示的核心支撑。

### 依赖的枚举、实体

- **数据建模-实体-组织部门**：[系统管理-实体-组织部门（OrganizationDepartment）](specs/001-bootdo-management-system/plan/data-model/entity-OrganizationDepartment.md)

### 依赖的外部能力

