# 工作流引擎-批量操作审批流程（batchOperateApprovalProcess）

- **生成时间**：2026-03-25

## 批量操作审批流程（batchOperateApprovalProcess）

### 功能概述

批量操作审批流程服务端逻辑提供对多个审批流程定义进行统一管理的能力，支持系统管理员在审批流程列表页面中选择多个流程定义后执行批量启用、批量停用或批量删除等操作。该逻辑确保了工作流引擎中审批流程配置的高效维护，通过一次操作即可对多个流程定义进行状态变更或删除处理，大大提升了系统管理效率。批量操作过程中会进行权限验证和数据完整性检查，确保操作的安全性和一致性，并在操作完成后返回处理结果统计信息。

### 功能要点

- **批量启用审批流程**：系统管理员可以在审批流程列表中选择多个处于停用状态的流程定义，通过调用此服务端逻辑将选中的流程定义批量设置为启用状态，使其能够被业务模块正常调用和使用。
- **批量停用审批流程**：系统管理员可以在审批流程列表中选择多个处于启用状态的流程定义，通过调用此服务端逻辑将选中的流程定义批量设置为停用状态，防止其被新的业务流程实例化使用，同时不影响已存在的流程实例。
- **批量删除审批流程**：系统管理员可以在审批流程列表中选择多个不再需要的流程定义，通过调用此服务端逻辑将选中的流程定义从系统中批量删除，释放存储空间并简化流程管理界面，删除前会检查是否存在关联的流程实例以确保数据完整性。

### 逻辑签名

```naturalts path="app.logics.batchOperateApprovalProcess.ts"
$Logic({
    description: '批量操作审批流程',
    directory: 'workflow_engine(工作流引擎)',
    transactional: true
})
export declare function batchOperateApprovalProcess(processIds: List<Integer>, operationType: String): { successCount: Integer, failedCount: Integer, failedItems: List<{ processId: Integer, reason: String }> };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| processIds | 流程定义ID列表 | List<Integer> | 需要进行批量操作的流程定义ID列表 |
| operationType | 操作类型 | String | 批量操作的类型，可选值为"enable"（启用）、"disable"（停用）、"delete"（删除） |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| successCount | 成功数量 | Integer | 批量操作成功的流程定义数量 |
| failedCount | 失败数量 | Integer | 批量操作失败的流程定义数量 |
| failedItems | 失败项详情 | List<{ processId: Integer, reason: String }> | 操作失败的流程定义ID及失败原因列表 |

### 被前端调用

- **审批流程（approvalProcess）**：系统管理员在审批流程列表页面中选择多个审批流程后，点击批量操作按钮（启用、停用或删除），前端调用此服务端逻辑执行相应的批量操作，实现对多个审批流程定义的统一管理。

### 依赖的枚举、实体

- **数据建模-实体-流程定义**：[工作流引擎-实体-流程定义（ProcessDefinition）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessDefinition.md)

### 依赖的外部能力

无匹配内容

