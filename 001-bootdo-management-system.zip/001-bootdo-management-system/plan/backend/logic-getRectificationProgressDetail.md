# 质量管理-获取整改进度详情（getRectificationProgressDetail）

- **生成时间**：2026-03-25

## 获取整改进度详情（getRectificationProgressDetail）

### 功能概述

获取整改进度详情服务端逻辑是质量管理模块中的核心功能，专门用于查询和返回特定整改进度记录的完整信息。该逻辑通过接收整改进度ID作为参数，从数据库中检索对应的整改进度实体，并关联加载相关的整改任务、质量问题等关联数据，为前端提供全面的整改进度详情视图。此逻辑确保用户能够查看整改进度的完成百分比、进度备注、更新时间等关键信息，同时还能获取到关联的整改任务描述、责任人、状态以及原始质量问题的详细内容，形成完整的整改上下文信息链。通过该逻辑，系统支持对整改过程的精细化跟踪和管理，帮助质量管理人员全面了解整改执行情况，及时发现和解决整改过程中的问题。

### 功能要点

- **整改进度详情查询**：根据提供的整改进度ID，精确查询并返回对应的整改进度记录详情，包括完成百分比、进度备注、创建和更新时间等基本信息。该功能确保用户能够快速定位并查看特定整改进度的详细状态，为后续的整改决策提供准确的数据支持。系统会对输入的ID进行有效性验证，防止无效查询，并在找不到对应记录时返回适当的提示信息。

### 逻辑签名

```naturalts path="app.logics.getRectificationProgressDetail.ts"
$Logic({
    description: '获取整改进度详情',
    directory: 'quality_management(质量管理)'
})
export declare function getRectificationProgressDetail(id: Integer): { 
    rectificationProgress: app.dataSources.defaultDS.entities.RectificationProgress,
    rectificationTask: app.dataSources.defaultDS.entities.RectificationTask,
    qualityIssue: app.dataSources.defaultDS.entities.QualityIssue
};
```

### 被前端调用

- **整改进度（rectificationProgress）**：在整改进度详情页面中，通过调用此服务端逻辑获取指定整改进度ID的完整详情信息，包括整改进度本身的数据、关联的整改任务信息以及原始质量问题详情，用于展示完整的整改上下文信息。

### 依赖的枚举、实体

- **数据建模-实体-整改进度**：[质量管理-实体-整改进度（RectificationProgress）](specs/001-bootdo-management-system/plan/data-model/entity-RectificationProgress.md)
- **数据建模-实体-整改任务**：[质量管理-实体-整改任务（RectificationTask）](specs/001-bootdo-management-system/plan/data-model/entity-RectificationTask.md)
- **数据建模-实体-质量问题**：[质量管理-实体-质量问题（QualityIssue）](specs/001-bootdo-management-system/plan/data-model/entity-QualityIssue.md)

### 依赖的外部能力

无