# 通用领域服务-刷新系统缓存（refreshSystemCache）

- **生成时间**：2026-03-25

## 刷新系统缓存（refreshSystemCache）

### 功能概述

刷新系统缓存服务端逻辑用于清除系统中的所有缓存数据，确保配置变更、数据更新等操作能够立即生效。该功能主要面向系统管理员，在修改全局配置参数、更新系统设置或进行系统维护后调用，以保证系统各模块能够获取到最新的数据状态。缓存刷新操作会清理包括配置缓存、权限缓存、数据字典缓存、用户会话缓存等多种类型的缓存数据，确保系统的一致性和实时性。该逻辑执行时会记录详细的操作日志，便于后续的审计和问题排查。

### 功能要点

- **缓存清理范围**：刷新系统缓存功能需要清理系统中所有类型的缓存数据，包括但不限于全局配置缓存、权限策略缓存、数据字典缓存、用户会话缓存、菜单导航缓存等。确保所有缓存数据被彻底清除，使系统各模块在下次请求时能够重新加载最新的数据，保证系统状态的一致性和准确性。缓存清理过程需要保证原子性，避免部分缓存清理成功而部分失败导致的数据不一致问题。

### 逻辑签名

```naturalts path="app.logics.refreshSystemCache.ts"
$Logic({
    description: '刷新系统缓存',
    directory: 'system_management(系统管理)'
})
export declare function refreshSystemCache(): Boolean;
```

### 被前端调用

- **系统参数配置（systemParameterConfiguration）**：在系统参数配置页面中，管理员完成配置参数的修改后，通过点击缓存刷新按钮调用此服务端逻辑，确保配置变更能够立即生效，无需重启系统服务。

### 依赖的枚举、实体

- **数据建模-实体-全局配置**：[系统管理-实体-全局配置（GlobalConfiguration）](specs/001-bootdo-management-system/plan/data-model/entity-GlobalConfiguration.md)

### 依赖的外部能力

无外部能力依赖