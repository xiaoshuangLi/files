# 通用领域服务-删除分包商付款（deleteSubcontractorPayment）

- **生成时间**：2026-03-25

## 删除分包商付款（deleteSubcontractorPayment）

### 功能概述

该服务端逻辑用于处理分包商付款记录的删除操作，确保系统中分包商付款管理数据的准确性和完整性。当用户需要移除错误录入或已作废的分包商付款记录时，通过此接口执行删除操作。系统会验证当前用户是否具有删除分包商付款的权限，并检查待删除的付款记录是否存在关联的财务凭证或其他依赖数据。如果存在依赖关系，系统将阻止删除操作并返回相应的错误信息，以防止数据不一致。成功删除后，系统会记录操作日志，包括操作人、操作时间和被删除的付款记录详情，以便后续审计和追踪。

### 功能要点

- **权限验证与数据完整性保护**：系统在执行删除操作前，首先验证当前用户是否具有删除分包商付款记录的权限，通常仅限于系统管理员、部门管理员或具有特定付款管理权限的角色。同时，系统会检查待删除的付款记录是否存在关联的财务凭证、合同结算或其他业务数据。如果存在依赖关系，系统将拒绝删除请求并返回明确的错误提示，确保数据完整性和业务流程的连续性，防止因误删导致的财务数据不一致问题。

### 逻辑签名

```naturalts path="app.logics.deleteSubcontractorPayment.ts"
$Logic({
    description: '删除分包商付款记录',
    directory: 'subcontractor_management(分包商管理)'
})
export declare function deleteSubcontractorPayment(paymentId: String, operatorId: String): Boolean;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| paymentId | 分包商付款记录ID | String | 要删除的分包商付款记录的唯一标识符 |
| operatorId | 操作人ID | String | 执行删除操作的用户ID |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 删除结果 | Boolean | 删除操作是否成功，true表示成功，false表示失败 |

### 被前端调用

- **通用业务模块-付款管理（paymentManagement）**：在付款管理页面中，用户可以通过操作按钮触发删除分包商付款记录的功能。该页面调用此服务端逻辑来执行实际的删除操作，实现对错误或无效付款记录的清理，确保付款数据的准确性。

### 依赖的枚举、实体

- **数据建模-实体-分包商付款**：[分包商管理-实体-分包商付款（SubcontractorPayment）](specs/001-bootdo-management-system/plan/data-model/entity-SubcontractorPayment.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

[文件内部已经提供，无需进行生成。如果文件内部已经有 `依赖的外部能力` 内容，禁止修改或删除文件内的 `依赖的外部能力` 内容]