# 薪资管理-查询薪资结构列表（querySalaryStructureList）

- **生成时间**：2026-03-25

## 查询薪资结构列表（querySalaryStructureList）

### 功能概述

查询薪资结构列表服务端逻辑用于获取系统中所有薪资结构的分页数据，支持按人员配置ID、生效日期范围等条件进行筛选。该逻辑为前端薪资结构定义页面提供数据支撑，允许用户查看、搜索和筛选薪资结构记录。通过该逻辑，系统能够高效地返回薪资结构的基本信息，包括基本工资、奖金、津贴等组成部分，以及关联的人员配置信息。该逻辑还支持按指定字段进行排序，确保用户能够按照业务需求组织数据展示顺序，提高薪资管理的效率和用户体验。

### 功能要点

- **分页查询功能**：支持标准的分页查询机制，接收页码(page)和每页条数(size)参数，返回指定页的数据和总记录数，避免一次性加载过多数据导致性能问题。
- **多条件筛选功能**：支持按人员配置ID(personnelId)精确匹配、按生效日期范围(effectiveFromStart和effectiveFromEnd)进行筛选，满足不同场景下的查询需求。
- **排序功能**：支持按任意字段(sort)和排序方向(order)对结果进行排序，默认按创建时间降序排列，确保最新创建的薪资结构优先显示。
- **关联数据查询**：在返回薪资结构数据的同时，关联查询对应的人员配置信息，包括人员姓名、岗位等基本信息，为用户提供完整的上下文信息。
- **权限控制集成**：与系统权限中心集成，确保只有具有薪资管理相关权限的用户才能访问薪资结构数据，保障敏感薪资信息的安全性。

### 逻辑签名

```naturalts path="app.logics.querySalaryStructureList.ts"
$Logic({
    description: '查询薪资结构列表',
    directory: 'salary_management(薪资管理)'
})
export declare function querySalaryStructureList(page: Integer, size: Integer, sort: String, order: String, personnelId?: Integer, effectiveFromStart?: Date, effectiveFromEnd?: Date): { list: List<{ salaryStructure: app.dataSources.defaultDS.entities.SalaryStructure, personnelConfiguration: app.dataSources.defaultDS.entities.PersonnelConfiguration }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 分页查询的页码，从1开始 |
| size | 每页条数 | Integer | 每页返回的记录数量 |
| sort | 排序字段 | String | 用于排序的字段名称 |
| order | 排序顺序 | String | 排序方向，asc表示升序，desc表示降序 |
| personnelId | 人员配置ID | Integer? | 筛选条件：关联的人员配置ID |
| effectiveFromStart | 生效日期开始 | Date? | 筛选条件：薪资结构生效日期的起始日期 |
| effectiveFromEnd | 生效日期结束 | Date? | 筛选条件：薪资结构生效日期的结束日期 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 薪资结构列表 | List<{ salaryStructure: app.dataSources.defaultDS.entities.SalaryStructure, personnelConfiguration: app.dataSources.defaultDS.entities.PersonnelConfiguration }> | 薪资结构列表，每个列表项包含薪资结构实体和关联的人员配置实体 |
| total | 总记录数 | Integer | 符合查询条件的总记录数 |

### 被前端调用

- **薪资结构定义（salaryStructure）**：薪资结构定义页面通过调用此服务端逻辑获取薪资结构列表数据，用于在表格中展示所有薪资结构记录。用户可以通过页面上的筛选条件和分页控件与该逻辑交互，实现数据的动态加载和筛选。

### 依赖的枚举、实体

- **数据建模-实体-薪资结构**：[薪资管理-实体-薪资结构（SalaryStructure）](specs/001-bootdo-management-system/plan/data-model/entity-SalaryStructure.md)
- **数据建模-实体-人员配置**：[分包商管理-实体-人员配置（PersonnelConfiguration）](specs/001-bootdo-management-system/plan/data-model/entity-PersonnelConfiguration.md)

### 依赖的外部能力

无外部能力依赖