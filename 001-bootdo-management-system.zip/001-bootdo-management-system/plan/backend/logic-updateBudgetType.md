# 预算管理-更新预算类型（updateBudgetType）

- **生成时间**：2026-03-25

## 更新预算类型（updateBudgetType）

### 功能概述

更新预算类型功能用于修改已存在的预算类型信息，是预算管理系统的基础数据维护操作之一。该功能允许预算管理人员对预算类型的名称和描述进行修改，确保预算分类标准能够随着业务需求的变化而及时调整。通过此功能，系统能够保持预算类型数据的准确性和时效性，为后续的预算分配、执行监控等业务流程提供可靠的基础数据支持。

### 功能要点

- **预算类型信息更新**：预算管理人员可以修改预算类型的名称和描述信息，系统会验证类型名称的唯一性，防止重复的预算类型名称导致数据混乱。更新操作会自动记录更新时间和更新人信息，确保数据变更的可追溯性。

### 逻辑签名

```naturalts path="app.logics.updateBudgetType.ts"
$Logic({
    description: '更新预算类型',
    directory: 'budget_management(预算管理)',
    transactional: true
})
export declare function updateBudgetType(budgetType: app.dataSources.defaultDS.entities.BudgetType): app.dataSources.defaultDS.entities.BudgetType;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| budgetType | 预算类型实体 | app.dataSources.defaultDS.entities.BudgetType | 包含要更新的预算类型完整信息，包括ID、类型名称、描述等字段 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 更新后的预算类型 | app.dataSources.defaultDS.entities.BudgetType | 返回更新后的完整预算类型实体，包含更新后的所有字段信息 |

### 被前端调用

- **预算类型管理（budgetType）**：在预算类型管理页面中，当用户编辑预算类型并点击保存按钮时，系统会调用此服务端逻辑来更新预算类型信息，实现预算类型数据的修改功能。

### 依赖的枚举、实体

- **数据建模-实体-预算类型**：[预算管理-实体-预算类型（BudgetType）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetType.md)

### 依赖的外部能力

无匹配内容

