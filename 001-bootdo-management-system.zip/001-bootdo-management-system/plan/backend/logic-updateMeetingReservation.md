# 通用领域服务-更新会议预约（updateMeetingReservation）

- **生成时间**：2026-03-25

## 更新会议预约（updateMeetingReservation）

### 功能概述

更新会议预约服务端逻辑用于修改已存在的会议预约信息，包括会议主题、开始时间、结束时间、参会人员、会议室、会议描述等基本信息。该功能允许用户在会议开始前对预约内容进行调整，确保会议安排的灵活性和准确性。系统会验证更新后的会议时间是否与其他已预约的会议冲突，并在必要时通知相关参会人员会议变更信息。

### 功能要点

- **会议信息更新**：允许用户修改会议的基本信息，包括会议主题、开始时间、结束时间、会议室、会议描述等内容。系统会对输入的数据进行完整性验证，确保必填字段不为空，时间格式正确，且结束时间晚于开始时间。同时，系统会检查更新后的会议室在指定时间段是否可用，避免资源冲突。

### 逻辑签名

```naturalts path="app.logics.updateMeetingReservation.ts"
$Logic({
    description: '更新会议预约信息',
    directory: 'schedule_management(日程管理)'
})
export declare function updateMeetingReservation(meetingId: Text, title?: Text, startTime: DateTime, endTime: DateTime, roomId?: Text, attendees?: Array<Text>, description?: Text, status?: Text): { success: Bool, meetingId: Text, info?: Text };
```

### 被前端调用

- **日程管理（scheduleArrangement）**：用户在日程管理模块中可以查看和编辑自己的会议预约，通过调用此服务端逻辑来更新会议信息。
- **会议管理（meetingReservation）**：在专门的会议管理页面中，用户可以对已创建的会议进行详细编辑，包括修改会议时间、地点、参会人员等，这些操作都依赖此服务端逻辑。

### 依赖的枚举、实体

- **数据建模-枚举-会议状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-会议预约**：[办公自动化-实体-会议预约（MeetingReservation）](specs/001-bootdo-management-system/plan/data-model/entity-MeetingReservation.md)
- **数据建模-实体-会议室**：[办公自动化-实体-会议室（MeetingRoom）](specs/001-bootdo-management-system/plan/data-model/entity-MeetingRoom.md)
- **数据建模-实体-用户**：specs/001-bootdo-management-system/plan/data-model/entity-User.md

### 依赖的外部能力