# 质量管理-创建质量指标（createQualityIndicator）

- **生成时间**：2026-03-25

## 创建质量指标（createQualityIndicator）

### 功能概述

该服务端逻辑负责创建新的质量指标记录，支持用户定义质量管理的关键指标参数，包括指标名称、计算公式、目标值、预警阈值等核心属性。创建的质量指标将用于后续的质量监控、分析和报告生成，为质量管理体系提供数据支撑。系统会验证指标参数的完整性和有效性，确保创建的指标符合质量管理规范要求，并自动分配唯一的指标标识符。

### 功能要点

- **指标参数定义**：支持用户完整定义质量指标的各项参数，包括指标中文名称、英文标识符、指标描述、计算公式、计量单位、目标值范围、预警阈值、严重阈值等关键属性。系统提供参数校验机制，确保输入数据的格式正确性和业务逻辑合理性，防止无效或冲突的指标参数被保存到系统中。

### 逻辑签名

```naturalts path="app.logics.createQualityIndicator.ts"
$Logic({
    description: '创建质量指标',
    directory: 'quality_management(质量管理)'
})
export declare function createQualityIndicator(
  name: String,
  code: String,
  description: String,
  formula: String,
  unit: String,
  targetValue: Decimal,
  warningThreshold: Decimal,
  criticalThreshold: Decimal,
  indicatorType: QualityIndicatorType,
  enabled: Boolean
): QualityIndicator;
```

### 被前端调用

- **质量指标（qualityIndicator）**：在质量指标页面中，用户通过创建表单提交新的质量指标信息，调用此服务端逻辑完成指标的创建操作，并在列表中显示新创建的指标记录。

### 依赖的枚举、实体

- **数据建模-枚举-质量指标类型**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-枚举-质量指标状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-质量指标**：[质量管理-实体-质量指标（QualityIndicator）](specs/001-bootdo-management-system/plan/data-model/entity-QualityIndicator.md)

### 依赖的外部能力

无