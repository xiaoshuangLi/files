# 质量管理-创建质量问题（createQualityIssue）

- **生成时间**：2026-03-25

## 创建质量问题（createQualityIssue）

### 功能概述

创建质量问题服务端逻辑是质量管理模块的核心功能，用于在系统中登记和记录新发现的质量问题。该逻辑接收前端提交的质量问题基本信息，包括问题标题、详细描述、报告人ID等必要数据，并自动设置问题的初始状态为"已报告"。系统会为每个质量问题生成唯一的标识符，并记录创建时间和创建者信息。通过该服务端逻辑，企业能够建立标准化的质量问题上报流程，确保所有质量问题都能被及时捕获并进入后续的处理流程，为质量改进提供数据基础。

### 功能要点

- **质量问题数据验证与持久化**：创建质量问题时，系统会对输入数据进行严格验证，确保问题标题和描述等必填字段不为空。验证通过后，系统将质量问题数据持久化到数据库中，并自动生成唯一的问题ID。同时，系统会自动记录问题的创建时间、创建者、报告时间等元数据，确保质量问题数据的完整性和可追溯性。

### 逻辑签名

```naturalts path="app.logics.createQualityIssue.ts"
$Logic({
    description: '创建质量问题',
    directory: 'quality_management(质量管理)',
    transactional: true
})
export declare function createQualityIssue(
  title: String,
  description: String,
  reporterId: Integer
): app.dataSources.defaultDS.entities.QualityIssue;
```

### 被前端调用

- **质量问题登记（qualityIssueRegistration）**：质量问题登记页面通过调用createQualityIssue服务端逻辑来创建新的质量问题记录。用户在表单中填写问题标题、详细描述并选择报告人后，点击保存按钮触发该逻辑，完成质量问题的创建和持久化。
- **质量问题登记（qualityIssue）**：质量问题登记页面在创建模式下使用createQualityIssue服务端逻辑来保存新报告的质量问题。用户填写完问题基本信息后提交表单，系统调用该逻辑完成质量问题的创建。

### 依赖的枚举、实体

- **数据建模-枚举-质量问题状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-质量问题**：[质量管理-实体-质量问题（QualityIssue）](specs/001-bootdo-management-system/plan/data-model/entity-QualityIssue.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无外部能力依赖。创建质量问题服务端逻辑完全基于系统内部的数据模型和业务规则实现，不依赖任何外部系统或第三方服务。