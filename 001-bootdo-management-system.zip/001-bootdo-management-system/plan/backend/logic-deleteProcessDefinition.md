# 工作流引擎-删除流程定义（deleteProcessDefinition）

- **生成时间**：2026-03-25

## 删除流程定义（deleteProcessDefinition）

### 功能概述

删除流程定义服务端逻辑提供对工作流引擎中已存在的流程模板进行永久删除的能力。该功能允许系统管理员移除不再需要或已过时的流程定义，从而保持工作流模型库的整洁性和有效性。删除操作会彻底移除指定的流程定义记录及其相关元数据，包括流程名称、描述和BPMN XML定义等内容。为确保数据一致性，系统在执行删除前会验证流程定义是否存在，并检查是否有正在运行的流程实例依赖于该定义，如有依赖则阻止删除操作以避免业务中断。该服务端逻辑是流程定义全生命周期管理的重要组成部分，与创建、更新、查询等操作共同构成完整的流程模型管理能力。

### 功能要点

- **安全删除验证**：在执行删除操作前，系统会验证指定的流程定义ID是否存在于数据库中，确保不会对不存在的记录执行删除操作；同时检查该流程定义是否有正在运行的流程实例，如果有活跃实例则拒绝删除请求，防止因删除基础模板而导致业务流程执行异常，确保系统数据的一致性和业务连续性。

### 逻辑签名

```naturalts path="app.logics.deleteProcessDefinition.ts"
$Logic({
    description: '删除流程定义',
    directory: 'workflow_engine(工作流引擎)'
})
export declare function deleteProcessDefinition(
    processDefinitionId: app.dataSources.defaultDS.entities.ProcessDefinition['id']
): app.dataSources.defaultDS.entities.ProcessDefinition;
```

### 被前端调用

- **流程定义（processDefinition）**：在流程定义管理页面中，系统管理员选择一个或多个流程定义后点击删除按钮，前端会调用此服务端逻辑执行删除操作。该操作用于移除不再需要的流程模板，保持工作流模型库的整洁性，删除前会弹出确认对话框并验证是否有活跃的流程实例依赖该定义。

### 依赖的枚举、实体

- **数据建模-实体-流程定义**：[工作流引擎-实体-流程定义（ProcessDefinition）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessDefinition.md)

### 依赖的外部能力

（无）