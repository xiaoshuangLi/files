# 工作流引擎-创建流程定义（createProcessDefinition）

- **生成时间**：2026-03-25

## 创建流程定义（createProcessDefinition）

### 功能概述

创建流程定义服务端逻辑是工作流引擎的核心功能之一，负责处理业务流程模板的创建操作。该逻辑接收包含流程名称、描述和BPMN XML格式定义数据的完整流程定义实体，将其持久化存储到数据库中，并返回包含自动生成主键ID的完整流程定义实体。此功能支持系统管理员通过可视化设计器创建新的业务流程模型，为后续的流程实例化和执行提供标准化模板。逻辑实现过程中会自动填充创建时间和创建人等审计字段，确保流程定义数据的完整性和可追溯性，同时对BPMN XML内容进行必要的验证，保证流程定义的有效性和合规性。

### 功能要点

- **流程定义创建**：接收完整的流程定义实体参数，包括必填的流程名称和BPMN XML定义数据，以及可选的流程描述信息，将这些数据持久化存储到数据库中，并返回包含自动生成主键ID的完整流程定义实体，同时自动填充创建时间、更新时间、创建人和更新人等审计字段，确保数据的完整性和一致性。

### 逻辑签名

```naturalts path="app.logics.createProcessDefinition.ts"
$Logic({
    description: '创建流程定义',
    directory: 'workflow_engine(工作流引擎)',
    transactional: true
})
export declare function createProcessDefinition(processDefinition: app.dataSources.defaultDS.entities.ProcessDefinition): app.dataSources.defaultDS.entities.ProcessDefinition;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| processDefinition | 流程定义实体 | app.dataSources.defaultDS.entities.ProcessDefinition | 包含流程名称、描述和BPMN XML定义的完整流程定义实体 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 创建结果 | app.dataSources.defaultDS.entities.ProcessDefinition | 补充了主键ID和审计字段的完整流程定义实体 |

### 被前端调用

- **流程定义（processDefinition）**：在流程定义管理页面中，当系统管理员点击添加按钮并填写完流程基本信息和BPMN设计后，点击保存操作时调用此服务端逻辑，用于将新创建的流程定义持久化存储到数据库中。

### 依赖的枚举、实体

- **数据建模-实体-流程定义**：[工作流引擎-实体-流程定义（ProcessDefinition）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessDefinition.md)

### 依赖的外部能力

（无）