# 工作流引擎-创建工作流（createWorkflow）

- **生成时间**：2026-03-25

## 创建工作流（createWorkflow）

### 功能概述

创建工作流服务端逻辑提供审批流程的创建功能，支持系统管理员在审批流程管理页面配置新的业务审批流程。该逻辑接收包含流程基本信息（如流程名称、描述、状态、类型等）的审批流程实体，将其持久化存储到数据库中，并返回创建成功的完整流程信息。通过此逻辑，系统能够为预算调整、薪资变更、质量整改等需要审批的业务模块提供统一的流程定义基础，确保审批流程的标准化和可配置性。该逻辑还支持流程版本管理和启用状态控制，便于后续的流程维护和实例化使用。

### 功能要点

- **审批流程创建功能**：系统管理员可以在审批流程列表页面点击添加按钮，填写流程名称、描述、状态、类型等基本信息后，调用此服务端逻辑创建新的审批流程配置。该功能确保所有必要的流程属性都被正确设置，包括必填的流程名称和状态字段，以及可选的流程描述、类型、启用状态和版本号等属性。创建成功后，新流程将出现在审批流程列表中，可供后续的编辑、启用或实例化使用。

### 逻辑签名

```naturalts path="app.logics.createWorkflow.ts"
$Logic({
    description: '创建工作流',
    directory: 'workflow_engine(工作流引擎)',
    transactional: true
})
export declare function createWorkflow(approvalProcess: app.dataSources.defaultDS.entities.ApprovalProcess): app.dataSources.defaultDS.entities.ApprovalProcess;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| approvalProcess | 审批流程实体 | app.dataSources.defaultDS.entities.ApprovalProcess | 包含流程名称、描述、状态、类型等基本信息的审批流程实体 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 创建结果 | app.dataSources.defaultDS.entities.ApprovalProcess | 补充了主键ID和时间戳信息的完整审批流程实体 |

### 被前端调用

- **审批流程（approvalProcess）**：系统管理员在审批流程列表页面点击添加按钮后，跳转到审批流程添加页面，填写流程基本信息并提交时调用此服务端逻辑，用于保存新的审批流程配置到系统中。

### 依赖的枚举、实体

- **数据建模-枚举-审批状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-审批流程**：[数据建模-实体-审批流程（plan/data-model/entity-ApprovalProcess.md）](specs/001-bootdo-management-system/plan/data-model/entity-ApprovalProcess.md)

### 依赖的外部能力

无匹配内容

