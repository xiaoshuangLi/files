# 环保管理-删除环境风险评估（deleteEnvironmentalRiskAssessment）

- **生成时间**：2026-03-25

## 删除环境风险评估（deleteEnvironmentalRiskAssessment）

### 功能概述

删除环境风险评估服务端逻辑用于安全地移除系统中不再需要的环境风险评估记录。该功能支持环保管理人员对过期、错误或重复的环境风险评估数据进行清理，确保环保管理数据的准确性和有效性。删除操作会进行严格的权限验证，确保只有具备相应权限的用户才能执行删除操作。同时，系统会对关联的合规检查和应急预案进行保护性处理，防止因删除操作导致数据不一致。删除前系统会进行二次确认，避免误操作造成重要数据丢失。

### 功能要点

- **安全删除机制**：删除环境风险评估记录时，系统会验证当前用户是否具有删除权限，并检查该记录是否处于可删除状态。对于已关联重要合规检查或应急预案的高风险评估记录，系统会提示用户确认删除操作，确保不会意外删除关键数据。
- **关联数据保护**：删除环境风险评估记录时，系统会保留关联的合规检查和应急预案数据完整性。由于环境风险评估实体与合规检查、应急预案实体之间建立了PROTECT级外键关系，删除操作不会级联删除关联数据，而是仅移除环境风险评估记录本身，确保环保管理体系的数据一致性。
- **操作审计追踪**：所有删除操作都会被记录在系统操作日志中，包括删除时间、操作用户、被删除记录的关键信息等。这为后续的审计和问题追溯提供了完整的数据支持，符合企业环保管理的合规要求。

### 逻辑签名

```naturalts path="app.logics.deleteEnvironmentalRiskAssessment.ts"
$Logic({
    description: '删除环境风险评估记录',
    directory: 'environmental_management(环保管理)'
})
export declare function deleteEnvironmentalRiskAssessment(
    environmentalRiskAssessmentId: Integer
): Boolean;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| environmentalRiskAssessmentId | 环境风险评估ID | Integer | 要删除的环境风险评估记录的唯一标识 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 删除结果 | Boolean | 删除操作是否成功，true表示成功，false表示失败 |

### 被前端调用

- **风险评估（environmentalRiskAssessment）**：在环境风险评估列表页面，用户可以通过点击删除按钮调用此服务端逻辑，删除选中的环境风险评估记录。删除操作会触发二次确认对话框，用户确认后系统执行删除操作并刷新列表。

### 依赖的枚举、实体

- **数据建模-实体-环境风险评估**：[环保管理-实体-环境风险评估（EnvironmentalRiskAssessment）](specs/001-bootdo-management-system/plan/data-model/entity-EnvironmentalRiskAssessment.md)
- **数据建模-实体-合规检查**：[环保管理-实体-合规检查（ComplianceInspection）](specs/001-bootdo-management-system/plan/data-model/entity-ComplianceInspection.md)
- **数据建模-实体-应急预案**：[环保管理-实体-应急预案（EmergencyPlan）](specs/001-bootdo-management-system/plan/data-model/entity-EmergencyPlan.md)

### 依赖的外部能力

无