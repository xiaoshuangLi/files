# 工作流引擎-更新任务状态（updateTaskStatus）

- **生成时间**：2026-03-25

## 更新任务状态（updateTaskStatus）

### 功能概述

更新任务状态服务端逻辑是工作流引擎模块的核心功能，用于处理任务节点的状态变更操作。该逻辑支持将任务从当前状态转换为新的有效状态，包括待处理、处理中、已完成和已取消等状态。在实际业务场景中，当用户完成分配给自己的任务或需要调整任务处理进度时，会调用此接口更新任务状态。系统会验证状态转换的合法性，确保任务状态按照预定义的工作流规则进行流转，并记录状态变更的时间戳和操作人信息。同时，状态更新会触发相关的业务通知和后续流程节点的激活，保证整个工作流的连贯性和数据一致性。

### 功能要点

- **任务状态更新与验证**：系统接收任务ID和目标状态作为输入参数，首先验证任务是否存在以及当前用户是否有权限更新该任务。然后检查状态转换的合法性，确保只能进行有效的状态转换（如从"待处理"转为"处理中"或"已完成"，但不能从"已完成"转回"待处理"）。状态更新成功后，系统会自动记录更新时间和操作人，并根据新状态决定是否需要设置完成时间（如状态变为"已完成"时）。

### 逻辑签名

```naturalts path="app.logics.updateTaskStatus.ts"
$Logic({
    description: '更新任务状态',
    directory: 'workflow_engine(工作流引擎)'
})
export declare function updateTaskStatus(
    taskId: Integer,
    newStatus: app.enums.TaskStatusEnum
): { success: Boolean, message: String };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| taskId | 任务ID | Integer | 需要更新状态的任务唯一标识 |
| newStatus | 新状态 | app.enums.TaskStatusEnum | 任务的目标状态 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 更新结果 | { success: Boolean, message: String } | 包含操作成功标志和消息提示的结果对象 |

### 被前端调用

- **任务管理（taskManagement）**：在任务管理页面中，用户可以通过任务详情页面或列表页面的操作按钮更新任务状态。当用户选择新的任务状态（如标记为已完成）并确认后，前端会调用此服务端逻辑来更新任务节点的状态，并在操作成功后刷新页面显示最新的任务状态信息。

### 依赖的枚举、实体

- **办公自动化-枚举-任务状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **工作流引擎-实体-任务节点**：[工作流引擎-实体-任务节点（TaskNode）](specs/001-bootdo-management-system/plan/data-model/entity-TaskNode.md)

### 依赖的外部能力

无外部能力依赖