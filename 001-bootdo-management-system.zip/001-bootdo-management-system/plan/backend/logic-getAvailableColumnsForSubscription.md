# 内容管理-获取可订阅栏目（getAvailableColumnsForSubscription）

- **生成时间**：2026-03-25

## 获取可订阅栏目（getAvailableColumnsForSubscription）

### 功能概述

该服务端逻辑用于获取当前用户可以订阅的栏目列表。系统会根据用户的权限级别、所属部门以及已有的订阅关系，筛选出可供用户订阅的栏目。此功能支持前端订阅管理界面展示可选栏目，确保用户只能看到并订阅其有权限访问的内容栏目，同时避免重复订阅已存在的栏目。逻辑会查询栏目结构数据，结合用户权限信息进行过滤，并返回格式化的栏目列表供前端展示。

### 功能要点

- **权限过滤**：根据用户的角色权限（如系统管理员、部门管理员或普通用户）确定可访问的栏目范围。系统管理员可查看所有栏目，部门管理员只能查看本部门及子部门的栏目，普通用户则只能查看公开或授权访问的栏目。此过滤机制确保了内容安全性和权限隔离，防止越权访问敏感栏目信息。

### 逻辑签名

```naturalts path="app.logics.getAvailableColumnsForSubscription.ts"
$Logic({
    description: '获取当前用户可订阅的栏目列表',
    directory: 'content_management(内容管理)'
})
export declare function getAvailableColumnsForSubscription(userId: String): { columns: List<{ id: String, name: String, path: String, description?: String }> };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| userId | 用户ID | String | 当前登录用户的唯一标识 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| columns | 可订阅栏目列表 | List<{ id: String, name: String, path: String, description?: String }> | 用户可订阅的栏目列表，包含栏目ID、名称、路径和可选描述信息 |

### 被前端调用

- **用户订阅（userSubscription）**：在用户订阅页面中，调用此服务端逻辑获取当前用户可以订阅的栏目列表，用于展示可选栏目供用户进行订阅操作，确保用户只能订阅其有权限访问的内容栏目。

### 依赖的枚举、实体

- **数据建模-实体-栏目结构**：[内容管理-实体-栏目结构（ColumnStructure）](specs/001-bootdo-management-system/plan/data-model/entity-ColumnStructure.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)
- **数据建模-实体-用户角色**：[系统管理-实体-用户角色（UserRole）](specs/001-bootdo-management-system/plan/data-model/entity-UserRole.md)

### 依赖的外部能力

[文件内部已经提供，无需进行生成。如果文件内部已经有 `依赖的外部能力` 内容，禁止修改或删除文件内的 `依赖的外部能力` 内容]