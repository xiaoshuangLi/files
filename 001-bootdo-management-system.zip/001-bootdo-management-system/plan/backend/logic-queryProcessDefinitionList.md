# 工作流引擎-查询流程定义列表（queryProcessDefinitionList）

- **生成时间**：2026-03-25

## 查询流程定义列表（queryProcessDefinitionList）

### 功能概述

查询流程定义列表服务端逻辑提供对工作流引擎中所有流程定义的分页查询功能。该逻辑支持基于流程名称的模糊搜索过滤，允许用户在审批流程配置页面中快速查找和选择合适的流程定义模板。作为工作流引擎的基础查询接口，该逻辑返回完整的流程定义信息，包括流程ID、名称、描述、创建时间等关键字段，为前端审批流程管理功能提供数据支撑。该逻辑确保了流程定义数据的安全访问，并支持高效的分页加载，适用于包含大量流程定义的企业级应用场景。

### 功能要点

- **分页查询功能**：支持标准的分页参数（页码、每页条数），能够高效处理大量流程定义数据的查询请求，避免一次性加载过多数据导致的性能问题。通过分页机制，系统可以按需加载流程定义列表，提升用户体验和系统响应速度。
- **模糊搜索过滤**：支持基于流程名称的模糊匹配搜索，用户可以通过输入部分流程名称快速定位目标流程定义。搜索功能采用数据库模糊匹配操作实现，能够匹配流程名称中包含指定关键词的所有记录，提高流程查找的准确性和效率。
- **排序功能**：支持按指定字段（如创建时间、流程名称）进行升序或降序排序，确保流程定义列表能够按照用户期望的顺序展示。默认按创建时间降序排列，最新的流程定义优先显示。
- **完整数据返回**：返回完整的流程定义实体信息，包括主键ID、流程名称、详细描述、BPMN XML定义、创建时间和更新时间等所有必要字段，满足前端审批流程配置页面的数据展示和选择需求。

### 逻辑签名

```naturalts path="app.logics.queryProcessDefinitionList.ts"
$Logic({
    description: '查询流程定义列表',
    directory: 'workflow_engine(工作流引擎)'
})
export declare function queryProcessDefinitionList(page: Integer, size: Integer, sort: String, order: String, nameFilter: String): { list: List<app.dataSources.defaultDS.entities.ProcessDefinition>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 分页查询的页码，从1开始 |
| size | 每页条数 | Integer | 每页返回的记录数量 |
| sort | 排序字段 | String | 排序的字段名，如"createdTime"、"name"等 |
| order | 排序顺序 | String | 排序顺序，"asc"表示升序，"desc"表示降序 |
| nameFilter | 流程名称过滤 | String | 流程名称的模糊搜索关键词，为空时表示不过滤 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 流程定义列表 | List<app.dataSources.defaultDS.entities.ProcessDefinition> | 当前页的流程定义实体列表 |
| total | 总记录数 | Integer | 符合查询条件的流程定义总数量 |

### 被前端调用

- **审批流程（approvalWorkflow）**：在审批流程配置页面的新增和编辑表单中，通过下拉选择器调用此服务端逻辑获取可用的流程定义列表，供用户选择关联的工作流模板。该逻辑支持分页加载和搜索功能，确保在流程定义数量较多时仍能提供流畅的用户体验。

### 依赖的枚举、实体

- **数据建模-实体-流程定义**：[工作流引擎-实体-流程定义（ProcessDefinition）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessDefinition.md)

### 依赖的外部能力

无匹配内容

