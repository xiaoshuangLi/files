# 预算管理-创建预算类型（createBudgetType）

- **生成时间**：2026-03-25

## 创建预算类型（createBudgetType）

### 功能概述

创建预算类型服务端逻辑用于在预算管理系统中新增预算分类标准，是预算类型管理模块的核心功能之一。该逻辑接收前端提交的预算类型基本信息，包括类型名称和描述，并进行必要的业务验证，如类型名称的唯一性检查。验证通过后，系统将自动填充创建人、创建时间等系统字段，并将数据持久化到数据库中。此服务端逻辑确保了预算类型数据的一致性和完整性，为后续的预算分配、执行监控和调整申请提供标准化的分类依据，支持企业建立统一的预算管理体系。

### 功能要点

- **预算类型数据验证与保存**：当预算管理人员在前端页面提交预算类型表单时，服务端逻辑首先验证必填字段"类型名称"是否为空，然后检查该类型名称在系统中是否已存在以确保唯一性。验证通过后，系统自动填充当前操作用户作为创建人和更新人，设置当前时间为创建时间和更新时间，并将完整的预算类型数据保存到数据库中。如果类型名称已存在，服务端将返回明确的错误信息"预算类型名称已存在，请重新输入"，指导用户进行修正。

### 逻辑签名

```naturalts path="app.logics.createBudgetType.ts"
$Logic({
    description: '创建预算类型',
    directory: 'budget_management(预算管理)',
    transactional: true
})
export declare function createBudgetType(typeName: String, description?: String): app.dataSources.defaultDS.entities.BudgetType;
```

### 被前端调用

- **预算类型管理（budgetType）**：在预算类型管理页面的新增功能中，当用户填写完预算类型表单并点击保存按钮时，前端调用此服务端逻辑完成预算类型的创建操作，实现预算分类标准的定义和维护。

### 依赖的枚举、实体

- **数据建模-实体-预算类型**：[预算管理-实体-预算类型（BudgetType）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetType.md)

### 依赖的外部能力

无外部能力依赖