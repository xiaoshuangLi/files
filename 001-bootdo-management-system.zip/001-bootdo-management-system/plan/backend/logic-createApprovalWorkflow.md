# 预算管理-创建审批流程（createApprovalWorkflow）

- **生成时间**：2026-03-25

## 创建审批流程（createApprovalWorkflow）

### 功能概述

创建审批流程服务端逻辑负责处理预算管理模块中审批工作流的新增操作。该逻辑接收前端提交的审批流程配置信息，包括流程名称、关联的流程定义ID和审批规则等参数，验证数据完整性后将新的审批流程记录持久化到数据库中。通过与工作流引擎的深度集成，该逻辑确保新建的审批流程能够正确关联到已有的BPMN流程定义，并支持后续的流程实例化和执行。该服务还负责设置审批流程的启用状态，默认情况下新创建的流程处于启用状态，可立即用于预算审批业务场景。

### 功能要点

- **审批流程创建**：接收包含workflowName、definitionId、workflowRules等字段的审批流程配置数据，验证必填字段的完整性，确保workflowName非空且definitionId有效存在，然后创建新的审批流程记录并返回完整的实体信息。
- **流程定义关联**：在创建审批流程时，自动验证提供的definitionId是否对应有效的流程定义实体，确保审批流程能够正确关联到工作流引擎中的BPMN流程模板，防止无效关联导致后续流程执行失败。
- **默认状态设置**：为新创建的审批流程自动设置isEnabled字段为true，确保流程创建后立即可用，同时记录创建人、创建时间等审计信息，便于后续的流程管理和追踪。

### 逻辑签名

```naturalts path="app.logics.createApprovalWorkflow.ts"
$Logic({
    description: '创建预算审批流程',
    directory: 'budget_management(预算管理)',
    transactional: true
})
export declare function createApprovalWorkflow(workflowName: String, definitionId: Integer, workflowRules: String): app.dataSources.defaultDS.entities.ApprovalWorkflow;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| workflowName | 工作流名称 | String | 审批流程的显示名称，必填字段 |
| definitionId | 流程定义ID | Integer | 关联的流程定义实体主键ID，必填字段 |
| workflowRules | 工作流规则 | String | 审批流程的具体规则和条件，可选字段 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 创建结果 | app.dataSources.defaultDS.entities.ApprovalWorkflow | 包含完整字段信息的审批流程实体，包括自动生成的id和其他元数据 |

### 被前端调用

- **审批流程（approvalWorkflow）**：在审批流程页面的新增功能中调用此服务端逻辑，用户填写流程名称、选择关联的流程定义、输入审批规则后，通过该逻辑将新的审批流程配置保存到系统中。

### 依赖的枚举、实体

- **预算管理-实体-审批流程**：[预算管理-实体-审批流程（ApprovalWorkflow）](specs/001-bootdo-management-system/plan/data-model/entity-ApprovalWorkflow.md)
- **工作流引擎-实体-流程定义**：[工作流引擎-实体-流程定义（ProcessDefinition）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessDefinition.md)

### 依赖的外部能力

无匹配内容

