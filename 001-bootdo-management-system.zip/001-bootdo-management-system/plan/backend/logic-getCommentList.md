# 内容管理-获取评论列表（getCommentList）

- **生成时间**：2026-03-25

## 获取评论列表（getCommentList）

### 功能概述

该服务端逻辑用于获取系统中的评论列表数据，支持按文章ID、评论状态、时间范围等条件进行筛选和分页查询。评论列表包含评论的基本信息、评论者信息、关联文章信息以及审核状态等，为前端提供完整的评论数据展示和管理功能。

### 功能要点

- **评论列表查询功能**：根据指定的查询条件（如文章ID、评论状态、时间范围等）获取评论列表，支持分页加载，每页默认显示20条记录。查询结果按照评论时间倒序排列，最新的评论显示在最前面。系统会根据当前用户的权限过滤可查看的评论数据，确保数据安全性。

### 逻辑签名

```naturalts path="app.logics.getCommentList.ts"
$Logic({
    description: '获取评论列表',
    directory: 'content_management(内容管理)'
})
export declare function getCommentList(page: Integer, size: Integer, articleId?: Text, status?: CommentStatus, startTime?: Text, endTime?: Text): { list: List<CommentItem>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 页码，从1开始 |
| size | 每页条数 | Integer | 每页显示的评论数量 |
| articleId | 文章ID | Text | 可选，指定查询某篇文章的评论 |
| status | 评论状态 | CommentStatus | 可选，评论状态过滤条件 |
| startTime | 开始时间 | Text | 可选，评论时间范围开始时间 |
| endTime | 结束时间 | Text | 可选，评论时间范围结束时间 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 评论列表 | List<CommentItem> | 评论项列表 |
| total | 总条数 | Integer | 符合条件的评论总数 |

### 被前端调用

- **评论管理（commentInteraction）**：在评论管理页面中，通过调用getCommentList接口获取指定文章或全部文章的评论列表，支持按评论状态（待审核、已通过、已拒绝）进行筛选，并提供分页浏览功能。

### 依赖的枚举、实体

- **数据建模-枚举-评论状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-评论项**：[内容管理-实体-评论项（CommentItem）](specs/001-bootdo-management-system/plan/data-model/entity-CommentItem.md)

### 依赖的外部能力

[文件内部已经提供，无需进行生成。如果文件内部已经有 `依赖的外部能力` 内容，禁止修改或删除文件内的 `依赖的外部能力` 内容]