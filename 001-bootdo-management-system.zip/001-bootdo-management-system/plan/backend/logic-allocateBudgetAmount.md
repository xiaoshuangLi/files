# 预算管理-分配预算额度（allocateBudgetAmount）

- **生成时间**：2026-03-25

## 分配预算额度（allocateBudgetAmount）

### 功能概述

分配预算额度服务端逻辑用于为特定的预算周期、预算类型和组织部门分配具体的预算金额，是预算管理模块的核心功能之一。该逻辑支持财务管理人员创建新的预算分配记录，包括选择预算周期、预算类型、目标部门，输入分配金额和分配说明等必要信息。系统会验证分配金额的有效性（必须为正数且不超过可用预算额度），并将数据持久化到数据库中。成功分配后，系统会返回完整的预算分配记录，包括自动生成的主键、创建时间和分配人等系统字段，为后续的预算执行监控和分析提供基础数据支持。

### 功能要点

- **预算分配数据验证与保存**：该功能要点实现了预算分配表单数据的完整验证和持久化存储。系统首先验证必填字段（预算周期、预算类型、目标部门、分配金额）是否已正确填写，然后验证分配金额是否为正数且不超过当前可用预算额度。验证通过后，系统将创建新的预算分配记录，自动填充创建时间、创建人、分配时间等系统字段，并将记录保存到数据库。保存成功后，系统返回完整的预算分配实体，包含所有字段信息，确保数据的一致性和完整性。

### 逻辑签名

```naturalts path="app.logics.allocateBudgetAmount.ts"
$Logic({
    description: '分配预算额度',
    directory: 'budget_management(预算管理)',
    transactional: true
})
export declare function allocateBudgetAmount(budgetAllocation: app.dataSources.defaultDS.entities.BudgetAllocation): app.dataSources.defaultDS.entities.BudgetAllocation;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| budgetAllocation | 预算分配实体 | app.dataSources.defaultDS.entities.BudgetAllocation | 包含预算类型ID、预算周期ID、分配金额、分配人ID、预算状态、分配时间等字段的预算分配实体 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 创建结果 | app.dataSources.defaultDS.entities.BudgetAllocation | 补充了主键ID、创建时间、更新时间、创建人、更新人等系统字段的完整预算分配实体 |

### 被前端调用

- **预算分配（budgetAllocation）**：在预算分配页面中，当财务管理人员填写完预算分配表单并点击保存按钮时，前端调用此服务端逻辑将预算分配数据保存到数据库。该逻辑实现了预算分配的核心业务功能，包括数据验证、持久化存储和返回完整记录。

### 依赖的枚举、实体

- **数据建模-枚举-预算状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-预算分配**：[预算管理-实体-预算分配（BudgetAllocation）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetAllocation.md)
- **数据建模-实体-预算类型**：[预算管理-实体-预算类型（BudgetType）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetType.md)
- **数据建模-实体-预算周期**：[预算管理-实体-预算周期（BudgetCycle）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetCycle.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无匹配内容

