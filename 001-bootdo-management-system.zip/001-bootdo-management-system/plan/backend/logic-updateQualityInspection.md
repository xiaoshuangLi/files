# 质量管理-更新质量检验（updateQualityInspection）

- **生成时间**：2026-03-25

## 更新质量检验（updateQualityInspection）

### 功能概述

更新质量检验服务端逻辑用于修改已存在的质量检验记录，支持质量管理员对检验结果、检验通过状态等关键信息进行更新。该逻辑确保质量检验数据的准确性和时效性，为质量问题的后续处理提供可靠依据。更新操作会验证检验记录的存在性，并检查当前用户是否具有修改权限，同时记录完整的操作日志以保证数据变更的可追溯性。

### 功能要点

- **检验数据更新功能**：质量管理员可以修改已存在的质量检验记录，包括检验结果描述、检验通过状态等核心字段。系统会验证输入数据的有效性，确保检验结果不为空，检验时间格式正确，并且检验员ID对应有效的系统用户。更新操作会保留原有的创建信息，仅更新修改时间和更新者信息，确保数据历史的完整性。

### 逻辑签名

```naturalts path="app.logics.updateQualityInspection.ts"
$Logic({
    description: '更新质量检验记录',
    directory: 'quality_management(质量管理)',
    transactional: true
})
export declare function updateQualityInspection(qualityInspection: app.dataSources.defaultDS.entities.QualityInspection): app.dataSources.defaultDS.entities.QualityInspection;
```

### 被前端调用

- **质量检验（qualityInspection）**：质量检验页面在编辑现有检验记录时调用此服务端逻辑，用于保存修改后的检验信息，包括检验结果、检验通过状态等。

### 依赖的枚举、实体

- **数据建模-实体-质量检验**：[质量管理-实体-质量检验（QualityInspection）](specs/001-bootdo-management-system/plan/data-model/entity-QualityInspection.md)
- **数据建模-实体-质量问题**：[质量管理-实体-质量问题（QualityIssue）](specs/001-bootdo-management-system/plan/data-model/entity-QualityIssue.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无外部能力依赖