# 办公自动化-重置个人工作台配置（resetPersonalWorkspaceConfig）

- **生成时间**：2026-03-25

## 重置个人工作台配置（resetPersonalWorkspaceConfig）

### 功能概述

重置个人工作台配置服务端逻辑用于将用户的个性化工作台界面恢复到系统默认状态。该功能允许用户一键清除所有自定义的布局配置、快捷入口设置和个性化参数，重新应用系统预设的标准工作台配置。当用户对当前工作台布局不满意或希望重新开始配置时，可以通过此功能快速恢复到初始状态。系统在执行重置操作时会保留用户的基本账户信息，仅清除与界面布局和个性化相关的配置数据，确保用户的核心数据安全不受影响。重置操作完成后，用户将看到系统默认的工作台布局，并可以基于此重新进行个性化定制。

### 功能要点

- **恢复默认布局配置**：将个人工作台的模块布局、位置、大小和显示状态全部恢复为系统预设的默认值，清除用户所有的自定义布局设置。
- **重置快捷入口**：清除用户自定义的快捷功能入口，恢复系统默认提供的标准快捷入口集合，确保用户能够快速访问基础功能模块。
- **保留核心用户数据**：在重置过程中，系统仅清除与界面布局和个性化相关的配置数据，用户的账户信息、权限设置和业务数据保持不变。
- **跨设备同步重置**：重置操作会在所有设备上同步生效，确保用户在不同终端访问系统时都能获得一致的默认工作台体验。
- **操作确认机制**：提供明确的操作确认提示，防止用户误操作导致个性化配置丢失，确保重置操作是有意为之的明确行为。

### 逻辑签名

```naturalts path="app.logics.resetPersonalWorkspaceConfig.ts"
$Logic({
    description: '重置个人工作台配置',
    directory: 'office_automation(办公自动化)'
})
export declare function resetPersonalWorkspaceConfig(userId: Integer): Boolean;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| userId | 用户ID | Integer | 需要重置工作台配置的用户唯一标识符 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 重置结果 | Boolean | 重置操作是否成功完成，true表示成功，false表示失败 |

### 被前端调用

- **个人门户（personalWorkspace）**：在个人门户页面中提供"重置默认配置"按钮，用户点击后调用此服务端逻辑，将当前用户的工作台配置恢复到系统默认状态，清除所有自定义布局和快捷入口设置。

### 依赖的枚举、实体

- **数据建模-实体-个人工作台**：[办公自动化-实体-个人工作台（PersonalWorkspace）](specs/001-bootdo-management-system/plan/data-model/entity-PersonalWorkspace.md)
- **数据建模-实体-个人偏好设置**：[办公自动化-实体-个人偏好设置（PersonalPreferenceEntity）](specs/001-bootdo-management-system/plan/data-model/entity-PersonalPreferenceEntity.md)
- **数据建模-实体-用户配置**：[系统管理-实体-用户配置（UserConfigurationEntity）](specs/001-bootdo-management-system/plan/data-model/entity-UserConfigurationEntity.md)

### 依赖的外部能力

无匹配内容

