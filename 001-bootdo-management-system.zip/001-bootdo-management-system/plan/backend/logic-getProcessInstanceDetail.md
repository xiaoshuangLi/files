# 工作流引擎-获取流程实例详情（getProcessInstanceDetail）

- **生成时间**：2026-03-25

## 获取流程实例详情（getProcessInstanceDetail）

### 功能概述

获取流程实例详情服务端逻辑提供对工作流引擎中特定流程实例的完整信息查询功能。该逻辑根据传入的流程实例ID，从数据库中检索并返回该实例的所有相关信息，包括基础信息（实例ID、定义ID、启动用户、启动时间、结束时间、当前状态）、关联的流程定义详情（流程名称、BPMN XML定义）、任务节点列表（包含每个节点的状态、处理人、处理时间等）以及相关的业务表单数据。此服务确保前端能够完整展示流程实例的执行状态、历史轨迹和当前进度，为流程监控、问题排查和数据分析提供全面的数据支持。

### 功能要点

- **流程实例基础信息查询**：根据流程实例ID精确查询实例的基础属性信息，包括实例唯一标识、关联的流程定义ID、启动用户ID、启动时间、结束时间以及当前执行状态。系统会验证实例ID的有效性，确保返回的数据准确无误，并处理实例不存在或已被删除的异常情况，保证数据查询的可靠性和完整性。

- **关联数据完整加载**：在获取流程实例基础信息的同时，自动加载所有关联的必要数据，包括流程定义的详细信息（如流程名称、描述、BPMN XML格式的流程图定义）和启动用户的账户信息（用户名、昵称等）。这种关联数据的预加载机制避免了前端多次请求，提高了数据获取效率，确保流程实例详情页面能够一次性展示完整的上下文信息。

- **任务节点状态跟踪**：查询并返回与该流程实例相关的所有任务节点信息，包括每个节点的ID、名称、类型、当前状态、分配的处理人、实际处理人、处理开始时间、处理完成时间以及审批意见等详细数据。通过完整的任务节点历史记录，用户可以清晰了解流程的执行路径、各环节的处理情况和耗时分析，为流程优化提供数据依据。

### 逻辑签名

```naturalts path="app.logics.getProcessInstanceDetail.ts"
$Logic({
    description: '获取流程实例详情',
    directory: 'workflow_engine(工作流引擎)'
})
export declare function getProcessInstanceDetail(
  processInstanceId: Integer
): {
  instance: app.dataSources.defaultDS.entities.ProcessInstance;
  definition: app.dataSources.defaultDS.entities.ProcessDefinition;
  startUser: app.dataSources.defaultDS.entities.LcapUser;
  taskNodes: List<{
    id: Integer;
    nodeId: String;
    nodeName: String;
    nodeType: String;
    status: String;
    assigneeId: Integer;
    assigneeName: String;
    startTime: DateTime;
    endTime: DateTime;
    comments: String;
  }>;
};
```

### 被前端调用

- **流程实例管理（processInstance）**：在流程实例管理页面中，当用户点击某个流程实例查看详情时，前端调用此服务端逻辑获取该实例的完整信息，包括基础数据、流程定义、任务节点状态等，用于在详情页面中全面展示流程的执行情况和历史轨迹。

### 依赖的枚举、实体

- **数据建模-实体-流程实例**：[工作流引擎-实体-流程实例（ProcessInstance）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessInstance.md)
- **数据建模-实体-流程定义**：[工作流引擎-实体-流程定义（ProcessDefinition）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessDefinition.md)
- **数据建模-实体-用户**：[权限中心-实体-用户（LcapUser）](specs/001-bootdo-management-system/plan/data-model/entity-LcapUser.md)

### 依赖的外部能力

（无）