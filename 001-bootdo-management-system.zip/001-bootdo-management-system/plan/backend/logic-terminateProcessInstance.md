# 工作流引擎-终止流程实例（terminateProcessInstance）

- **生成时间**：2026-03-25

## 终止流程实例（terminateProcessInstance）

### 功能概述

终止流程实例功能提供对正在运行的工作流流程实例进行强制终止的能力。该功能允许系统管理员或具有相应权限的用户在必要时中断流程的正常执行，将流程实例的状态标记为已终止，并记录终止操作的相关信息。终止操作会立即停止流程实例的所有后续任务节点执行，释放相关资源，并可选择性地通知相关参与人员。此功能对于处理异常流程、取消无效审批或应对紧急业务变更场景至关重要，确保了工作流管理的灵活性和可控性。

### 功能要点

- **流程实例终止操作**：系统支持通过提供流程实例ID来终止指定的流程实例。终止操作会验证当前用户是否具有终止该流程实例的权限，检查流程实例是否处于可终止状态（如非已完成或已终止状态），然后执行终止逻辑，更新流程实例的currentStatus字段为'TERMINATED'，设置endedAt时间为当前时间，并记录操作日志。终止操作不可逆，一旦执行成功，该流程实例将无法恢复执行。

### 逻辑签名

```naturalts path="app.logics.terminateProcessInstance.ts"
$Logic({
    description: '终止指定的流程实例',
    directory: 'workflow_engine(工作流引擎)'
})
export declare function terminateProcessInstance(
    processInstanceId: String,
    userId: Integer,
    terminationReason: String
): Boolean;
```

### 被前端调用

- **流程实例管理（processInstanceManagement）**：在流程实例管理页面中，管理员可以选择一个或多个处于活动状态的流程实例，点击"终止"按钮来执行终止操作。系统会弹出确认对话框，要求输入终止原因，确认后调用此服务端逻辑完成终止操作。
- **流程监控（processMonitoring）**：在流程监控页面中，当发现某个流程实例出现异常或需要紧急处理时，管理员可以通过操作菜单选择"终止流程"选项，系统会调用此服务端逻辑来终止对应的流程实例。

### 依赖的枚举、实体

- **数据建模-实体-流程实例**：[工作流引擎-实体-流程实例（ProcessInstance）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessInstance.md)
- **数据建模-实体-用户**：.specify/warehouse/plan/data-model/entity-LcapUser.md

### 依赖的外部能力

无匹配内容

