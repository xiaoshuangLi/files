# 内容管理-审核评论（approveComment）

- **生成时间**：2026-03-25

## 审核评论（approveComment）

### 功能概述

审核评论服务端逻辑是内容管理系统中的核心业务功能，专门用于处理用户对文章内容发表的评论审核操作。该逻辑允许系统管理员或具有相应权限的用户对处于待审核状态的评论进行审核通过操作，将评论状态从"未审核"更新为"已审核"，从而使评论能够在前端页面公开展示。该逻辑确保了内容发布的合规性和安全性，防止不当内容直接对外展示，同时维护了健康的社区互动环境。审核操作会记录操作人信息和操作时间，并触发相应的通知机制，告知评论者其评论已被审核通过。

### 功能要点

- **评论审核状态更新**：当系统管理员在评论管理界面选择一条待审核的评论并执行审核通过操作时，系统需要调用此服务端逻辑，将对应评论记录的 isApproved 字段从 false 更新为 true，同时更新 updatedTime 和 updatedBy 字段，记录审核操作的时间和执行人信息。此操作必须确保数据的一致性和完整性，避免出现审核状态与实际显示不一致的情况。

### 逻辑签名

```naturalts path="app.logics.approveComment.ts"
$Logic({
    description: '审核通过评论',
    directory: 'content_management(内容管理)'
})
export declare function approveComment(commentId: String): app.dataSources.defaultDS.entities.CommentInteraction;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| commentId | 评论ID | String | 需要审核通过的评论唯一标识 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 审核后的评论实体 | app.dataSources.defaultDS.entities.CommentInteraction | 更新后的完整评论实体信息，包含已更新的审核状态 |

### 被前端调用

- **评论管理（commentInteraction）**：在评论管理页面中，当系统管理员选择待审核的评论并点击"审核通过"按钮时，前端会调用此服务端逻辑，传入评论ID，将评论状态从待审核更改为已审核，使该评论能够在前端页面显示。

### 依赖的枚举、实体

- **数据建模-实体-评论互动**：[内容管理-实体-评论互动（CommentInteraction）](specs/001-bootdo-management-system/plan/data-model/entity-CommentInteraction.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

[文件内部已经提供，无需进行生成。如果文件内部已经有 `依赖的外部能力` 内容，禁止修改或删除文件内的 `依赖的外部能力` 内容]