# 系统管理-获取系统角色列表（getSystemRoleList）

- **生成时间**：2026-03-25

## 获取系统角色列表（getSystemRoleList）

### 功能概述

获取系统角色列表服务端逻辑用于查询和返回系统中所有可用的角色信息。该逻辑支持分页查询，允许前端按需加载角色数据，提高系统性能和用户体验。通过此接口，管理员可以在角色管理页面查看所有角色的基本信息，包括角色名称、描述等关键属性，为后续的角色权限分配和用户角色管理提供数据基础。该逻辑不包含复杂的业务过滤条件，主要提供基础的角色数据查询功能，确保数据的完整性和一致性。

### 功能要点

- **分页查询支持**：实现高效的分页查询机制，支持指定页码和每页显示数量，避免一次性加载过多数据导致系统性能下降。通过标准的分页参数（page、size）控制数据加载量，确保在大数据量场景下仍能保持良好的响应速度和用户体验。

### 逻辑签名

```naturalts path="app.logics.getSystemRoleList.ts"
$Logic({
    description: '获取系统角色列表',
    directory: 'system_management(系统管理)'
})
export declare function getSystemRoleList(page: Integer, size: Integer): { list: List<app.dataSources.defaultDS.entities.UserRole>, total: Integer };
```

### 被前端调用

- **角色管理页（roleManagement）**：在角色管理页面的左侧角色列表中，通过调用此服务端逻辑获取系统中的所有角色数据，用于表格展示角色名称、描述等基本信息，并支持分页浏览。

### 依赖的枚举、实体

- **数据建模-实体-用户角色**：[系统管理-实体-用户角色（UserRole）](specs/001-bootdo-management-system/plan/data-model/entity-UserRole.md)

### 依赖的外部能力

无