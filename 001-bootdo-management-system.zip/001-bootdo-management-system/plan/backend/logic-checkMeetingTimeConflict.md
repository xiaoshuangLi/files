# 通用领域服务-检查会议时间冲突（checkMeetingTimeConflict）

- **生成时间**：2026-03-25

## 检查会议时间冲突（checkMeetingTimeConflict）

### 功能概述

该服务端逻辑用于检查用户尝试预约的会议时间是否与已有会议安排存在时间冲突。系统会根据提供的会议开始时间、结束时间以及会议室ID，查询数据库中同一会议室在该时间段内是否已有其他会议安排。如果存在时间重叠，则返回冲突信息；否则确认可以安排会议。此功能确保会议室资源不会被重复预订，维护会议安排的一致性和有效性。

### 功能要点

- **时间冲突检测**：系统能够精确检测会议时间冲突，包括完全包含、部分重叠和边界相接等多种冲突场景。当用户提交新的会议预约请求时，系统会比对新会议的开始时间和结束时间与同一会议室已有的所有会议安排，判断是否存在任何时间上的重叠。对于边界情况（如一个会议结束时间恰好等于另一个会议开始时间），系统可根据配置决定是否视为冲突，确保会议室使用效率最大化的同时避免实际使用冲突。

### 逻辑签名

```naturalts path="app.logics.checkMeetingTimeConflict.ts"
$Logic({
    description: '检查会议时间冲突',
    directory: 'meeting_management(会议管理)'
})
export declare function checkMeetingTimeConflict(meetingRoomId: String, startTime: DateTime, endTime: DateTime, excludeMeetingId?: String): { hasConflict: Boolean, conflictingMeetings: List<{ meetingId: String, title: String, startTime: DateTime, endTime: DateTime, organizer: String }> };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| meetingRoomId | 会议室ID | String | 要检查的会议室唯一标识 |
| startTime | 开始时间 | DateTime | 会议开始时间 |
| endTime | 结束时间 | DateTime | 会议结束时间 |
| excludeMeetingId | 排除的会议ID | String? | 编辑会议时排除当前会议ID，避免自身冲突 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| hasConflict | 是否存在冲突 | Boolean | 标识是否存在时间冲突 |
| conflictingMeetings | 冲突会议列表 | List<{ meetingId: String, title: String, startTime: DateTime, endTime: DateTime, organizer: String }> | 存在时间冲突的会议详情列表 |

### 被前端调用

- **会议管理（meetingReservation）**：在用户创建或编辑会议预约时，前端会调用此服务端逻辑来验证所选时间段是否可用。当用户选择会议室和时间后，系统实时检查是否存在时间冲突，并向用户提供即时反馈，避免提交无效的会议预约请求。

### 依赖的枚举、实体

- **数据建模-实体-会议预约**：[办公自动化-实体-会议预约（MeetingReservation）](specs/001-bootdo-management-system/plan/data-model/entity-MeetingReservation.md)
- **数据建模-实体-会议室**：[办公自动化-实体-会议室（MeetingRoom）](specs/001-bootdo-management-system/plan/data-model/entity-MeetingRoom.md)

### 依赖的外部能力

无