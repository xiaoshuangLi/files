# 系统管理-删除字典项（deleteDictionaryItem）

- **生成时间**：2026-03-25

## 删除字典项（deleteDictionaryItem）

### 功能概述

删除字典项服务端逻辑负责处理数据字典中指定字典项的删除操作。该功能允许系统管理员从系统中移除不再需要的字典项，确保数据字典的整洁性和准确性。删除操作支持单个字典项删除和批量删除两种模式，所有删除操作都会进行权限验证，确保只有具备相应权限的用户才能执行删除操作。删除前会检查字典项是否被其他业务模块引用，如果存在引用关系则阻止删除并提示用户。删除成功后会记录操作日志，包含操作人、操作时间、被删除的字典项信息等，便于后续审计和追踪。

### 功能要点

- **安全删除验证**：在执行删除操作前，系统会严格验证当前用户是否具有删除字典项的权限，只有系统管理员或具备相应权限的角色才能执行此操作。同时，系统会检查要删除的字典项是否被其他业务模块引用，如果存在引用关系（如被用作下拉选择框的选项、业务状态值等），则阻止删除操作并返回明确的错误提示，避免因误删导致业务功能异常。这种安全机制确保了数据字典的完整性和系统的稳定性。

### 逻辑签名

```naturalts path="app.logics.deleteDictionaryItem.ts"
$Logic({
    description: '删除数据字典项',
    directory: 'system_management(系统管理)',
    transactional: true
})
export declare function deleteDictionaryItem(dictIds: List<Integer>): { success: Boolean, message: String };
```

### 被前端调用

- **字典管理（dictionaryManagement）**：在字典管理页面中，用户可以通过点击单个字典项的"删除"按钮或选择多个字典项后点击"批量删除"按钮来调用此服务端逻辑。该逻辑负责处理删除请求，执行权限验证、引用检查和实际的删除操作，并向前端返回操作结果，用于显示成功或失败的消息。

### 依赖的枚举、实体

- **数据建模-实体-数据字典**：[系统管理-实体-数据字典（DataDictionary）](specs/001-bootdo-management-system/plan/data-model/entity-DataDictionary.md)

### 依赖的外部能力

无外部能力依赖