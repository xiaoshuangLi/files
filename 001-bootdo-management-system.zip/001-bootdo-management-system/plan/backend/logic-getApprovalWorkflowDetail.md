# 预算管理-获取审批流程详情（getApprovalWorkflowDetail）

- **生成时间**：2026-03-25

## 获取审批流程详情（getApprovalWorkflowDetail）

### 功能概述

获取审批流程详情服务端逻辑用于查询和返回指定审批流程的完整配置信息。该逻辑基于审批流程ID从数据库中检索对应的审批流程记录，并关联获取相关的流程定义信息，为前端提供完整的审批流程详情展示数据。通过此逻辑，用户可以在审批流程详情页面查看流程的名称、关联的流程定义、审批规则、启用状态等关键配置信息，确保审批流程配置的透明性和可追溯性。

### 功能要点

- **审批流程详情查询**：根据提供的审批流程ID，从数据库中精确查询对应的审批流程记录，包括工作流ID、工作流名称、流程定义ID、工作流规则、启用状态等所有字段信息。该功能确保用户能够准确获取到指定审批流程的完整配置详情，支持审批流程管理的精细化操作和审计需求。

### 逻辑签名

```naturalts path="app.logics.getApprovalWorkflowDetail.ts"
$Logic({
    description: '获取审批流程详情',
    directory: 'budget_management(预算管理)'
})
export declare function getApprovalWorkflowDetail(workflowId: Integer): { approvalWorkflow: app.dataSources.defaultDS.entities.ApprovalWorkflow, processDefinition: app.dataSources.defaultDS.entities.ProcessDefinition };
```

### 被前端调用

- **审批流程（approvalWorkflow）**：在审批流程列表页面中，当用户点击"查看详情"链接时，前端会调用此服务端逻辑，传入审批流程ID参数，获取完整的审批流程配置信息并在详情页面进行展示。

### 依赖的枚举、实体

- **预算管理-实体-审批流程**：[预算管理-实体-审批流程（ApprovalWorkflow）](specs/001-bootdo-management-system/plan/data-model/entity-ApprovalWorkflow.md)
- **工作流引擎-实体-流程定义**：[工作流引擎-实体-流程定义（ProcessDefinition）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessDefinition.md)

### 依赖的外部能力

无匹配内容

