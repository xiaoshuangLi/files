# 薪资管理-查询年薪总额列表（queryAnnualSalaryTotalList）

- **生成时间**：2026-03-25

## 查询年薪总额列表（queryAnnualSalaryTotalList）

### 功能概述

查询年薪总额列表服务端逻辑用于支持年薪总额计算功能页面的数据查询需求，提供分页、排序和条件过滤的年薪总额记录查询功能。该逻辑通过查询年薪总额实体表，结合系统账户实体关联，返回符合条件的年薪总额记录列表及其总数。用户可以通过员工ID、财年等条件进行精确查询，也可以通过员工姓名等信息进行模糊匹配。查询结果包含年薪总额的详细信息以及关联的员工基本信息，支持前端页面的数据展示、统计分析和报表导出功能。

### 功能要点

- **分页查询功能**：支持按页码和每页条数进行分页查询，避免一次性加载大量数据导致性能问题，确保系统在处理大规模年薪数据时仍能保持良好的响应速度。
- **多条件过滤查询**：支持根据员工ID、财年等精确条件以及员工姓名等模糊条件进行复合查询，满足人力资源部门对不同维度年薪数据的筛选需求。
- **排序功能**：支持按年薪总额、财年、计算时间等字段进行升序或降序排列，便于用户快速找到关注的数据记录。
- **关联数据查询**：在查询年薪总额记录的同时，关联获取员工的基本信息（如姓名、邮箱等），减少前端多次请求的开销，提升用户体验。
- **数据统计支持**：返回查询结果总数，支持前端实现分页控件和数据统计展示，为薪酬分析提供基础数据支撑。

### 逻辑签名

```naturalts path="app.logics.queryAnnualSalaryTotalList.ts"
$Logic({
    description: '查询年薪总额列表',
    directory: 'salary_management(薪资管理)'
})
export declare function queryAnnualSalaryTotalList(page: Integer, size: Integer, sort: String, order: String, employeeId?: Integer, fiscalYear?: Integer, employeeName?: String): { list: List<{ annualSalaryTotal: app.dataSources.defaultDS.entities.AnnualSalaryTotal, employee: app.dataSources.defaultDS.entities.SystemAccount }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 查询的页码，从1开始 |
| size | 每页条数 | Integer | 每页显示的记录数量 |
| sort | 排序字段 | String | 排序的字段名，如"totalAmount"、"fiscalYear"等 |
| order | 排序顺序 | String | 排序顺序，"asc"表示升序，"desc"表示降序 |
| employeeId | 员工ID | Integer? | 精确匹配的员工ID，可选参数 |
| fiscalYear | 财年 | Integer? | 精确匹配的财年，可选参数 |
| employeeName | 员工姓名 | String? | 模糊匹配的员工姓名，可选参数 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 年薪总额列表 | List<{ annualSalaryTotal: app.dataSources.defaultDS.entities.AnnualSalaryTotal, employee: app.dataSources.defaultDS.entities.SystemAccount }> | 年薪总额记录列表，每个列表项包含年薪总额实体和关联的员工账户实体 |
| total | 总记录数 | Integer | 符合查询条件的总记录数 |

### 被前端调用

- **年薪总额计算（annualSalaryTotal）**：在年薪总额计算页面中，用户输入查询条件（如员工ID、年份等）后，前端调用此服务端逻辑获取分页的年薪总额记录列表，用于在表格中展示查询结果，并支持后续的查看详情、编辑、删除等操作。

### 依赖的枚举、实体

- **数据建模-实体-年薪总额**：[薪资管理-实体-年薪总额（AnnualSalaryTotal）](specs/001-bootdo-management-system/plan/data-model/entity-AnnualSalaryTotal.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无匹配内容

