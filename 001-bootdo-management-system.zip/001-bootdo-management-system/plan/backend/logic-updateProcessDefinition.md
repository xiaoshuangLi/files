# 工作流引擎-更新流程定义（updateProcessDefinition）

- **生成时间**：2026-03-25

## 更新流程定义（updateProcessDefinition）

### 功能概述

更新流程定义功能允许系统管理员对已存在的工作流模型进行修改和更新。该功能支持编辑流程的基本信息（如名称、描述）以及完整的BPMN XML流程定义内容，确保业务流程能够根据实际需求进行调整和优化。通过此服务端逻辑，管理员可以保持流程定义的时效性和准确性，适应不断变化的业务规则和审批要求。更新操作会保留原有的流程ID，但会更新创建时间和更新者信息，同时记录完整的变更历史，便于后续审计和版本追踪。

### 功能要点

- **流程基本信息更新**：系统管理员可以修改流程定义的基本属性，包括流程名称和流程描述。流程名称作为流程的标识必须保持唯一性，系统在更新时会进行重复性校验，防止出现同名流程导致混淆。流程描述字段支持富文本格式，允许管理员详细说明流程的用途、适用场景和注意事项，为流程使用者提供清晰的指导。

- **BPMN流程定义更新**：系统管理员可以更新流程的BPMN XML定义内容，这是流程定义的核心部分。更新操作支持完整的BPMN 2.0标准，包括流程节点、流转条件、任务分配规则、网关配置等所有流程元素。系统会对上传的BPMN XML进行语法验证，确保其符合标准规范，避免因格式错误导致流程无法正常执行。更新后的流程定义将立即生效，影响后续创建的流程实例。

- **权限控制与审计**：更新流程定义操作仅限于具有系统管理员角色的用户执行，确保流程定义的安全性和稳定性。每次更新操作都会记录详细的审计日志，包括操作人、操作时间、原流程定义和新流程定义的关键差异信息。这些审计信息有助于追踪流程变更历史，满足企业合规性要求，并在出现问题时快速定位变更原因。

### 逻辑签名

```naturalts path="app.logics.updateProcessDefinition.ts"
$Logic({
    description: '更新流程定义',
    directory: 'workflow_engine(工作流引擎)',
    transactional: true
})
export declare function updateProcessDefinition(
  id: Integer,
  name: String,
  description: String,
  bpmnXml: String
): app.dataSources.defaultDS.entities.ProcessDefinition;
```

### 被前端调用

- **流程定义（processDefinition）**：在流程定义管理页面中，当系统管理员点击编辑按钮并提交修改后的流程信息时，前端会调用此服务端逻辑来更新指定ID的流程定义，实现流程模型的修改功能。

### 依赖的枚举、实体

- **数据建模-实体-流程定义**：[工作流引擎-实体-流程定义（ProcessDefinition）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessDefinition.md)

### 依赖的外部能力

（无）