# 办公自动化-获取文档协作列表（getDocumentCollaborationList）

- **生成时间**：2026-03-25

## 获取文档协作列表（getDocumentCollaborationList）

### 功能概述

获取文档协作列表服务端逻辑提供查询和筛选系统中所有文档协作记录的功能。该逻辑支持基于多种条件的查询，包括文档标题关键词搜索、创建者筛选、创建时间范围过滤等。返回的结果包含文档的基本信息，如文档ID、标题、创建者、创建时间和更新时间等关键字段。该服务还支持分页功能，允许前端按需加载文档列表，提高系统性能和用户体验。通过与权限中心集成，确保用户只能查看其有权限访问的文档，保障数据安全性和隐私性。

### 功能要点

- **文档列表查询与筛选**：支持多维度的文档查询条件，包括文档标题模糊匹配、创建者ID精确匹配、创建时间范围筛选等。用户可以通过组合不同的查询条件来精确定位所需的文档列表。系统会对查询参数进行验证和处理，确保查询的安全性和有效性。查询结果按照更新时间倒序排列，确保最新的文档优先显示，便于用户快速找到最近编辑的文档。

### 逻辑签名

```naturalts path="app.logics.getDocumentCollaborationList.ts"
$Logic({
    description: '获取文档协作列表',
    directory: 'office_automation(办公自动化)'
})
export declare function getDocumentCollaborationList(
    page: Integer,
    size: Integer,
    title?: String,
    authorId?: Integer,
    createdTimeStart?: DateTime,
    createdTimeEnd?: DateTime
): { list: List<app.dataSources.defaultDS.entities.DocumentCollaboration>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 分页查询的页码，从1开始 |
| size | 每页数量 | Integer | 每页返回的文档数量 |
| title | 文档标题 | String | 文档标题关键词，用于模糊匹配 |
| authorId | 创建者ID | Integer | 文档创建者的用户ID |
| createdTimeStart | 创建开始时间 | DateTime | 文档创建时间的起始时间点 |
| createdTimeEnd | 创建结束时间 | DateTime | 文档创建时间的结束时间点 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 文档列表 | List<app.dataSources.defaultDS.entities.DocumentCollaboration> | 符合条件的文档协作记录列表 |
| total | 总数量 | Integer | 符合条件的文档总数 |

### 被前端调用

- **文档协作（documentCollaboration）**：在文档协作功能页面中，当用户进入文档列表视图时，前端会调用此服务端逻辑来获取文档列表。该逻辑支持用户通过搜索框输入关键词、选择时间范围等方式筛选文档，并以分页形式展示结果，实现高效的文档浏览和管理功能。

### 依赖的枚举、实体

- **数据建模-实体-文档协作**：[办公自动化-实体-文档协作（DocumentCollaboration）](specs/001-bootdo-management-system/plan/data-model/entity-DocumentCollaboration.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无