# 薪资管理-计算月度工资（calculateMonthlySalary）

- **生成时间**：2026-03-25

## 计算月度工资（calculateMonthlySalary）

### 功能概述

该服务端逻辑负责根据员工的薪资结构、考勤记录、绩效评估和其他相关因素，计算员工的月度工资金额。系统会综合考虑基本工资、岗位津贴、绩效奖金、加班费、各类补贴以及扣除项（如社保、公积金、个人所得税等），最终得出员工当月应发工资和实发工资。此功能确保薪资计算的准确性和合规性，支持不同薪酬档级和薪资调整历史的处理。

### 功能要点

- **薪资结构处理**：根据员工所属的薪酬档级和薪资结构调整历史，确定基本工资组成部分。系统能够识别并应用最新的薪资结构配置，包括固定部分（基本工资、岗位工资）和浮动部分（绩效工资、奖金）。同时支持处理试用期、转正、晋升等特殊状态下的薪资计算规则，确保在不同雇佣状态下薪资计算的准确性。

### 逻辑签名

```naturalts path="app.logics.calculateMonthlySalary.ts"
$Logic({
    description: '计算员工月度工资',
    directory: 'salary_management(薪资管理)'
})
export declare function calculateMonthlySalary(
  employeeId: String,
  salaryYear: Integer,
  salaryMonth: Integer
): MonthlySalaryAmount;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| employeeId | 员工ID | String | 员工唯一标识符 |
| salaryYear | 年份 | Integer | 薪资计算年份 |
| salaryMonth | 月份 | Integer | 薪资计算月份 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 月度工资计算结果 | MonthlySalaryAmount | 包含基本工资、津贴、奖金、扣除项等详细信息的月度工资计算结果 |

### 被前端调用

- **薪资报表（salaryReport）**：薪资报表页面调用此服务端逻辑来获取指定员工在特定月份的工资计算详情，用于展示工资明细和生成工资条。用户可以通过选择不同的员工和月份，查看对应的月度工资计算结果，包括各项收入和扣除明细。

### 依赖的枚举、实体

- **数据建模-实体-月工资额**：[薪资管理-实体-月工资额（MonthlySalaryAmount）](specs/001-bootdo-management-system/plan/data-model/entity-MonthlySalaryAmount.md)
- **数据建模-实体-薪资结构**：[薪资管理-实体-薪资结构（SalaryStructure）](specs/001-bootdo-management-system/plan/data-model/entity-SalaryStructure.md)
- **数据建模-实体-薪酬档级**：[薪资管理-实体-薪酬档级（CompensationGrade）](specs/001-bootdo-management-system/plan/data-model/entity-CompensationGrade.md)

### 依赖的外部能力

[文件内部已经提供，无需进行生成。如果文件内部已经有 `依赖的外部能力` 内容，禁止修改或删除文件内的 `依赖的外部能力` 内容]