# 系统管理-批量删除操作日志（batchDeleteOperationLogs）

- **生成时间**：2026-03-25

## 批量删除操作日志（batchDeleteOperationLogs）

### 功能概述

批量删除操作日志服务端逻辑用于支持系统管理员一次性删除多条操作日志记录，提高日志清理效率。该功能接收一个包含多个操作日志ID的列表作为输入参数，对每个ID执行删除验证和权限检查，确保只有授权用户才能执行删除操作。删除成功后，系统会从数据库中永久移除这些日志记录，并返回操作结果统计信息，包括成功删除的数量和失败的数量。此功能对于维护系统性能、释放存储空间以及定期清理过期日志具有重要意义，同时保证了操作的安全性和可追溯性。

### 功能要点

- **批量删除能力**：支持一次性删除多条操作日志记录，通过传入操作日志ID数组实现高效批量处理，避免逐条删除带来的性能开销和用户体验问题。系统会对每个ID进行独立验证和处理，确保即使部分删除失败也不会影响其他记录的删除操作，提供原子性的批量操作体验。
- **权限与安全控制**：严格限制只有具备系统管理员权限的用户才能执行批量删除操作，防止普通用户误删或恶意删除重要操作日志。系统在执行删除前会验证当前用户的权限级别，并记录此次批量删除操作本身作为新的操作日志，确保所有敏感操作都有迹可循，符合系统安全审计要求。
- **操作结果反馈**：提供详细的删除操作结果反馈，包括成功删除的日志数量、失败删除的日志数量以及具体的失败原因（如ID不存在、权限不足等）。这种细粒度的结果报告帮助管理员了解操作执行情况，便于后续的问题排查和处理，提升系统的可用性和可靠性。

### 逻辑签名

```naturalts path="app.logics.batchDeleteOperationLogs.ts"
$Logic({
    description: '批量删除操作日志',
    directory: 'system_management(系统管理)'
})
export declare function batchDeleteOperationLogs(logIds: List<Integer>): {
    successCount: Integer;
    failureCount: Integer;
    failureDetails: List<{
        logId: Integer;
        reason: String;
    }>;
};
```

### 被前端调用

- **日志管理（logManagement）**：在日志管理页面中，系统管理员可以勾选多条操作日志记录，点击批量删除按钮后，前端调用此服务端逻辑，一次性删除所有选中的日志记录，提高日志清理效率。

### 依赖的枚举、实体

- **数据建模-实体-操作记录**：[系统管理-实体-操作记录（OperationRecord）](specs/001-bootdo-management-system/plan/data-model/entity-OperationRecord.md)

### 依赖的外部能力

无