# 权限中心-获取用户列表（getUserList）

- **生成时间**：2026-03-25

## 获取用户列表（getUserList）

### 功能概述

获取用户列表服务端逻辑是权限中心的核心数据查询接口，用于支持用户管理页面的分页表格展示功能。该逻辑提供完整的用户数据分页查询能力，支持按用户名、邮箱等关键字段进行筛选过滤，并可按指定字段和顺序进行排序。返回的数据包含用户的基本信息（用户名、全名、邮箱）、账户状态、用户来源以及完整的创建和更新审计信息。此逻辑确保前端能够高效地加载和展示系统中的所有用户账户，为用户管理操作提供数据基础。通过标准化的分页查询接口，系统能够处理大量用户数据而不会影响性能，同时保持数据的一致性和完整性。

### 功能要点

- **分页查询与排序功能**：支持标准的分页查询参数（页码、每页条数），并允许按任意用户字段进行升序或降序排列，确保前端表格能够灵活展示用户数据。查询结果包含当前页的用户列表和总记录数，便于实现完整的分页导航功能。
- **多条件筛选过滤**：支持基于用户实体属性的多条件筛选，包括用户名模糊匹配、邮箱精确匹配、用户状态和用户来源的精确匹配等。这些筛选条件通过用户实体对象传递，确保查询的灵活性和一致性，满足不同场景下的用户查找需求。
- **完整用户信息返回**：返回的用户数据包含系统账户实体的所有核心字段，包括基本身份信息（用户名、全名、邮箱）、账户状态（正常/禁用）、用户来源（普通登录/OpenId）以及完整的审计信息（创建时间、更新时间、创建者、更新者）。这些信息为用户管理页面提供了全面的数据展示基础。

### 逻辑签名

```naturalts path="app.logics.getUserList.ts"
$Logic({
    description: '获取用户列表',
    directory: 'permission_center(权限中心)'
})
export declare function getUserList(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.SystemAccount): { list: List<app.dataSources.defaultDS.entities.SystemAccount>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 分页查询的页码，从1开始 |
| size | 每页条数 | Integer | 每页返回的用户记录数量 |
| sort | 排序字段 | String | 用于排序的用户字段名称 |
| order | 排序顺序 | String | 排序顺序，'asc'表示升序，'desc'表示降序 |
| filter | 过滤条件 | app.dataSources.defaultDS.entities.SystemAccount | 用户筛选条件，支持用户名、邮箱、状态、来源等字段的过滤 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 用户列表 | List<app.dataSources.defaultDS.entities.SystemAccount> | 当前页的用户账户实体列表 |
| total | 总条数 | Integer | 符合筛选条件的用户总记录数 |

### 被前端调用

- **用户管理页（userManagement）**：在用户管理页面中，通过分页表格展示系统用户列表时调用此逻辑。该逻辑为表格提供分页数据，支持按用户名筛选、排序等功能，是用户管理页面的核心数据源。

### 依赖的枚举、实体

- **数据建模-枚举-用户状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-枚举-用户来源**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-系统账户**：[数据建模-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无