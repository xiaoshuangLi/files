# 内容管理-验证栏目名称唯一性（validateColumnNameUniqueness）

- **生成时间**：2026-03-25

## 验证栏目名称唯一性（validateColumnNameUniqueness）

### 功能概述

该服务端逻辑用于验证在创建或更新栏目时，栏目名称在同一父级目录下是否唯一。系统需要确保用户输入的栏目名称不会与同级已存在的栏目名称重复，以维护栏目结构的清晰性和避免混淆。此功能在栏目管理界面中实时调用，为用户提供即时反馈，防止因名称重复导致的数据混乱和用户体验问题。

### 功能要点

- **栏目名称唯一性校验**：系统需要检查用户输入的栏目名称在同一父级目录下是否已经存在。校验过程需要考虑大小写敏感性，并支持特殊字符的正确处理。当检测到重复名称时，系统应返回明确的错误信息，指导用户修改名称。此功能对于维护多级栏目树形结构的完整性至关重要，确保每个栏目在同级目录中具有唯一的标识。

### 逻辑签名

```naturalts path="app.logics.validateColumnNameUniqueness.ts"
$Logic({
    description: '验证栏目名称唯一性',
    directory: 'content_management(内容管理)'
})
export declare function validateColumnNameUniqueness(columnName: String, parentId?: String): Boolean;
```

### 被前端调用

- **栏目结构（columnStructure）**：在创建新栏目或编辑现有栏目名称时，调用此服务端逻辑验证输入的栏目名称在同一父级目录下是否唯一，确保栏目结构的清晰性和避免命名冲突。

### 依赖的枚举、实体

- **数据建模-实体-栏目结构**：[内容管理-实体-栏目结构（ColumnStructure）](specs/001-bootdo-management-system/plan/data-model/entity-ColumnStructure.md)

### 依赖的外部能力
