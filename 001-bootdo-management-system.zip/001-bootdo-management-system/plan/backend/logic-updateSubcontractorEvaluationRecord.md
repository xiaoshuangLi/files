# 分包商管理-更新分包商评估记录（updateSubcontractorEvaluationRecord）

- **生成时间**：2026-03-25

## 更新分包商评估记录（updateSubcontractorEvaluationRecord）

### 功能概述

更新分包商评估记录服务端逻辑用于修改系统中已存在的分包商绩效评估记录。该逻辑接收完整的评估记录实体作为输入参数，包括评估ID、分包商ID、评估人ID、绩效评分、评估意见和评估时间等关键信息，并将这些信息持久化到数据库中。通过此服务，用户可以修正之前录入的错误数据、补充遗漏的评估意见或更新评估结果，确保分包商绩效评估数据的准确性和完整性。该逻辑是分包商评估管理体系中的重要组成部分，支持对历史评估数据的动态维护和修正。

### 功能要点

- **完整评估记录更新**：支持更新评估记录的所有字段，包括绩效评分(performanceScore)、评估意见(evaluationComments)和评估时间(evaluatedAt)等核心评估指标。系统会验证输入数据的完整性和有效性，确保更新后的评估记录符合业务规则，如绩效评分必须在0-100范围内，评估时间和分包商ID等关键字段不能为空。
- **数据一致性保障**：在更新过程中，系统会验证关联的分包商(subcontractorId)和评估人(evaluatorId)是否存在且有效，防止出现孤立的评估记录。同时，系统会自动更新记录的updatedTime和updatedBy字段，记录最后修改的时间和操作人，便于后续的数据审计和追踪。
- **事务性操作保证**：整个更新操作在一个数据库事务中执行，确保数据的一致性和完整性。如果更新过程中发生任何异常，系统会自动回滚所有更改，避免产生部分更新导致的数据不一致问题，保证评估记录数据的可靠性。

### 逻辑签名

```naturalts path="app.logics.updateSubcontractorEvaluationRecord.ts"
$Logic({
    description: '更新分包商评估记录',
    directory: 'subcontractor_management(分包商管理)',
    transactional: true
})
export declare function updateSubcontractorEvaluationRecord(evaluationRecord: app.dataSources.defaultDS.entities.EvaluationRecord): app.dataSources.defaultDS.entities.EvaluationRecord;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| evaluationRecord | 评估记录 | app.dataSources.defaultDS.entities.EvaluationRecord | 完整的评估记录实体，包含需要更新的所有字段 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 更新结果 | app.dataSources.defaultDS.entities.EvaluationRecord | 更新后的评估记录实体，包含完整的字段信息 |

### 被前端调用

- **评估记录（evaluationRecord）**：评估记录管理页面使用此服务端逻辑更新已有的分包商评估记录。当用户在编辑表单中修改评估信息并提交时，页面会将完整的评估记录实体传递给此接口，实现评估数据的更新操作。该功能支持用户修正错误数据、补充评估意见或调整绩效评分，确保评估记录的准确性和完整性。

### 依赖的枚举、实体

- **数据建模-实体-评估记录**：[分包商管理-实体-评估记录（EvaluationRecord）](specs/001-bootdo-management-system/plan/data-model/entity-EvaluationRecord.md)
- **数据建模-实体-分包商信息**：[分包商管理-实体-分包商信息（SubcontractorInformation）](specs/001-bootdo-management-system/plan/data-model/entity-SubcontractorInformation.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无