# 质量管理-获取质量检验详情（getQualityInspectionDetail）

- **生成时间**：2026-03-25

## 获取质量检验详情（getQualityInspectionDetail）

### 功能概述

获取质量检验详情服务端逻辑用于根据检验ID查询并返回完整的质量检验详细信息，包括检验结果、检验员信息、检验时间、通过状态以及关联的质量问题数据。该逻辑是质量检验页面的核心数据支撑接口，确保用户能够查看特定质量检验记录的完整信息。通过关联查询系统账户实体和质量问题实体，该逻辑提供了一个包含所有必要上下文信息的完整数据视图，支持前端展示质量检验的详细内容，并为后续可能的编辑操作提供基础数据。

### 功能要点

- **质量检验详情查询**：根据提供的质量检验ID，从数据库中精确查询对应的检验记录。该功能点确保系统能够准确获取指定ID的质量检验数据，避免数据混淆或错误。查询过程需要验证ID的有效性，并处理不存在记录的情况，保证系统的健壮性和用户体验的一致性。

- **关联数据加载**：在返回质量检验详情的同时，自动加载关联的质量问题(QualityIssue)和检验员(SystemAccount)的详细信息。质量问题数据包括问题标题、描述、状态等关键信息，检验员数据包括用户名、全名、邮箱等基本信息。这种关联查询减少了前端多次请求的开销，提供了一站式的完整数据视图，提升用户体验和数据展示效率。

### 逻辑签名

```naturalts path="app.logics.getQualityInspectionDetail.ts"
$Logic({
    description: '获取质量检验详情',
    directory: 'quality_management(质量管理)'
})
export declare function getQualityInspectionDetail(id: Integer): { 
  qualityInspection: app.dataSources.defaultDS.entities.QualityInspection, 
  qualityIssue: app.dataSources.defaultDS.entities.QualityIssue,
  inspector: app.dataSources.defaultDS.entities.SystemAccount 
};
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| id | 质量检验ID | Integer | 要查询的质量检验记录的唯一标识符 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| qualityInspection | 质量检验 | app.dataSources.defaultDS.entities.QualityInspection | 完整的质量检验实体数据 |
| qualityIssue | 质量问题 | app.dataSources.defaultDS.entities.QualityIssue | 关联的质量问题实体数据 |
| inspector | 检验员 | app.dataSources.defaultDS.entities.SystemAccount | 关联的系统账户实体数据，表示执行检验的用户 |

### 被前端调用

- **质量检验（qualityInspection）**：在质量检验详情页面中，当用户点击某条质量检验记录时，前端调用此服务端逻辑获取完整的质量检验详情数据，用于展示检验结果、检验员信息、检验时间、通过状态等核心数据，以及关联的质量问题信息。

### 依赖的枚举、实体

- **数据建模-实体-质量检验**：[质量管理-实体-质量检验（QualityInspection）](specs/001-bootdo-management-system/plan/data-model/entity-QualityInspection.md)
- **数据建模-实体-质量问题**：[质量管理-实体-质量问题（QualityIssue）](specs/001-bootdo-management-system/plan/data-model/entity-QualityIssue.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无