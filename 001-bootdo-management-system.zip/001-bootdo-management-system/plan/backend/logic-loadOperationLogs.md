# 系统管理-加载操作日志（loadOperationLogs）

- **生成时间**：2026-03-25

## 加载操作日志（loadOperationLogs）

### 功能概述

加载操作日志服务端逻辑用于分页查询系统中的操作记录数据，支持按用户ID、操作类型、时间范围等条件进行过滤，并提供排序功能。该逻辑是日志管理页面的核心数据支撑接口，返回包含操作记录列表和总记录数的分页结果。每条操作记录包含完整的操作信息，包括执行操作的用户账户信息、操作类型、操作详情、IP地址和操作时间等关键字段。通过关联查询系统账户实体，该逻辑能够提供操作用户的完整身份信息，便于系统管理员进行安全审计、异常行为检测和操作追溯。

### 功能要点

- **分页查询与过滤功能**：支持标准的分页参数（页码、每页条数）控制返回数据量，避免一次性加载过多数据导致性能问题。同时支持通过操作记录实体（OperationRecord）作为过滤条件，允许按用户ID、操作类型、操作时间范围等多个维度进行精确筛选，帮助管理员快速定位到关注的操作记录。
- **关联数据查询**：在返回操作记录列表的同时，自动关联获取执行操作的用户账户（SystemAccount）详细信息，包括用户名、全名等关键身份信息。这种关联查询减少了前端的多次请求，提高了数据展示的完整性和用户体验，使管理员能够直观地看到操作是由哪个具体用户执行的。
- **排序与分页支持**：支持按任意字段进行升序或降序排列，默认按操作时间降序排列，确保最新的操作记录优先显示。分页查询结果包含当前页的数据列表和总记录数，便于前端实现完整的分页控件，支持管理员高效浏览大量操作日志数据.

### 逻辑签名

```naturalts path="app.logics.loadOperationLogs.ts"
$Logic({
    description: '分页查询操作日志',
    directory: 'system_management(系统管理)'
})
export declare function loadOperationLogs(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.OperationRecord): { list: List<{ operationRecord: app.dataSources.defaultDS.entities.OperationRecord, userAccount: app.dataSources.defaultDS.entities.SystemAccount }>, total: Integer };
```

### 被前端调用

- **日志管理（logManagement）**：日志管理页面在初始化时调用此服务端逻辑加载操作日志列表数据，支持系统管理员查看所有操作记录。页面通过分页、筛选和排序参数调用此接口，获取符合业务需求的操作日志数据，并在表格中展示用户、操作类型、操作详情、IP地址、操作时间等关键信息.

### 依赖的枚举、实体

- **数据建模-实体-操作记录**：[系统管理-实体-操作记录（OperationRecord）](specs/001-bootdo-management-system/plan/data-model/entity-OperationRecord.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无匹配内容

