# 预算管理-获取分析报告列表（getAnalysisReportList）

- **生成时间**：2026-03-25

## 获取分析报告列表（getAnalysisReportList）

### 功能概述

获取分析报告列表服务端逻辑提供查询和筛选预算执行分析报告的功能。该逻辑支持用户查看系统中所有已生成的分析报告，并可以根据预算分配ID和报表格式ID进行条件筛选。返回的结果包含分析报告的基本信息，如报告ID、关联的预算分配、使用的报表格式、生成时间等关键字段，为前端分析报告页面的列表展示提供数据支持。该服务确保用户能够快速定位和访问所需的预算分析报告，提高预算管理的效率和透明度。

### 功能要点

- **分页查询分析报告列表**：支持分页获取分析报告列表，避免一次性加载过多数据导致性能问题和用户体验下降。系统默认按生成时间倒序排列，确保最新的分析报告显示在列表最前面，便于用户快速查看和访问最近生成的预算执行分析报告，提高工作效率和数据获取的及时性。
- **按预算分配筛选**：支持通过预算分配ID参数筛选特定预算分配相关的分析报告，帮助用户聚焦于特定预算项目的分析结果，提高数据查询的精准度和相关性，满足用户对特定预算项目进行深入分析的需求。
- **按报表格式筛选**：支持通过报表格式ID参数筛选使用特定报表模板生成的分析报告，便于用户比较不同报表格式下的分析结果，满足多样化的分析需求和不同管理层级对数据展示格式的偏好。
- **返回完整报告元数据**：返回的分析报告列表包含完整的元数据信息，包括报告ID、预算分配ID、报表格式ID、生成时间等关键字段，但不包含详细的报告内容（reportContent字段），以优化列表加载性能，确保页面响应速度。
- **权限控制集成**：在查询分析报告列表时，自动集成系统的权限控制机制，确保用户只能查看其有权限访问的预算分配所生成的分析报告，严格遵循数据安全和隐私保护原则，防止未授权的数据访问。

### 逻辑签名

```naturalts path="app.logics.loadAnalysisReportList.ts"
$Logic({
  description: '分页查询分析报告列表',
  directory: 'budget_management(预算管理)'
})
export declare function getAnalysisReportList(
  budgetAllocationId?: Integer,
  reportFormatId?: Integer,
  page: Integer,
  size: Integer
): { 
  list: List<app.dataSources.defaultDS.entities.AnalysisReport>, 
  total: Integer 
};
```

### 被前端调用

- **分析报告（analysisReport）**：在分析报告页面中，当用户进入页面或切换筛选条件时，调用此服务端逻辑获取符合条件的分析报告列表，用于在页面上展示报告列表，支持用户进行后续的查看详情、导出等操作。

### 依赖的枚举、实体

- **数据建模-实体-分析报告**：[预算管理-实体-分析报告（AnalysisReport）](specs/001-bootdo-management-system/plan/data-model/entity-AnalysisReport.md)
- **数据建模-实体-预算分配**：[预算管理-实体-预算分配（BudgetAllocation）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetAllocation.md)
- **数据建模-实体-报表格式**：[预算管理-实体-报表格式（ReportFormat）](specs/001-bootdo-management-system/plan/data-model/entity-ReportFormat.md)

### 依赖的外部能力

无匹配内容

