# 通用领域服务-获取文档协作详情（getDocumentCollaborationDetail）

- **生成时间**：2026-03-25

## 获取文档协作详情（getDocumentCollaborationDetail）

### 功能概述

该服务端逻辑用于获取指定文档协作的详细信息，包括文档基本信息、协作者列表、编辑历史、权限设置以及当前状态等。系统会根据用户提供的文档ID查询数据库，验证用户是否有权访问该文档，然后返回完整的文档协作详情。此功能支持个人工作台中的文档协作模块，使用户能够查看自己参与或拥有的协作文档的完整信息，便于进行后续的编辑、分享或管理操作。

### 功能要点

- **文档详情获取**：根据文档ID精确查询文档协作的详细信息，包括文档标题、内容摘要、创建时间、最后修改时间、文档状态等基本信息。系统会验证文档是否存在以及请求用户是否有权限查看该文档，确保数据安全性和隐私保护。对于不存在的文档或无权限访问的情况，系统将返回相应的错误信息而非空数据。

### 逻辑签名

```naturalts path="app.logics.getDocumentCollaborationDetail.ts"
$Logic({
    description: '获取文档协作详情',
    directory: 'personal_workspace(个人工作台)'
})
export declare function getDocumentCollaborationDetail(documentId: String): app.dataSources.defaultDS.entities.DocumentCollaboration;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| documentId | 文档ID | String | 文档唯一标识符 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 文档协作详情 | app.dataSources.defaultDS.entities.DocumentCollaboration | 完整的文档协作实体信息 |

### 被前端调用

- **个人工作台（personalWorkspace）**：在个人工作台的文档协作列表中，当用户点击某个文档时，调用此服务端逻辑获取该文档的详细信息，用于展示文档内容、协作者信息和操作选项。

### 依赖的枚举、实体

- **数据建模-实体-文档协作**：[办公自动化-实体-文档协作（DocumentCollaboration）](specs/001-bootdo-management-system/plan/data-model/entity-DocumentCollaboration.md)

### 依赖的外部能力

无