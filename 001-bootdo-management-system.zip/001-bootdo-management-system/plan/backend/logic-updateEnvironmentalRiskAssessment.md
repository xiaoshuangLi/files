# 环保管理-更新环境风险评估（updateEnvironmentalRiskAssessment）

- **生成时间**：2026-03-25

## 更新环境风险评估（updateEnvironmentalRiskAssessment）

### 功能概述

更新环境风险评估服务端逻辑用于修改已存在的环境风险评估记录。该逻辑支持对环境风险评估的各项关键信息进行编辑和更新，包括风险类型、风险等级、评估结果描述、评估日期等核心字段。系统会对更新操作进行权限验证，确保只有授权用户才能修改相关数据，并对输入数据进行完整性校验，保证数据的一致性和有效性。更新后的数据会自动同步到关联系统模块，如合规检查和应急预案，确保整个环保管理体系的数据一致性。

### 功能要点

- **环境风险评估数据更新**：支持对已存在的环境风险评估记录进行全面或部分字段的更新操作。用户可以修改风险类型、风险等级、评估结果详细描述、评估日期等关键信息，系统会保留原有的创建时间和创建者信息，同时更新修改时间和修改者信息。更新操作会触发数据验证规则，确保修改后的数据符合业务规范要求，并自动维护与合规检查实体和应急预案实体的关联关系。

### 逻辑签名

```naturalts path="app.logics.updateEnvironmentalRiskAssessment.ts"
$Logic({
    description: '更新环境风险评估',
    directory: 'environmental_management(环保管理)'
})
export declare function updateEnvironmentalRiskAssessment(
  id: Integer,
  riskType: String,
  riskLevel: app.enums.RiskLevelEnum,
  assessmentResult: String,
  assessmentDate: Date,
  complianceStatus: app.enums.ComplianceStatusEnum,
  complianceInspectionId: Integer,
  emergencyPlanId: Integer
): app.dataSources.defaultDS.entities.EnvironmentalRiskAssessment;
```

### 被前端调用

- **风险评估（environmentalRiskAssessment）**：在风险评估页面中，用户点击"编辑"按钮后，通过调用此服务端逻辑来更新已存在的环境风险评估记录，实现对环境风险数据的修改和维护功能。

### 依赖的枚举、实体

- **数据建模-枚举-风险等级**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-枚举-环保合规状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-环境风险评估**：[环保管理-实体-环境风险评估（EnvironmentalRiskAssessment）](specs/001-bootdo-management-system/plan/data-model/entity-EnvironmentalRiskAssessment.md)
- **数据建模-实体-合规检查**：[环保管理-实体-合规检查（ComplianceInspection）](specs/001-bootdo-management-system/plan/data-model/entity-ComplianceInspection.md)
- **数据建模-实体-应急预案**：[环保管理-实体-应急预案（EmergencyPlan）](specs/001-bootdo-management-system/plan/data-model/entity-EmergencyPlan.md)

### 依赖的外部能力

无