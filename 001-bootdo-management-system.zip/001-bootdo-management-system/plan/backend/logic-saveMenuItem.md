# 系统管理-保存菜单项（saveMenuItem）

- **生成时间**：2026-03-25

## 保存菜单项（saveMenuItem）

### 功能概述

保存菜单项服务端逻辑用于处理系统导航菜单的创建和更新操作。该逻辑接收前端传递的菜单配置信息，包括菜单名称、父菜单ID、URL路径、图标样式、排序权重、角色权限绑定等关键属性，并将其持久化存储到数据库中。对于新增菜单项，系统会自动生成唯一标识符并记录创建时间和创建者信息；对于更新操作，系统会验证菜单项的存在性并更新相应的字段，同时记录更新时间和更新者信息。该逻辑还负责维护菜单的树形层级结构，确保父子菜单关系的一致性，并支持菜单项的启用/禁用状态控制，为系统提供灵活的导航菜单配置能力。

### 功能要点

- **菜单数据持久化**：保存菜单项逻辑负责将前端提交的菜单配置数据完整地持久化到数据库中。系统会根据传入的菜单ID判断是新增还是更新操作，对于新增操作会自动生成主键ID并设置默认值（如父菜单ID默认为0表示根菜单，isEnabled默认为true表示启用状态），对于更新操作则会验证菜单项是否存在并仅更新传入的字段。该逻辑确保所有菜单属性（包括菜单名称、URL、图标、排序、角色ID等）都能正确存储，并维护菜单的创建和更新审计信息，为系统提供可靠的菜单数据管理基础。

### 逻辑签名

```naturalts path="app.logics.saveMenuItem.ts"
$Logic({
    description: '保存菜单项',
    directory: 'system_management(系统管理)'
})
export declare function saveMenuItem(menuItem: {
    id?: Integer;
    menuName: String;
    parentMenuId?: Integer;
    menuUrl?: String;
    icon?: String;
    sortOrder?: Integer;
    roleId?: Integer;
    isEnabled?: Boolean;
}): Integer;
```

### 被前端调用

- **菜单管理（menuManagement）**：菜单管理页面通过保存菜单项逻辑实现新菜单的创建和现有菜单的更新功能。当管理员在菜单创建或编辑表单中填写完菜单信息并点击保存按钮时，前端会调用此服务端逻辑，将完整的菜单配置数据提交到后端进行持久化存储，从而实现系统导航菜单的动态配置和管理。

### 依赖的枚举、实体

- **数据建模-实体-导航菜单**：[系统管理-实体-导航菜单（NavigationMenu）](specs/001-bootdo-management-system/plan/data-model/entity-NavigationMenu.md)
- **数据建模-实体-用户角色**：[系统管理-实体-用户角色（UserRole）](specs/001-bootdo-management-system/plan/data-model/entity-UserRole.md)

### 依赖的外部能力

无外部能力依赖