# 工作流引擎-更新表单集成（updateFormIntegration）

- **生成时间**：2026-03-25

## 更新表单集成（updateFormIntegration）

### 功能概述

更新表单集成服务端逻辑负责修改系统中已存在的表单集成记录，允许用户对已关联的业务表单数据进行更新和调整。该逻辑接收包含表单集成ID和更新后的表单数据内容的输入参数，验证数据的有效性和完整性后，在数据库中更新对应的表单集成记录，并返回更新后的完整实体信息。此功能确保了在工作流执行过程中，业务表单数据可以根据实际需求进行动态调整，提高了工作流系统的灵活性和实用性。

### 功能要点

- **表单数据动态更新**：允许用户修改已存在的表单集成记录中的JSON格式表单数据内容，同时保持与原流程实例的关联关系不变。该功能支持在工作流执行过程中的各种业务场景下对表单数据进行修正、补充或调整，确保业务数据的准确性和时效性，同时保证数据更新操作的原子性和一致性，防止并发修改导致的数据冲突。

### 逻辑签名

```naturalts path="app.logics.updateFormIntegration.ts"
$Logic({
    description: '更新工作流表单集成记录',
    directory: 'workflow_engine(工作流引擎)',
    transactional: true
})
export declare function updateFormIntegration(formIntegration: app.dataSources.defaultDS.entities.FormIntegration): app.dataSources.defaultDS.entities.FormIntegration;
```

### 被前端调用

- **通用业务模块-表单集成（formIntegration）**：在表单集成页面中，用户通过表单弹框编辑现有表单集成记录时，调用此服务端逻辑来更新表单数据内容，同时保持与原有流程实例的关联关系。

### 依赖的枚举、实体

- **工作流引擎-实体-表单集成**：[工作流引擎-实体-表单集成（FormIntegration）](specs/001-bootdo-management-system/plan/data-model/entity-FormIntegration.md)
- **工作流引擎-实体-流程实例**：[工作流引擎-实体-流程实例（ProcessInstance）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessInstance.md)

### 依赖的外部能力

无外部能力依赖