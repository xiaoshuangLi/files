# 薪资管理-获取税务计算明细（getTaxCalculationDetails）

- **生成时间**：2026-03-25

## 获取税务计算明细（getTaxCalculationDetails）

### 功能概述

获取税务计算明细服务端逻辑负责查询和返回指定条件下的个人所得税计算详细信息。该功能支持根据员工ID、年份、月份和部门ID等多种条件进行精确查询，返回包含税前工资、各项扣除、应纳税所得额、适用税率、速算扣除数和最终税额等完整税务计算过程的详细数据。系统会从月工资额实体和税务计算实体中提取相关数据，按照国家最新的个人所得税法规定，展示累计预扣法下的完整计算过程，确保用户能够清晰了解每位员工的税务计算依据和结果。该服务还支持批量查询多个员工或时间段的税务计算明细，为薪资报表生成、税务审计和员工查询提供准确的数据支持。

### 功能要点

- **多条件精确查询**：支持通过员工ID、年份、月份和部门ID等多种条件组合进行税务计算明细的精确查询。当用户提供员工ID时，系统返回该员工指定时间段内的所有税务计算记录；当用户提供部门ID时，系统返回该部门所有员工在指定时间段内的税务计算明细；当同时提供年份和月份参数时，系统返回对应月份的所有税务计算数据。查询结果按照员工姓名和计算时间排序，确保数据展示的有序性和可读性。
- **完整税务计算过程展示**：返回完整的个人所得税计算过程详情，包括税前工资总额、基本减除费用（5000元/月）、专项扣除（社保公积金）、专项附加扣除（子女教育、继续教育、大病医疗、住房贷款利息、住房租金、赡养老人）等各项扣除明细，以及累计应纳税所得额、适用税率、速算扣除数和最终应纳税额等关键计算步骤。系统严格按照国家税务总局发布的最新个人所得税法规定和累计预扣法进行计算，确保数据的准确性和合规性。
- **历史数据追溯与对比**：支持查询员工的历史税务计算记录，并提供相邻月份或年度的税务数据对比功能。系统会自动计算并展示税额变化的原因，如薪资调整、扣除项目变更或税率政策更新等因素对税额的影响。这有助于财务人员和员工理解税务计算的变化趋势，提高薪资管理的透明度和可信度。

### 逻辑签名

```naturalts path="app.logics.getTaxCalculationDetails.ts"
$Logic({
    description: "获取税务计算明细",
    directory: "salary_management(薪资管理)"
})
export declare function getTaxCalculationDetails(
    employeeId?: Integer,
    taxYear?: Integer,
    month?: Integer,
    departmentId?: Integer
): List<{
    employeeId: Integer;
    employeeName: String;
    paymentMonth: String;
    grossAmount: Decimal;
    baseDeduction: Decimal;
    socialSecurityDeduction: Decimal;
    housingFundDeduction: Decimal;
    specialAdditionalDeductions: Decimal;
    taxableIncome: Decimal;
    cumulativeTaxableIncome: Decimal;
    taxRate: Decimal;
    quickDeduction: Decimal;
    taxAmount: Decimal;
    netAmount: Decimal;
    calculatedAt: DateTime;
}>;
```

### 被前端调用

- **税务计算（taxCalculation）**：税务计算功能页面调用此服务端逻辑获取指定条件下的税务计算明细数据。当用户在页面上选择特定员工、年份、月份或部门进行查询时，前端会传递相应的查询参数给此服务，获取详细的税务计算结果并在页面上以表格形式展示，包括每位员工的税前工资、各项扣除、应纳税所得额、适用税率和最终税额等完整计算过程。

### 依赖的枚举、实体

- **数据建模-实体-税务计算**：[薪资管理-实体-税务计算（TaxCalculation）](specs/001-bootdo-management-system/plan/data-model/entity-TaxCalculation.md)
- **数据建模-实体-月工资额**：[薪资管理-实体-月工资额（MonthlySalaryAmount）](specs/001-bootdo-management-system/plan/data-model/entity-MonthlySalaryAmount.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无外部能力依赖。该服务端逻辑完全基于系统内部的税务计算实体、月工资额实体和系统账户实体实现数据查询和处理，不依赖任何第三方API或外部服务。