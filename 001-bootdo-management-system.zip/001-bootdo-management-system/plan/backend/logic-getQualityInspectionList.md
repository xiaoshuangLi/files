# 质量管理-获取质量检验列表（getQualityInspectionList）

- **生成时间**：2026-03-25

## 获取质量检验列表（getQualityInspectionList）

### 功能概述

该服务端逻辑用于获取系统中的质量检验列表数据，支持根据多种条件进行筛选和分页查询。用户可以通过指定检验状态、检验类型、时间范围等参数来获取符合要求的质量检验记录。系统会根据用户的权限范围返回相应的数据，确保数据安全性和隔离性。返回的数据包含检验基本信息、关联的质量问题、检验结果、执行人员等详细信息，为前端质量检验页面提供完整的数据支持。

### 功能要点

- **多条件筛选与分页查询**：支持根据检验状态（待检验、检验中、已完成、已取消）、检验类型、创建时间范围、关联项目等多种条件组合筛选质量检验记录，并提供分页功能以优化大数据量下的查询性能。系统会根据用户输入的分页参数（页码、每页数量）返回对应的数据子集，同时包含总记录数以便前端实现完整的分页控件。

### 逻辑签名

```naturalts path="app.logics.getQualityInspectionList.ts"
$Logic({
    description: '获取质量检验列表',
    directory: 'quality_management(质量管理)'
})
export declare function getQualityInspectionList(page: Integer, size: Integer, sort: String, order: String, status?: app.enums.QualityInspectionStatus, inspectionType?: String, startTime?: DateTime, endTime?: DateTime, projectId?: String): { list: List<app.dataSources.defaultDS.entities.QualityInspection>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 页码 |
| size | 每页条数 | Integer | 每页条数 |
| sort | 排序字段 | String | 排序字段 |
| order | 排序顺序 | String | 排序顺序 |
| status | 检验状态 | app.enums.QualityInspectionStatus | 检验状态，可选 |
| inspectionType | 检验类型 | String | 检验类型，可选 |
| startTime | 开始时间 | DateTime | 创建时间范围开始，可选 |
| endTime | 结束时间 | DateTime | 创建时间范围结束，可选 |
| projectId | 项目ID | String | 关联项目ID，可选 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 质量检验列表 | List<app.dataSources.defaultDS.entities.QualityInspection> | 质量检验实体列表 |
| total | 总条数 | Integer | 符合条件的总记录数 |

### 被前端调用

- **质量检验（qualityInspection）**：在质量检验页面中，用户需要查看系统中所有的质量检验记录列表，该页面通过调用此服务端逻辑获取分页数据，并支持按状态、类型、时间等条件筛选，实现质量检验工作的全面监控和管理。

### 依赖的枚举、实体

- **数据建模-枚举-质量检验状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-质量检验**：[质量管理-实体-质量检验（QualityInspection）](specs/001-bootdo-management-system/plan/data-model/entity-QualityInspection.md)

### 依赖的外部能力

[文件内部已经提供，无需进行生成。如果文件内部已经有 `依赖的外部能力` 内容，禁止修改或删除文件内的 `依赖的外部能力` 内容]