# 通用领域服务-创建文档协作（createDocumentCollaboration）

- **生成时间**：2026-03-25

## 创建文档协作（createDocumentCollaboration）

### 功能概述

创建文档协作服务端逻辑负责处理用户在系统中创建新文档的请求。该逻辑接收文档的基本信息（如标题、初始内容等）和创建者身份，验证输入数据的有效性，并在数据库中创建新的文档协作记录。创建成功后，系统会自动设置文档的初始权限（默认仅创建者拥有完全访问权限），记录操作日志，并返回新创建文档的唯一标识符。此逻辑是文档协作功能的基础，为后续的编辑、分享、评论和审批等操作提供数据支持。

### 功能要点

- **文档创建与初始化**：该功能要点负责处理新文档的创建请求，包括验证文档标题的必填性和长度限制（不超过255个字符），初始化文档内容为空字符串或用户提供的初始内容，并设置文档的元数据（如创建时间、更新时间、创建者ID等）。系统会自动关联当前登录用户的系统账户作为文档作者，并确保所有必填字段都已正确填充。创建过程中还会进行权限检查，确保只有经过身份验证的用户才能创建文档，防止未授权访问。

### 逻辑签名

```naturalts path="app.logics.createDocumentCollaboration.ts"
$Logic({
    description: '创建文档协作',
    directory: 'office_automation(办公自动化)',
    transactional: true
})
export declare function createDocumentCollaboration(
  title: String,
  content?: String,
  authorId: Integer
): app.dataSources.defaultDS.entities.DocumentCollaboration;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| title | 文档标题 | String | 文档标题，必填，不超过255个字符 |
| content | 文档初始内容 | String? | 文档初始内容，可选，默认为空字符串 |
| authorId | 文档作者ID | Integer | 文档作者ID，关联SystemAccount实体 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 创建结果 | app.dataSources.defaultDS.entities.DocumentCollaboration | 创建成功的文档协作对象 |

### 被前端调用

- **文档协作（documentCollaboration）**：在文档协作功能页面中，当用户点击"新建文档"按钮并填写文档标题后，前端会调用此服务端逻辑来创建新的文档协作记录。该逻辑负责处理文档的初始创建，为用户提供一个可编辑的空白文档或带有初始内容的文档，是整个文档协作工作流的起点。

### 依赖的枚举、实体

- **数据建模-实体-文档协作**：[办公自动化-实体-文档协作（DocumentCollaboration）](specs/001-bootdo-management-system/plan/data-model/entity-DocumentCollaboration.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无