# 工作流引擎-加载工作流列表（loadWorkflowList）

- **生成时间**：2026-03-25

## 加载工作流列表（loadWorkflowList）

### 功能概述

加载工作流列表服务端逻辑提供审批流程的分页查询功能，支持系统管理员查看和管理各类业务场景中的审批流程配置。该逻辑根据前端传递的分页参数（页码、每页条数）、排序条件（排序字段、排序顺序）以及过滤条件（流程名称、状态、类型、启用状态等），从数据库中检索符合条件的审批流程记录，并返回包含流程基本信息的分页结果。返回的数据包括流程名称、流程状态、流程类型、是否启用、版本号、创建时间、创建者等关键字段，满足审批流程管理页面的数据展示需求。该逻辑还支持与其他相关实体（如流程定义）的关联查询，确保数据的完整性和一致性，为工作流引擎的流程管理功能提供核心数据支撑。

### 功能要点

- **分页查询功能**：支持标准的分页查询机制，通过页码和每页条数参数控制返回结果的数量和范围，避免一次性加载过多数据导致性能问题。系统能够高效处理大量审批流程记录的查询请求，确保页面响应速度和用户体验。
- **多条件过滤功能**：支持基于流程名称、流程状态（草稿、已提交、审核中、已批准、已驳回）、流程类型、启用状态等多个维度的组合过滤查询。用户可以根据实际业务需求灵活设置查询条件，快速定位目标审批流程。
- **排序功能**：支持按任意字段进行升序或降序排列，包括按创建时间、更新时间、流程名称等字段排序，帮助用户按照不同维度组织和查看审批流程列表。
- **关联数据查询**：在必要时能够关联查询流程定义等相关实体信息，提供更完整的流程上下文数据，支持复杂的业务展示需求。

### 逻辑签名

```naturalts path="app.logics.loadWorkflowList.ts"
$Logic({
    description: '加载审批流程列表',
    directory: 'workflow_engine(工作流引擎)'
})
export declare function loadWorkflowList(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.ApprovalProcess): { list: List<app.dataSources.defaultDS.entities.ApprovalProcess>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 查询的页码，从1开始 |
| size | 每页条数 | Integer | 每页返回的记录数量 |
| sort | 排序字段 | String | 用于排序的字段名称 |
| order | 排序顺序 | String | 排序顺序，ascending表示升序，descending表示降序 |
| filter | 过滤条件 | app.dataSources.defaultDS.entities.ApprovalProcess | 审批流程过滤条件，包含流程名称、状态、类型、启用状态等字段 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 审批流程列表 | List<app.dataSources.defaultDS.entities.ApprovalProcess> | 符合查询条件的审批流程列表 |
| total | 总条数 | Integer | 符合查询条件的总记录数 |

### 被前端调用

- **审批流程（approvalProcess）**：审批流程管理页面调用此服务端逻辑来加载审批流程列表数据，支持分页、排序和过滤查询功能，用于在表格中展示流程名称、流程状态、流程类型、是否启用、版本号、创建时间、创建者等信息。

### 依赖的枚举、实体

- **数据建模-枚举-审批状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-审批流程**：[工作流引擎-实体-审批流程（ApprovalProcess）](specs/001-bootdo-management-system/plan/data-model/entity-ApprovalProcess.md)

### 依赖的外部能力

无匹配内容

