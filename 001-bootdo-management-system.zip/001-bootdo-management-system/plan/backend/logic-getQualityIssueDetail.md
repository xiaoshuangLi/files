# 质量管理-获取质量问题详情（getQualityIssueDetail）

- **生成时间**：2026-03-25

## 获取质量问题详情（getQualityIssueDetail）

### 功能概述

该服务端逻辑用于获取系统中特定质量问题的详细信息，包括问题的基本描述、发现时间、责任部门、当前状态、关联的整改任务、检验报告以及处理进度等完整信息。此功能为质量问题跟踪和管理提供数据支持，确保相关人员能够全面了解质量问题的具体情况，从而有效推进整改工作。

### 功能要点

- **质量问题详情查询**：根据提供的质量问题ID，从数据库中检索该质量问题的完整信息，包括问题标题、详细描述、发现时间、发现人、责任部门、问题等级、当前状态等基本信息。同时还需要关联查询该问题相关的整改任务、检验报告和处理进度等扩展信息，确保返回的数据完整且准确，满足前端展示和业务处理的需求。

### 逻辑签名

```naturalts path="app.logics.getQualityIssueDetail.ts"
$Logic({
    description: '获取质量问题详情',
    directory: 'quality_management(质量管理)'
})
export declare function getQualityIssueDetail(qualityIssueId: Text): { 
    qualityIssue: app.dataSources.defaultDS.entities.QualityIssue,
    rectificationTasks: List<app.dataSources.defaultDS.entities.RectificationTask>,
    inspectionReports: List<app.dataSources.defaultDS.entities.InspectionReport>,
    rectificationProgress: List<app.dataSources.defaultDS.entities.RectificationProgress>
};
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| qualityIssueId | 质量问题ID | Text | 要查询的特定质量问题的唯一标识符 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| qualityIssue | 质量问题 | app.dataSources.defaultDS.entities.QualityIssue | 质量问题的完整信息，包括问题描述、发现时间、责任部门等 |
| rectificationTasks | 整改任务 | List<app.dataSources.defaultDS.entities.RectificationTask> | 与该质量问题关联的所有整改任务列表 |
| inspectionReports | 检验报告 | List<app.dataSources.defaultDS.entities.InspectionReport> | 与该质量问题关联的所有检验报告列表 |
| rectificationProgress | 整改进度 | List<app.dataSources.defaultDS.entities.RectificationProgress> | 与该质量问题关联的所有整改进度记录列表 |

### 被前端调用

- **问题跟踪（issueTracking）**：在问题跟踪页面中，用户点击某个具体的质量问题条目时，调用此服务端逻辑获取该问题的详细信息，包括问题描述、责任部门、当前状态以及关联的整改任务和检验报告等，用于在详情页面中完整展示质量问题的全貌。

### 依赖的枚举、实体

- **数据建模-实体-质量问题**：[质量管理-实体-质量问题（QualityIssue）](specs/001-bootdo-management-system/plan/data-model/entity-QualityIssue.md)
- **数据建模-实体-整改任务**：[质量管理-实体-整改任务（RectificationTask）](specs/001-bootdo-management-system/plan/data-model/entity-RectificationTask.md)
- **数据建模-实体-检验报告**：[质量管理-实体-检验报告（InspectionReport）](specs/001-bootdo-management-system/plan/data-model/entity-InspectionReport.md)
- **数据建模-实体-整改进度**：[质量管理-实体-整改进度（RectificationProgress）](specs/001-bootdo-management-system/plan/data-model/entity-RectificationProgress.md)

### 依赖的外部能力

[文件内部已经提供，无需进行生成。如果文件内部已经有 `依赖的外部能力` 内容，禁止修改或删除文件内的 `依赖的外部能力` 内容]