# 内容管理-获取评论详情（getCommentDetail）

- **生成时间**：2026-03-25

## 获取评论详情（getCommentDetail）

### 功能概述

该服务端逻辑用于获取系统中特定评论的详细信息，包括评论内容、评论者信息、评论时间、关联的文章或内容、评论状态（如已审核、待审核、已删除等）以及可能的回复信息。此功能为内容管理员提供查看和管理用户评论的能力，支持评论审核、回复和删除等后续操作。

### 功能要点

- **评论详情查询**：根据评论ID精确查询单条评论的完整信息，包括评论的基本属性（ID、内容、创建时间、更新时间）、评论者的用户信息（用户ID、用户名、头像等）、评论所关联的内容信息（文章ID、标题等）、评论状态（待审核、已审核、已拒绝、已删除等）以及该评论下的所有回复信息。系统需要确保只有具有相应权限的用户（如内容管理员、系统管理员或评论所属内容的作者）才能查看评论详情，普通用户只能查看自己发布的且状态为已审核的评论详情。

### 逻辑签名

```naturalts path="app.logics.getCommentDetail.ts"
$Logic({
    description: '获取评论详情',
    directory: 'content_management(内容管理)'
})
export declare function getCommentDetail(commentId: String): app.dataSources.defaultDS.entities.CommentDetail;
```

### 被前端调用

- **评论管理（commentInteraction）**：在评论管理列表中点击某条评论时，调用此服务端逻辑获取该评论的完整详情信息，用于在详情弹窗或详情页面中展示，以便管理员进行审核、回复或删除操作。

### 依赖的枚举、实体

- **数据建模-枚举-评论状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-评论详情**：[内容管理-实体-评论详情（CommentDetail）](specs/001-bootdo-management-system/plan/data-model/entity-CommentDetail.md)
- **数据建模-实体-用户信息**：[系统管理-实体-用户信息（UserInfo）](specs/001-bootdo-management-system/plan/data-model/entity-UserInfo.md)
- **数据建模-实体-文章内容**：[内容管理-实体-文章内容（ArticleContent）](specs/001-bootdo-management-system/plan/data-model/entity-ArticleContent.md)

### 依赖的外部能力

[文件内部已经提供，无需进行生成。如果文件内部已经有 `依赖的外部能力` 内容，禁止修改或删除文件内的 `依赖的外部能力` 内容]