# 分包商管理-删除分包商合同（deleteSubcontractorContract）

- **生成时间**：2026-03-25

## 删除分包商合同（deleteSubcontractorContract）

### 功能概述

删除分包商合同服务端逻辑实现了对分包商已签订合同的安全删除功能。该逻辑负责验证用户权限、检查合同状态、执行删除操作并记录审计日志，确保合同数据删除的合规性和可追溯性。通过该服务，系统管理员或具有相应权限的用户可以移除无效、重复或不再需要的分包商合同记录，同时保证数据完整性，防止误删正在执行中的重要合同。删除操作采用软删除机制，在数据库中标记合同为已删除状态而非物理删除，以支持必要的历史数据查询和审计需求。

### 功能要点

- **合同删除权限验证**：系统在执行删除操作前必须验证当前用户是否具有删除分包商合同的权限。只有系统管理员、部门管理员或合同所属项目的负责人可以执行删除操作，普通用户无权删除任何合同记录，确保合同数据的安全性和操作的合规性。
- **合同状态检查**：在删除分包商合同时，系统必须检查合同的当前执行状态。对于处于"执行中"、"已完成"等关键业务状态的合同，系统应阻止直接删除操作，并提示用户先完成相应的业务流程或变更合同状态，避免因误删导致业务数据不一致和财务风险。
- **级联数据处理**：删除分包商合同时，系统需要处理与该合同关联的其他业务数据。由于SubcontractAgreement实体与SubcontractorInformation实体存在外键关联（级联删除），系统必须确保在删除合同记录时不会影响分包商基本信息的完整性，同时正确处理合同相关的付款记录、评估记录等依赖数据。
- **操作审计日志**：每次删除分包商合同的操作都必须记录详细的审计日志，包括操作用户、操作时间、被删除合同的标识信息（如合同编号、合同名称）、删除前的合同状态等关键信息。这些日志用于后续的审计追踪和问题排查，确保所有删除操作都有据可查。

### 逻辑签名

```naturalts path="app.logics.deleteSubcontractorContract.ts"
$Logic({
    description: '删除分包商合同',
    directory: 'subcontractor_management(分包商管理)'
})
export declare function deleteSubcontractorContract(contractId: Integer): app.dataSources.defaultDS.entities.SubcontractAgreement;
```

### 被前端调用

- **合同关联（contractAssociation）**：在合同关联页面中，当用户选择一条或多条合同记录并点击删除按钮时，系统会调用此服务端逻辑执行删除操作。该功能页面通过此逻辑实现合同数据的安全删除，包括权限验证、状态检查和操作确认等完整流程。

### 依赖的枚举、实体

- **数据建模-实体-分包商合同**：[分包商管理-实体-分包商合同（SubcontractAgreement）](specs/001-bootdo-management-system/plan/data-model/entity-SubcontractAgreement.md)
- **数据建模-实体-分包商信息**：[分包商管理-实体-分包商信息（SubcontractorInformation）](specs/001-bootdo-management-system/plan/data-model/entity-SubcontractorInformation.md)

### 依赖的外部能力

无