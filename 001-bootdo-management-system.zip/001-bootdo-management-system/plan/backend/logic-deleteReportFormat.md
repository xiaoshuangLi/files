# 预算管理-删除报表格式（deleteReportFormat）

- **生成时间**：2026-03-25

## 删除报表格式（deleteReportFormat）

### 功能概述

删除报表格式服务端逻辑用于处理系统中已存在的预算执行报表格式的删除操作。该功能允许具有相应权限的用户（如系统管理员或部门管理员）从系统中移除不再需要的报表格式定义。删除操作会验证报表格式是否存在、是否正在被其他业务流程引用，并在确认无依赖关系后执行物理删除，同时记录操作日志以确保系统的可追溯性。

### 功能要点

- **安全删除验证**：在执行删除操作前，系统必须验证当前用户是否具有删除报表格式的权限，并检查待删除的报表格式是否存在。如果报表格式不存在或用户无权删除，则返回相应的错误信息。此外，系统还需要检查该报表格式是否被其他业务模块（如预算执行监控、分析报告生成等）所引用，如果存在引用关系，则禁止删除操作，以避免破坏系统的数据完整性。

### 逻辑签名

```naturalts path="app.logics.deleteReportFormat.ts"
$Logic({
    description: '删除报表格式',
    directory: 'budget_management(预算管理)'
})
export declare function deleteReportFormat(reportFormatId: Integer): Boolean;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| reportFormatId | 报表格式ID | Integer | 要删除的报表格式的唯一标识符 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 删除结果 | Boolean | 删除操作是否成功，true表示成功，false表示失败 |

### 被前端调用

- **报表格式（reportFormat）**：在报表格式页面中，用户可以通过点击删除按钮调用此服务端逻辑，实现对选中的报表格式进行删除操作。该功能为用户提供了一种清理和维护报表格式库的手段，确保系统中的报表格式始终保持最新和有效。

### 依赖的枚举、实体

- **数据建模-实体-报表格式**：[预算管理-实体-报表格式（ReportFormat）](specs/001-bootdo-management-system/plan/data-model/entity-ReportFormat.md)

### 依赖的外部能力

无