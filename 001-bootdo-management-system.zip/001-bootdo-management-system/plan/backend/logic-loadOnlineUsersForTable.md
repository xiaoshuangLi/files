# 系统管理-加载在线用户列表（loadOnlineUsersForTable）

- **生成时间**：2026-03-25

## 加载在线用户列表（loadOnlineUsersForTable）

### 功能概述

加载在线用户列表服务端逻辑用于分页查询系统中当前所有活跃的用户会话信息，支持按指定字段排序和过滤条件筛选。该逻辑是在线用户管理功能页面的核心数据支撑接口，能够返回包含在线会话详细信息及其关联的用户账户信息的分页结果。通过此逻辑，系统管理员可以实时监控系统中的在线用户状态，包括用户的登录时间、最后活跃时间、IP地址等关键信息，并能够根据需要对数据进行排序和筛选，提高在线用户管理的效率和准确性。

### 功能要点

- **分页查询与排序功能**：提供标准的分页查询接口，支持指定页码(page)和每页条数(size)参数，同时支持按任意字段(sort)和排序方向(order)进行结果排序。该功能确保前端能够高效加载大量在线用户数据，避免一次性加载过多数据导致性能问题，并允许用户根据需要对在线用户列表进行排序查看，如按最后活跃时间降序排列以查看最近活跃的用户，提升用户体验和数据浏览效率。

- **多条件过滤功能**：支持通过在线会话实体(OnlineSession)的各个字段进行精确或模糊匹配过滤，包括会话ID、用户ID、IP地址、活跃状态等。用户可以根据实际需求组合不同的过滤条件，快速定位到关注的在线用户会话，例如筛选特定IP地址段的用户或查找长时间未活动的会话，提高数据查询的准确性和管理效率。

- **关联数据查询**：在查询在线会话记录的同时，自动关联获取对应的系统账户(SystemAccount)详细信息，包括用户名、全名、邮箱等关键身份信息。这种关联查询减少了前端的多次请求，提供了完整的用户会话视图，使管理员能够直观地识别每个在线会话对应的具体用户身份，增强系统安全监控能力。

### 逻辑签名

```naturalts path="app.logics.loadOnlineUsersForTable.ts"
$Logic({
    description: '分页查询在线用户列表',
    directory: 'system_management(系统管理)'
})
export declare function loadOnlineUsersForTable(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.OnlineSession): { list: List<{ onlineSession: app.dataSources.defaultDS.entities.OnlineSession, systemAccount: app.dataSources.defaultDS.entities.SystemAccount }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 查询的页码，从1开始 |
| size | 每页条数 | Integer | 每页显示的记录数量 |
| sort | 排序字段 | String | 用于排序的字段名称，如"lastActive"、"loginTime"等 |
| order | 排序顺序 | String | 排序方向，"ascending"表示升序，"descending"表示降序 |
| filter | 过滤条件 | app.dataSources.defaultDS.entities.OnlineSession | 在线会话实体作为过滤条件，支持各字段的精确匹配 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 在线用户列表 | List<{ onlineSession: app.dataSources.defaultDS.entities.OnlineSession, systemAccount: app.dataSources.defaultDS.entities.SystemAccount }> | 在线用户会话列表，每个列表项包含在线会话实体及其关联的系统账户实体 |
| total | 总记录数 | Integer | 符合过滤条件的总记录数，用于分页计算 |

### 被前端调用

- **在线用户管理（onlineUserManagement）**：在线用户管理页面使用此服务端逻辑加载在线用户会话数据列表，支持系统管理员查看、筛选和排序当前所有在线用户的会话信息。页面通过分页、排序和过滤参数调用此接口，获取符合业务需求的在线用户数据，并在表格中展示用户身份、登录时间、最后活跃时间、IP地址和活跃状态等关键信息。

### 依赖的枚举、实体

- **数据建模-实体-在线会话**：[系统管理-实体-在线会话（OnlineSession）](specs/001-bootdo-management-system/plan/data-model/entity-OnlineSession.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无