# 办公自动化-管理会议纪要（manageMeetingMinutes）

- **生成时间**：2026-03-25

## 管理会议纪要（manageMeetingMinutes）

### 功能概述

管理会议纪要服务端逻辑提供对会议纪要的完整管理功能，支持在会议结束后添加、编辑和查询会议纪要内容。该逻辑允许会议组织者或具有相应权限的用户记录会议讨论的关键要点、决策结果、行动项和后续跟进事项。会议纪要作为会议的重要产出物，能够帮助参会人员回顾会议内容，跟踪决策执行情况，并为组织知识积累提供支持。该逻辑确保会议纪要与对应的会议预约记录关联存储，便于后续检索和管理，同时支持纪要内容的版本控制和历史记录追踪。

### 功能要点

- **会议纪要创建与编辑**：支持为已完成的会议创建会议纪要，用户可以在富文本编辑器中输入会议讨论要点、决策结果、分配的任务和截止日期等关键信息。系统会自动将纪要与对应的会议预约ID关联，并记录创建人和创建时间。对于已存在的会议纪要，允许会议组织者或授权用户进行编辑更新，系统会保留修改历史以便追溯变更过程。
- **会议纪要查询与展示**：提供根据会议ID查询对应会议纪要的功能，返回完整的纪要内容包括标题、正文、创建人、创建时间等信息。该功能支持前端会议详情页面展示会议纪要，确保参会人员能够随时查看会议的重要产出和后续行动项。
- **权限控制与验证**：在管理会议纪要时，系统会验证当前用户是否具有操作权限。只有会议的组织者或被明确授权的用户才能创建或编辑会议纪要，防止未经授权的修改。同时，系统会验证会议状态，确保只能为已完成的会议添加纪要，避免为未开始或进行中的会议创建不准确的记录。
- **数据完整性与关联性**：会议纪要数据与会议预约实体保持强关联关系，通过外键约束确保数据的一致性和完整性。当会议预约被删除时，相关的会议纪要也会被级联删除，避免产生孤立的数据记录。系统还支持纪要内容的格式验证，确保输入的内容符合业务要求.

### 逻辑签名

```naturalts path="app.logics.manageMeetingMinutes.ts"
$Logic({
    description: '管理会议纪要',
    directory: 'office_automation(办公自动化)'
})
export declare function manageMeetingMinutes(meetingId: Integer, action: String, minutesContent?: String): { success: Boolean, message: String, meetingMinutes: { id: Integer, meetingId: Integer, content: String, createdBy: app.dataSources.defaultDS.entities.SystemAccount, createdAt: DateTime, updatedAt: DateTime } };
```

### 被前端调用

- **会议管理（meetingManagement）**：在会议管理页面的会议详情视图中，用户可以通过"添加纪要"或"编辑纪要"按钮调用此服务端逻辑。当会议状态为已完成时，系统允许用户创建新的会议纪要；对于已有纪要的会议，用户可以更新现有纪要内容。该逻辑为会议纪要管理功能提供完整的后端支持.

### 依赖的枚举、实体

- **数据建模-实体-会议预约**：[办公自动化-实体-会议预约（MeetingReservation）](specs/001-bootdo-management-system/plan/data-model/entity-MeetingReservation.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

#### 邮件服务（EmailService） 【当前业务功能相关】

- 关联文档：[邮件服务（EmailService）](specs/001-bootdo-management-system/plan/integration/retrieval-EmailService.md)