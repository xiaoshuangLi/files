# 分包商管理-导出分包商数据（exportSubcontractorData）

- **生成时间**：2026-03-25

## 导出分包商数据（exportSubcontractorData）

### 功能概述

导出分包商数据服务端逻辑是分包商管理模块的核心功能之一，专门用于将系统中存储的分包商相关信息按照指定格式导出为Excel文件。该逻辑支持导出完整的分包商基础信息、资质证书详情、合同关联记录、人员配置数据、绩效评估结果、付款管理信息、项目分配情况以及风险评估记录等全方位数据。通过该服务，系统管理员和部门管理员能够便捷地获取分包商的完整档案信息，用于离线分析、数据备份、合规审计或与其他系统的数据交换。导出功能确保了分包商数据的可移植性和可用性，满足企业在分包商管理过程中的多样化数据需求。

### 功能要点

- **分包商基础信息导出**：导出分包商的基本信息，包括公司名称、联系人、联系电话、注册地址和注册时间等核心字段，确保基础数据的完整性。
- **资质证书信息导出**：导出分包商持有的所有资质证书信息，包括证书名称、证书编号、颁发机构、颁发日期和有效期等关键数据，便于资质合规性检查。
- **合同关联信息导出**：导出分包商签订的所有合同详情，包括合同编号、合同条款、签署日期、合同有效期和合同价值等业务数据，支持合同管理分析。
- **人员配置信息导出**：导出分包商的人员配置详情，包括员工姓名、职位、联系信息、雇佣日期和终止日期等人力资源数据，为人员管理提供依据。
- **绩效评估信息导出**：导出分包商的历史绩效评估记录，包括评估时间、绩效评分、评估意见和评估人等评价数据，支持分包商绩效分析。
- **付款管理信息导出**：导出分包商的付款结算信息，包括付款金额、付款方式、付款日期、发票号和付款状态等财务数据，便于财务对账和分析。
- **项目分配信息导出**：导出分配给分包商的项目详情，包括项目名称、项目范围、分配时间和完成期限等项目管理数据，支持项目跟踪和资源规划。
- **风险评估信息导出**：导出分包商的风险评估记录，包括风险类型、风险等级、评估状态、建议措施和处理情况等风险管理数据，辅助风险决策。

### 逻辑签名

```naturalts path="app.logics.exportSubcontractorData.ts"
$Logic({
    description: '导出分包商数据',
    directory: 'subcontractor_management(分包商管理)'
})
export declare function exportSubcontractorData(
  filter: {
    companyName?: String;
    contactPerson?: String;
    contactPhone?: String;
    registeredAtStart?: Date;
    registeredAtEnd?: Date;
  }
): {
  downloadUrl: String;
  fileName: String;
  fileSize: Integer;
};
```

### 被前端调用

- **分包商信息维护（subcontractorInformation）**：在分包商信息维护页面，用户点击导出按钮时调用此服务端逻辑，将当前筛选条件下的分包商列表数据导出为Excel文件，包含分包商的所有相关字段信息，便于离线分析和存档。

### 依赖的枚举、实体

- **数据建模-实体-分包商信息**：[分包商管理-实体-分包商信息（SubcontractorInformation）](specs/001-bootdo-management-system/plan/data-model/entity-SubcontractorInformation.md)
- **数据建模-实体-资质证书**：[分包商管理-实体-资质证书（QualificationCertificate）](specs/001-bootdo-management-system/plan/data-model/entity-QualificationCertificate.md)
- **数据建模-实体-合同关联**：[分包商管理-实体-合同关联（ContractAssociation）](specs/001-bootdo-management-system/plan/data-model/entity-ContractAssociation.md)
- **数据建模-实体-人员配置**：[分包商管理-实体-人员配置（PersonnelConfiguration）](specs/001-bootdo-management-system/plan/data-model/entity-PersonnelConfiguration.md)
- **数据建模-实体-评估记录**：[分包商管理-实体-评估记录（EvaluationRecord）](specs/001-bootdo-management-system/plan/data-model/entity-EvaluationRecord.md)
- **数据建模-实体-付款管理**：[分包商管理-实体-付款管理（PaymentManagement）](specs/001-bootdo-management-system/plan/data-model/entity-PaymentManagement.md)
- **数据建模-实体-项目分配**：[分包商管理-实体-项目分配（ProjectAssignment）](specs/001-bootdo-management-system/plan/data-model/entity-ProjectAssignment.md)
- **数据建模-实体-风险评估**：[分包商管理-实体-风险评估（RiskAssessment）](specs/001-bootdo-management-system/plan/data-model/entity-RiskAssessment.md)
- **数据建模-枚举-任务状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)

### 依赖的外部能力

[文件内部已经提供，无需进行生成。如果文件内部已经有 `依赖的外部能力` 内容，禁止修改或删除文件内的 `依赖的外部能力` 内容]