# 分包商管理-创建分包商评估记录（createSubcontractorEvaluationRecord）

- **生成时间**：2026-03-25

## 创建分包商评估记录（createSubcontractorEvaluationRecord）

### 功能概述

该服务端逻辑用于创建新的分包商评估记录，支持对分包商的绩效、质量、合规性等多维度进行综合评估。系统将记录评估的基本信息、评分详情、评估结论以及相关附件，为后续的分包商管理和决策提供数据支撑。评估记录将与分包商信息、项目信息进行关联，确保评估数据的完整性和可追溯性。

### 功能要点

- **评估记录创建**：支持创建包含分包商基本信息、评估周期、评估维度、各项评分及总体评价的完整评估记录。系统会自动关联当前登录用户的部门信息，并记录创建时间和操作人，确保评估记录的来源可追溯。评估记录必须包含必要的业务字段，如分包商ID、评估日期、评估人、各项指标得分等，以满足后续的数据分析和报表生成需求。

### 逻辑签名

```naturalts path="app.logics.createSubcontractorEvaluationRecord.ts"
$Logic({
    description: '创建分包商评估记录',
    directory: 'subcontractor_management(分包商管理)',
    transactional: true
})
export declare function createSubcontractorEvaluationRecord(
  subcontractorId: String,
  evaluationDate: Date,
  evaluationPeriod: String,
  qualityScore: Integer,
  deliveryScore: Integer,
  complianceScore: Integer,
  safetyScore: Integer,
  overallComment: String,
  attachments: List<String>
): app.dataSources.defaultDS.entities.EvaluationRecord;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| subcontractorId | 分包商ID | String | 被评估的分包商唯一标识 |
| evaluationDate | 评估日期 | Date | 评估执行的具体日期 |
| evaluationPeriod | 评估周期 | String | 评估所覆盖的时间周期 |
| qualityScore | 质量评分 | Integer | 质量维度的评分（0-100） |
| deliveryScore | 交付评分 | Integer | 交付维度的评分（0-100） |
| complianceScore | 合规评分 | Integer | 合规维度的评分（0-100） |
| safetyScore | 安全评分 | Integer | 安全维度的评分（0-100） |
| overallComment | 总体评价 | String | 对分包商的综合评价意见 |
| attachments | 附件列表 | List<String> | 相关证明材料的附件ID列表 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 评估记录 | app.dataSources.defaultDS.entities.EvaluationRecord | 创建成功的完整评估记录实体 |

### 被前端调用

- **评估记录（evaluationRecord）**：在评估记录管理页面中，用户可以通过表单填写分包商的各项评估指标，提交后调用此服务端逻辑创建新的评估记录，实现对分包商绩效的系统化管理。

### 依赖的枚举、实体

- **数据建模-实体-分包商信息**：[分包商管理-实体-分包商信息（SubcontractorInformation）](specs/001-bootdo-management-system/plan/data-model/entity-SubcontractorInformation.md)
- **数据建模-实体-评估记录**：[分包商管理-实体-评估记录（EvaluationRecord）](specs/001-bootdo-management-system/plan/data-model/entity-EvaluationRecord.md)

### 依赖的外部能力

文件内部已经提供，无需进行生成。如果文件内部已经有 `依赖的外部能力` 内容，禁止修改或删除文件内的 `依赖的外部能力` 内容