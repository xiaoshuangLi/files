# 办公自动化-获取共享日程列表（getSharedScheduleList）

- **生成时间**：2026-03-25

## 获取共享日程列表（getSharedScheduleList）

### 功能概述

获取共享日程列表服务端逻辑为用户提供查询团队成员和部门共享的日程安排的能力。该逻辑根据当前用户的组织架构关系，检索所有可查看的共享日程，包括来自同部门同事、上级领导以及被明确授权共享的日程事件。系统支持按时间范围、日程标题关键词、共享人等条件进行筛选，并提供分页功能以处理大量数据。返回的结果包含完整的日程信息以及共享来源信息，帮助用户了解日程的上下文和相关性。该逻辑确保了数据的安全性和隐私保护，只返回用户有权限查看的共享日程，避免敏感信息泄露。

### 功能要点

- **共享日程查询功能**：系统能够根据当前用户的组织架构和权限设置，自动识别并检索所有可查看的共享日程。这包括同部门成员的日程、上级领导的日程以及通过显式共享授权的日程。查询过程会验证用户的访问权限，确保只返回有权限查看的数据，同时支持高效的数据库查询以保证响应速度。

- **多维度筛选与分页**：系统提供灵活的筛选条件，用户可以按时间范围（开始时间和结束时间）、日程标题关键词、共享人ID等维度进行组合筛选。同时支持分页查询，通过页码和每页条数参数控制返回结果的数量，避免一次性加载过多数据影响系统性能。排序功能允许用户按日程开始时间、创建时间等字段进行升序或降序排列。

### 逻辑签名

```naturalts path="app.logics.getSharedScheduleList.ts"
$Logic({
    description: '获取共享日程列表',
    directory: 'office_automation(办公自动化)'
})
export declare function getSharedScheduleList(page: Integer, size: Integer, sort: String, order: String, startTime?: DateTime, endTime?: DateTime, title?: String, sharerId?: Integer): { list: List<app.dataSources.defaultDS.entities.ScheduleArrangement>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 分页查询的页码，从1开始 |
| size | 每页条数 | Integer | 每页返回的日程数量 |
| sort | 排序字段 | String | 排序的字段名，如"startTime"、"createdTime"等 |
| order | 排序顺序 | String | 排序顺序，"asc"表示升序，"desc"表示降序 |
| startTime | 开始时间 | DateTime | 筛选日程的开始时间范围下限 |
| endTime | 结束时间 | DateTime | 筛选日程的结束时间范围上限 |
| title | 日程标题 | String | 日程标题关键词模糊匹配 |
| sharerId | 共享人ID | Integer | 特定共享人的用户ID |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 共享日程列表 | List<app.dataSources.defaultDS.entities.ScheduleArrangement> | 符合条件的共享日程实体列表 |
| total | 总条数 | Integer | 符合条件的共享日程总数量 |

### 被前端调用

- **日程管理（scheduleArrangement）**：在日程管理页面的"共享日程"标签页中，系统调用此服务端逻辑获取用户可查看的所有共享日程列表。用户可以通过时间范围、日程标题等条件进行筛选，并查看团队成员和部门共享的日程安排，实现高效的团队协作和时间协调。

### 依赖的枚举、实体

- **数据建模-实体-日程安排**：[办公自动化-实体-日程安排（ScheduleArrangement）](specs/001-bootdo-management-system/plan/data-model/entity-ScheduleArrangement.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无外部能力依赖