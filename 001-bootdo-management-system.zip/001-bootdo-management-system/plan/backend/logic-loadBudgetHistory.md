# 预算管理-加载预算历史记录（loadBudgetHistory）

- **生成时间**：2026-03-25

## 加载预算历史记录（loadBudgetHistory）

### 功能概述

加载预算历史记录服务端逻辑用于查询和获取特定预算分配的完整执行历史数据。该功能支持按预算分配ID精确查询，返回该预算分配下所有相关的预算执行记录，包括每次执行的金额、执行时间、执行人、支出用途和审批状态等详细信息。系统会按照执行时间倒序排列历史记录，确保用户能够清晰地了解预算资金的使用轨迹。此服务为执行监控页面提供核心数据支撑，使用户能够全面掌握预算的实际执行情况，识别资金使用的模式和趋势，并为后续的预算分析和调整决策提供准确的历史数据基础。

### 功能要点

- **预算执行历史查询**：根据指定的预算分配ID，查询并返回该预算分配下的所有预算执行记录。每条记录包含执行金额、执行时间、执行人、支出用途、审批状态等完整信息，支持按执行时间倒序排列，确保用户能够清晰了解预算资金的完整使用轨迹和历史详情。

### 逻辑签名

```naturalts path="app.logics.loadBudgetHistory.ts"
$Logic({
    description: '加载预算历史记录',
    directory: 'budget_management(预算管理)'
})
export declare function loadBudgetHistory(budgetAllocationId: Integer): List<app.dataSources.defaultDS.entities.BudgetExecution>;
```

### 被前端调用

- **执行监控（executionMonitoring）**：在执行监控详情页面中，当用户查看特定预算分配的执行历史时，调用此服务端逻辑获取该预算分配的完整执行记录列表，用于展示预算资金的详细使用轨迹和历史执行情况。

### 依赖的枚举、实体

- **数据建模-枚举-审批状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-预算执行**：[预算管理-实体-预算执行（BudgetExecution）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetExecution.md)
- **数据建模-实体-预算分配**：[预算管理-实体-预算分配（BudgetAllocation）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetAllocation.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

#### 邮件服务（EmailService） 【当前业务功能相关】

- 关联文档：[邮件服务（EmailService）](specs/001-bootdo-management-system/plan/integration/retrieval-EmailService.md)