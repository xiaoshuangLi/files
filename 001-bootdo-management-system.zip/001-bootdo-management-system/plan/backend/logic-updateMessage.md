# 办公自动化-更新消息（updateMessage）

- **生成时间**：2026-03-25

## 更新消息（updateMessage）

### 功能概述

更新消息功能用于修改已存在的通知消息内容和属性，支持对通知标题、内容、接收者、优先级、有效期等关键信息的编辑和更新。该功能允许系统管理员或通知发送者在通知发布后对其进行修正或调整，确保信息的准确性和时效性。通过此功能，用户可以更新通知的阅读状态、置顶状态等交互属性，优化通知管理体验。系统会记录通知的更新历史，包括更新时间和更新人信息，保证操作的可追溯性。

### 功能要点

- **通知内容更新**：支持对已发布的通知消息的标题和内容进行修改，包括富文本格式的内容编辑，确保通知信息的准确性和完整性。系统会验证更新后的通知内容是否符合格式要求，并保留原始通知的历史版本以供追溯。
- **通知属性调整**：允许修改通知的接收者类型和ID、通知类型、优先级、置顶状态以及有效时间范围等属性。这些调整可以帮助发送者根据实际情况优化通知的分发策略和展示效果，提升通知传达的有效性。
- **状态管理**：支持更新通知的已读状态和阅读时间，便于系统跟踪通知的接收情况。同时可以调整通知的置顶状态，控制其在接收者通知列表中的显示位置，确保重要通知能够获得足够的关注。

### 逻辑签名

```naturalts path="app.logics.updateMessage.ts"
$Logic({
    description: '更新通知消息',
    directory: 'office_automation(办公自动化)'
})
export declare function updateMessage(notificationData: app.dataSources.defaultDS.entities.NotificationMessageEntity): app.dataSources.defaultDS.entities.NotificationMessageEntity;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| notificationData | 通知数据 | app.dataSources.defaultDS.entities.NotificationMessageEntity | 包含更新后所有属性的通知消息实体 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 更新结果 | app.dataSources.defaultDS.entities.NotificationMessageEntity | 更新后的完整消息实体 |

### 被前端调用

- **个人门户（personalWorkspace）**：在个人门户页面中，用户可以通过通知管理区域对已接收的通知进行状态更新，如标记为已读或取消置顶等操作，这些操作会调用updateMessage服务端逻辑来同步通知状态。

### 依赖的枚举、实体

- **数据建模-实体-通知消息**：[办公自动化-实体-通知消息（NotificationMessageEntity）](specs/001-bootdo-management-system/plan/data-model/entity-NotificationMessageEntity.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无外部能力依赖。