# 权限中心-创建根部门（LcapCreateRootDept）

## 创建根部门（LcapCreateRootDept）

### 功能概述

创建根部门服务端逻辑用于在系统初始化时自动创建一个名为"根部门"的基础部门记录，作为整个组织架构的顶级节点。该逻辑首先检查系统中是否已存在任何部门记录，如果不存在则创建根部门，并将所有现有用户自动关联到该根部门下，确保系统组织架构的完整性和用户归属的一致性。此功能是权限中心模块正常运行的基础保障，为后续的部门管理、用户管理和权限分配提供必要的组织架构支撑。

### 功能要点

- **系统初始化保障**：在权限中心页面或部门管理页面首次加载时，自动检测并创建根部门，确保系统始终拥有一个有效的组织架构起点，避免因缺少基础部门导致的业务异常。
- **根部门创建逻辑**：当系统中不存在任何部门记录时，自动创建一个名为"根部门"的部门，**其部门标识(deptId)必须设置为"根部门"，父部门标识(parentDeptId)不设置**。
- **用户自动关联**：在创建根部门的同时，系统会查询所有现有用户，并通过批量操作将这些用户与新创建的根部门建立关联关系，确保每个用户都有明确的部门归属，避免出现无部门用户的异常情况。
- **数据一致性维护**：在关联用户到根部门之前，系统会先清理现有的所有用户部门映射关系，然后重新建立新的映射，确保用户部门关系数据的准确性和一致性，防止数据冗余或冲突。
- **无重复创建机制**：该逻辑包含防重复创建机制，只有在系统中完全不存在部门记录时才会执行创建操作，避免多次调用导致重复创建根部门的问题，保证组织架构数据的唯一性。

### 逻辑签名

```naturalts path="app.logics.LcapCreateRootDept.ts"
$Logic({
    description: '在系统初始化时自动创建一个名为"根部门"的基础部门记录，作为整个组织架构的顶级节点',
    directory: 'permission_center(权限中心)',
})
export declare function LcapCreateRootDept(): app.dataSources.defaultDS.entities.LcapDepartment;
```

### 被前端调用

- **部门管理页（departmentManagement）**：在部门管理页面初始化加载时调用此逻辑，确保系统存在根部门作为组织架构的基础，支持后续的部门新增、编辑等操作。
- **权限中心（permissionCenter）**：在权限中心页面初始化加载时调用此逻辑，自动创建根部门，确保系统基础数据完整性，为用户提供完整的权限管理功能。

### 依赖的枚举、实体、数据结构

- **数据建模-实体-部门**：[权限中心-实体-部门（LcapDepartment）](specs/001-bootdo-management-system/plan/data-model/entity-LcapDepartment.md)
- **数据建模-实体-用户**：[权限中心-实体-用户（LcapUser）](specs/001-bootdo-management-system/plan/data-model/entity-LcapUser.md)
- **数据建模-实体-用户与部门映射**：[权限中心-实体-用户与部门映射（LcapUserDeptMapping）](specs/001-bootdo-management-system/plan/data-model/entity-LcapUserDeptMapping.md)

