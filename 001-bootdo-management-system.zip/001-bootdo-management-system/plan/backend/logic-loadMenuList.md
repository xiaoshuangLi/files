# 系统管理-加载菜单列表（loadMenuList）

- **生成时间**：2026-03-25

## 加载菜单列表（loadMenuList）

### 功能概述

加载菜单列表服务端逻辑用于根据当前用户的角色权限动态获取系统导航菜单数据，支持多级树形结构的菜单展示。该逻辑通过关联查询导航菜单实体（NavigationMenu）和系统账户实体（SystemAccount），结合用户角色信息，返回经过权限过滤的菜单列表。系统会自动排除已禁用的菜单项，并按照预设的排序权重对菜单进行排序，确保前端能够正确展示符合当前用户权限的导航菜单。此服务是权限中心功能的核心支撑，为系统提供细粒度的菜单级权限控制能力。

### 功能要点

- **权限过滤的菜单加载**：根据当前登录用户的系统账户ID和关联的角色信息，从导航菜单实体中筛选出用户有权访问的菜单项。系统会自动过滤掉用户无权访问或已被禁用的菜单，确保菜单列表的安全性和准确性。菜单数据包含完整的菜单属性，如菜单名称、URL路径、图标样式、父菜单ID等，为前端菜单组件提供完整的渲染数据。
- **多级树形菜单构建**：支持构建多层级的树形菜单结构，通过递归处理父菜单ID和子菜单的关系，将扁平的菜单数据转换为嵌套的树形结构。系统会按照菜单的排序权重（sortOrder）对同级菜单进行排序，确保菜单展示顺序符合业务需求。这种树形结构便于前端实现可折叠的侧边栏导航菜单，提升用户体验。
- **角色关联菜单查询**：通过导航菜单实体中的角色ID字段与用户角色进行关联匹配，实现基于角色的菜单权限控制。每个菜单项都关联特定的角色，只有具备相应角色的用户才能看到对应的菜单项。这种设计实现了灵活的权限分配机制，支持不同角色用户看到不同的功能菜单。
- **菜单状态验证**：在返回菜单列表前，系统会验证每个菜单项的启用状态（isEnabled），自动排除已禁用的菜单项，确保用户只能看到当前可用的功能入口。同时，系统还会检查菜单URL的有效性，避免返回无效的路由路径，保证前端导航的稳定性。

### 逻辑签名

```naturalts path="app.logics.loadMenuList.ts"
$Logic({
    description: '加载菜单列表',
    directory: 'system_management(系统管理)'
})
export declare function loadMenuList(currentUserId: Integer): List<{ menu: app.dataSources.defaultDS.entities.NavigationMenu, user: app.dataSources.defaultDS.entities.SystemAccount }>;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| currentUserId | 当前用户ID | Integer | 当前登录用户的系统账户ID |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| menu | 菜单信息 | app.dataSources.defaultDS.entities.NavigationMenu | 导航菜单实体，包含菜单名称、URL、图标、父菜单ID等完整信息 |
| user | 用户信息 | app.dataSources.defaultDS.entities.SystemAccount | 系统账户实体，包含用户名、全名、邮箱等用户基本信息 |

### 被前端调用

- **权限中心（permissionCenter）**：权限中心页面在初始化时调用此服务端逻辑，根据当前登录用户的角色权限加载对应的导航菜单列表。该逻辑为左侧菜单区域提供数据支撑，确保用户只能看到其有权访问的功能菜单项，并支持多级菜单的树形展示结构。

### 依赖的枚举、实体

- **数据建模-实体-导航菜单**：[系统管理-实体-导航菜单（NavigationMenu）](specs/001-bootdo-management-system/plan/data-model/entity-NavigationMenu.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无