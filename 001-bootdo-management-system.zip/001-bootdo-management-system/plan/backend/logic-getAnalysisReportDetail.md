# 预算管理-获取分析报告详情（getAnalysisReportDetail）

- **生成时间**：2026-03-25

## 获取分析报告详情（getAnalysisReportDetail）

### 功能概述

获取分析报告详情服务端逻辑用于根据分析报告ID查询并返回完整的预算执行分析报告详细信息。该逻辑支持前端分析报告页面查看特定报告的完整内容，包括报告关联的预算分配信息、使用的报表格式模板以及详细的分析数据内容。通过该逻辑，用户能够深入了解预算执行的具体情况，为后续的决策提供数据支持。

### 功能要点

- **查询分析报告详情**：根据传入的分析报告ID，从数据库中精确查询对应的分析报告记录，并通过外键关联同时获取相关的预算分配详细信息（包括预算类型、预算周期、分配金额、预算状态等）以及报表格式模板配置。该功能确保用户在查看分析报告详情时能够获得完整的上下文信息，不仅包含报告本身的详细内容和生成时间，还能了解该报告是基于哪个具体的预算分配和使用何种报表格式生成的。这种完整的数据关联为用户提供了全面的预算执行分析视角，支持深入的数据追溯和业务决策，确保预算管理的透明度和可审计性。

### 逻辑签名

```naturalts path="app.logics.getAnalysisReportDetail.ts"
$Logic({
    description: '获取分析报告详情',
    directory: 'budget_management(预算管理)'
})
export declare function getAnalysisReportDetail(reportId: Integer): { analysisReport: app.dataSources.defaultDS.entities.AnalysisReport, budgetAllocation: app.dataSources.defaultDS.entities.BudgetAllocation, reportFormat: app.dataSources.defaultDS.entities.ReportFormat };
```

### 被前端调用

- **分析报告（analysisReport）**：在分析报告详情页面中，通过传入reportId参数调用此服务端逻辑，获取完整的分析报告详细信息，包括报告内容、关联的预算分配和报表格式，用于展示报告的完整数据内容。

### 依赖的枚举、实体

- **数据建模-实体-分析报告**：[预算管理-实体-分析报告（AnalysisReport）](specs/001-bootdo-management-system/plan/data-model/entity-AnalysisReport.md)
- **数据建模-实体-预算分配**：[预算管理-实体-预算分配（BudgetAllocation）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetAllocation.md)
- **数据建模-实体-报表格式**：[预算管理-实体-报表格式（ReportFormat）](specs/001-bootdo-management-system/plan/data-model/entity-ReportFormat.md)

### 依赖的外部能力

无匹配内容

