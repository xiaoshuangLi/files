# 质量管理-查询质量指标列表（queryQualityIndicators）

- **生成时间**：2026-03-25

## 查询质量指标列表（queryQualityIndicators）

### 功能概述

查询质量指标列表服务端逻辑用于分页获取系统中的质量指标数据，支持按指标名称、关联质量问题、测量时间范围等条件进行过滤，并支持按指定字段和顺序进行排序。该逻辑返回符合条件的质量指标列表及其总数，为前端质量指标管理页面提供数据支撑。通过该逻辑，质量管理员能够高效地检索和分析质量管理过程中的关键绩效指标（KPI），包括指标的目标值与实际值对比，从而评估质量管理体系的有效性并识别改进机会。

### 功能要点

- **分页查询功能**：支持标准的分页参数（页码page、每页条数size），能够高效处理大量质量指标数据，避免一次性加载过多数据导致系统性能问题。分页查询结果包含当前页的数据列表和总记录数，便于前端实现完整的分页控件，确保用户能够流畅浏览所有质量指标记录。
- **多条件过滤功能**：支持通过指标名称、关联质量问题ID、测量时间范围等多个维度对质量指标数据进行精确筛选。用户可以根据实际需求组合不同的过滤条件，快速定位到关注的质量指标，提高数据查询的准确性和效率，满足不同场景下的分析需求。
- **动态排序功能**：支持按任意字段（如测量时间、目标值、实际值等）进行升序或降序排列，通过sort参数指定排序字段，order参数指定排序方向。默认按测量时间(measuredAt)降序排列，确保最新的质量指标记录优先显示，便于用户及时掌握最新质量状况。
- **关联数据加载**：在返回质量指标列表的同时，自动加载关联的质量问题(QualityIssue)详细信息，包括问题标题、状态等关键字段。这种关联查询减少了前端的多次请求开销，提升了用户体验，并确保质量指标与其关联问题的上下文信息完整展示。

### 逻辑签名

```naturalts path="app.logics.queryQualityIndicators.ts"
$Logic({
    description: '分页查询质量指标列表',
    directory: 'quality_management(质量管理)'
})
export declare function queryQualityIndicators(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.QualityIndicator): { list: List<{ qualityIndicator: app.dataSources.defaultDS.entities.QualityIndicator, qualityIssue: app.dataSources.defaultDS.entities.QualityIssue }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 分页查询的页码，从1开始计数 |
| size | 每页条数 | Integer | 每页返回的记录数量，建议范围1-100 |
| sort | 排序字段 | String | 排序的字段名，如"measuredAt"、"targetValue"等 |
| order | 排序顺序 | String | 排序方向，"ascending"表示升序，"descending"表示降序 |
| filter | 过滤条件 | app.dataSources.defaultDS.entities.QualityIndicator | 质量指标实体作为过滤条件，支持各字段的精确匹配 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 质量指标列表 | List<{ qualityIndicator: app.dataSources.defaultDS.entities.QualityIndicator, qualityIssue: app.dataSources.defaultDS.entities.QualityIssue }> | 质量指标列表，每个列表项包含质量指标实体及其关联的质量问题实体 |
| total | 总条数 | Integer | 符合筛选条件的总记录数，用于分页计算 |

### 被前端调用

- **质量指标（qualityIndicator）**：质量指标管理页面使用此服务端逻辑加载质量指标列表数据，支持用户查看、筛选和管理质量指标记录。页面通过分页、筛选和排序参数调用此接口，获取符合业务需求的质量指标数据，并在表格中展示指标名称、单位、目标值、实际值、测量时间等关键信息，同时显示关联的质量问题详情。

### 依赖的枚举、实体

- **数据建模-实体-质量指标**：[质量管理-实体-质量指标（QualityIndicator）](specs/001-bootdo-management-system/plan/data-model/entity-QualityIndicator.md)
- **数据建模-实体-质量问题**：[质量管理-实体-质量问题（QualityIssue）](specs/001-bootdo-management-system/plan/data-model/entity-QualityIssue.md)

### 依赖的外部能力

无