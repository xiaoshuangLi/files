# 通用领域服务-创建环境风险评估（createEnvironmentalRiskAssessment）

- **生成时间**：2026-03-25

## 创建环境风险评估（createEnvironmentalRiskAssessment）

### 功能概述

该服务端逻辑负责创建新的环境风险评估记录，支持用户录入环境风险评估的基本信息、风险等级、评估内容、整改措施建议等关键数据。系统将对输入数据进行完整性验证和业务规则校验，确保评估数据的规范性和有效性，并将评估结果与相关的环境监测数据、合规检查记录进行关联，为后续的环境管理决策提供数据支撑。

### 功能要点

- **环境风险评估数据录入**：支持用户录入环境风险评估的完整信息，包括评估标题、评估类型、风险等级、评估描述、潜在影响分析、现有控制措施评估等内容。系统提供结构化的表单界面，确保关键信息的完整采集，并支持附件上传功能，允许用户附加相关的监测报告、现场照片等证明材料。

### 逻辑签名

```naturalts path="app.logics.createEnvironmentalRiskAssessment.ts"
$Logic({
    description: '创建环境风险评估',
    directory: 'environmental_management(环境管理)'
})
export declare function createEnvironmentalRiskAssessment(
  title: String,
  assessmentType: String,
  riskLevel: String,
  description: String,
  potentialImpact: String,
  existingControls: String,
  recommendedMeasures: String,
  attachments?: List<String>
): {
  id: String;
  createdAt: DateTime;
  status: String;
};
```

### 被前端调用

- **风险评估（environmentalRiskAssessment）**：在风险评估页面中，用户点击"新建评估"按钮后，通过调用此服务端逻辑来创建新的环境风险评估记录，实现环境风险数据的初始录入和保存功能。

### 依赖的枚举、实体

- **数据建模-枚举-风险等级**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-环境风险评估**：[环保管理-实体-环境风险评估（EnvironmentalRiskAssessment）](specs/001-bootdo-management-system/plan/data-model/entity-EnvironmentalRiskAssessment.md)

### 依赖的外部能力
