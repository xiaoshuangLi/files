# 质量管理-获取问题跟踪记录（getIssueTrackingRecords）

- **生成时间**：2026-03-25

## 获取问题跟踪记录（getIssueTrackingRecords）

### 功能概述

该服务端逻辑用于查询和获取系统中所有质量问题的跟踪记录，支持按多种条件进行筛选和分页。用户可以通过此接口获取指定时间段、指定责任人、指定状态或指定问题类型的问题跟踪记录，以便进行质量分析、整改进度监控和报表生成。系统会根据用户的权限范围返回相应的问题跟踪数据，确保数据安全性和隐私保护。

### 功能要点

- **多条件筛选功能**：支持按问题ID、问题标题关键词、责任人、问题状态、问题类型、创建时间范围等多种条件组合筛选问题跟踪记录。用户可以根据实际需求灵活设置筛选条件，精确获取所需的问题跟踪数据，提高查询效率和准确性。

- **分页与排序功能**：提供标准的分页参数（页码、每页数量）和排序参数（按字段和排序方向），确保在大量问题跟踪记录的情况下仍能高效加载和展示数据。默认按创建时间倒序排列，最新问题优先显示。

- **权限控制功能**：根据当前用户的角色和权限范围过滤问题跟踪记录。系统管理员可查看所有记录，部门管理员只能查看本部门相关记录，普通用户只能查看自己负责或参与的问题记录，确保数据访问的安全性。

### 逻辑签名

```naturalts path="app.logics.getIssueTrackingRecords.ts"
$Logic({
    description: '获取问题跟踪记录',
    directory: 'quality_management(质量管理)'
})
export declare function getIssueTrackingRecords(page: Integer, size: Integer, sort: String, order: String, issueId: String, titleKeyword: String, assigneeId: String, status: app.enums.IssueStatus, issueType: app.enums.IssueType, startTime: DateTime, endTime: DateTime): { list: List<app.dataSources.defaultDS.entities.IssueTrackingRecord>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 页码 |
| size | 每页条数 | Integer | 每页条数 |
| sort | 排序字段 | String | 排序字段 |
| order | 排序顺序 | String | 排序顺序（'asc'或'desc'） |
| issueId | 问题ID | String | 问题ID，用于精确查询 |
| titleKeyword | 问题标题关键词 | String | 问题标题关键词，用于模糊查询 |
| assigneeId | 责任人ID | String | 责任人ID，用于筛选指定责任人的问题 |
| status | 问题状态 | app.enums.IssueStatus | 问题状态枚举值 |
| issueType | 问题类型 | app.enums.IssueType | 问题类型枚举值 |
| startTime | 开始时间 | DateTime | 查询开始时间 |
| endTime | 结束时间 | DateTime | 查询结束时间 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 问题跟踪记录列表 | List<app.dataSources.defaultDS.entities.IssueTrackingRecord> | 问题跟踪记录列表 |
| total | 总条数 | Integer | 符合条件的总记录数 |

### 被前端调用

- **问题跟踪（issueTracking）**：在问题跟踪页面中，用户通过此服务端逻辑获取所有质量问题的跟踪记录列表，支持筛选、分页和排序，用于监控质量问题处理进度和状态。

### 依赖的枚举、实体

- **数据建模-枚举-问题状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-枚举-问题类型**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-问题跟踪记录**：[质量管理-实体-问题跟踪记录（IssueTrackingRecord）](specs/001-bootdo-management-system/plan/data-model/entity-IssueTrackingRecord.md)

### 依赖的外部能力

[文件内部已经提供，无需进行生成。如果文件内部已经有 `依赖的外部能力` 内容，禁止修改或删除文件内的 `依赖的外部能力` 内容]