# 环保管理-获取合规检查详情（getComplianceInspectionDetail）

- **生成时间**：2026-03-25

## 获取合规检查详情（getComplianceInspectionDetail）

### 功能概述

该服务端逻辑用于获取环保法规合规检查的详细信息，包括检查的基本信息、检查结果、发现的问题、整改措施建议以及相关附件等。系统会根据传入的合规检查ID查询数据库，返回完整的合规检查记录，供前端展示和后续处理使用。此功能是环境管理模块的核心功能之一，支持环保合规工作的全流程管理。

### 功能要点

- **合规检查详情查询**：根据合规检查ID精确查询对应的合规检查记录，确保数据的准确性和完整性。系统需要验证用户是否有权限查看该合规检查记录，防止未授权访问敏感环保数据。查询结果应包含检查的时间、地点、检查人员、被检查单位、检查依据的法规条款、检查发现的问题描述、问题严重程度评级、整改建议、整改期限等关键信息，为后续的整改工作提供完整依据。

### 逻辑签名

```naturalts path="app.logics.getComplianceInspectionDetail.ts"
$Logic({
    description: '获取合规检查详情',
    directory: 'environmental_management(环保管理)'
})
export declare function getComplianceInspectionDetail(complianceInspectionId: String): app.dataSources.defaultDS.entities.ComplianceInspection;
```

### 被前端调用

- **通用业务模块-合规检查（complianceInspection）**：在合规检查列表中点击某条记录的查看详情操作，通过调用此服务端逻辑获取完整的合规检查信息并展示详细内容，包括检查基本信息、问题描述、合规状态等关键信息。

### 依赖的枚举、实体

- **数据建模-实体-合规检查**：[环保管理-实体-合规检查（ComplianceInspection）](specs/001-bootdo-management-system/plan/data-model/entity-ComplianceInspection.md)
- **数据建模-实体-环境问题**：[环保管理-实体-环境问题（EnvironmentalIssue）](specs/001-bootdo-management-system/plan/data-model/entity-EnvironmentalIssue.md)
- **数据建模-实体-整改措施**：[环保管理-实体-整改措施（RectificationMeasure）](specs/001-bootdo-management-system/plan/data-model/entity-RectificationMeasure.md)

### 依赖的外部能力

[文件内部已经提供，无需进行生成。如果文件内部已经有 `依赖的外部能力` 内容，禁止修改或删除文件内的 `依赖的外部能力` 内容]