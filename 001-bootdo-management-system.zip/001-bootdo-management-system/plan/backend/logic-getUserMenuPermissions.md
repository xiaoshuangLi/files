# 权限中心-获取用户菜单权限（getUserMenuPermissions）

- **生成时间**：2026-03-25

## 获取用户菜单权限（getUserMenuPermissions）

### 功能概述

获取用户菜单权限服务端逻辑负责根据当前登录用户的ID查询其所有关联的角色，并基于这些角色获取对应的导航菜单权限。该逻辑通过查询用户角色映射表、角色权限映射表以及导航菜单表，构建完整的菜单树形结构，确保用户只能看到和访问其有权限的功能模块。返回的菜单数据包含菜单ID、名称、URL路径、图标、排序权重、父菜单ID等完整信息，支持多级嵌套菜单结构，为前端Dashboard页面提供动态菜单渲染所需的数据基础。该逻辑还处理菜单的启用状态过滤，确保禁用的菜单项不会显示给用户，同时保证菜单数据的安全性和完整性。

### 功能要点

- **动态菜单权限获取**：根据用户ID查询其所有关联的角色，然后基于角色获取对应的导航菜单权限，实现细粒度的菜单访问控制。系统首先通过LcapUserRoleMapping实体查询用户的所有角色ID，然后通过NavigationMenu实体查询与这些角色ID关联的菜单项，最终构建完整的菜单树形结构返回给前端。该过程确保了用户只能看到其有权限访问的功能模块，提高了系统的安全性和用户体验的一致性。

### 逻辑签名

```naturalts path="app.logics.getUserMenuPermissions.ts"
$Logic({
    description: '获取用户菜单权限',
    directory: 'permission_center(权限中心)'
})
export declare function getUserMenuPermissions(userId: Integer): List<app.dataSources.defaultDS.entities.NavigationMenu>;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| userId | 用户ID | Integer | 当前登录用户的唯一标识 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 导航菜单列表 | List<app.dataSources.defaultDS.entities.NavigationMenu> | 用户有权访问的导航菜单列表，包含菜单的完整信息 |

### 被前端调用

- **Dashboard（dashboard）**：Dashboard页面在用户登录后调用此服务端逻辑，获取当前用户的菜单权限数据，用于动态渲染左侧主菜单栏。根据返回的菜单数据，系统能够正确显示用户有权访问的所有功能模块，并隐藏无权限的菜单项，确保用户界面的安全性和个性化。

### 依赖的枚举、实体

- **数据建模-实体-用户**：[权限中心-实体-用户（LcapUser）](specs/001-bootdo-management-system/plan/data-model/entity-LcapUser.md)
- **数据建模-实体-角色**：[权限中心-实体-角色（LcapRole）](specs/001-bootdo-management-system/plan/data-model/entity-LcapRole.md)
- **数据建模-实体-用户与角色映射**：[权限中心-实体-用户与角色映射（LcapUserRoleMapping）](specs/001-bootdo-management-system/plan/data-model/entity-LcapUserRoleMapping.md)
- **数据建模-实体-导航菜单**：[系统管理-实体-导航菜单（NavigationMenu）](specs/001-bootdo-management-system/plan/data-model/entity-NavigationMenu.md)

### 依赖的外部能力

无