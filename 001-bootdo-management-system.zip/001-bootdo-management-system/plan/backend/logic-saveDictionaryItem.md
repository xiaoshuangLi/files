# 系统管理-保存字典项（saveDictionaryItem）

- **生成时间**：2026-03-25

## 保存字典项（saveDictionaryItem）

### 功能概述

保存字典项服务端逻辑实现数据字典的创建和更新功能，支持系统管理员对各类分类数据和配置项进行统一维护。该逻辑接收完整的字典项实体数据，根据字典项是否包含主键ID来判断执行创建或更新操作。创建操作会自动生成主键ID并设置创建时间和创建者信息，更新操作则会更新字典项的所有字段并记录更新时间和更新者信息。该逻辑确保数据字典的一致性和完整性，为整个应用提供可靠的数据引用标准。

### 功能要点

- **字典项创建与更新**：根据传入的字典项实体是否包含主键ID，自动判断执行创建或更新操作。创建操作会生成新的主键ID并设置初始的创建时间和创建者信息，更新操作则会保留原有ID并更新所有字段内容，同时记录更新时间和更新者信息。该功能确保字典项数据的完整生命周期管理，支持系统管理员灵活维护各类分类数据。

### 逻辑签名

```naturalts path="app.logics.saveDictionaryItem.ts"
$Logic({
    description: '保存字典项',
    directory: 'system_management(系统管理)',
    transactional: true
})
export declare function saveDictionaryItem(dictionaryItem: app.dataSources.defaultDS.entities.DataDictionary): app.dataSources.defaultDS.entities.DataDictionary;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| dictionaryItem | 字典项实体 | app.dataSources.defaultDS.entities.DataDictionary | 包含字典类型、标签名、数据值和描述信息的字典项实体 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 保存结果 | app.dataSources.defaultDS.entities.DataDictionary | 保存后的字典项实体，包含完整的字段信息和自动生成的元数据 |

### 被前端调用

- **字典管理（dictionaryManagement）**：在字典管理页面中，用户通过新增或编辑表单提交字典项数据时，调用此服务端逻辑保存字典项。该逻辑处理字典项的创建和更新操作，确保字典数据的一致性和完整性。

### 依赖的枚举、实体

- **数据建模-实体-数据字典**：[系统管理-实体-数据字典（DataDictionary）](specs/001-bootdo-management-system/plan/data-model/entity-DataDictionary.md)

### 依赖的外部能力

无外部能力依赖