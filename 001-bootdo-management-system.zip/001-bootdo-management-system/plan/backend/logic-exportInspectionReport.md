# 质量管理-导出检验报告（exportInspectionReport）

- **生成时间**：2026-03-25

## 导出检验报告（exportInspectionReport）

### 功能概述

导出检验报告服务端逻辑用于将质量检验的详细报告数据转换为标准格式的外部文件，支持PDF、Word等常用文档格式的导出。该逻辑接收检验报告ID作为输入参数，查询关联的检验报告实体及其相关联的质量检验、质量问题等完整数据，按照预定义的模板格式生成结构化的文档内容。导出功能支持单个检验报告导出和批量导出两种模式，满足质量管理人员在不同场景下的文档分享和存档需求。生成的导出文件包含完整的检验过程记录、结果分析、专业结论以及审核信息，确保导出内容的完整性和专业性，同时符合企业质量管理体系对文档化信息的要求。

### 功能要点

- **多格式文档导出**：支持将检验报告数据导出为PDF、Word等多种标准文档格式，满足不同使用场景的需求。系统根据用户选择的格式类型，调用相应的文档生成引擎，将检验报告的结构化数据转换为对应格式的文件。每种格式都经过精心设计，确保文档布局美观、内容完整，并保持与系统内显示效果的一致性。导出过程中会自动处理特殊字符编码、表格格式、图片嵌入等技术细节，保证生成文件的专业性和可用性。

### 逻辑签名

```naturalts path="app.logics.exportInspectionReport.ts"
$Logic({
    description: '导出检验报告',
    directory: 'quality_management(质量管理)'
})
export declare function exportInspectionReport(
  inspectionReportId: Integer,
  format: app.enums.ReportFormatEnum = app.enums.ReportFormatEnum.PDF
): String;
```

### 被前端调用

- **检验报告（inspectionReport）**：质量管理员在检验报告管理页面点击"导出"按钮时，系统调用此服务端逻辑，将指定的检验报告数据导出为用户选择的格式（PDF、Word等），并返回文件下载链接供用户下载保存。

### 依赖的枚举、实体

- **数据建模-枚举-报表格式**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-检验报告**：[质量管理-实体-检验报告（InspectionReport）](specs/001-bootdo-management-system/plan/data-model/entity-InspectionReport.md)
- **数据建模-实体-质量检验**：[质量管理-实体-质量检验（QualityInspection）](specs/001-bootdo-management-system/plan/data-model/entity-QualityInspection.md)
- **数据建模-实体-质量问题**：[质量管理-实体-质量问题（QualityIssue）](specs/001-bootdo-management-system/plan/data-model/entity-QualityIssue.md)

### 依赖的外部能力

无外部能力依赖。导出检验报告逻辑完全基于系统内部的数据模型和文档生成能力实现，不依赖任何第三方外部服务或API。