# 分包商管理-查询分包商资质证书列表（querySubcontractorQualificationCertificates）

- **生成时间**：2026-03-25

## 查询分包商资质证书列表（querySubcontractorQualificationCertificates）

### 功能概述

该服务端逻辑用于查询指定分包商的所有资质证书信息，支持分页、排序和过滤功能。通过该逻辑，系统能够获取分包商持有的各类专业资质证书的完整列表，包括证书名称、证书编号、颁发机构、颁发日期、过期日期等关键信息，为资质管理页面提供数据支撑，确保企业能够有效验证分包商的合法合规经营资格。

### 功能要点

- **分页查询功能**：支持按页码和每页条数进行分页查询，避免一次性加载过多数据导致性能问题，提升系统响应速度和用户体验。
- **排序筛选功能**：支持按任意字段进行升序或降序排序，用户可以根据证书名称、颁发日期、过期日期等字段对资质证书列表进行灵活排序，便于快速定位所需信息。
- **条件过滤功能**：支持根据分包商ID进行精确过滤，确保只返回指定分包商的资质证书信息；同时支持按证书名称、证书编号等字段进行模糊匹配过滤，提高查询的精准度和效率。
- **关联数据查询**：在返回资质证书列表的同时，自动关联分包商的基本信息，包括公司名称、联系人等，为用户提供完整的上下文信息，便于进行综合评估和决策。

### 逻辑签名

```naturalts path="app.logics.querySubcontractorQualificationCertificates.ts"
$Logic({
    description: '查询分包商资质证书列表',
    directory: 'subcontractor_management(分包商管理)'
})
export declare function querySubcontractorQualificationCertificates(page: Integer, size: Integer, sort: String, order: String, subcontractorId: Integer, certificateName?: String, certificateNumber?: String): { list: List<{ qualificationCertificate: app.dataSources.defaultDS.entities.QualificationCertificate, subcontractorInformation: app.dataSources.defaultDS.entities.SubcontractorInformation }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 查询的页码，从1开始 |
| size | 每页条数 | Integer | 每页显示的记录数量 |
| sort | 排序字段 | String | 用于排序的字段名称 |
| order | 排序顺序 | String | 排序顺序，'asc'表示升序，'desc'表示降序 |
| subcontractorId | 分包商ID | Integer | 要查询资质证书的分包商ID |
| certificateName | 证书名称 | String | 证书名称模糊匹配条件，可选 |
| certificateNumber | 证书编号 | String | 证书编号模糊匹配条件，可选 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 资质证书列表 | List<{ qualificationCertificate: app.dataSources.defaultDS.entities.QualificationCertificate, subcontractorInformation: app.dataSources.defaultDS.entities.SubcontractorInformation }> | 资质证书列表，每个列表项包含资质证书实体和关联的分包商信息实体 |
| total | 总条数 | Integer | 符合查询条件的资质证书总数量 |

### 被前端调用

- **资质管理（qualificationCertificate）**：在资质管理页面中，当用户查看特定分包商的资质证书时，调用此服务端逻辑获取分包商的所有资质证书列表，并支持分页、排序和搜索功能，实现对分包商资质证书的有效管理。

### 依赖的枚举、实体

- **数据建模-实体-资质证书**：[分包商管理-实体-资质证书（QualificationCertificate）](specs/001-bootdo-management-system/plan/data-model/entity-QualificationCertificate.md)
- **数据建模-实体-分包商信息**：[分包商管理-实体-分包商信息（SubcontractorInformation）](specs/001-bootdo-management-system/plan/data-model/entity-SubcontractorInformation.md)

### 依赖的外部能力

无外部能力依赖