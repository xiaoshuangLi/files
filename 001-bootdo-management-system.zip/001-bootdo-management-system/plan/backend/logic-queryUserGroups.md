# 系统管理-查询用户组列表（queryUserGroups）

- **生成时间**：2026-03-25

## 查询用户组列表（queryUserGroups）

### 功能概述

查询用户组列表服务端逻辑用于检索系统中所有用户组的信息，支持分页、搜索和过滤功能。该逻辑为前端用户提供高效获取用户组数据的能力，便于在用户和组管理页面中展示用户组列表。通过此接口，系统管理员可以查看所有已创建的用户组，包括其基本信息如组名称、描述、激活状态等，并支持按组名称进行模糊搜索，提高查找效率。该逻辑还支持分页加载，避免一次性加载过多数据导致性能问题，确保系统在大规模用户组场景下的响应速度和稳定性。

### 功能要点

- **分页查询功能**：支持按页码和每页大小参数进行分页查询，避免一次性加载过多数据影响系统性能，确保在大规模用户组场景下仍能保持良好的响应速度。
- **搜索过滤功能**：支持按用户组名称进行模糊搜索，帮助用户快速定位目标用户组，提高管理效率。
- **状态筛选功能**：支持按用户组激活状态进行筛选，可分别查看激活或非激活的用户组，便于系统管理员进行针对性管理。
- **完整数据返回**：返回用户组的完整信息，包括ID、组名称、描述、激活状态、创建时间和更新时间等关键字段，满足前端展示需求。

### 逻辑签名

```naturalts path="app.logics.queryUserGroups.ts"
/**
 * 查询用户组列表
 * @param page 页码，从1开始
 * @param size 每页大小
 * @param groupName 用户组名称（模糊匹配）
 * @param isActive 是否激活状态
 * @result 分页结果，包含用户组列表和总记录数
 */
export declare function queryUserGroups(
  page: Integer,
  size: Integer,
  groupName?: String,
  isActive?: Boolean
): { list: List<app.dataSources.defaultDS.entities.UserGroup>, total: Integer };
```

### 被前端调用

- **用户和组管理（userGroupManagement）**：在用户和组管理页面中，通过调用此服务端逻辑获取用户组列表数据，支持分页浏览、搜索过滤和状态筛选功能，实现用户组的高效管理。

### 依赖的枚举、实体

- **数据建模-实体-用户组**：[系统管理-实体-用户组（UserGroup）](specs/001-bootdo-management-system/plan/data-model/entity-UserGroup.md)

### 依赖的外部能力

无外部能力依赖