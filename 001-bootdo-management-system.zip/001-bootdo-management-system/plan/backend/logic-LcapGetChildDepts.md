# 权限中心-获取子部门列表（LcapGetChildDepts）

## 获取子部门列表（LcapGetChildDepts）

### 功能概述

该服务端逻辑用于根据父部门ID（parentDeptId）查询直接子部门列表，返回 `{ list: List<LcapDepartment> }`。部门管理页在 getDeptIdAndNameList 中用于获取同级部门名称/标识列表以做唯一性校验，以及在树形展开等场景中获取子节点。

### 功能要点

- **按父部门ID查询**：在 LcapDepartment 实体中按 parentDeptId 等于传入参数查询，得到直接子部门列表。
- **返回结构**：返回 `{ list, total }` 或仅 list 包装，与现有调用方式一致（如 deptChildList = ...list）。

### 逻辑签名

```naturalts path="app.logics.LcapGetChildDepts.ts"
$Logic({
    description: '根据父部门ID查询直接子部门列表',
    directory: 'permission_center(权限中心)'
})
export declare function LcapGetChildDepts(parentDeptId: String): { list: List<app.dataSources.defaultDS.entities.LcapDepartment> };
```

### 被前端调用

- **部门管理页（departmentManagement）**：getDeptIdAndNameList 中根据当前操作上下文（根部门或当前部门父级）获取同级部门列表；树形组件展开时获取子部门列表。

### 依赖的枚举、实体、数据结构

- **数据建模-实体-部门**：[权限中心-实体-部门（LcapDepartment）](specs/001-bootdo-management-system/plan/data-model/entity-LcapDepartment.md)

