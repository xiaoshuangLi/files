# 质量管理-获取质量问题列表（queryQualityIssues）

- **生成时间**：2026-03-25

## 获取质量问题列表（queryQualityIssues）

### 功能概述

获取质量问题列表服务端逻辑用于分页查询系统中的质量问题记录，支持按问题状态、报告人、报告时间范围等条件进行过滤，并支持按指定字段和顺序进行排序。该逻辑返回符合条件的质量问题列表及其总数，为前端质量问题登记页面提供数据支撑。通过关联查询系统账户实体，该逻辑能够同时返回报告人的详细信息，包括用户名、真实姓名等关键字段，确保前端能够完整展示质量问题的相关上下文信息。

### 功能要点

- **分页查询与筛选功能**：支持标准的分页参数（页码、每页条数）控制返回数据量，避免一次性加载过多数据导致性能问题。同时支持基于质量问题实体（QualityIssue）的多维度筛选，包括问题状态（QualityIssueStatusEnum）、报告人ID、报告时间范围等条件，用户可以根据实际需求组合不同的筛选条件，快速定位到关注的质量问题记录。

- **动态排序与关联数据加载**：支持按任意字段（如报告时间、问题标题等）进行升序或降序排序，通过sort和order参数控制排序规则。在返回质量问题列表的同时，自动关联加载报告人的系统账户信息，减少前端多次请求的开销，提升用户体验和数据展示的完整性。

### 逻辑签名

```naturalts path="app.logics.queryQualityIssues.ts"
$Logic({
    description: '分页查询质量问题列表',
    directory: 'quality_management(质量管理)'
})
export declare function queryQualityIssues(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.QualityIssue): { list: List<{ qualityIssue: app.dataSources.defaultDS.entities.QualityIssue, reporter: app.dataSources.defaultDS.entities.SystemAccount }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 分页查询的页码，从1开始计数 |
| size | 每页条数 | Integer | 每页返回的记录数量 |
| sort | 排序字段 | String | 排序的字段名，如"reportedAt"、"title"等 |
| order | 排序顺序 | String | 排序方向，"asc"表示升序，"desc"表示降序 |
| filter | 过滤条件 | app.dataSources.defaultDS.entities.QualityIssue | 质量问题实体作为过滤条件，支持各字段的精确匹配 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 质量问题列表 | List<{ qualityIssue: app.dataSources.defaultDS.entities.QualityIssue, reporter: app.dataSources.defaultDS.entities.SystemAccount }> | 质量问题列表，每个列表项包含质量问题实体及其关联的报告人信息 |
| total | 总条数 | Integer | 符合筛选条件的总记录数，用于分页计算 |

### 被前端调用

- **质量问题登记（qualityIssue）**：质量问题登记页面使用此服务端逻辑加载质量问题列表数据，支持用户查看、筛选和管理质量问题记录。页面通过分页、筛选和排序参数调用此接口，获取符合业务需求的质量问题数据，并在表格中展示问题标题、报告人、报告时间、问题状态等关键信息。

### 依赖的枚举、实体

- **数据建模-枚举-质量问题状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-质量问题**：[质量管理-实体-质量问题（QualityIssue）](specs/001-bootdo-management-system/plan/data-model/entity-QualityIssue.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无匹配内容

