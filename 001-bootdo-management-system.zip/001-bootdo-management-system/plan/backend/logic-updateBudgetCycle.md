# 预算管理-更新预算周期（updateBudgetCycle）

- **生成时间**：2026-03-25

## 更新预算周期（updateBudgetCycle）

### 功能概述

更新预算周期功能用于修改已存在的预算周期配置，确保预算管理系统中的时间框架数据能够根据实际业务需求进行调整。该功能允许系统管理员修改预算周期的名称、时间范围和描述信息，以适应组织架构变化、财年调整或其他业务场景的需求。通过严格的日期验证规则（结束日期不能早于开始日期）和周期名称唯一性校验，保证更新后的预算周期数据仍然保持准确性和一致性。更新操作会保留原有的系统字段（如创建时间、创建人等），仅更新业务相关字段，并记录最新的修改时间和修改人信息。

### 功能要点

- **预算周期信息更新**：系统需要接收并验证待更新的预算周期完整信息，包括周期名称、开始日期、结束日期和描述信息。更新时必须确保周期名称在系统中保持唯一性，开始日期和结束日期必须符合业务逻辑（结束日期不能早于开始日期）。系统会保留原有的创建时间、创建人等系统字段，同时更新修改时间和修改人字段为当前操作用户和时间戳。

### 逻辑签名

```naturalts path="app.logics.updateBudgetCycle.ts"
$Logic({
    description: '更新预算周期',
    directory: 'budget_management(预算管理)',
    transactional: true
})
export declare function updateBudgetCycle(budgetCycle: app.dataSources.defaultDS.entities.BudgetCycle): app.dataSources.defaultDS.entities.BudgetCycle;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| budgetCycle | 预算周期实体 | app.dataSources.defaultDS.entities.BudgetCycle | 包含完整预算周期信息的实体，其中id字段用于标识要更新的记录，其他字段包含新的周期名称、开始日期、结束日期和描述等 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 更新结果 | app.dataSources.defaultDS.entities.BudgetCycle | 更新后的完整预算周期实体，包含最新的业务字段和系统字段（如更新时间、更新人等） |

### 被前端调用

- **预算周期管理（budgetCycle）**：在预算周期管理页面中，当系统管理员点击某条记录的"编辑"按钮，修改预算周期信息后点击保存，前端会调用此服务端逻辑将修改后的预算周期数据更新到数据库，完成编辑操作。

### 依赖的枚举、实体

- **数据建模-实体-预算周期**：[预算管理-实体-预算周期（BudgetCycle）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetCycle.md)

### 依赖的外部能力

无