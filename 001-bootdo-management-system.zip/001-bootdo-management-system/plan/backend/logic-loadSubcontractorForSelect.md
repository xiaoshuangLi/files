# 分包商管理-加载分包商选择列表（loadSubcontractorForSelect）

- **生成时间**：2026-03-25

## 加载分包商选择列表（loadSubcontractorForSelect）

### 功能概述

加载分包商选择列表服务端逻辑用于在需要选择分包商的业务场景中提供分包商数据支持。该逻辑专门针对下拉选择、自动完成等用户界面组件的需求，返回简化的分包商信息列表，包含分包商ID和公司名称等关键字段，便于用户在表单中快速选择合适的分包商。与完整的分包商列表查询不同，此逻辑优化了数据结构和查询性能，只返回必要的选择字段，减少数据传输量并提高前端渲染效率。该逻辑支持按公司名称进行模糊搜索，帮助用户在大量分包商中快速定位目标分包商。

### 功能要点

- **分包商选择数据提供**：为前端下拉选择框、自动完成组件等提供优化的分包商数据源，返回包含分包商ID和公司名称的简化数据结构。该功能点确保在需要选择分包商的业务场景（如项目分配、合同关联、人员配置等）中，用户能够快速、准确地选择目标分包商，提升用户体验和操作效率。系统会根据传入的搜索关键词对分包商公司名称进行模糊匹配，返回匹配度最高的分包商列表，支持用户输入部分公司名称即可找到目标分包商。

### 逻辑签名

```naturalts path="app.logics.loadSubcontractorForSelect.ts"
$Logic({
    description: '加载分包商选择列表',
    directory: 'subcontractor_management(分包商管理)'
})
export declare function loadSubcontractorForSelect(searchTerm?: String, maxResults?: Integer): List<{ id: Integer, companyName: String }>;
```

### 被前端调用

- **分包商信息维护（subcontractorInformation）**：在分包商信息维护页面的某些表单场景中，当需要选择关联的分包商时，前端会调用此服务端逻辑获取分包商选择列表，供用户在下拉框或自动完成组件中选择目标分包商。
- **项目分配（projectAssignment）**：在项目分配功能页面中，当需要为项目分配分包商时，前端会调用此服务端逻辑加载可用的分包商列表，供用户选择合适的分包商进行项目分配。
- **合同关联（contractAssociation）**：在合同关联管理页面中，当需要将合同与分包商进行关联时，前端会调用此服务端逻辑获取分包商选择数据，支持用户快速选择对应的分包商。

### 依赖的枚举、实体

- **数据建模-实体-分包商信息**：[分包商管理-实体-分包商信息（SubcontractorInformation）](specs/001-bootdo-management-system/plan/data-model/entity-SubcontractorInformation.md)

### 依赖的外部能力

无