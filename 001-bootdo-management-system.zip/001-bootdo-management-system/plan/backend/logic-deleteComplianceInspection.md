# 环保管理-删除合规检查（deleteComplianceInspection）

- **生成时间**：2026-03-25

## 删除合规检查（deleteComplianceInspection）

### 功能概述

删除合规检查服务端逻辑用于处理环保管理人员删除已存在的合规检查记录的请求。该功能确保只有授权用户才能执行删除操作，并在删除前验证合规检查记录的存在性。删除操作会从数据库中永久移除指定的合规检查记录及其相关联的数据引用，同时记录操作日志以便审计追踪。该逻辑支持前端合规检查管理页面的删除功能，提供安全可靠的合规检查数据清理能力。

### 功能要点

- **安全删除验证**：删除操作前必须验证当前用户是否具有删除合规检查的权限，通常仅限于系统管理员、部门管理员或创建该合规检查的用户。系统会检查用户角色和权限，确保只有授权人员才能执行删除操作，防止未授权的数据删除。
- **关联数据处理**：删除合规检查时需要处理与其关联的整改措施数据。由于合规检查实体与整改措施实体存在关联关系，系统会检查是否存在依赖该合规检查的整改措施记录。如果存在关联的整改措施，系统会根据业务规则决定是级联删除还是阻止删除操作，确保数据一致性。
- **操作审计记录**：每次删除操作都会生成详细的操作日志，记录删除操作的执行者、删除时间、被删除的合规检查ID等关键信息。这些审计日志对于后续的问题追溯和责任认定至关重要，符合企业数据安全管理要求。

### 逻辑签名

```naturalts path="app.logics.deleteComplianceInspection.ts"
$Logic({
    description: '删除合规检查',
    directory: 'environmental_management(环保管理)',
    transactional: true
})
export declare function deleteComplianceInspection(id: Integer): Boolean;
```

### 被前端调用

- **合规检查（complianceInspection）**：在合规检查列表页面中，用户点击某条记录的"删除"按钮后，系统会调用此服务端逻辑执行删除操作。前端会先弹出二次确认对话框，用户确认后才会发起删除请求，删除成功后前端会刷新列表显示最新的合规检查数据。

### 依赖的枚举、实体

- **数据建模-实体-合规检查**：[环保管理-实体-合规检查（ComplianceInspection）](specs/001-bootdo-management-system/plan/data-model/entity-ComplianceInspection.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)
- **数据建模-实体-整改措施**：[环保管理-实体-整改措施（RectificationMeasure）](specs/001-bootdo-management-system/plan/data-model/entity-RectificationMeasure.md)

### 依赖的外部能力

无