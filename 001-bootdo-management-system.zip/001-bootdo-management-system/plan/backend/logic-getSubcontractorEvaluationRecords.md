# 分包商管理-获取分包商评估记录（getSubcontractorEvaluationRecords）

- **生成时间**：2026-03-25

## 获取分包商评估记录（getSubcontractorEvaluationRecords）

### 功能概述

获取分包商评估记录服务端逻辑用于分页查询系统中所有分包商的绩效评估记录，支持按分包商ID、评估人ID、评估时间范围等条件进行过滤，并支持按指定字段和顺序进行排序。该逻辑返回符合条件的评估记录列表及其总数，每条记录包含完整的评估信息以及关联的分包商和评估人详细信息。此服务为前端评估记录管理页面提供数据支撑，使用户能够高效地浏览、筛选和分析分包商的历史绩效表现，为分包商选择和合作决策提供客观依据。

### 功能要点

- **分页查询与筛选功能**：支持标准的分页参数（页码、每页条数）控制返回数据量，避免一次性加载过多数据导致性能问题。同时支持多维度筛选条件，包括分包商ID、评估人ID、评估时间范围等，用户可以根据实际需求组合不同的筛选条件，快速定位到关注的评估记录，提高数据查询的准确性和效率。
- **动态排序功能**：支持按任意字段（如评估时间、绩效评分等）进行升序或降序排列，通过sort参数指定排序字段，order参数指定排序方向。默认按评估时间(evaluatedAt)降序排列，确保最新的评估记录优先显示，便于用户了解分包商的最新绩效表现。
- **关联数据加载**：在返回评估记录列表的同时，自动加载关联的分包商信息(SubcontractorInformation)和评估人(SystemAccount)的详细信息，包括分包商公司名称、联系人信息以及评估人的用户名、全名等关键字段。这种关联查询减少了前端的多次请求，提高了数据展示的完整性和用户体验。

### 逻辑签名

```naturalts path="app.logics.getSubcontractorEvaluationRecords.ts"
$Logic({
    description: '分页查询分包商评估记录',
    directory: 'subcontractor_management(分包商管理)'
})
export declare function getSubcontractorEvaluationRecords(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.EvaluationRecord): { list: List<{ evaluationRecord: app.dataSources.defaultDS.entities.EvaluationRecord, subcontractor: app.dataSources.defaultDS.entities.SubcontractorInformation, evaluator: app.dataSources.defaultDS.entities.SystemAccount }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 分页查询的页码，从1开始计数 |
| size | 每页条数 | Integer | 每页返回的记录数量，建议范围1-100 |
| sort | 排序字段 | String | 排序的字段名，如"evaluatedAt"、"performanceScore"等 |
| order | 排序顺序 | String | 排序方向，"ascending"表示升序，"descending"表示降序 |
| filter | 过滤条件 | app.dataSources.defaultDS.entities.EvaluationRecord | 评估记录实体作为过滤条件，支持各字段的精确匹配 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 评估记录列表 | List<{ evaluationRecord: app.dataSources.defaultDS.entities.EvaluationRecord, subcontractor: app.dataSources.defaultDS.entities.SubcontractorInformation, evaluator: app.dataSources.defaultDS.entities.SystemAccount }> | 评估记录列表，每个列表项包含评估记录实体及其关联的分包商和评估人信息 |
| total | 总条数 | Integer | 符合筛选条件的总记录数，用于分页计算 |

### 被前端调用

- **评估记录（evaluationRecord）**：评估记录管理页面使用此服务端逻辑加载分包商评估记录列表数据，支持用户查看、筛选和管理评估记录。页面通过分页、筛选和排序参数调用此接口，获取符合业务需求的评估数据，并在表格中展示分包商名称、评估人、绩效评分、评估意见等关键信息。

### 依赖的枚举、实体

- **数据建模-实体-评估记录**：[分包商管理-实体-评估记录（EvaluationRecord）](specs/001-bootdo-management-system/plan/data-model/entity-EvaluationRecord.md)
- **数据建模-实体-分包商信息**：[分包商管理-实体-分包商信息（SubcontractorInformation）](specs/001-bootdo-management-system/plan/data-model/entity-SubcontractorInformation.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无