# 分包商管理-获取分包商付款列表（getSubcontractorPaymentList）

- **生成时间**：2026-03-25

## 获取分包商付款列表（getSubcontractorPaymentList）

### 功能概述

该服务端逻辑用于获取分包商的付款记录列表，支持按多种条件进行筛选和分页查询。系统管理员、部门管理员或具有相应权限的用户可以通过此接口查询特定分包商的所有付款记录，包括付款金额、付款状态、付款日期等关键信息。此功能是分包商付款管理模块的核心组成部分，为用户提供全面的付款历史视图，便于财务对账和付款跟踪。

### 功能要点

- **分页查询与筛选功能**：系统支持对分包商付款记录进行分页查询，每页可自定义显示条数。同时提供多种筛选条件，包括分包商ID、付款状态（已付款、待付款、部分付款等）、付款日期范围、项目关联等。用户可以根据实际需求组合这些筛选条件，快速定位到目标付款记录，提高查询效率和用户体验。

### 逻辑签名

```naturalts path="app.logics.getSubcontractorPaymentList.ts"
$Logic({
    description: '获取分包商付款列表',
    directory: 'subcontractor_management(分包商管理)'
})
export declare function getSubcontractorPaymentList(page: Integer, size: Integer, sort: String, order: String, subcontractorId?: Integer, paymentStatus?: String, startDate?: Date, endDate?: Date): { list: List<app.dataSources.defaultDS.entities.PaymentManagement>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 页码，从1开始 |
| size | 每页条数 | Integer | 每页显示的记录数量 |
| sort | 排序字段 | String | 用于排序的字段名称 |
| order | 排序顺序 | String | 排序顺序，asc表示升序，desc表示降序 |
| subcontractorId | 分包商ID | Integer | 可选，用于筛选特定分包商的付款记录 |
| paymentStatus | 付款状态 | String | 可选，用于筛选特定状态的付款记录 |
| startDate | 开始日期 | Date | 可选，用于筛选付款日期大于等于该日期的记录 |
| endDate | 结束日期 | Date | 可选，用于筛选付款日期小于等于该日期的记录 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 付款记录列表 | List<app.dataSources.defaultDS.entities.PaymentManagement> | 付款记录列表，每个元素为PaymentManagement实体 |
| total | 总记录数 | Integer | 符合筛选条件的总记录数 |

### 被前端调用

- **通用业务模块-付款管理（paymentManagement）**：在付款管理页面中，用户可以通过该服务端逻辑获取分包商的付款记录列表，支持按分包商、付款状态、日期范围等条件进行筛选，并以分页形式展示结果，便于用户查看和管理分包商的付款情况。

### 依赖的枚举、实体

- **数据建模-实体-分包商信息**：[分包商管理-实体-分包商信息（SubcontractorInformation）](specs/001-bootdo-management-system/plan/data-model/entity-SubcontractorInformation.md)
- **数据建模-实体-付款管理**：[分包商管理-实体-付款管理（PaymentManagement）](specs/001-bootdo-management-system/plan/data-model/entity-PaymentManagement.md)

### 依赖的外部能力

无