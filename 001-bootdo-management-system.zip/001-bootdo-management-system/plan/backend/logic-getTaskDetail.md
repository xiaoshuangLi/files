# 通用领域服务-获取任务详情（getTaskDetail）

- **生成时间**：2026-03-25

## 获取任务详情（getTaskDetail）

### 功能概述

该服务端逻辑用于获取系统中指定待办任务的详细信息，包括任务的基本属性、执行状态、关联用户、截止时间、优先级等完整信息。通过提供任务ID作为查询条件，系统能够返回该任务的所有相关数据，供前端页面展示和后续操作使用。此功能是待办任务管理模块的核心查询接口，确保用户能够准确查看任务的当前状态和历史记录。

### 功能要点

- **任务详情查询**：根据提供的任务ID参数，从数据库中检索对应的待办任务完整信息，包括任务标题、描述、创建时间、截止时间、优先级、执行状态、负责人、创建人等所有属性字段。系统需要验证任务ID的有效性，并确保当前用户具有查看该任务的权限，防止未授权访问。查询结果应包含任务的所有相关数据，为前端提供完整的任务视图。

### 逻辑签名

```naturalts path="app.logics.getTaskDetail.ts"
$Logic({
    description: '获取待办任务详情',
    directory: 'todo_management(待办管理)'
})
export declare function getTaskDetail(taskId: Text): app.dataSources.defaultDS.entities.TodoTask;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| taskId | 任务ID | Text | 待办任务的唯一标识符 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 任务详情 | app.dataSources.defaultDS.entities.TodoTask | 完整的待办任务详细信息 |

### 被前端调用

- **待办事项（todoTask）**：在用户点击待办任务列表中的某个任务时，调用此服务端逻辑获取该任务的完整详情信息，用于在详情页面中展示任务的所有属性和状态信息。

### 依赖的枚举、实体

- **数据建模-实体-待办任务**：[办公自动化-实体-待办任务（TodoTask）](specs/001-bootdo-management-system/plan/data-model/entity-TodoTask.md)

### 依赖的外部能力

[文件内部已经提供，无需进行生成。如果文件内部已经有 `依赖的外部能力` 内容，禁止修改或删除文件内的 `依赖的外部能力` 内容]