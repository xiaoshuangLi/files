# 质量管理-创建质量检验（createQualityInspection）

- **生成时间**：2026-03-25

## 创建质量检验（createQualityInspection）

### 功能概述

创建质量检验功能用于在质量管理模块中新增一条质量检验记录，该记录关联到特定的质量问题，并由指定的检验员执行检验操作。此功能支持质量管理员或相关授权用户录入详细的检验结果、设置检验通过状态，并记录实际检验时间。创建的质量检验记录将成为质量问题处理流程中的关键环节，为后续的问题验证和关闭提供依据。该功能确保了质量检验过程的规范化和可追溯性，同时与质量问题实体、系统账户实体等紧密集成，实现完整的质量管理闭环。

### 功能要点

- **质量检验记录创建**：系统支持创建新的质量检验记录，必须关联到已存在的质量问题ID，并指定执行检验的检验员ID。创建时需要提供详细的检验结果描述、实际检验时间和检验是否通过的结论。所有必填字段都必须有有效值，系统会进行数据完整性验证，确保创建的检验记录符合业务规则和数据约束。

### 逻辑签名

```naturalts path="app.logics.createQualityInspection.ts"
$Logic({
    description: '创建质量检验记录',
    directory: 'quality_management(质量管理)',
    transactional: true
})
export declare function createQualityInspection(
    qualityIssueId: Integer,
    inspectorId: Integer,
    inspectionResult: String,
    inspectedAt: DateTime,
    passed: Boolean
): app.dataSources.defaultDS.entities.QualityInspection;
```

### 被前端调用

- **质量检验（qualityInspection）**：质量管理员在质量检验页面点击"新建检验"按钮时，系统调用此服务端逻辑创建新的质量检验记录。该功能实现了检验数据的录入和保存，支持质量问题处理流程的推进。

### 依赖的枚举、实体

- **数据建模-实体-质量问题**：[质量管理-实体-质量问题（QualityIssue）](specs/001-bootdo-management-system/plan/data-model/entity-QualityIssue.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)
- **数据建模-实体-质量检验**：[质量管理-实体-质量检验（QualityInspection）](specs/001-bootdo-management-system/plan/data-model/entity-QualityInspection.md)

### 依赖的外部能力

无