# 薪资管理-导出薪资报表（exportSalaryReport）

- **生成时间**：2026-03-25

## 导出薪资报表（exportSalaryReport）

### 功能概述

导出薪资报表服务端逻辑负责根据用户指定的筛选条件生成Excel格式的薪资报表文件，并提供下载链接。该功能支持按部门、岗位、时间范围、员工姓名等多种条件进行数据筛选，确保导出的数据符合用户的特定需求。系统会从月工资额实体和薪资报表实体中提取相关数据，按照预定义的报表模板格式进行组织和格式化，最终生成标准的Excel文件。导出的报表包含完整的薪资构成明细，如基本工资、奖金、津贴、扣款项目、税前金额、税后金额等，便于财务部门进行数据分析和存档。同时，该逻辑还支持将生成的报表通过邮件服务发送给指定的收件人，满足企业内部审批和分发的需求。

### 功能要点

- **多维度数据筛选与导出**：支持根据部门ID、岗位ID、时间范围和员工姓名等多个维度进行薪资数据筛选，确保导出的报表数据精准匹配用户需求。系统会根据筛选条件从月工资额和薪资报表实体中查询相关数据，按照Excel模板格式进行组织，生成包含完整薪资构成明细的报表文件，包括基本工资、绩效奖金、津贴补贴、社保公积金扣款、个人所得税等详细项目，确保数据的完整性和准确性。

### 逻辑签名

```naturalts path="app.logics.exportSalaryReport.ts"
$Logic({
    description: '导出薪资报表',
    directory: 'salary_management(薪资管理)'
})
export declare function exportSalaryReport(departmentId?: Integer, positionId?: Integer, timeRange?: { startDate: DateTime, endDate: DateTime }, employeeName?: String): { downloadUrl: String, fileName: String };
```

### 被前端调用

- **薪资报表（salaryReport）**：薪资报表页面通过调用此服务端逻辑，根据用户设置的筛选条件（部门、岗位、时间范围、员工姓名）生成Excel格式的薪资报表文件，并提供下载链接供用户下载保存。

### 依赖的枚举、实体

- **数据建模-实体-薪资报表**：[薪资管理-实体-薪资报表（SalaryReport）](specs/001-bootdo-management-system/plan/data-model/entity-SalaryReport.md)
- **数据建模-实体-月工资额**：[薪资管理-实体-月工资额（MonthlySalaryAmount）](specs/001-bootdo-management-system/plan/data-model/entity-MonthlySalaryAmount.md)

### 依赖的外部能力

无匹配内容

