# 工作流引擎-获取用户组详情（getUserGroupDetail）

- **生成时间**：2026-03-25

## 获取用户组详情（getUserGroupDetail）

### 功能概述

该服务端逻辑用于获取系统中特定用户组的详细信息，包括用户组的基本属性、成员列表、权限配置以及关联的工作流信息。用户组作为工作流管理中的核心组织单元，其详情信息对于权限分配、流程审批和用户管理至关重要。此接口支持根据用户组ID查询完整的用户组数据，确保前端能够准确展示用户组的全部相关信息，并为后续的编辑、权限调整等操作提供数据基础。

### 功能要点

- **用户组基本信息查询**：根据提供的用户组ID，从数据库中检索用户组的核心属性信息，包括用户组名称、描述、创建时间、更新时间、状态（启用/禁用）等基本信息，确保数据的完整性和准确性，为前端展示提供可靠的数据源。

- **用户组成员列表获取**：查询并返回该用户组包含的所有成员用户信息，包括用户ID、用户名、真实姓名、角色等关键信息，支持分页加载以应对大型用户组的情况，同时保证成员数据的实时性和一致性。

- **权限配置信息提取**：获取该用户组当前配置的权限信息，包括功能权限、数据权限和操作权限的具体设置，确保权限数据结构清晰，便于前端进行权限管理和可视化展示。

- **工作流关联信息查询**：检索与该用户组关联的工作流实例、流程定义和任务节点信息，明确用户组在工作流中的角色和职责，为工作流监控和管理提供必要的上下文数据支持。

### 逻辑签名

```naturalts path="app.logics.getUserGroupDetail.ts"
$Logic({
    description: '获取用户组详情',
    directory: 'workflow_engine(工作流引擎)'
})
export declare function getUserGroupDetail(userGroupId: String): { 
  userGroup: {
    id: String;
    name: String;
    description: String;
    status: String;
    createdAt: DateTime;
    updatedAt: DateTime;
    members: List<{
      userId: String;
      username: String;
      realName: String;
      role: String;
    }>;
    permissions: {
      functional: List<String>;
      data: List<String>;
      operational: List<String>;
    };
    workflowAssociations: List<{
      workflowId: String;
      workflowName: String;
      processDefinitionId: String;
      taskNodes: List<String>;
    }>;
  };
};
```

### 被前端调用

- **用户和组管理（userGroupManagement）**：在用户和组管理页面中，当用户点击某个用户组查看详情时，调用此服务端逻辑获取完整的用户组信息，包括基本信息、成员列表、权限配置和工作流关联，用于在详情弹窗或详情页面中展示。

### 依赖的枚举、实体

- **数据建模-实体-用户组**：[系统管理-实体-用户组（UserGroup）](specs/001-bootdo-management-system/plan/data-model/entity-UserGroup.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)
- **数据建模-实体-工作流**：[工作流引擎-实体-工作流（Workflow）](specs/001-bootdo-management-system/plan/data-model/entity-Workflow.md)

### 依赖的外部能力

无