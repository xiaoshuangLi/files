# 办公自动化-查询会议预约列表（queryMeetingReservationList）

- **生成时间**：2026-03-25

## 查询会议预约列表（queryMeetingReservationList）

### 功能概述

查询会议预约列表服务端逻辑提供分页查询系统中会议预约记录的功能，支持按会议标题、组织者、时间范围、地点等条件进行过滤，并支持按指定字段和顺序进行排序。该逻辑返回符合条件的会议预约列表及其总数，用于在会议管理页面中展示会议安排信息，帮助用户高效地浏览、筛选和管理会议预约。通过关联查询系统账户实体获取组织者的详细信息，确保前端能够完整展示会议的基本信息和组织者身份。

### 功能要点

- **分页查询与筛选功能**：支持标准的分页参数（页码、每页条数）控制返回数据量，避免一次性加载过多数据导致性能问题。同时支持多条件组合筛选，包括会议标题模糊匹配、组织者ID精确匹配、会议时间范围筛选、地点关键词搜索等，用户可以根据实际需求灵活组合筛选条件，快速定位到目标会议记录。
- **动态排序功能**：支持按任意字段（如开始时间、结束时间、会议标题等）进行升序或降序排列，通过sort和order参数控制排序规则。默认按开始时间降序排列，确保最新的会议预约优先显示，便于用户关注近期的会议安排。
- **关联数据查询**：在返回会议预约列表的同时，自动关联查询组织者的系统账户信息，包括用户名、全名、邮箱等关键字段，减少前端多次请求的开销，提升用户体验和数据展示的完整性。
- **时间冲突检测支持**：虽然主要的时间冲突检测在创建和更新会议时执行，但查询接口也支持按时间范围筛选，为前端提供时间冲突预检查的数据基础，帮助用户在创建新会议前了解特定时间段的会议室占用情况。

### 逻辑签名

```naturalts path="app.logics.queryMeetingReservationList.ts"
$Logic({
    description: '分页查询会议预约列表',
    directory: 'office_automation(办公自动化)'
})
export declare function queryMeetingReservationList(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.MeetingReservation): { list: List<{ meetingReservation: app.dataSources.defaultDS.entities.MeetingReservation, organizer: app.dataSources.defaultDS.entities.SystemAccount }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 分页查询的页码，从1开始计数 |
| size | 每页条数 | Integer | 每页返回的记录数量，建议范围1-100 |
| sort | 排序字段 | String | 排序的字段名，如"startTime"、"title"等 |
| order | 排序顺序 | String | 排序方向，"asc"表示升序，"desc"表示降序 |
| filter | 过滤条件 | app.dataSources.defaultDS.entities.MeetingReservation | 会议预约实体作为过滤条件，支持各字段的精确或模糊匹配 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 会议预约列表 | List<{ meetingReservation: app.dataSources.defaultDS.entities.MeetingReservation, organizer: app.dataSources.defaultDS.entities.SystemAccount }> | 会议预约列表，每个列表项包含会议预约实体及其关联的组织者信息 |
| total | 总条数 | Integer | 符合筛选条件的总记录数，用于分页计算 |

### 被前端调用

- **会议管理（meetingManagement）**：会议管理页面使用此服务端逻辑加载会议预约列表数据，支持用户查看、筛选和管理会议安排。页面通过分页、筛选和排序参数调用此接口，获取符合业务需求的会议数据，并在表格中展示会议标题、组织者、开始时间、结束时间、地点等关键信息。

### 依赖的枚举、实体

- **数据建模-实体-会议预约**：[办公自动化-实体-会议预约（MeetingReservation）](specs/001-bootdo-management-system/plan/data-model/entity-MeetingReservation.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力