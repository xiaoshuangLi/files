# 内容管理-删除评论（deleteComment）

- **生成时间**：2026-03-25

## 删除评论（deleteComment）

### 功能概述

删除评论功能提供对系统中用户发表的评论进行删除操作的能力。该功能允许系统管理员或具有相应权限的用户永久移除不符合规范、违规或不再需要的评论内容。删除操作会将评论从数据库中彻底移除，并记录操作日志以确保系统的可追溯性。该功能支持单条评论的删除操作，通过传入评论ID作为唯一标识，确保删除操作的精确性和安全性。

### 功能要点

- **评论删除操作**：系统管理员在评论管理页面选择需要删除的评论，点击删除按钮后，系统会弹出二次确认对话框，防止误操作。确认删除后，系统将根据传入的评论ID从数据库中永久删除对应的评论记录，并更新相关统计数据。删除操作完成后，系统会返回操作结果，前端页面会实时刷新评论列表，确保已删除的评论不再显示。整个删除过程会记录详细的操作日志，包括操作人、操作时间、被删除评论的ID等信息，以便后续审计和追踪。

### 逻辑签名

```naturalts path="app.logics.deleteComment.ts"
$Logic({
    description: "删除评论",
    directory: "content_management(内容管理)"
})
export declare function deleteComment(commentId: Integer): Boolean;
```

### 被前端调用

- **评论管理（commentInteraction）**：在评论管理页面中，系统管理员可以对任意评论执行删除操作。当管理员点击删除按钮并确认后，前端会调用deleteComment服务端逻辑，传入评论ID参数，实现评论的永久删除功能。

### 依赖的枚举、实体

- **数据建模-实体-评论互动**：[内容管理-实体-评论互动（CommentInteraction）](specs/001-bootdo-management-system/plan/data-model/entity-CommentInteraction.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

[文件内部已经提供，无需进行生成。如果文件内部已经有 `依赖的外部能力` 内容，禁止修改或删除文件内的 `依赖的外部能力` 内容]