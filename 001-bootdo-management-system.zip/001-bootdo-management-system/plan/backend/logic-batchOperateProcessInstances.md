# 工作流引擎-批量操作流程实例（batchOperateProcessInstances）

- **生成时间**：2026-03-25

## 批量操作流程实例（batchOperateProcessInstances）

### 功能概述

批量操作流程实例功能提供对多个工作流流程实例同时执行相同管理操作的能力，支持系统管理员高效处理大量流程实例。该功能允许用户选择一个或多个流程实例，然后统一执行挂起、恢复、终止等操作，大大提升了流程管理的效率。通过批量操作，管理员可以快速响应业务需求变化，如在系统维护期间批量挂起所有流程实例，或在紧急情况下批量终止异常流程。该功能还包含完善的操作确认机制和权限控制，确保批量操作的安全性和准确性，防止误操作导致业务中断。操作结果会详细记录到系统日志中，便于后续审计和问题追踪。

### 功能要点

- **批量流程实例管理**：系统管理员可以在流程实例管理页面中选择多个流程实例（通过复选框），然后执行统一的管理操作。支持的操作包括批量挂起（暂停流程执行）、批量恢复（重新激活已挂起的流程）和批量终止（强制结束流程实例）。每次批量操作前系统会弹出确认对话框，显示将要操作的实例数量和具体操作类型，用户确认后才会执行实际操作。操作过程中系统会验证每个流程实例的当前状态是否允许执行指定操作，例如只有处于活动状态的实例才能被挂起，只有已挂起的实例才能被恢复。操作完成后系统会返回处理后的流程实例列表，用于前端刷新显示最新的状态信息，并在操作日志中记录详细的操作历史，包括操作人、操作时间、操作类型和影响的实例数量。

### 逻辑签名

```naturalts path="app.logics.workflowEngine.batchOperateProcessInstances.ts"
$Logic({
    description: '批量操作流程实例',
    directory: 'workflow_engine(工作流引擎)'
})
export declare function batchOperateProcessInstances(
    userId: Integer,
    userRoleIds: List<Integer>,
    processInstanceIds: List<String>,
    operationType: String,
    reason: Optional<String>
): List<app.dataSources.defaultDS.entities.ProcessInstance>;
```

### 被前端调用

- **流程实例管理（processInstanceManagement）**：在流程实例管理页面中，当系统管理员选择多个流程实例并点击批量操作按钮（如批量挂起、批量恢复、批量终止）时，前端会调用此服务端逻辑。该逻辑接收选中的流程实例ID列表、操作类型和可选的操作原因，执行相应的批量管理操作，并返回处理后的流程实例列表，用于在前端刷新显示最新的流程实例状态。

### 依赖的枚举、实体

- **数据建模-实体-流程实例**：[工作流引擎-实体-流程实例（ProcessInstance）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessInstance.md)
- **数据建模-实体-用户**：.specify/warehouse/plan/data-model/entity-LcapUser.md

### 依赖的外部能力

无外部能力依赖