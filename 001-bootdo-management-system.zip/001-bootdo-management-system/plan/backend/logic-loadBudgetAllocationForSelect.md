# 预算管理-获取预算分配选择列表（loadBudgetAllocationForSelect）

- **生成时间**：2026-03-25

## 获取预算分配选择列表（loadBudgetAllocationForSelect）

### 功能概述

获取预算分配选择列表服务端逻辑为调整申请功能页面提供预算分配数据的下拉选择支持。该逻辑根据当前用户的权限范围和业务需求，查询系统中所有可用的预算分配记录，并以简化的格式返回用于前端下拉选择组件的数据。返回的数据包含预算分配的基本识别信息，如ID、预算类型名称、预算周期名称、分配金额等关键字段，便于用户在创建或编辑调整申请时能够快速选择关联的预算分配。该逻辑还支持基本的过滤条件，确保只返回状态为"已批准"、"执行中"或"已完成"的有效预算分配，排除草稿或无效的分配记录，保证数据的准确性和业务逻辑的一致性。

### 功能要点

- **提供预算分配选择数据**：根据调整申请页面的需求，查询并返回所有有效的预算分配记录作为下拉选择项，包含预算分配ID、预算类型、预算周期、分配金额等关键信息，确保用户能够准确选择需要调整的预算分配对象。
- **权限范围控制**：根据当前登录用户的部门权限或角色权限，过滤返回的预算分配列表，确保用户只能看到其有权限访问的预算分配记录，保障数据安全和业务隔离。
- **状态过滤**：仅返回状态为"已批准"、"执行中"或"已完成"的预算分配记录，排除"计划中"或"已调整"等不适合进行调整申请的状态，确保业务流程的正确性。
- **性能优化**：对查询结果进行合理的分页或限制返回数量，避免因数据量过大导致接口响应缓慢，提升用户体验。

### 逻辑签名

```naturalts path="app.logics.loadBudgetAllocationForSelect.ts"
$Logic({
    description: '获取预算分配选择列表',
    directory: 'budget_management(预算管理)'
})
export declare function loadBudgetAllocationForSelect(): List<{ id: Integer, budgetTypeName: String, budgetCycleName: String, amount: Decimal, allocatedAt: DateTime }>;
```

### 被前端调用

- **调整申请（adjustmentApplication）**：在调整申请页面的查询筛选区域和创建/编辑表单中，使用此服务端逻辑获取预算分配的下拉选择列表，用户可以通过该列表选择需要调整的预算分配记录，实现基于特定预算分配的调整申请创建和筛选功能。

### 依赖的枚举、实体

- **数据建模-枚举-预算状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-预算分配**：[预算管理-实体-预算分配（BudgetAllocation）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetAllocation.md)
- **数据建模-实体-预算类型**：[预算管理-实体-预算类型（BudgetType）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetType.md)
- **数据建模-实体-预算周期**：[预算管理-实体-预算周期（BudgetCycle）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetCycle.md)

### 依赖的外部能力

无匹配内容

