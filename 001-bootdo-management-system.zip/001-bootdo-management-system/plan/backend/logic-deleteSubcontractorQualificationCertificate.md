# 分包商管理-删除分包商资质证书（deleteSubcontractorQualificationCertificate）

- **生成时间**：2026-03-25

## 删除分包商资质证书（deleteSubcontractorQualificationCertificate）

### 功能概述

删除分包商资质证书服务端逻辑用于安全地移除系统中已存在的分包商资质证书记录。该逻辑接收资质证书的唯一标识符作为输入参数，执行删除操作前会验证证书的存在性，并确保删除操作符合数据完整性约束。删除操作会同时记录操作日志，包括操作人、操作时间和被删除的证书信息，以便后续审计追踪。此功能支持资质管理模块中的证书清理需求，帮助维护分包商资质信息的准确性和时效性，避免无效或过期证书对业务决策造成干扰。

### 功能要点

- **安全删除机制**：删除分包商资质证书时，系统首先验证待删除证书ID的有效性和存在性，确保不会对不存在的记录执行删除操作。删除过程中会检查该证书是否与其他业务实体存在关联依赖，如发现强关联关系则阻止删除并返回错误提示，保障数据完整性。删除操作在数据库事务中执行，确保操作的原子性，避免部分删除成功导致的数据不一致问题。

### 逻辑签名

```naturalts path="app.logics.deleteSubcontractorQualificationCertificate.ts"
$Logic({
    description: '删除分包商资质证书',
    directory: 'subcontractor_management(分包商管理)',
    transactional: true
})
export declare function deleteSubcontractorQualificationCertificate(certificateId: Integer): Boolean;
```

### 被前端调用

- **资质管理（qualificationCertificate）**：在资质管理页面中，用户可以通过点击资质证书列表中的"删除"按钮触发此服务端逻辑，传入要删除的资质证书ID，实现对特定分包商资质证书的删除操作。

### 依赖的枚举、实体

- **数据建模-实体-资质证书**：[分包商管理-实体-资质证书（QualificationCertificate）](specs/001-bootdo-management-system/plan/data-model/entity-QualificationCertificate.md)

### 依赖的外部能力

无