# 工作流引擎-重新分配任务节点（reassignTaskNode）

- **生成时间**：2026-03-25

## 重新分配任务节点（reassignTaskNode）

### 功能概述

重新分配任务节点功能允许管理员或具有相应权限的用户将工作流中的任务节点从当前分配的用户重新分配给其他用户。该功能在处理人员变动、任务积压或需要专业技能处理特定任务时尤为重要。通过此功能，系统能够灵活调整任务分配，确保业务流程的高效执行和及时完成。重新分配操作会更新任务节点的分配用户ID，并记录操作日志，同时向新的分配用户发送通知，确保任务交接的透明性和可追溯性。

### 功能要点

- **任务重新分配管理**：系统支持管理员或具有相应权限的用户将工作流中的任务节点从当前分配的用户重新分配给其他用户。该功能适用于处理人员变动、任务积压或需要专业技能处理特定任务的场景。重新分配操作会验证目标用户的有效性，确保新分配的用户存在于系统中且状态正常。操作完成后，系统会自动更新任务节点的分配用户ID，并记录完整的操作日志，包括操作人、原分配用户、新分配用户、操作时间等关键信息，确保任务交接过程的透明性和可追溯性。

### 逻辑签名

```naturalts path="app.logics.reassignTaskNode.ts"
$Logic({
    description: '重新分配任务节点',
    directory: 'workflow_engine(工作流引擎)',
    transactional: true
})
export declare function reassignTaskNode(taskId: Integer, newAssigneeId: Integer, reassignReason: String): app.dataSources.defaultDS.entities.TaskNode;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| taskId | 任务ID | Integer | 需要重新分配的任务节点ID |
| newAssigneeId | 新分配用户ID | Integer | 任务重新分配的目标用户ID |
| reassignReason | 重新分配原因 | String | 任务重新分配的原因说明 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 更新后的任务节点 | app.dataSources.defaultDS.entities.TaskNode | 重新分配后更新的任务节点实体 |

### 被前端调用

- **任务管理（taskManagement）**：在任务管理页面中，管理员可以选中特定的任务节点，通过重新分配功能将其分配给其他用户处理。该功能用于处理人员变动或任务积压情况，确保任务能够及时得到处理。
- **流程实例管理（processInstanceManagement）**：在流程实例管理页面中，管理员可以查看流程实例的详细信息，包括其中的任务节点。对于需要重新分配的任务节点，管理员可以直接在此页面执行重新分配操作，提高管理效率。

### 依赖的枚举、实体

- **工作流引擎-实体-任务节点**：[工作流引擎-实体-任务节点（TaskNode）](specs/001-bootdo-management-system/plan/data-model/entity-TaskNode.md)
- **系统管理-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无外部能力依赖