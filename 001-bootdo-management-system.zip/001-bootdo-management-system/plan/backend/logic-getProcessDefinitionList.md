# 工作流引擎-获取流程定义列表（getProcessDefinitionList）

- **生成时间**：2026-03-25

## 获取流程定义列表（getProcessDefinitionList）

### 功能概述

获取流程定义列表服务端逻辑提供工作流引擎中所有已定义流程模型的查询功能，支持分页、排序和条件筛选。该逻辑从数据存储中检索流程定义实体数据，返回包含流程基本信息（如ID、名称、描述、创建时间、更新时间等）的集合，供前端流程定义管理页面展示使用。作为工作流管理的基础查询接口，该逻辑确保系统管理员能够高效地浏览和管理所有可用的业务流程模板，为后续的流程编辑、删除或实例化操作提供数据支撑。

### 功能要点

- **分页查询支持**：该服务端逻辑实现标准的分页查询机制，支持前端传递页码（page）和每页大小（size）参数，后端根据这些参数计算数据查询的偏移量和限制数量，避免一次性加载过多数据导致性能问题。默认情况下，如果没有指定分页参数，系统将返回第一页数据，每页包含20条记录，确保在大数据量场景下仍能保持良好的响应性能。

- **条件筛选功能**：服务端逻辑支持基于流程名称的模糊搜索功能，允许用户通过关键词快速定位特定的流程定义。当前端传递搜索关键词（searchKeyword）时，后端会在数据查询中添加相应的过滤条件，对流程名称字段进行模式匹配，返回符合条件的流程定义集合，提升用户在大量流程模型中的查找效率。

- **排序控制机制**：该逻辑支持按任意字段（sort）进行升序或降序（order）排序，满足不同场景下的展示需求。默认情况下，流程集合按照创建时间降序排列，确保最新创建的流程定义显示在集合顶部。用户也可以通过前端界面选择其他排序方式，后端会根据传递的排序参数动态调整数据查询的排序规则，返回按指定规则排序的结果集。

### 逻辑签名

```naturalts path="app.logics.getProcessDefinitionList.ts"
$Logic({
    description: '获取流程定义列表',
    directory: 'workflow_engine(工作流引擎)'
})
export declare function getProcessDefinitionList(page: Integer, size: Integer, sort: String, order: String, searchKeyword: String): { list: List<app.dataSources.defaultDS.entities.ProcessDefinition>, total: Integer };
```

### 被前端调用

- **流程定义（processDefinition）**：流程定义管理页面调用此服务端逻辑来获取工作流模型列表数据，用于在表格中展示所有已定义的流程模型，支持分页、搜索和排序功能，为用户提供完整的流程定义浏览体验。

### 依赖的枚举、实体

- **数据建模-实体-流程定义**：[工作流引擎-实体-流程定义（ProcessDefinition）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessDefinition.md)

### 依赖的外部能力

（无）