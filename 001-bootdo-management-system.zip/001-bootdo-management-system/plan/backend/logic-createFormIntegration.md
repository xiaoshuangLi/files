# 工作流引擎-创建表单集成（createFormIntegration）

- **生成时间**：2026-03-25

## 创建表单集成（createFormIntegration）

### 功能概述

创建表单集成服务端逻辑负责在工作流引擎中创建新的表单集成记录，将业务表单数据与特定的流程实例进行关联。该逻辑接收包含流程实例ID和表单数据内容的输入参数，验证数据的完整性和有效性后，在数据库中持久化存储表单集成记录，并返回创建成功的完整实体信息。此逻辑确保了业务数据能够正确地与工作流流程实例绑定，为后续的流程执行和数据处理提供基础支持。

### 功能要点

- **表单数据持久化**：将传入的JSON格式表单数据内容与流程实例ID一起存储到数据库中，创建完整的表单集成记录。该功能确保业务表单数据能够在工作流执行过程中被正确捕获和保存，支持各种业务场景（如预算审批、薪资调整、质量整改等）的表单数据管理需求，同时保证数据的完整性和一致性。

### 逻辑签名

```naturalts path="app.logics.createFormIntegration.ts"
$Logic({
    description: '创建工作流表单集成记录',
    directory: 'workflow_engine(工作流引擎)',
    transactional: true
})
export declare function createFormIntegration(formIntegration: app.dataSources.defaultDS.entities.FormIntegration): app.dataSources.defaultDS.entities.FormIntegration;
```

### 被前端调用

- **通用业务模块-表单集成（formIntegration）**：在表单集成页面中，用户通过表单弹框创建新的表单集成记录时，调用此服务端逻辑来保存表单数据和关联的流程实例信息。

### 依赖的枚举、实体

- **工作流引擎-实体-表单集成**：[工作流引擎-实体-表单集成（FormIntegration）](specs/001-bootdo-management-system/plan/data-model/entity-FormIntegration.md)
- **工作流引擎-实体-流程实例**：[工作流引擎-实体-流程实例（ProcessInstance）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessInstance.md)

### 依赖的外部能力

无外部能力依赖