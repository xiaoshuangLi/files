# 质量管理-删除整改任务（deleteRectificationTask）

- **生成时间**：2026-03-25

## 删除整改任务（deleteRectificationTask）

### 功能概述

该服务端逻辑提供删除整改任务的功能，允许授权用户从系统中移除不再需要或错误创建的整改任务记录。删除操作会同时清理与该整改任务相关的所有关联数据，包括任务分配记录、进度跟踪信息、相关附件和评论等，确保数据一致性。系统会在执行删除前进行权限验证，确保只有具备相应权限的用户才能执行此操作，并记录完整的操作日志用于审计追踪。

### 功能要点

- **安全删除机制**：删除整改任务时，系统会先验证当前用户是否具有删除该任务的权限，通常只有任务创建者、质量管理员或系统管理员可以执行删除操作。删除前会检查任务状态，对于已完成或正在进行中的任务可能需要额外的审批流程或禁止删除，以防止误操作导致重要数据丢失。系统会提供软删除和硬删除两种模式，软删除会保留数据但标记为已删除状态，硬删除则彻底从数据库中移除记录。

### 逻辑签名

```naturalts path="app.logics.deleteRectificationTask.ts"
$Logic({
    description: '删除整改任务',
    directory: 'quality_management(质量管理)'
})
export declare function deleteRectificationTask(taskId: String, operatorId: String, deletionType: String): { success: Boolean, messageContent: String, deletedAt: DateTime };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| taskId | 整改任务ID | String | 要删除的整改任务的唯一标识符 |
| operatorId | 操作人ID | String | 执行删除操作的用户ID |
| deletionType | 删除类型 | String | 删除类型，可选值为'soft'(软删除)或'hard'(硬删除) |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| success | 操作结果 | Boolean | 删除操作是否成功 |
| messageContent | 消息内容 | String | 操作结果的消息描述 |
| deletedAt | 删除时间 | DateTime | 任务被删除的时间戳 |

### 被前端调用

- **问题跟踪（issueTracking）**：在问题跟踪页面中，用户可以通过操作菜单选择删除特定的整改任务，系统会调用此服务端逻辑来执行删除操作，并在删除成功后刷新页面显示最新的任务列表。

### 依赖的枚举、实体

- **数据建模-实体-整改任务**：[质量管理-实体-整改任务（RectificationTask）](specs/001-bootdo-management-system/plan/data-model/entity-RectificationTask.md)
- **数据建模-实体-质量问题**：[质量管理-实体-质量问题（QualityIssue）](specs/001-bootdo-management-system/plan/data-model/entity-QualityIssue.md)