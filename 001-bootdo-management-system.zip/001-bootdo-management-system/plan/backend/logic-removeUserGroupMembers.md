# 系统管理-移除用户组成员（removeUserGroupMembers）

- **生成时间**：2026-03-25

## 移除用户组成员（removeUserGroupMembers）

### 功能概述

移除用户组成员服务端逻辑用于从指定的用户组中移除一个或多个系统账户成员。该功能是用户和组管理模块的核心操作之一，支持工作流引擎中的团队协作和权限管理。通过此逻辑，系统管理员可以灵活调整用户组的成员构成，确保任务分配和权限控制的准确性。该逻辑会验证用户组的存在性和激活状态，同时验证待移除成员是否确实属于该用户组，并在操作完成后更新相关的审计信息，保证操作的可追溯性。

### 功能要点

- **批量移除成员功能**：支持一次性从用户组中移除多个系统账户成员，提高管理效率。系统会验证每个待移除成员是否确实属于指定的用户组，避免无效操作，并在移除过程中保持数据一致性，确保不会出现部分成功部分失败的情况。
- **权限与状态验证**：在执行移除操作前，系统会严格验证用户组的存在性和激活状态，只有激活状态的用户组才能进行成员管理操作。同时验证当前操作用户是否具有管理该用户组的权限，防止未授权操作导致的安全风险。
- **审计日志记录**：每次移除操作都会自动记录详细的审计日志，包括操作时间、操作人、被移除的成员列表等信息，便于后续追踪和问题排查。这些日志对于系统安全审计和合规性检查具有重要意义。

### 逻辑签名

```naturalts path="app.logics.removeUserGroupMembers.ts"
$Logic({
    description: '从指定用户组中移除成员',
    directory: 'system_management(系统管理)'
})
export declare function removeUserGroupMembers(groupId: Integer, memberIds: List<Integer>): { 
    success: Boolean; 
    message: String; 
};
```

### 被前端调用

- **用户和组管理（userGroupManagement）**：在用户组详情页面，管理员可以通过成员列表中的"移除"按钮调用此服务端逻辑，将选中的用户从当前用户组中移除。该操作会弹出确认对话框，确认后执行移除操作并刷新成员列表。

### 依赖的枚举、实体

- **数据建模-实体-用户组**：[系统管理-实体-用户组（UserGroup）](specs/001-bootdo-management-system/plan/data-model/entity-UserGroup.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无外部能力依赖