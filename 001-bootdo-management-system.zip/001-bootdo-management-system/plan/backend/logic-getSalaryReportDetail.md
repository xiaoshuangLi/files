# 薪资管理-获取薪资报表详情（getSalaryReportDetail）

- **生成时间**：2026-03-25

## 获取薪资报表详情（getSalaryReportDetail）

### 功能概述

该服务端逻辑用于获取指定员工的详细薪资报表信息，包括薪资结构组成、月工资额、年薪总额、税务计算明细以及历史发放记录等完整数据。系统会根据用户权限范围返回相应的薪资数据，确保数据安全性和隐私保护。报表详情包含基本工资、绩效奖金、津贴补贴、社保公积金扣款、个人所得税等各项明细，并支持按月份、季度或年度查询特定时间段的薪资数据。

### 功能要点

- **薪资数据查询与权限控制**：根据当前登录用户的权限级别（系统管理员、部门管理员或普通用户）控制可查询的薪资数据范围。系统管理员可以查看全公司所有员工的薪资详情，部门管理员只能查看本部门员工的薪资信息，普通用户仅能查看自己的薪资报表。查询时需要验证用户身份和权限，确保敏感薪资数据不会被越权访问，同时支持按员工ID、时间范围等多种条件进行精确查询。

### 逻辑签名

```naturalts path="app.logics.getSalaryReportDetail.ts"
$Logic({
    description: '获取薪资报表详情',
    directory: 'salary_management(薪资管理)'
})
export declare function getSalaryReportDetail(employeeId: String, startTime: DateTime, endTime: DateTime, reportType: app.enums.SalaryReportType): { 
  reportId: String,
  employeeInfo: app.dataSources.defaultDS.entities.EmployeeBasicInfo,
  salaryStructure: List<app.dataSources.defaultDS.entities.SalaryStructureDetail>,
  monthlyAmount: Decimal,
  annualTotal: Decimal,
  taxDetails: app.dataSources.defaultDS.entities.TaxCalculationDetail,
  paymentRecords: List<app.dataSources.defaultDS.entities.PaymentRecord>,
  generationTime: DateTime
};
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| employeeId | 员工ID | String | 查询指定员工的薪资报表详情 |
| startTime | 开始时间 | DateTime | 查询时间范围的开始时间 |
| endTime | 结束时间 | DateTime | 查询时间范围的结束时间 |
| reportType | 报表类型 | app.enums.SalaryReportType | 薪资报表类型（月度、季度、年度） |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| reportId | 报表ID | String | 薪资报表的唯一标识 |
| employeeInfo | 员工信息 | app.dataSources.defaultDS.entities.EmployeeBasicInfo | 员工基本信息 |
| salaryStructure | 薪资结构 | List<app.dataSources.defaultDS.entities.SalaryStructureDetail> | 薪资结构明细列表 |
| monthlyAmount | 月工资额 | Decimal | 月度工资计算金额 |
| annualTotal | 年薪总额 | Decimal | 年度薪酬总额计算 |
| taxDetails | 税务详情 | app.dataSources.defaultDS.entities.TaxCalculationDetail | 个人所得税计算详情 |
| paymentRecords | 发放记录 | List<app.dataSources.defaultDS.entities.PaymentRecord> | 薪资发放历史记录列表 |
| generationTime | 生成时间 | DateTime | 报表生成时间 |

### 被前端调用

- **薪资报表（salaryReport）**：在薪资报表页面中，用户可以通过选择员工和时间范围来调用此服务端逻辑，获取详细的薪资报表数据用于展示和分析。页面会根据返回的薪资结构明细渲染表格，显示各项收入和扣款的具体金额，并提供报表导出功能。

### 依赖的枚举、实体

- **数据建模-枚举-薪资报表类型**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-员工基本信息**：[系统管理-实体-员工基本信息（EmployeeBasicInfo）](specs/001-bootdo-management-system/plan/data-model/entity-EmployeeBasicInfo.md)
- **数据建模-实体-薪资结构详情**：[薪资管理-实体-薪资结构详情（SalaryStructureDetail）](specs/001-bootdo-management-system/plan/data-model/entity-SalaryStructureDetail.md)
- **数据建模-实体-税务计算详情**：[薪资管理-实体-税务计算详情（TaxCalculationDetail）](specs/001-bootdo-management-system/plan/data-model/entity-TaxCalculationDetail.md)
- **数据建模-实体-发放记录**：[薪资管理-实体-发放记录（PaymentRecord）](specs/001-bootdo-management-system/plan/data-model/entity-PaymentRecord.md)

### 依赖的外部能力

[文件内部已经提供，无需进行生成。如果文件内部已经有 `依赖的外部能力` 内容，禁止修改或删除文件内的 `依赖的外部能力` 内容]