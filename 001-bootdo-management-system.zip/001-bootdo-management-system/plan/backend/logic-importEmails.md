# 通用领域服务-导入邮件（importEmails）

- **生成时间**：2026-03-25

## 导入邮件（importEmails）

### 功能概述

导入邮件功能允许系统管理员或具有相应权限的用户从外部邮件服务器或本地邮件文件批量导入邮件数据到系统中。该功能支持多种邮件格式（如EML、MSG等）的解析和导入，能够保留邮件的原始元数据（包括发件人、收件人、主题、正文、附件、时间戳等），并将导入的邮件与系统中的用户账户进行关联。导入过程中会进行数据验证和重复检测，确保数据的完整性和一致性，同时支持导入进度监控和错误日志记录，便于用户了解导入状态并处理异常情况。

### 功能要点

- **邮件格式兼容性**：系统支持多种主流邮件格式的导入，包括EML（RFC 822标准格式）、MSG（Microsoft Outlook格式）以及其他常见的邮件存档格式。导入功能能够自动识别邮件文件格式并调用相应的解析器进行处理，确保不同来源的邮件数据都能被正确解析和导入。对于不支持的格式，系统会提供明确的错误提示，并建议用户转换为支持的格式后再尝试导入。

### 逻辑签名

```naturalts path="app.logics.importEmails.ts"
$Logic({
    description: '导入邮件',
    directory: 'email_integration(邮件集成)'
})
export declare function importEmails(emailFiles: List<app.dataSources.defaultDS.entities.AttachmentResource>, targetUserId: TextType, overwriteDuplicates: Boolean, importOptions: { includeAttachments: Boolean, preserveOriginalTimestamps: Boolean, categoryTags: List<TextType> }): { successCount: Integer, failureCount: Integer, skippedCount: Integer, taskId: TextType, errors: List<{ fileName: TextType, errorCode: TextType, errorMessage: TextType }> };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| emailFiles | 邮件文件列表 | List&lt;app.dataSources.defaultDS.entities.AttachmentResource&gt; | 邮件文件列表，支持EML、MSG等格式 |
| targetUserId | 目标用户ID | TextType | 指定邮件导入到哪个用户账户 |
| overwriteDuplicates | 覆盖重复邮件 | Boolean | 是否覆盖已存在的重复邮件 |
| importOptions | 导入配置选项 | { includeAttachments: Boolean, preserveOriginalTimestamps: Boolean, categoryTags: List&lt;TextType&gt; } | 导入配置选项，包含是否导入附件、是否保留原始时间戳、邮件分类标签等 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| successCount | 成功数量 | Integer | 导入成功的邮件数量 |
| failureCount | 失败数量 | Integer | 导入失败的邮件数量 |
| skippedCount | 跳过数量 | Integer | 跳过的重复邮件数量 |
| taskId | 任务ID | TextType | 导入任务ID，用于查询导入进度 |
| errors | 错误详情 | List&lt;{ fileName: TextType, errorCode: TextType, errorMessage: TextType }&gt; | 错误详情列表，包含文件名、错误代码和错误描述 |

### 被前端调用

- **邮件集成（emailCommunication）**：在邮件管理界面中，用户可以通过"导入邮件"按钮触发此服务端逻辑，选择本地邮件文件或配置外部邮件服务器连接信息，将历史邮件数据批量导入到系统中，实现邮件数据的迁移和整合。

### 依赖的枚举、实体

- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)
- **数据建模-实体-附件资源**：[内容管理-实体-附件资源（AttachmentResource）](specs/001-bootdo-management-system/plan/data-model/entity-AttachmentResource.md)