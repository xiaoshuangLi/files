# 通用领域服务-删除回收站记录（deleteRecyclingRecord）

- **生成时间**：2026-03-25

## 删除回收站记录（deleteRecyclingRecord）

### 功能概述

该服务端逻辑用于永久删除系统回收站中的指定记录，支持单条或批量删除操作。用户在回收站页面选择一个或多个已删除的项目后，可通过此接口彻底清除这些数据，释放系统存储空间。操作完成后，被删除的记录将无法恢复，系统会返回操作结果状态，包括成功删除的记录数量和可能的错误信息。此功能仅对具有相应权限的用户开放，确保数据安全。

### 功能要点

- **永久删除机制**：该功能提供永久删除回收站中记录的能力，与普通删除操作不同，此操作会直接从数据库中移除数据，而非仅标记为已删除状态。系统会验证用户权限，确保只有授权用户才能执行此敏感操作。删除过程包含事务处理，保证数据一致性，即使在批量删除场景下也能确保部分成功时的回滚机制，避免数据不一致问题。

### 逻辑签名

```naturalts path="app.logics.deleteRecyclingRecord.ts"
$Logic({
    description: '永久删除回收站中的指定记录',
    directory: 'recycling_management(回收管理)',
    transactional: true
})
export declare function deleteRecyclingRecord(recordIds: List<String>, operatorId: String): { successCount: Integer, failedCount: Integer, errorMessages: List<String> };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| recordIds | 记录ID列表 | List<String> | 要删除的回收站记录ID列表 |
| operatorId | 操作人ID | String | 执行删除操作的用户ID |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| successCount | 成功删除数量 | Integer | 成功删除的记录数量 |
| failedCount | 删除失败数量 | Integer | 删除失败的记录数量 |
| errorMessages | 错误信息列表 | List<String> | 删除过程中产生的错误信息列表 |

### 被前端调用

- **通用业务模块-回收记录（recyclingRecord）**：在回收记录页面中，用户可以选择一个或多个已删除的项目，然后点击"永久删除"按钮调用此服务端逻辑，实现彻底清除选中记录的功能，释放系统存储空间。

### 依赖的枚举、实体

- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)
- **数据建模-实体-操作记录**：[系统管理-实体-操作记录（OperationRecord）](specs/001-bootdo-management-system/plan/data-model/entity-OperationRecord.md)

### 依赖的外部能力

无