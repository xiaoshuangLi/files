# 系统管理-搜索操作日志（searchOperationLogs）

- **生成时间**：2026-03-25

## 搜索操作日志（searchOperationLogs）

### 功能概述

搜索操作日志功能为系统管理员和安全审计人员提供全面的操作行为追踪能力。该功能允许用户根据多种条件筛选和查询系统中的操作记录，包括操作时间范围、操作用户、操作类型、操作结果等维度。通过此功能，可以有效监控系统使用情况，识别异常操作行为，满足合规性审计要求，并为问题排查提供数据支持。操作日志记录了用户在系统中的关键操作行为，是保障系统安全性和可追溯性的重要组成部分。

### 功能要点

- **多维度条件搜索**：支持按操作时间范围（开始时间和结束时间）、操作用户（用户名或用户ID）、操作类型（如登录、数据修改、权限变更等）、操作结果（成功或失败）等多个维度进行组合条件搜索。用户可以根据实际需求灵活设置搜索条件，精确获取所需的操作日志记录，提高审计和监控效率。

### 逻辑签名

```naturalts path="app.logics.searchOperationLogs.ts"
$Logic({
    description: '搜索操作日志',
    directory: 'system_management(系统管理)'
})
export declare function searchOperationLogs(page: Integer, size: Integer, startTime?: DateTime, endTime?: DateTime, userId?: String, operationType?: String, operationResult?: String): { list: List<app.dataSources.defaultDS.entities.OperationRecord>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 当前页码，从1开始 |
| size | 每页条数 | Integer | 每页显示的操作日志数量 |
| startTime | 开始时间 | DateTime? | 操作开始时间，可选 |
| endTime | 结束时间 | DateTime? | 操作结束时间，可选 |
| userId | 用户ID | String? | 执行操作的用户ID，可选 |
| operationType | 操作类型 | String? | 操作类型，如登录、数据修改等，可选 |
| operationResult | 操作结果 | String? | 操作结果，如SUCCESS或FAILURE，可选 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 操作日志列表 | List<app.dataSources.defaultDS.entities.OperationRecord> | 符合条件的操作日志记录列表 |
| total | 总条数 | Integer | 符合条件的操作日志总数量 |

### 被前端调用

- **日志管理（logManagement）**：在日志管理页面中，用户可以通过搜索操作日志功能查询系统中的操作记录，查看详细的操作信息，包括操作人、操作时间、操作类型、操作结果等，用于系统审计和安全监控。

### 依赖的枚举、实体

- **数据建模-实体-操作记录**：[系统管理-实体-操作记录（OperationRecord）](specs/001-bootdo-management-system/plan/data-model/entity-OperationRecord.md)

### 依赖的外部能力

[文件内部已经提供，无需进行生成。如果文件内部已经有 `依赖的外部能力` 内容，禁止修改或删除文件内的 `依赖的外部能力` 内容]