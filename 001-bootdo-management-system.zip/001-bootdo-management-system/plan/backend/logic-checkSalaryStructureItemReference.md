# 薪资管理-检查薪资结构项引用（checkSalaryStructureItemReference）

- **生成时间**：2026-03-25

## 检查薪资结构项引用（checkSalaryStructureItemReference）

### 功能概述

检查薪资结构项引用功能用于验证指定的薪资结构项是否已被其他业务模块或功能所引用。该服务端逻辑在用户尝试删除薪资结构项时被调用，通过查询系统中是否存在对该薪资结构项的依赖关系，来判断是否允许执行删除操作。如果薪资结构项已被引用（例如在薪资计算规则、薪酬档级配置或历史薪资记录中使用），则返回引用状态为true，阻止删除操作；如果未被引用，则返回引用状态为false，允许安全删除。此功能确保了薪资数据的完整性和一致性，防止因误删关键薪资结构项而导致薪资计算错误或系统异常。

### 功能要点

- **引用关系检查**：当系统接收到检查薪资结构项引用的请求时，服务端逻辑会查询所有可能引用该薪资结构项的业务模块和数据表。这包括但不限于薪资调整审批流程中的薪资结构引用、薪酬档级配置中的薪资组成部分关联、月度工资计算历史记录中的薪资结构快照等。逻辑会遍历这些关联数据，检查是否存在与目标薪资结构项ID匹配的记录。如果发现任何引用记录，立即返回引用状态为true；如果遍历完所有可能的引用点都没有发现匹配记录，则返回引用状态为false。此检查过程确保了引用检测的全面性和准确性，避免遗漏潜在的依赖关系。

### 逻辑签名

```naturalts path="app.logics.checkSalaryStructureItemReference.ts"
$Logic({
    description: '检查薪资结构项是否被引用',
    directory: 'salary_management(薪资管理)'
})
export declare function checkSalaryStructureItemReference(salaryStructureId: Integer): Boolean;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| salaryStructureId | 薪资结构项ID | Integer | 需要检查引用状态的薪资结构项唯一标识 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 引用状态 | Boolean | 返回true表示薪资结构项已被引用，false表示未被引用 |

### 被前端调用

- **薪资结构定义（salaryStructure）**：在薪资结构定义页面，当用户尝试删除某个薪资结构项时，前端会调用此服务端逻辑来检查该薪资结构项是否已被其他业务功能引用。根据返回结果，如果已被引用（返回true），系统将显示"该薪资结构项已被引用，无法删除"的提示信息；如果未被引用（返回false），则允许执行删除操作。

### 依赖的枚举、实体

- **数据建模-实体-薪资结构**：[薪资管理-实体-薪资结构（SalaryStructure）](specs/001-bootdo-management-system/plan/data-model/entity-SalaryStructure.md)
- **数据建模-实体-人员配置**：[分包商管理-实体-人员配置（PersonnelConfiguration）](specs/001-bootdo-management-system/plan/data-model/entity-PersonnelConfiguration.md)

### 依赖的外部能力

无外部能力依赖