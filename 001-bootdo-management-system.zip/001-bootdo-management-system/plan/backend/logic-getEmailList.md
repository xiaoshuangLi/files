# 办公自动化-获取邮件列表（getEmailList）

- **生成时间**：2026-03-25

## 获取邮件列表（getEmailList）

### 功能概述

获取邮件列表服务端逻辑负责从系统中检索并返回用户的邮件列表数据。该功能支持按不同条件筛选邮件，包括邮件类型（收件箱、发件箱、草稿箱、垃圾箱等）、搜索关键词、收件人ID等参数。系统会根据当前用户的身份权限，只返回该用户有权访问的邮件数据，并包含每封邮件的基本信息如发件人、收件人、主题、发送时间、阅读状态、重要标记等。此服务为前端邮件集成页面提供数据支持，确保用户能够高效地浏览和管理自己的邮件。

### 功能要点

- **邮件列表分页查询**：支持分页加载邮件列表，避免一次性加载过多数据导致性能问题。系统默认按发送时间倒序排列，最新的邮件显示在最前面。每次请求可指定页码和每页数量，提高用户体验和系统响应速度。
- **多维度邮件筛选**：支持按邮件类型（收件箱、发件箱、草稿箱、垃圾箱、星标邮件等）、搜索关键词（匹配发件人、收件人、主题、内容）、特定收件人ID等多种条件进行筛选。用户可以根据实际需求灵活组合筛选条件，快速定位目标邮件。
- **权限控制与数据隔离**：严格遵循系统权限控制机制，确保用户只能查看自己有权访问的邮件。普通用户只能查看自己的邮件，部门管理员可以查看本部门用户的邮件，系统管理员可以查看所有邮件。系统会自动过滤无权访问的数据，保障数据安全。
- **邮件状态实时更新**：返回的邮件列表包含每封邮件的最新状态信息，如已读/未读状态、重要标记、附件存在标识等。系统会在用户操作邮件后实时更新这些状态，并在下次查询时返回最新状态，确保前端展示的数据准确性。

### 逻辑签名

```naturalts path="app.logics.getEmailList.ts"
$Logic({
    description: '获取邮件列表',
    directory: 'office_automation(办公自动化)'
})
export declare function getEmailList(
    mailType?: String,
    searchKeyword?: String,
    recipientId?: Integer,
    page?: Integer,
    pageSize?: Integer
): { list: Array<{ emailId: Integer, senderId: Integer, senderName: String, recipientId: Integer, recipientName: String, subject: String, sendTime: DateTime, isRead: Boolean, isImportant: Boolean, hasAttachment: Boolean, mailType: String }>, total: Integer };
```

### 被前端调用

- **邮件集成（emailCommunication）**：邮件集成页面通过调用获取邮件列表服务端逻辑，实现邮件列表的展示和管理功能。用户在页面上选择不同的邮件类型（如收件箱、发件箱等）、输入搜索关键词或指定特定收件人时，前端会向该服务端逻辑发送请求，获取符合条件的邮件列表数据，并在页面上渲染展示。同时，该逻辑还支持分页加载，确保大量邮件数据的高效处理。

### 依赖的枚举、实体

- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)
- **数据建模-实体-邮件**：[办公自动化-实体-邮件（Email）](specs/001-bootdo-management-system/plan/data-model/entity-Email.md)

### 依赖的外部能力