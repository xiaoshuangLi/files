# 预算管理-获取报表格式列表（getReportFormatList）

- **生成时间**：2026-03-25

## 获取报表格式列表（getReportFormatList）

### 功能概述

获取报表格式列表服务端逻辑用于查询系统中所有可用的预算分析报告模板格式，支持分页、排序和条件筛选功能。该逻辑根据前端传递的查询参数（如格式名称模糊匹配、创建时间范围等）从数据库中检索符合条件的报表格式记录，并以标准化的数据结构返回给前端页面进行展示。此功能为预算管理人员提供了灵活的报表格式浏览和选择能力，确保用户能够快速找到所需的预算分析报告模板，提高预算数据展示和分析的工作效率。

### 功能要点

- **分页查询功能**：支持标准的分页查询机制，包含页码（page）和每页数量（pageSize）参数，避免一次性加载过多数据导致性能问题。默认每页显示10条记录，最大支持每页100条记录，确保在大数据量场景下仍能保持良好的响应性能。
- **条件筛选功能**：支持基于报表格式名称的模糊匹配查询，用户可以通过输入部分格式名称快速定位相关报表模板。同时支持按创建时间范围进行筛选，便于用户查找特定时间段内创建的报表格式。
- **排序功能**：默认按创建时间倒序排列（最新创建的在前），确保用户能够优先看到最近使用的报表格式。系统还支持按格式名称进行字母序排序，满足不同用户的浏览习惯。
- **数据权限控制**：根据当前登录用户的角色权限，自动过滤可访问的报表格式数据。普通用户只能查看自己创建的报表格式，部门管理员可以查看本部门所有用户的报表格式，系统管理员可以查看系统中所有的报表格式。

### 逻辑签名

```naturalts path="app.logics.getReportFormatList.ts"
$Logic({
    description: '获取报表格式列表',
    directory: 'budget_management(预算管理)'
})
export declare function getReportFormatList(page: Integer, size: Integer, sort?: String, order?: String, formatName?: String, createdTimeStart?: DateTime, createdTimeEnd?: DateTime): { list: List<app.dataSources.defaultDS.entities.ReportFormat>, total: Integer };
```

### 被前端调用

- **通用业务模块-报表格式（reportFormat）**：报表格式管理页面通过调用此服务端逻辑获取报表格式列表数据，用于在页面上展示所有可用的报表模板。用户可以在列表中浏览、搜索和选择不同的报表格式，为后续的预算分析报告生成提供模板基础。

### 依赖的枚举、实体

- **数据建模-实体-报表格式**：[预算管理-实体-报表格式（ReportFormat）](specs/001-bootdo-management-system/plan/data-model/entity-ReportFormat.md)

### 依赖的外部能力

无