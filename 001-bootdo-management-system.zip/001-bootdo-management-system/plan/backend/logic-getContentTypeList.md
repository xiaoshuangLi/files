# 内容管理-获取内容类型列表（getContentTypeList）

- **生成时间**：2026-03-25

## 获取内容类型列表（getContentTypeList）

### 功能概述

获取内容类型列表服务端逻辑为内容管理系统提供标准化的内容类型分类数据。该逻辑负责从系统预定义的内容类型配置中检索所有可用的内容类型选项，供前端在创建、编辑或筛选内容时进行选择和分类。内容类型作为内容管理系统的核心元数据，用于区分不同类型的内容资源，如文章、公告、新闻、技术文档、产品介绍、行业动态、政策解读等，帮助用户实现精细化的内容组织和管理。通过统一的内容类型管理机制，系统能够确保内容分类的一致性和规范性，支持基于内容类型的高级查询、统计分析和权限控制功能，为用户提供更加灵活和高效的内容管理体验。

### 功能要点

- **内容类型数据加载**：当用户在内容管理相关页面访问创建或编辑内容表单时，系统调用此逻辑获取所有可用的内容类型选项，以填充内容类型下拉选择框或分类组件。该功能确保用户能够从预定义的内容类型列表中选择合适的内容类型，保证数据的一致性和规范性。内容类型作为内容分类的重要维度，直接影响后续的内容展示、搜索、统计和权限控制功能，因此必须确保选项数据的完整性和准确性。该逻辑通过统一的数据接口，为前端提供标准化的内容类型选择数据，避免了硬编码和数据不一致的问题，同时支持动态扩展新的内容类型。

### 逻辑签名

```naturalts path="app.logics.getContentTypeList.ts"
$Logic({
    description: '获取内容类型列表',
    directory: 'content_management(内容管理)'
})
export declare function getContentTypeList(): List<{ id: Integer, name: String, code: String, description: String }>;
```

### 被前端调用

- **文章管理（articleManagement）**：在文章管理页面的创建和编辑文章表单中，系统调用此逻辑获取内容类型下拉选择框的选项数据，确保用户能够选择正确的内容类型进行文章分类。
- **栏目结构（columnStructure）**：在栏目结构管理页面中，系统调用此逻辑获取内容类型选项，用于配置特定栏目允许发布的内容类型，实现栏目与内容类型的关联管理。

### 依赖的枚举、实体

- **数据建模-实体-栏目结构**：[内容管理-实体-栏目结构（ColumnStructure）](specs/001-bootdo-management-system/plan/data-model/entity-ColumnStructure.md)
- **数据建模-实体-文章内容**：[内容管理-实体-文章内容（ArticleContent）](specs/001-bootdo-management-system/plan/data-model/entity-ArticleContent.md)

### 依赖的外部能力

无匹配内容