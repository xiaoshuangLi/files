# 通用领域服务-设置日程提醒（setScheduleReminder）

- **生成时间**：2026-03-25

## 设置日程提醒（setScheduleReminder）

### 功能概述

设置日程提醒功能允许用户为其日程安排创建、修改或删除提醒通知。该功能支持多种提醒方式（如系统通知、邮件提醒等），可设置提醒时间（提前5分钟、15分钟、30分钟、1小时、1天等），并能针对重复性日程设置相应的提醒规则。用户可以在创建日程时同时设置提醒，也可以在已有日程上添加或修改提醒设置。

### 功能要点

- **灵活的提醒时间配置**：系统提供多种预设的提醒时间选项，包括提前5分钟、15分钟、30分钟、1小时、1天等，同时也支持用户自定义具体的提醒时间点。对于重复性日程，提醒设置可以应用于所有实例或仅当前实例，确保用户能够根据实际需求精确控制提醒行为。用户可以选择不同的提醒方式，如系统通知、邮件提醒等，并能针对不同类型的日程设置不同的提醒策略。系统会根据用户的时区自动调整提醒时间，确保在全球范围内都能准时收到提醒。此外，用户还可以随时修改或取消已设置的提醒，系统会立即更新相关配置并同步到所有设备，提高日程管理的效率和准确性。

### 逻辑签名

```naturalts path="app.logics.setScheduleReminder.ts"
$Logic({
    description: '设置日程提醒',
    directory: 'schedule_management(日程管理)'
})
export declare function setScheduleReminder(scheduleId: String, reminderType: ReminderType, advanceTime: Integer, isCustomTime?: Boolean, customDateTime?: String, applyToAllInstances?: Boolean): { success: Boolean, reminderId?: String, infoMsg?: String };
```

### 被前端调用

- **个人门户（personalWorkspace）**：用户在个人门户的日程管理模块中，可以通过日程详情页面设置或修改日程提醒，系统会调用此服务端逻辑来保存用户的提醒偏好设置。
- **日程管理（scheduleManagement）**：在专门的日程管理功能页面中，用户创建或编辑日程时可以直接配置提醒选项，通过调用此服务端逻辑实现提醒功能的设置和更新。

### 依赖的枚举、实体

- **数据建模-枚举-提醒类型**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-日程管理**：[办公自动化-实体-日程管理（ScheduleManagement）](specs/001-bootdo-management-system/plan/data-model/entity-ScheduleManagement.md)

### 依赖的外部能力

#### 邮件服务（EmailService） 【当前业务功能相关】

- 关联文档：[邮件服务（EmailService）](specs/001-bootdo-management-system/plan/integration/retrieval-EmailService.md)