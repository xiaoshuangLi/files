# 分包商管理-查询分包商合同列表（querySubcontractorContracts）

- **生成时间**：2026-03-25

## 查询分包商合同列表（querySubcontractorContracts）

### 功能概述

查询分包商合同列表服务端逻辑提供对分包商合同数据的全面查询能力，支持企业对分包商签订的各类合同进行高效检索和筛选。该逻辑实现了基于多种条件的合同查询功能，包括按分包商ID、合同编号、合同状态、签署日期范围、合同价值区间等维度进行精确或模糊查询。通过该服务，前端页面能够获取符合条件的合同列表数据，支持分页显示和排序功能，确保用户能够快速定位所需的合同信息。同时，该逻辑还支持关联查询分包商基本信息，为合同管理提供完整的上下文数据支撑。

### 功能要点

- **多条件组合查询**：支持用户通过分包商ID、合同编号、签署日期范围、合同价值区间等多个条件进行组合查询，系统能够准确解析查询参数并返回匹配的合同记录列表。查询条件可以单独使用也可以任意组合，满足不同场景下的查询需求，确保查询结果的精确性和完整性。
- **分页与排序支持**：提供标准的分页查询接口，支持指定页码、每页记录数以及排序字段和方向。系统能够高效处理大量合同数据的分页请求，确保查询性能稳定，同时支持按合同编号、签署日期、合同价值等关键字段进行升序或降序排列，提升用户体验。
- **关联数据查询**：在查询合同列表的同时，能够自动关联获取对应的分包商基本信息，包括分包商名称、联系方式等关键字段，避免前端多次请求获取关联数据。这种关联查询机制提高了数据获取效率，减少了网络请求次数，优化了整体系统性能。

### 逻辑签名

```naturalts path="app.logics.querySubcontractorContracts.ts"
$Logic({
    description: '查询分包商合同列表',
    directory: 'subcontractor_management(分包商管理)'
})
export declare function querySubcontractorContracts(page: Integer, size: Integer, sort: String, order: String, subcontractorId?: Integer, contractNumber?: String, signedDateFrom?: Date, signedDateTo?: Date, contractValueMin?: Decimal, contractValueMax?: Decimal): { list: List<{ contract: app.dataSources.defaultDS.entities.ContractAssociation, subcontractor: app.dataSources.defaultDS.entities.SubcontractorInformation }>, total: Integer };
```

### 被前端调用

- **合同关联（contractAssociation）**：合同关联页面通过调用此服务端逻辑实现合同数据的查询功能，用户在页面上输入查询条件后，系统调用该接口获取符合条件的合同列表数据，并在表格中展示结果，支持分页浏览和排序操作。

### 依赖的枚举、实体

- **数据建模-实体-合同关联**：[分包商管理-实体-合同关联（ContractAssociation）](specs/001-bootdo-management-system/plan/data-model/entity-ContractAssociation.md)
- **数据建模-实体-分包商信息**：[分包商管理-实体-分包商信息（SubcontractorInformation）](specs/001-bootdo-management-system/plan/data-model/entity-SubcontractorInformation.md)

### 依赖的外部能力

无匹配内容

