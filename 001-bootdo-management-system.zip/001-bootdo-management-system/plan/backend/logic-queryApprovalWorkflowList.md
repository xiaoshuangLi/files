# 预算管理-查询审批流程列表（queryApprovalWorkflowList）

- **生成时间**：2026-03-25

## 查询审批流程列表（queryApprovalWorkflowList）

### 功能概述

查询审批流程列表服务端逻辑提供预算管理模块中审批流程的分页查询功能，支持基于流程名称、启用状态等条件进行过滤，并返回关联的流程定义信息。该逻辑实现了审批流程列表页面的核心数据获取能力，确保用户能够高效地浏览、筛选和管理预算相关的审批流程配置。通过与工作流引擎的流程定义实体关联，该逻辑能够同时返回审批流程的基本信息和对应的流程定义详情，为前端展示提供完整的数据支撑。

### 功能要点

- **分页查询功能**：支持标准的分页参数（页码、每页条数），能够高效处理大量审批流程数据的查询请求，避免一次性加载过多数据导致性能问题。分页机制确保了系统在处理大规模数据时仍能保持良好的响应速度和用户体验。
- **多条件过滤功能**：支持基于审批流程名称的模糊匹配过滤和启用状态的精确匹配过滤，允许用户根据实际需求快速定位特定的审批流程。过滤条件的设计充分考虑了用户在日常操作中的常见查询场景，提高了数据检索的精准度和效率。
- **关联数据查询功能**：在查询审批流程列表的同时，自动关联查询对应的流程定义信息，包括流程名称和描述，为用户提供完整的上下文信息。这种关联查询避免了前端多次请求的开销，优化了整体的数据获取流程。

### 逻辑签名

```naturalts path="app.logics.queryApprovalWorkflowList.ts"
$Logic({
    description: '查询审批流程列表',
    directory: 'budget_management(预算管理)'
})
export declare function queryApprovalWorkflowList(page: Integer, size: Integer, sort: String, order: String, workflowName?: String, isEnabled?: Boolean): { list: List<{ approvalWorkflow: app.dataSources.defaultDS.entities.ApprovalWorkflow, processDefinition: app.dataSources.defaultDS.entities.ProcessDefinition }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 分页查询的页码，从1开始 |
| size | 每页条数 | Integer | 每页显示的记录数量 |
| sort | 排序字段 | String | 排序的字段名 |
| order | 排序顺序 | String | 排序顺序，'asc' 或 'desc' |
| workflowName | 流程名称 | String? | 审批流程名称的模糊匹配条件 |
| isEnabled | 是否启用 | Boolean? | 审批流程启用状态的精确匹配条件 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 审批流程列表 | List<{ approvalWorkflow: app.dataSources.defaultDS.entities.ApprovalWorkflow, processDefinition: app.dataSources.defaultDS.entities.ProcessDefinition }> | 审批流程列表，每个列表项包含审批流程实体和关联的流程定义实体 |
| total | 总条数 | Integer | 符合查询条件的总记录数 |

### 被前端调用

- **审批流程（approvalWorkflow）**：在审批流程列表页面中，通过调用此服务端逻辑获取分页的审批流程数据，用于表格展示。该逻辑支持页面的初始加载、分页切换、排序和过滤操作，为用户提供完整的审批流程列表浏览体验。

### 依赖的枚举、实体

- **预算管理-实体-审批流程**：[预算管理-实体-审批流程（ApprovalWorkflow）](specs/001-bootdo-management-system/plan/data-model/entity-ApprovalWorkflow.md)
- **工作流引擎-实体-流程定义**：[工作流引擎-实体-流程定义（ProcessDefinition）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessDefinition.md)

### 依赖的外部能力

无匹配内容

