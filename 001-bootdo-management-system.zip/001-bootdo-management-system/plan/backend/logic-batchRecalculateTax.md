# 通用领域服务-批量重新计算税务（batchRecalculateTax）

- **生成时间**：2026-03-25

## 批量重新计算税务（batchRecalculateTax）

### 功能概述

该服务端逻辑提供批量重新计算员工个人所得税的功能，支持根据最新的税率政策或薪资结构调整，对指定范围内的员工薪资数据进行税务重新计算。系统会自动识别需要重新计算的薪资记录，并应用最新的税务计算规则，确保薪资发放的准确性和合规性。

### 功能要点

- **批量处理能力**：支持按部门、时间段、员工类型等多种条件筛选需要重新计算税务的薪资记录，能够高效处理大量数据而不影响系统性能。系统会自动分批处理大规模数据，避免单次操作超时或内存溢出问题，确保计算过程的稳定性和可靠性。

### 逻辑签名

```naturalts path="app.logics.batchRecalculateTax.ts"
$Logic({
    description: '批量重新计算员工个人所得税',
    directory: 'salary_management(薪资管理)'
})
export declare function batchRecalculateTax(
  departmentIds?: List<String>,
  startDate?: DateTime,
  endDate?: DateTime,
  employeeTypes?: List<String>
): {
  totalProcessed: Integer;
  successCount: Integer;
  failedCount: Integer;
  failedRecords: List<{
    employeeId: String;
    errorMessage: String;
  }>;
};
```

### 被前端调用

- **薪资报表（salaryReport）**：在薪资报表页面中，管理员可以触发批量重新计算税务功能，以确保报表数据基于最新的税务政策计算，保证薪资报表的准确性和合规性。

### 依赖的枚举、实体

- **数据建模-实体-薪资结构**：[薪资管理-实体-薪资结构（SalaryStructure）](specs/001-bootdo-management-system/plan/data-model/entity-SalaryStructure.md)
- **数据建模-实体-月工资额**：[薪资管理-实体-月工资额（MonthlySalaryAmount）](specs/001-bootdo-management-system/plan/data-model/entity-MonthlySalaryAmount.md)
- **数据建模-实体-税务计算**：[薪资管理-实体-税务计算（TaxCalculation）](specs/001-bootdo-management-system/plan/data-model/entity-TaxCalculation.md)

### 依赖的外部能力

无