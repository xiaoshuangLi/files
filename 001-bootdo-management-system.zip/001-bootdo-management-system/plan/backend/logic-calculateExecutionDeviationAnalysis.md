# 预算管理-计算执行偏差分析（calculateExecutionDeviationAnalysis）

- **生成时间**：2026-03-25

## 计算执行偏差分析（calculateExecutionDeviationAnalysis）

### 功能概述

计算执行偏差分析服务端逻辑是预算管理模块的核心分析功能，用于对预算分配的实际执行情况进行深度分析和偏差计算。该逻辑通过对比预算分配金额与实际执行金额，计算出执行偏差率、预算使用率等关键指标，并识别预算超支或执行滞后的异常情况。系统会基于执行监控实体中的实时数据，结合预算分配的原始计划数据，进行多维度的偏差分析，包括按部门、预算类型、时间周期等维度的汇总分析。分析结果不仅用于前端执行监控页面的可视化展示，还为生成分析报告提供核心数据支撑，帮助财务管理人员及时发现预算执行问题并采取相应的调整措施。

### 功能要点

- **执行偏差计算**：基于预算分配金额和实际执行金额，精确计算执行偏差绝对值和偏差率。偏差率计算公式为(实际执行金额-预算分配金额)/预算分配金额*100%，当预算分配金额为0时需特殊处理避免除零错误。系统会根据偏差率的正负值判断预算是否超支或节余，并设置合理的阈值来标识异常偏差情况，为后续的预警和决策提供数据基础。

- **多维度汇总分析**：支持按部门、预算类型、时间周期等多个维度对执行偏差数据进行汇总分析。系统能够自动聚合同一维度下的所有预算分配记录，计算总体的预算分配总额、实际执行总额、综合偏差率等指标。这种多维度的分析能力使管理层能够从不同视角全面了解组织的预算执行状况，识别执行效果最佳和最差的业务单元，为资源优化配置提供决策依据。

- **异常情况识别**：自动识别预算执行中的异常情况，包括严重超支（偏差率超过预设阈值）、执行严重滞后（在预算周期内执行率过低）等情况。系统会根据预设的业务规则对异常情况进行分类标记，并生成相应的预警信息。这些异常识别结果不仅用于前端页面的高亮显示，还会作为分析报告中的重点内容，提醒相关人员及时关注和处理潜在的预算风险。

### 逻辑签名

```naturalts path="app.logics.calculateExecutionDeviationAnalysis.ts"
$Logic({
    description: '计算执行偏差分析',
    directory: 'budget_management(预算管理)'
})
export declare function calculateExecutionDeviationAnalysis(
  allocationId?: Integer,
  departmentId?: Integer,
  budgetTypeId?: Integer,
  timeRange?: {
    startTime: DateTime;
    endTime: DateTime;
  }
): {
  deviationRate: Decimal;
  usageRate: Decimal;
  allocatedAmount: Decimal;
  executedAmount: Decimal;
  deviationAmount: Decimal;
  isOverBudget: Boolean;
  isUnderExecuted: Boolean;
  anomalies: List<{
    type: String;
    severity: String;
    description: String;
  }>;
  summaryByDimension: List<{
    dimension: String;
    dimensionValue: String;
    allocatedAmount: Decimal;
    executedAmount: Decimal;
    deviationRate: Decimal;
  }>;
};
```

### 被前端调用

- **执行监控（executionMonitoring）**：在执行监控页面中调用此服务端逻辑，获取预算执行的偏差分析结果，用于页面上的数据展示和可视化图表渲染。该页面通过此逻辑实现对预算执行情况的实时监控和异常识别，帮助用户快速了解各预算项目的执行状态和偏差情况。

- **分析报告（analysisReport）**：在生成分析报告时调用此服务端逻辑，获取详细的执行偏差分析数据作为报告的核心内容。分析报告页面利用此逻辑提供的多维度汇总分析结果和异常情况识别信息，生成全面的预算执行分析报告，为管理层决策提供数据支持。

### 依赖的枚举、实体

- **数据建模-实体-执行监控**：[预算管理-实体-执行监控（ExecutionMonitoring）](specs/001-bootdo-management-system/plan/data-model/entity-ExecutionMonitoring.md)
- **数据建模-实体-预算分配**：[预算管理-实体-预算分配（BudgetAllocation）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetAllocation.md)
- **数据建模-实体-预算执行**：[预算管理-实体-预算执行（BudgetExecution）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetExecution.md)
- **数据建模-实体-分析报告**：[预算管理-实体-分析报告（AnalysisReport）](specs/001-bootdo-management-system/plan/data-model/entity-AnalysisReport.md)
- **数据建模-实体-组织部门**：[系统管理-实体-组织部门（OrganizationDepartment）](specs/001-bootdo-management-system/plan/data-model/entity-OrganizationDepartment.md)
- **数据建模-实体-预算类型**：[预算管理-实体-预算类型（BudgetType）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetType.md)

### 依赖的外部能力

无