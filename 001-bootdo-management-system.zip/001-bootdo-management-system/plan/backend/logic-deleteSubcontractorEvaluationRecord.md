# 分包商管理-删除分包商评估记录（deleteSubcontractorEvaluationRecord）

- **生成时间**：2026-03-25

## 删除分包商评估记录（deleteSubcontractorEvaluationRecord）

### 功能概述

该服务端逻辑提供删除分包商评估记录的功能，允许系统管理员或具有相应权限的用户移除不再需要或错误录入的分包商绩效评估记录。删除操作会从系统中永久移除指定的评估记录数据，同时确保数据一致性和完整性，防止因删除操作导致的数据关联异常。此功能对于维护分包商评估数据的准确性和有效性至关重要，有助于保持系统数据的整洁和可靠性。

### 功能要点

- **安全删除验证**：在执行删除操作前，系统必须验证当前用户是否具有删除分包商评估记录的权限，并确认要删除的评估记录ID有效且存在。删除操作需要进行二次确认，防止误删重要数据。系统还需检查该评估记录是否已被其他业务流程引用，如已被引用则需提示用户并阻止删除操作，确保数据完整性不受破坏。

### 逻辑签名

```naturalts path="app.logics.deleteSubcontractorEvaluationRecord.ts"
$Logic({
    description: '删除分包商评估记录',
    directory: 'subcontractor_management(分包商管理)'
})
export declare function deleteSubcontractorEvaluationRecord(evaluationRecordId: String): Boolean;
```

### 被前端调用

- **分包商信息维护（subcontractorInformation）**：在分包商详情页面的评估记录列表中，管理员可以通过点击删除按钮调用此服务端逻辑，移除不需要的评估记录，从而维护分包商评估数据的准确性。

### 依赖的枚举、实体

- **数据建模-实体-评估记录**：[分包商管理-实体-评估记录（EvaluationRecord）](specs/001-bootdo-management-system/plan/data-model/entity-EvaluationRecord.md)