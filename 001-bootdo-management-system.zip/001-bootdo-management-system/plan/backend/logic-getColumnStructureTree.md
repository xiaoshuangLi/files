# 内容管理-获取栏目结构树（getColumnStructureTree）

- **生成时间**：2026-03-25

## 获取栏目结构树（getColumnStructureTree）

### 功能概述

该服务端逻辑用于获取系统中的多级栏目树形结构数据，支持前端展示完整的栏目层级关系。栏目结构是内容管理系统的核心组成部分，用于组织和分类文章内容，提供清晰的内容导航体系。此逻辑能够根据用户权限过滤可访问的栏目，并返回包含栏目ID、名称、父级ID、排序权重、状态等关键信息的树形结构，便于前端进行递归渲染和交互操作。

### 功能要点

- **栏目树形结构构建**：根据数据库中存储的栏目扁平数据，构建完整的树形结构，确保父子级关系正确无误。系统支持无限级栏目嵌套，每个栏目节点包含基本信息如ID、名称、描述、创建时间等，以及业务属性如是否可发布内容、访问权限控制标识等。构建过程中需处理循环引用等异常情况，保证树形结构的完整性和稳定性。

### 逻辑签名

```naturalts path="app.logics.getColumnStructureTree.ts"
$Logic({
    description: '获取栏目结构树',
    directory: 'content_management(内容管理)'
})
export declare function getColumnStructureTree(): List<app.dataSources.defaultDS.entities.ColumnStructure>;
```

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 栏目结构树 | List<app.dataSources.defaultDS.entities.ColumnStructure> | 栏目结构树数组，每个元素代表一个栏目节点，包含完整的栏目信息 |

### 被前端调用

- **栏目结构（columnStructure）**：在栏目结构页面中，通过调用此服务端逻辑获取完整的栏目树形结构，用于展示当前系统中所有的栏目及其层级关系，支持管理员对栏目进行增删改查操作。
- **通用业务模块-文章管理（articleContent）**：在文章管理页面中，调用此服务端逻辑获取栏目树，供用户选择文章所属的栏目，确保文章能够被正确分类和展示。

### 依赖的枚举、实体

- **数据建模-实体-栏目结构**：[内容管理-实体-栏目结构（ColumnStructure）](specs/001-bootdo-management-system/plan/data-model/entity-ColumnStructure.md)

### 依赖的外部能力

无