# 权限中心-加载角色可添加用户列表（LcapLoadAddRoleUserTableView）

## 加载角色可添加用户列表（LcapLoadAddRoleUserTableView）

### 功能概述

该服务端逻辑用于角色管理页面中「添加用户」弹窗的候选用户列表数据。逻辑会根据当前角色已关联的用户ID列表，过滤掉已绑定用户，仅返回可新建用户角色映射的用户集合，支持分页与排序，为前端弹窗选择器提供数据来源。

### 功能要点

- **排除已关联用户**：接收一个已添加用户ID列表参数，查询用户实体时排除这些用户，确保候选列表中不会出现已属于该角色的用户。
- **按角色上下文过滤**：可根据当前角色ID进行上下文过滤（如限定在当前部门或数据权限范围内），保证候选用户集合符合业务约束。
- **分页与排序**：支持按页码、每页条数以及排序字段/方向进行分页和排序查询，适用于用户数量较多的场景。
- **结果结构友好**：返回的数据结构通常为 `{ list: List<{ lcapUser: app.dataSources.defaultDS.entities.LcapUser }>, total: Integer }`，便于前端直接渲染为选择列表。

### 逻辑签名

```naturalts path="app.logics.LcapLoadAddRoleUserTableView.ts"
$Logic({
    description: '为角色管理页面的“添加用户”弹窗提供候选用户列表数据',
    directory: 'permission_center(权限中心)'
})
export declare function LcapLoadAddRoleUserTableView(page: Integer, size: Integer, sort: String, order: String, alreadyAddUserIdList: List<String>, roleId: Integer): { list: List<{ lcapUser: app.dataSources.defaultDS.entities.LcapUser }>, total: Integer };
```

### 被前端调用

- **角色管理页（roleManagement）**：在点击「添加用户」按钮打开弹窗时调用，根据当前角色和已添加用户ID列表加载可选用户集合，用于在弹窗中展示可以添加到该角色的用户列表。

### 依赖的枚举、实体、数据结构

- **数据建模-实体-用户**：[权限中心-实体-用户（LcapUser）](specs/001-bootdo-management-system/plan/data-model/entity-LcapUser.md)

