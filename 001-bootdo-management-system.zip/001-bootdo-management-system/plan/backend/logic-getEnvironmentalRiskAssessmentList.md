# 环保管理-获取环境风险评估列表（getEnvironmentalRiskAssessmentList）

- **生成时间**：2026-03-25

## 获取环境风险评估列表（getEnvironmentalRiskAssessmentList）

### 功能概述

获取环境风险评估列表服务端逻辑用于查询和检索系统中存储的所有环境风险评估记录。该逻辑支持多种查询条件，包括风险类型、风险等级、评估日期范围、合规状态等筛选参数，能够返回符合指定条件的环境风险评估数据集合。通过此服务，前端页面可以动态加载和展示环境风险评估列表，支持环保管理人员对不同类型的环境风险进行分类查看和分析。该逻辑还支持分页查询，确保在大量数据情况下仍能保持良好的性能表现，并提供排序功能，允许用户按评估日期、风险等级等字段进行升序或降序排列。

### 功能要点

- **多条件筛选查询**：支持根据风险类型、风险等级、评估日期范围、合规状态等多个维度进行组合筛选，帮助用户精准定位所需的环境风险评估记录。系统会根据传入的筛选条件构建动态查询语句，确保查询结果的准确性和完整性。
- **分页与排序功能**：实现高效的分页机制，支持指定每页显示记录数量和当前页码，避免一次性加载过多数据导致性能问题。同时提供灵活的排序选项，允许用户按评估日期、风险等级、风险类型等关键字段进行升序或降序排列，提升用户体验。
- **关联数据预加载**：在查询环境风险评估列表时，自动预加载关联合规检查和应急预案的关键信息，减少前端多次请求的开销。通过优化的数据关联查询，确保返回的数据包含完整的业务上下文，便于用户全面了解每个风险评估项的相关情况。

### 逻辑签名

```naturalts path="app.logics.loadEnvironmentalRiskAssessmentList.ts"
$Logic({
    description: '获取环境风险评估列表',
    directory: 'environmental_management(环保管理)'
})
export declare function getEnvironmentalRiskAssessmentList(
  page: Integer, 
  size: Integer, 
  sortField: String, 
  sortOrder: String, 
  riskType: String, 
  riskLevel: app.enums.RiskLevelEnum, 
  assessmentDateFrom: Date, 
  assessmentDateTo: Date, 
  complianceStatus: app.enums.ComplianceStatusEnum
): { list: List<app.dataSources.defaultDS.entities.EnvironmentalRiskAssessment>, total: Integer };
```

### 被前端调用

- **风险评估（environmentalRiskAssessment）**：该功能页面使用当前服务端逻辑来加载和展示环境风险评估列表数据，支持用户通过多种筛选条件查询特定的风险评估记录，并提供分页和排序功能以优化大量数据的浏览体验。

### 依赖的枚举、实体

- **数据建模-枚举-环保合规状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-环境风险评估**：[环保管理-实体-环境风险评估（EnvironmentalRiskAssessment）](specs/001-bootdo-management-system/plan/data-model/entity-EnvironmentalRiskAssessment.md)

### 依赖的外部能力

无