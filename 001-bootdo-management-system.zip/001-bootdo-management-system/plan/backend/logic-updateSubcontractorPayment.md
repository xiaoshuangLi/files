# 分包商管理-更新分包商付款记录（updateSubcontractorPayment）

- **生成时间**：2026-03-25

## 更新分包商付款记录（updateSubcontractorPayment）

### 功能概述

更新分包商付款记录服务端逻辑负责处理分包商付款信息的修改操作，确保付款数据的准确性和一致性。该逻辑接收包含完整付款信息的实体对象作为输入参数，对数据库中的付款记录进行更新，并返回更新后的完整付款记录。通过此逻辑，系统能够支持用户在前端页面对已存在的付款记录进行编辑和修改，包括付款金额、付款方式、付款日期、发票号和付款状态等关键字段的调整。该逻辑还包含必要的数据验证机制，确保更新操作符合业务规则和数据完整性约束，为分包商付款管理提供可靠的后端支持。

### 功能要点

- **付款记录更新功能**：该功能允许用户修改已存在的分包商付款记录，包括付款金额、付款方式、付款日期、发票号和付款状态等关键信息。系统会验证输入数据的有效性，确保付款金额格式正确（最多两位小数）、付款日期不为空、付款状态符合预定义值等业务规则。更新操作会自动记录操作时间和操作人信息，并触发相应的审计日志记录，确保所有修改操作可追溯。更新成功后，系统返回完整的更新后付款记录，供前端页面展示和后续处理使用。

### 逻辑签名

```naturalts path="app.logics.updateSubcontractorPayment.ts"
$Logic({
    description: '更新分包商付款记录',
    directory: 'subcontractor_management(分包商管理)',
    transactional: true
})
export declare function updateSubcontractorPayment(payment: app.dataSources.defaultDS.entities.PaymentManagement): app.dataSources.defaultDS.entities.PaymentManagement;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| payment | 付款记录 | app.dataSources.defaultDS.entities.PaymentManagement | 包含要更新的付款记录完整信息的实体对象，必须包含主键id |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 更新结果 | app.dataSources.defaultDS.entities.PaymentManagement | 更新后的完整付款记录实体 |

### 被前端调用

- **付款管理（paymentManagement）**：在付款管理页面中，当用户编辑付款记录并点击保存按钮时，前端调用此服务端逻辑来更新数据库中的付款记录信息，实现付款数据的修改功能。

### 依赖的枚举、实体

- **数据建模-实体-付款管理**：[分包商管理-实体-付款管理（PaymentManagement）](specs/001-bootdo-management-system/plan/data-model/entity-PaymentManagement.md)
- **数据建模-实体-分包商信息**：[分包商管理-实体-分包商信息（SubcontractorInformation）](specs/001-bootdo-management-system/plan/data-model/entity-SubcontractorInformation.md)

### 依赖的外部能力

无外部能力依赖