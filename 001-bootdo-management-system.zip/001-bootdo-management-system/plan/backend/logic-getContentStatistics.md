# 内容管理-获取内容统计信息（getContentStatistics）

- **生成时间**：2026-03-25

## 获取内容统计信息（getContentStatistics）

### 功能概述

该服务端逻辑用于获取系统中文章内容的统计数据，包括文章浏览量、评论数量、点赞数、分享次数等关键指标。通过此接口，管理员和内容创作者可以全面了解内容的受欢迎程度和用户互动情况，为内容优化和运营决策提供数据支持。系统会根据用户权限返回相应范围内的统计数据，确保数据安全性和隐私保护。

### 功能要点

- **多维度统计分析**：提供文章级别的详细统计数据，包括总浏览量、日均浏览量、评论总数、点赞数、分享次数等核心指标，并支持按时间范围（日、周、月、年）进行筛选和聚合分析，帮助用户全面了解内容表现趋势。

### 逻辑签名

```naturalts path="app.logics.getContentStatistics.ts"
$Logic({
    description: '获取内容统计信息',
    directory: 'content_management(内容管理)'
})
export declare function getContentStatistics(articleId: String, timeRange?: String, startDate?: String, endDate?: String): { 
  articleId: String; 
  title: String; 
  totalViewCount: Integer; 
  dailyViewCount: Integer; 
  totalComments: Integer; 
  totalLikes: Integer; 
  totalShares: Integer; 
  viewTrend: { recordDate: String; viewAmount: Integer }[]; 
  engagementRate: Decimal 
};
```

### 被前端调用

- **统计分析（contentStatistics）**：在统计分析功能页面中调用此服务端逻辑，展示指定文章或所有文章的详细统计数据，支持时间范围筛选和数据可视化展示，帮助管理员和内容创作者分析内容表现。

### 依赖的枚举、实体

- **数据建模-实体-文章内容**：[内容管理-实体-文章内容（ArticleContent）](specs/001-bootdo-management-system/plan/data-model/entity-ArticleContent.md)
- **数据建模-实体-内容统计**：[内容管理-实体-内容统计（ContentStatistics）](specs/001-bootdo-management-system/plan/data-model/entity-ContentStatistics.md)

### 依赖的外部能力

[文件内部已经提供，无需进行生成。如果文件内部已经有 `依赖的外部能力` 内容，禁止修改或删除文件内的 `依赖的外部能力` 内容]