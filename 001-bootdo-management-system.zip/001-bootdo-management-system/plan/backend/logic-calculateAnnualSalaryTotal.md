# 薪资管理-计算年薪总额（calculateAnnualSalaryTotal）

- **生成时间**：2026-03-25

## 计算年薪总额（calculateAnnualSalaryTotal）

### 功能概述

计算年薪总额服务端逻辑用于处理员工年度薪酬总额的计算、存储和管理。该逻辑通过汇总员工在特定财年内的所有月度薪资数据，自动生成准确的年度薪酬总额，并将结果持久化存储到年薪总额实体中。系统支持按员工ID和财年查询已计算的年薪总额记录，同时提供手动触发重新计算的功能，确保薪资数据的准确性和时效性。该逻辑还支持批量计算多个员工的年薪总额，提高人力资源部门的工作效率。计算结果可用于年度绩效评估、薪酬预算规划、税务申报等重要业务场景，为企业的薪酬决策提供可靠的数据支撑。

### 功能要点

- **年薪总额计算**：根据员工ID和财年参数，自动汇总该员工在指定财年内的所有月度薪资数据，计算出准确的年度薪酬总额。计算过程包括基本工资、奖金、津贴等各项收入的累加，并考虑薪资调整、加班费等特殊情况的影响，确保计算结果的全面性和准确性。
- **年薪总额存储与更新**：将计算完成的年薪总额结果存储到年薪总额实体中，包含员工ID、财年、总额金额和计算时间戳等关键信息。如果相同员工和财年的记录已存在，则更新现有记录而非创建新记录，避免数据重复。系统会自动记录操作日志，包括创建者、更新者、创建时间和更新时间，确保数据的可追溯性。
- **年薪总额查询**：支持根据员工ID、财年等条件查询年薪总额记录，返回完整的年薪总额信息。查询功能支持单条记录查询和多条件组合查询，满足不同业务场景的需求。查询结果可用于前端页面展示、报表生成和数据分析等用途。

### 逻辑签名

```naturalts path="app.logics.calculateAnnualSalaryTotal.ts"
$Logic({
    description: '计算员工年薪总额',
    directory: 'salary_management(薪资管理)'
})
export declare function calculateAnnualSalaryTotal(employeeId: Integer, fiscalYear: Integer): app.dataSources.defaultDS.entities.AnnualSalaryTotal;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| employeeId | 员工ID | Integer | 需要计算年薪总额的员工ID，关联系统账户实体 |
| fiscalYear | 财年 | Integer | 薪酬统计的财年，如2025表示2025财年 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 年薪总额记录 | app.dataSources.defaultDS.entities.AnnualSalaryTotal | 包含计算完成的年薪总额信息的实体记录 |

### 被前端调用

- **年薪总额计算（annualSalaryTotal）**：该功能页面使用calculateAnnualSalaryTotal服务端逻辑来计算和展示员工的年度薪酬总额。用户在页面中输入员工ID和财年后，系统调用此逻辑进行计算，并将结果显示在页面上。该逻辑支持页面的新增年薪总额记录功能，当用户提交表单时，系统会调用此逻辑完成计算和存储操作。

### 依赖的枚举、实体

- **数据建模-实体-年薪总额**：[薪资管理-实体-年薪总额（AnnualSalaryTotal）](specs/001-bootdo-management-system/plan/data-model/entity-AnnualSalaryTotal.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无匹配内容

