# 质量管理-获取验收标准列表（getAcceptanceStandardsList）

- **生成时间**：2026-03-25

## 获取验收标准列表（getAcceptanceStandardsList）

### 功能概述

获取验收标准列表服务端逻辑是质量管理模块的核心数据查询接口，专门用于支持质量验收页面的验收标准数据展示功能。该逻辑提供分页查询能力，允许质量管理人员按需获取系统中存储的所有验收标准记录，并支持基于标准名称的模糊搜索过滤。通过该接口，前端页面能够高效地加载验收标准列表数据，以表格形式展示标准名称、验收准则、创建时间、更新时间等关键信息，为质量检验工作提供标准化的评判依据。该逻辑确保了验收标准数据的一致性访问和高效检索，是连接前端展示与后端数据存储的关键桥梁，有效支撑了从标准制定到检验执行的完整业务闭环。

### 功能要点

- **验收标准分页查询**：支持按页码和每页条数进行分页查询，避免一次性加载大量数据导致性能问题，确保系统在处理大规模验收标准数据时仍能保持良好的响应速度和用户体验。
- **验收标准搜索过滤**：支持基于标准名称的模糊搜索功能，允许质量管理人员通过输入关键词快速定位特定的验收标准，提高数据查找效率和操作便捷性。
- **验收标准数据完整性**：返回完整的验收标准信息，包括主键ID、标准名称、验收准则、创建时间、更新时间、创建人、更新人等所有必要字段，确保前端能够完整展示验收标准的详细信息。
- **数据排序支持**：支持按指定字段和排序方式进行结果排序，确保验收标准列表能够按照用户需求进行有序展示，提升数据浏览体验。

### 逻辑签名

```naturalts path="app.logics.getAcceptanceStandardsList.ts"
$Logic({
    description: '获取验收标准列表',
    directory: 'quality_management(质量管理)'
})
export declare function getAcceptanceStandardsList(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.AcceptanceStandard): { list: List<app.dataSources.defaultDS.entities.AcceptanceStandard>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 查询的页码，从1开始计数 |
| size | 每页条数 | Integer | 每页显示的验收标准记录数量 |
| sort | 排序字段 | String | 用于排序的字段名称，如"standardName"、"createdTime"等 |
| order | 排序顺序 | String | 排序顺序，"asc"表示升序，"desc"表示降序 |
| filter | 过滤条件 | app.dataSources.defaultDS.entities.AcceptanceStandard | 过滤条件对象，主要使用standardName字段进行模糊匹配 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 验收标准列表 | List<app.dataSources.defaultDS.entities.AcceptanceStandard> | 当前页的验收标准记录列表 |
| total | 总条数 | Integer | 符合过滤条件的验收标准总记录数 |

### 被前端调用

- **质量验收（acceptanceStandard）**：质量验收页面在初始化时调用此服务端逻辑获取验收标准列表数据，用于在表格中展示所有验收标准记录；同时在用户执行搜索操作时，也会调用此逻辑根据搜索关键词过滤并重新加载验收标准列表。

### 依赖的枚举、实体

- **数据建模-实体-验收标准**：[质量管理-实体-验收标准（AcceptanceStandard）](specs/001-bootdo-management-system/plan/data-model/entity-AcceptanceStandard.md)

### 依赖的外部能力

无匹配内容

