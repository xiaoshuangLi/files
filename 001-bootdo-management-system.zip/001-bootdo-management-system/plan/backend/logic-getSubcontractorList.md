# 通用领域服务-获取分包商列表（getSubcontractorList）

- **生成时间**：2026-03-25

## 获取分包商列表（getSubcontractorList）

### 功能概述

该服务端逻辑用于获取系统中所有分包商的列表信息，支持按多种条件进行筛选和分页查询。分包商作为项目执行的重要参与方，其信息管理对于项目进度控制、质量管理和风险评估至关重要。此接口提供分包商基本信息的查询功能，包括分包商名称、资质状态、联系信息、所属项目等核心数据，同时支持按分包商状态、资质等级、项目关联等条件进行过滤，满足不同业务场景下的查询需求。

### 功能要点

- **分页查询与筛选功能**：实现分包商列表的分页查询功能，支持按分包商名称、状态、资质等级、所属项目等多维度条件进行筛选。系统应能高效处理大量分包商数据的查询请求，确保在大数据量场景下仍能保持良好的响应性能。查询结果应包含分包商的基本信息、资质状态、关联项目数量等关键字段，便于前端展示和用户决策。

### 逻辑签名

```naturalts path="app.logics.getSubcontractorList.ts"
$Logic({
    description: '获取分包商列表',
    directory: 'subcontractor_management(分包商管理)'
})
export declare function getSubcontractorList(page: Integer, size: Integer, name?: String, status?: app.enums.SubcontractorStatus, qualificationLevel?: String, projectId?: String): { list: List<app.dataSources.defaultDS.entities.Subcontractor>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 页码 |
| size | 每页条数 | Integer | 每页条数 |
| name | 分包商名称 | String | 分包商名称，用于模糊查询 |
| status | 分包商状态 | app.enums.SubcontractorStatus | 分包商状态，用于精确匹配 |
| qualificationLevel | 资质等级 | String | 资质等级，用于精确匹配 |
| projectId | 项目ID | String | 项目ID，用于筛选关联特定项目的分包商 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 分包商列表 | List<app.dataSources.defaultDS.entities.Subcontractor> | 分包商实体列表 |
| total | 总记录数 | Integer | 符合条件的分包商总数量 |

### 被前端调用

- **分包商信息维护（subcontractorInformation）**：在分包商信息维护页面中，通过调用此服务端逻辑获取分包商列表数据，实现分包商信息的展示、筛选和分页功能，支持用户对分包商进行查看、编辑和管理操作。

### 依赖的枚举、实体

- **数据建模-枚举-分包商状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-分包商**：[分包商管理-实体-分包商（Subcontractor）](specs/001-bootdo-management-system/plan/data-model/entity-Subcontractor.md)

### 依赖的外部能力

无