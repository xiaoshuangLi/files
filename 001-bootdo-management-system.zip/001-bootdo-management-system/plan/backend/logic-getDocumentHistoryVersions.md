# 办公自动化-获取文档历史版本（getDocumentHistoryVersions）

- **生成时间**：2026-03-25

## 获取文档历史版本（getDocumentHistoryVersions）

### 功能概述

该服务端逻辑用于获取指定文档的所有历史版本信息，包括每个版本的创建时间、创建人、版本号、版本描述等元数据。用户可以通过此接口查看文档的完整修改历史，了解文档的演变过程，并能够选择特定的历史版本进行查看、恢复或比较操作。系统会按照时间倒序排列返回所有历史版本，确保用户能够快速访问最新的修改记录。

### 功能要点

- **历史版本查询**：根据文档ID查询该文档的所有历史版本记录，返回包含版本号、创建时间、创建人、版本描述、文件大小等详细信息的列表。系统支持按时间范围、创建人等条件进行筛选，帮助用户快速定位特定的历史版本。所有历史版本数据按照创建时间倒序排列，最新的版本显示在最前面。

### 逻辑签名

```naturalts path="app.logics.getDocumentHistoryVersions.ts"
$Logic({
    description: '获取文档历史版本',
    directory: 'office_automation(办公自动化)'
})
export declare function getDocumentHistoryVersions(documentId: Text, startTime: DateTime?, endTime: DateTime?, creatorId: Text?, page: Integer, size: Integer): { versions: List<app.dataSources.defaultDS.entities.DocumentVersion>, total: Integer, page: Integer, size: Integer };
```

### 被前端调用

- **文档协作（documentCollaboration）**：在文档协作页面中，用户点击文档历史版本按钮时，调用此服务端逻辑获取该文档的所有历史版本信息，用于在历史版本面板中展示版本列表，支持用户查看、恢复或比较不同版本的文档内容。

### 依赖的枚举、实体

- **数据建模-实体-文档版本**：[办公自动化-实体-文档版本（DocumentVersion）](specs/001-bootdo-management-system/plan/data-model/entity-DocumentVersion.md)
- **数据建模-实体-用户**：specs/001-bootdo-management-system/plan/data-model/entity-User.md

### 依赖的外部能力

无