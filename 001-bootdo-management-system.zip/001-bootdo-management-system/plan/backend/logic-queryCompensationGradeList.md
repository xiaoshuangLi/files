# 薪资管理-查询薪酬档级列表（queryCompensationGradeList）

- **生成时间**：2026-03-25

## 查询薪酬档级列表（queryCompensationGradeList）

### 功能概述

查询薪酬档级列表服务端逻辑用于分页获取系统中所有薪酬档级的详细信息，支持按档级名称进行条件筛选和排序。该逻辑从薪酬档级实体（CompensationGrade）中检索数据，返回包含档级名称、最低薪资、最高薪资范围、描述等关键字段的完整列表。通过分页机制，系统能够高效处理大量薪酬档级数据，避免一次性加载过多数据导致性能问题。该服务为前端薪酬档级管理页面提供数据支撑，确保管理员能够全面了解当前系统中的薪酬档级配置情况，便于进行档级标准的维护和管理。

### 功能要点

- **分页查询与展示**：系统根据前端请求参数（页码、每页条数）执行分页查询，返回指定页的薪酬档级列表数据及总记录数。默认每页显示10条记录，但支持前端动态调整每页显示数量（10/20/50条）。查询结果包含完整的档级信息，包括档级名称、最低薪资、最高薪资、描述、创建时间和更新时间等字段，直接适用于前端表格组件的渲染，确保薪酬档级管理界面能够清晰展示所有档级配置的状态和详情。

### 逻辑签名

```naturalts path="app.logics.queryCompensationGradeList.ts"
$Logic({
    description: '查询薪酬档级列表',
    directory: 'salary_management(薪资管理)'
})
export declare function queryCompensationGradeList(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.CompensationGrade): { list: List<app.dataSources.defaultDS.entities.CompensationGrade>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 当前页码，从1开始 |
| size | 每页条数 | Integer | 每页显示的记录数量 |
| sort | 排序字段 | String | 用于排序的字段名，如"gradeName"、"minSalary"等 |
| order | 排序顺序 | String | 排序方向，'asc'表示升序，'desc'表示降序 |
| filter | 过滤条件 | app.dataSources.defaultDS.entities.CompensationGrade | 薪酬档级过滤条件，支持档级名称等字段的模糊匹配 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 薪酬档级列表 | List<app.dataSources.defaultDS.entities.CompensationGrade> | 薪酬档级列表，包含档级的完整信息 |
| total | 总条数 | Integer | 符合条件的总记录数 |

### 被前端调用

- **薪酬档级（compensationGrade）**：薪酬档级管理页面在初始化时调用此服务端逻辑加载所有薪酬档级列表，并在用户执行档级名称搜索操作时再次调用，传入搜索关键词以获取筛选后的档级列表。该逻辑为页面表格提供了完整的数据源，支持薪酬档级的查看和管理功能。

### 依赖的枚举、实体

- **数据建模-实体-薪酬档级**：[薪资管理-实体-薪酬档级（CompensationGrade）](specs/001-bootdo-management-system/plan/data-model/entity-CompensationGrade.md)

### 依赖的外部能力