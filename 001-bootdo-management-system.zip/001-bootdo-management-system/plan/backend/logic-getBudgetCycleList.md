# 预算管理-获取预算周期列表（getBudgetCycleList）

- **生成时间**：2026-03-25

## 获取预算周期列表（getBudgetCycleList）

### 功能概述

获取预算周期列表服务端逻辑用于查询系统中所有预算周期数据，支持分页、排序和条件过滤功能。该逻辑为预算周期管理页面提供数据支撑，允许系统管理员查看、筛选和管理预算周期信息。通过该逻辑，用户可以按周期名称、时间范围等条件进行查询，并以分页形式展示结果，确保大量数据的高效加载和展示。返回的数据包含完整的预算周期实体信息，包括周期名称、开始日期、结束日期、描述以及系统字段如创建时间、更新时间等，为前端页面的数据展示和后续操作提供完整的基础数据。

### 功能要点

- **分页查询功能**：支持按页码和每页条数进行分页查询，避免一次性加载过多数据导致性能问题，确保系统在大数据量场景下的响应速度和稳定性。
- **多条件过滤功能**：支持按周期名称模糊匹配、开始日期范围、结束日期范围等多维度条件进行数据过滤，帮助用户快速定位所需的预算周期数据。
- **排序功能**：支持按任意字段进行升序或降序排序，用户可以根据业务需求自定义数据展示顺序，提升数据浏览和分析的效率。
- **关联数据完整性**：返回完整的预算周期实体数据，包含所有必要字段，确保前端页面能够完整展示预算周期信息并支持后续的编辑、删除等操作。

### 逻辑签名

```naturalts path="app.logics.getBudgetCycleList.ts"
$Logic({
    description: '获取预算周期列表',
    directory: 'budget_management(预算管理)'
})
export declare function getBudgetCycleList(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.BudgetCycle): { list: List<app.dataSources.defaultDS.entities.BudgetCycle>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 查询的页码，从1开始计数 |
| size | 每页条数 | Integer | 每页显示的记录数量 |
| sort | 排序字段 | String | 用于排序的字段名称，如"cycleName"、"startDate"等 |
| order | 排序顺序 | String | 排序方式，"asc"表示升序，"desc"表示降序 |
| filter | 过滤条件 | app.dataSources.defaultDS.entities.BudgetCycle | 预算周期实体作为过滤条件，支持周期名称模糊匹配、日期范围等过滤 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 预算周期列表 | List<app.dataSources.defaultDS.entities.BudgetCycle> | 符合查询条件的预算周期实体列表 |
| total | 总记录数 | Integer | 符合查询条件的总记录数量，用于分页计算 |

### 被前端调用

- **预算周期管理（budgetCycle）**：在预算周期管理页面的列表展示区域，调用此服务端逻辑获取预算周期数据，支持分页、排序和条件筛选功能，为用户提供完整的预算周期数据浏览体验。

### 依赖的枚举、实体

- **数据建模-实体-预算周期**：[预算管理-实体-预算周期（BudgetCycle）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetCycle.md)

### 依赖的外部能力

无外部能力依赖