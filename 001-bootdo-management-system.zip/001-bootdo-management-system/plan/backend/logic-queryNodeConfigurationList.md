# 工作流引擎-查询节点配置列表（queryNodeConfigurationList）

- **生成时间**：2026-03-25

## 查询节点配置列表（queryNodeConfigurationList）

### 功能概述

查询节点配置列表服务端逻辑用于分页获取工作流引擎中所有节点配置的详细信息，支持按任务节点ID、配置时间范围等条件进行过滤，并支持按指定字段和顺序进行排序。该逻辑返回符合条件的节点配置列表及其总数，为前端节点配置管理页面提供数据支撑。通过关联查询任务节点实体，确保返回的数据包含完整的节点上下文信息，包括任务名称、流程实例等关键字段，便于管理员全面了解和管理各个工作流节点的配置状态。

### 功能要点

- **分页查询与过滤功能**：支持标准的分页参数（页码、每页条数）控制返回数据量，避免一次性加载过多数据导致性能问题。同时支持基于节点配置实体的多条件过滤，包括按任务节点ID精确匹配、按配置时间范围筛选等，确保用户能够精准定位到目标节点配置记录。
- **动态排序与关联数据加载**：支持按任意字段（如配置时间、任务节点ID等）进行升序或降序排列，默认按配置时间降序显示最新配置。在返回节点配置列表的同时，自动关联加载对应的任务节点详细信息，包括任务名称、分配用户、任务状态等，减少前端多次请求的开销，提升用户体验。

### 逻辑签名

```naturalts path="app.logics.queryNodeConfigurationList.ts"
$Logic({
    description: '分页查询节点配置列表',
    directory: 'workflow_engine(工作流引擎)'
})
export declare function queryNodeConfigurationList(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.NodeConfiguration): { list: List<{ nodeConfiguration: app.dataSources.defaultDS.entities.NodeConfiguration, taskNode: app.dataSources.defaultDS.entities.TaskNode }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 分页查询的页码，从1开始计数 |
| size | 每页条数 | Integer | 每页返回的记录数量，建议范围1-100 |
| sort | 排序字段 | String | 排序的字段名，如"configuredAt"、"taskId"等 |
| order | 排序顺序 | String | 排序方向，"asc"表示升序，"desc"表示降序 |
| filter | 过滤条件 | app.dataSources.defaultDS.entities.NodeConfiguration | 节点配置实体作为过滤条件，支持各字段的精确匹配 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 节点配置列表 | List<{ nodeConfiguration: app.dataSources.defaultDS.entities.NodeConfiguration, taskNode: app.dataSources.defaultDS.entities.TaskNode }> | 节点配置列表，每个列表项包含节点配置实体及其关联的任务节点信息 |
| total | 总条数 | Integer | 符合筛选条件的总记录数，用于分页计算 |

### 被前端调用

- **节点配置（nodeConfiguration）**：节点配置管理页面使用此服务端逻辑加载节点配置列表数据，支持用户查看、筛选和管理各个工作流节点的配置信息。页面通过分页、过滤和排序参数调用此接口，获取符合业务需求的节点配置数据，并在表格中展示任务节点名称、配置时间、节点属性等关键信息。

### 依赖的枚举、实体

- **数据建模-实体-节点配置**：[工作流引擎-实体-节点配置（NodeConfiguration）](specs/001-bootdo-management-system/plan/data-model/entity-NodeConfiguration.md)
- **数据建模-实体-任务节点**：[工作流引擎-实体-任务节点（TaskNode）](specs/001-bootdo-management-system/plan/data-model/entity-TaskNode.md)

### 依赖的外部能力