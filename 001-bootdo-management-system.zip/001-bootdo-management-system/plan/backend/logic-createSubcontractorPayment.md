# 分包商管理-创建分包商付款（createSubcontractorPayment）

- **生成时间**：2026-03-25

## 创建分包商付款（createSubcontractorPayment）

### 功能概述

该服务端逻辑负责处理分包商付款的创建操作，包括验证分包商信息的有效性、关联相关合同、计算付款金额、记录付款详情以及触发后续审批流程。系统会根据分包商的资质状态、合同关联情况和历史付款记录来确定是否允许创建新的付款请求，并确保付款数据的完整性和一致性。此功能是分包商管理系统中财务结算模块的核心组成部分，直接关系到项目成本控制和供应商关系管理。

### 功能要点

- **付款信息验证与创建**：系统首先验证分包商的基本信息是否完整有效，包括分包商ID、资质证书状态等。然后检查关联的合同是否存在且处于有效状态。在验证通过后，系统会收集付款金额、付款原因、预计付款日期等必要信息，创建付款记录并分配唯一的付款编号。整个过程确保数据的完整性和业务规则的一致性，防止无效或重复的付款请求被创建。

### 逻辑签名

```naturalts path="app.logics.createSubcontractorPayment.ts"
$Logic({
    description: '创建分包商付款',
    directory: 'subcontractor_management(分包商管理)'
})
export declare function createSubcontractorPayment(subcontractorId: Text, contractId: Text, paymentAmount: Decimal, paymentReason: Text, expectedPaymentDate: DateTime): { paymentId: Text, status: PaymentStatus, createdAt: DateTime };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| subcontractorId | 分包商ID | Text | 分包商的唯一标识符 |
| contractId | 合同ID | Text | 关联合同的唯一标识符 |
| paymentAmount | 付款金额 | Decimal | 本次付款的金额 |
| paymentReason | 付款原因 | Text | 付款的具体原因说明 |
| expectedPaymentDate | 预计付款日期 | DateTime | 预计的付款日期 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| paymentId | 付款ID | Text | 创建的付款记录唯一标识符 |
| status | 状态 | PaymentStatus | 付款状态，可能为已创建或待审批 |
| createdAt | 创建时间 | DateTime | 付款记录的创建时间 |

### 被前端调用

- **付款管理（paymentManagement）**：在付款管理页面中，用户可以通过表单填写分包商付款信息，提交后调用此服务端逻辑创建新的付款记录，并在列表中显示创建结果。

### 依赖的枚举、实体

- **数据建模-实体-分包商信息**：[分包商管理-实体-分包商信息（SubcontractorInformation）](specs/001-bootdo-management-system/plan/data-model/entity-SubcontractorInformation.md)
- **数据建模-实体-合同关联**：[分包商管理-实体-合同关联（ContractAssociation）](specs/001-bootdo-management-system/plan/data-model/entity-ContractAssociation.md)
- **数据建模-实体-付款管理**：[分包商管理-实体-付款管理（PaymentManagement）](specs/001-bootdo-management-system/plan/data-model/entity-PaymentManagement.md)