# 预算管理-创建预算周期（createBudgetCycle）

- **生成时间**：2026-03-25

## 创建预算周期（createBudgetCycle）

### 功能概述

创建预算周期功能用于在预算管理系统中新增一个预算周期配置，为后续的预算分配、执行监控等业务操作提供时间框架基础。该功能允许系统管理员定义预算活动的起止时间边界，支持年度、季度、月度等多种时间维度的预算规划。通过严格的日期验证规则（结束日期不能早于开始日期）和周期名称唯一性校验，确保预算周期数据的准确性和一致性。创建成功的预算周期将作为预算类型和预算分配的基础关联数据，支撑整个预算管理模块的正常运行。

### 功能要点

- **预算周期基本信息创建**：系统需要接收并验证预算周期的基本信息，包括周期名称（如'2026年度预算'、'Q1季度预算'等）、开始日期、结束日期和描述信息。周期名称必须唯一且非空，开始日期和结束日期必须符合业务逻辑（结束日期不能早于开始日期），描述信息为可选字段，用于提供预算周期的详细说明。

### 逻辑签名

```naturalts path="app.logics.createBudgetCycle.ts"
$Logic({
    description: '创建预算周期',
    directory: 'budget_management(预算管理)',
    transactional: true
})
export declare function createBudgetCycle(budgetCycle: app.dataSources.defaultDS.entities.BudgetCycle): app.dataSources.defaultDS.entities.BudgetCycle;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| budgetCycle | 预算周期实体 | app.dataSources.defaultDS.entities.BudgetCycle | 包含周期名称、开始日期、结束日期和描述等字段的预算周期实体 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 创建结果 | app.dataSources.defaultDS.entities.BudgetCycle | 补充了id、创建时间、更新时间等系统字段的预算周期实体 |

### 被前端调用

- **预算周期管理（budgetCycle）**：在预算周期管理页面中，当系统管理员点击"新增"按钮并填写完预算周期表单后，前端会调用此服务端逻辑将预算周期数据保存到数据库，完成新增操作。

### 依赖的枚举、实体

- **数据建模-实体-预算周期**：[预算管理-实体-预算周期（BudgetCycle）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetCycle.md)

### 依赖的外部能力

无