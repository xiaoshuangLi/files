# 薪资管理-调整薪资（adjustSalary）

- **生成时间**：2026-03-25

## 调整薪资（adjustSalary）

### 功能概述

调整薪资服务端逻辑是BootDo管理系统薪资管理模块的核心业务功能，负责处理员工薪资调整申请的创建、更新和审批流程触发。该逻辑支持系统管理员或人力资源专员提交包含调整原因、原薪资、新薪资、生效日期等关键信息的薪资调整申请，并通过与工作流引擎的集成自动启动多级审批流程。同时，该逻辑还支持对已提交但未完成审批的薪资调整申请进行编辑和更新，确保薪资调整过程的灵活性和准确性。通过严格的参数验证和数据一致性检查，该逻辑保证了薪资调整数据的完整性和合规性，为企业的薪酬管理提供可靠的技术支撑。

### 功能要点

- **薪资调整申请创建**：当系统管理员或人力资源专员提交薪资调整申请时，该逻辑接收包含员工ID、申请人ID、原薪资、新薪资、调整原因、生效日期等必要信息的请求参数，验证参数的完整性和有效性后，在数据库中创建新的薪资调整记录，并将其初始状态设置为"已提交"。随后，该逻辑会自动触发工作流引擎的审批流程，将申请流转到相应的审批节点，确保薪资调整申请能够及时进入审批环节。

- **薪资调整申请更新**：当具有相应权限的用户需要修改已提交但尚未完成审批的薪资调整申请时，该逻辑支持对申请记录的部分字段进行更新操作。系统会验证用户权限和申请当前状态，确保只有在允许的状态下才能进行修改。更新操作完成后，系统会记录操作日志并保持申请在审批流程中的当前位置，避免因数据变更导致审批流程中断或数据不一致。

- **薪资结构调整验证**：该逻辑在处理薪资调整申请时，会执行严格的业务规则验证，包括但不限于：新薪资必须大于原薪资（除非特殊情况）、调整幅度不能超过预设阈值、生效日期不能早于当前日期等。这些验证规则确保了薪资调整的合理性和合规性，防止因人为错误或恶意操作导致的薪资计算异常。

### 逻辑签名

```naturalts path="app.logics.adjustSalary.ts"
$Logic({
    description: '调整员工薪资',
    directory: 'salary_management(薪资管理)',
    transactional: true
})
export declare function adjustSalary(employeeId: Integer, requesterId: Integer, oldSalary: Decimal, newSalary: Decimal, reason: String, effectiveDate: Date): app.dataSources.defaultDS.entities.SalaryAdjustment;
```

### 被前端调用

- **薪资调整审批（salaryAdjustment）**：薪资调整审批页面使用此服务端逻辑来提交新的薪资调整申请。当系统管理员或人力资源专员填写完薪资调整表单并点击提交按钮时，前端会调用此逻辑，传入员工ID、申请人ID、原薪资、新薪资、调整原因和生效日期等参数，创建薪资调整申请记录并触发审批流程。

### 依赖的枚举、实体

- **数据建模-枚举-审批状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-薪资调整**：[薪资管理-实体-薪资调整（SalaryAdjustment）](specs/001-bootdo-management-system/plan/data-model/entity-SalaryAdjustment.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无