# 系统管理-加载系统配置列表（loadSystemConfigurations）

- **生成时间**：2026-03-25

## 加载系统配置列表（loadSystemConfigurations）

### 功能概述

加载系统配置列表服务端逻辑用于分页查询系统中的全局配置参数，支持按配置键、配置描述等条件进行过滤，并提供排序功能。该逻辑返回包含系统配置实体列表和总记录数的分页结果，为系统参数配置页面提供数据支撑。通过此接口，管理员可以高效地浏览、搜索和管理系统的各项配置参数，包括基础运行环境设置、业务规则参数、第三方服务集成凭证等关键配置信息，确保系统能够灵活适应不同的部署场景和业务需求。

### 功能要点

- **分页查询与过滤功能**：支持标准的分页参数（页码、每页条数）控制返回数据量，避免一次性加载过多配置数据导致性能问题。同时支持按配置键(configKey)和配置描述(description)进行模糊匹配查询，用户可以通过关键词快速定位到特定的配置项，提高配置管理的效率和准确性。
- **动态排序功能**：支持按任意字段进行升序或降序排列，通过sort参数指定排序字段，order参数指定排序方向。默认按创建时间(createdTime)降序排列，确保最新的配置变更优先显示，便于管理员跟踪最近的配置修改情况。
- **完整配置数据返回**：返回的系统配置数据包含完整的配置信息，包括配置ID、配置键、配置值、配置描述以及创建和更新的时间戳和操作人信息。这些数据为前端提供了足够的信息来展示配置列表，并支持后续的编辑、删除等操作。

### 逻辑签名

```naturalts path="app.logics.loadSystemConfigurations.ts"
$Logic({
    description: '加载系统配置列表',
    directory: 'system_management(系统管理)'
})
export declare function loadSystemConfigurations(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.SystemConfigurationEntity): { list: List<app.dataSources.defaultDS.entities.SystemConfigurationEntity>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 分页查询的页码，从1开始计数 |
| size | 每页条数 | Integer | 每页返回的记录数量，建议范围1-100 |
| sort | 排序字段 | String | 排序的字段名，如"createdTime"、"configKey"等 |
| order | 排序顺序 | String | 排序方向，"ascending"表示升序，"descending"表示降序 |
| filter | 过滤条件 | app.dataSources.defaultDS.entities.SystemConfigurationEntity | 系统配置实体作为过滤条件，支持配置键、配置描述等字段的模糊匹配 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 系统配置列表 | List<app.dataSources.defaultDS.entities.SystemConfigurationEntity> | 系统配置实体列表，包含完整的配置信息 |
| total | 总条数 | Integer | 符合筛选条件的总记录数，用于分页计算 |

### 被前端调用

- **系统参数配置（systemConfig）**：系统参数配置页面在初始化时调用此服务端逻辑加载系统配置列表数据，并在用户执行查询操作时再次调用，传入搜索关键词以获取筛选后的配置列表。该逻辑为页面表格提供了完整的数据源，支持配置参数的查看、编辑和删除功能。

### 依赖的枚举、实体

- **数据建模-实体-系统配置**：[系统管理-实体-系统配置（SystemConfigurationEntity）](specs/001-bootdo-management-system/plan/data-model/entity-SystemConfigurationEntity.md)

### 依赖的外部能力

无匹配内容

