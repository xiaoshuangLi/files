# 办公自动化-加载通知公告列表（loadNotificationList）

- **生成时间**：2026-03-25

## 加载通知公告列表（loadNotificationList）

### 功能概述

加载通知公告列表服务端逻辑提供分页查询系统中通知公告的功能，支持按消息标题、消息类型、优先级、发送时间范围等条件进行过滤，并支持按指定字段和顺序进行排序。该逻辑返回符合条件的通知公告列表及其总数，用于在通知公告功能页面中展示可用的通知信息，方便用户查看和管理各类系统公告、业务提醒和审批通知。通过该逻辑，系统能够高效地管理和检索通知公告，提升用户使用通知功能的体验。

### 功能要点

- **分页查询功能**：支持分页查询通知公告，通过page和size参数控制返回结果的页码和每页条数，避免一次性加载过多数据导致性能问题。系统会根据传入的分页参数计算并返回对应页的数据以及总记录数，确保前端能够正确显示分页控件。
- **多条件过滤功能**：支持按消息标题、消息类型、优先级、发送时间范围等多个条件组合过滤通知公告。用户可以通过消息标题模糊匹配查找特定公告，通过消息类型筛选出仅适用于系统公告或业务提醒的公告，通过优先级过滤出重要或普通级别的公告，提高公告查找的精准度。
- **排序功能**：支持按任意字段（如发送时间、消息标题、优先级等）进行升序或降序排序，确保返回的通知公告列表按照用户期望的顺序排列。系统会根据传入的sort和order参数动态构建排序规则，满足不同场景下的排序需求。
- **关联数据加载**：在返回通知公告列表的同时，自动关联查询发送者的系统账户信息，包括用户名、真实姓名等基本信息，以便在通知公告页面正确显示发件人身份。这种关联查询通过外键关系实现，确保数据的一致性和完整性。

### 逻辑签名

```naturalts path="app.logics.loadNotificationList.ts"
$Logic({
    description: '加载通知公告列表',
    directory: 'office_automation(办公自动化)'
})
export declare function loadNotificationList(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.NotificationMessageEntity): { list: List<{ notification: app.dataSources.defaultDS.entities.NotificationMessageEntity, sender: app.dataSources.defaultDS.entities.SystemAccount }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 查询的页码，从1开始 |
| size | 每页条数 | Integer | 每页返回的记录数 |
| sort | 排序字段 | String | 用于排序的字段名 |
| order | 排序顺序 | String | 排序顺序，'asc'表示升序，'desc'表示降序 |
| filter | 过滤条件 | app.dataSources.defaultDS.entities.NotificationMessageEntity | 通知公告过滤条件，支持消息标题、消息类型、优先级、发送时间等字段的过滤 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 通知公告列表 | List<{ notification: app.dataSources.defaultDS.entities.NotificationMessageEntity, sender: app.dataSources.defaultDS.entities.SystemAccount }> | 符合条件的通知公告列表，每个元素包含通知公告实体和关联的发送者信息 |
| total | 总条数 | Integer | 符合条件的通知公告总数量 |

### 被前端调用

- **通知公告（noticeAnnouncement）**：在通知公告功能页面中，当用户需要查看通知公告列表时，系统会调用此服务端逻辑加载可用的通知公告列表。用户可以在公告列表界面中浏览、搜索和筛选通知公告，并查看公告的详细信息。

### 依赖的枚举、实体

- **数据建模-实体-通知消息**：[办公自动化-实体-通知消息（NotificationMessageEntity）](specs/001-bootdo-management-system/plan/data-model/entity-NotificationMessageEntity.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力