# 质量管理-删除质量检验（deleteQualityInspection）

- **生成时间**：2026-03-25

## 删除质量检验（deleteQualityInspection）

### 功能概述

删除质量检验功能允许授权用户从系统中移除不再需要或错误录入的质量检验记录。该功能确保数据的准确性和完整性，防止无效或过时的质量检验信息影响质量管理决策。删除操作会同时清理与该质量检验相关的所有关联数据，包括检验结果、问题记录和整改任务等，确保数据一致性。系统会在执行删除前进行权限验证和数据依赖检查，防止误删重要数据，并记录完整的操作日志用于审计追踪。

### 功能要点

- **安全删除机制**：删除质量检验记录时，系统首先验证当前用户是否具有删除权限，通常仅限于系统管理员、部门管理员或质量检验的创建者。然后检查该质量检验是否已被其他业务流程引用，如已关联到验收报告或整改任务且状态为进行中，则禁止删除并提示用户先处理相关依赖。删除操作采用软删除方式，保留基本记录用于审计，但对前端用户不可见，确保数据可追溯性的同时满足业务需求。

### 逻辑签名

```naturalts path="app.logics.deleteQualityInspection.ts"
$Logic({
    description: '删除质量检验记录',
    directory: 'quality_management(质量管理)'
})
export declare function deleteQualityInspection(inspectionId: Integer, operatorId: String): Boolean;
```

### 被前端调用

- **质量检验（qualityInspection）**：在质量检验页面，用户可以选择一条或多条质量检验记录执行删除操作，系统调用此服务端逻辑完成实际的删除处理，并返回操作结果用于界面反馈。

### 依赖的枚举、实体

- **数据建模-实体-质量检验**：[质量管理-实体-质量检验（QualityInspection）](specs/001-bootdo-management-system/plan/data-model/entity-QualityInspection.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无