# 通用领域服务-删除邮件（deleteEmail）

- **生成时间**：2026-03-25

## 删除邮件（deleteEmail）

### 功能概述

删除邮件服务端逻辑提供企业内部邮件系统的邮件删除功能，支持用户将不需要的邮件移动到垃圾箱或永久删除。该功能确保用户能够有效管理邮箱空间，清理过期或无关的邮件内容。系统在执行删除操作前会进行二次确认验证，防止误删重要邮件，并支持在一定时间内恢复已删除邮件。删除操作会更新邮件的状态标记，并记录操作日志用于审计追踪。

### 功能要点

- **安全删除机制**：删除邮件功能采用软删除机制，将邮件标记为已删除状态而非直接从数据库中物理删除。这样设计既保证了数据的安全性，又允许在必要时恢复误删的邮件。系统会记录删除操作的时间、操作人等审计信息，并在前端界面中将已删除邮件移至垃圾箱分类，用户可以在垃圾箱中查看和恢复这些邮件。对于超过保留期限的已删除邮件，系统会定期执行物理删除以释放存储空间。

### 逻辑签名

```naturalts path="app.logics.deleteEmail.ts"
$Logic({
    description: '删除邮件',
    directory: 'office_automation(办公自动化)'
})
export declare function deleteEmail(
    emailId: String,
    permanentDelete: Boolean = false,
    operatorId: Integer
): { success: Boolean, message: String };
```

### 被前端调用

- **邮件集成（emailCommunication）**：在邮件列表页面，用户可以选择一封或多封邮件并点击删除按钮，系统会调用deleteEmail逻辑将选中的邮件标记为已删除状态。如果用户在垃圾箱中选择永久删除操作，系统会再次调用deleteEmail逻辑并设置permanentDelete参数为true，执行物理删除操作。

### 依赖的枚举、实体

- **数据建模-实体-邮件通信**：[办公自动化-实体-邮件通信（EmailCommunication）](specs/001-bootdo-management-system/plan/data-model/entity-EmailCommunication.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力
