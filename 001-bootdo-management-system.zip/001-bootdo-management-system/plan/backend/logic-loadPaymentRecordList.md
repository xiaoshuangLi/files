# 薪资管理-加载发放记录列表（loadPaymentRecordList）

- **生成时间**：2026-03-25

## 加载发放记录列表（loadPaymentRecordList）

### 功能概述

加载发放记录列表服务端逻辑用于分页查询系统中的薪资发放记录，支持按员工ID、发放月份、确认状态等条件进行过滤，并支持按指定字段和顺序进行排序。该逻辑返回符合条件的发放记录列表及其总数，每条记录包含完整的发放记录信息以及关联的月工资额数据。此服务为前端发放记录管理页面提供数据支撑，使用户能够高效地浏览、筛选和分析薪资发放情况，确保薪资管理的透明度和可追溯性。

### 功能要点

- **分页查询功能**：支持标准的分页参数（页码、每页条数），能够高效处理大量发放记录数据，避免一次性加载过多数据导致系统性能问题。分页查询结果包含当前页的数据列表和总记录数，便于前端实现完整的分页控件，提升用户体验和系统响应速度。
- **多条件过滤功能**：支持通过员工ID、发放月份、确认状态等多个维度对发放记录进行精确筛选。用户可以根据实际需求组合不同的过滤条件，快速定位到关注的发放记录，提高数据查询的准确性和效率，满足不同角色用户的查询需求。
- **动态排序功能**：支持按任意字段进行升序或降序排列，用户可以根据发放日期、月工资额等关键指标对结果进行排序，便于识别最新或金额最大的发放记录，辅助薪资管理决策和数据分析。
- **关联数据加载**：在查询发放记录的同时，自动关联获取对应的月工资额数据，包括税前金额、税后金额等关键信息。这种关联查询减少了前端的多次请求，提高了数据展示的完整性和用户体验，确保薪资发放数据的一致性。

### 逻辑签名

```naturalts path="app.logics.loadPaymentRecordList.ts"
$Logic({
    description: '分页查询发放记录列表',
    directory: 'salary_management(薪资管理)'
})
export declare function loadPaymentRecordList(page: Integer, size: Integer, sort: String, order: String, filter: app.dataSources.defaultDS.entities.PaymentRecord): { list: List<{ paymentRecord: app.dataSources.defaultDS.entities.PaymentRecord, monthlySalaryAmount: app.dataSources.defaultDS.entities.MonthlySalaryAmount }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 查询的页码，从1开始 |
| size | 每页条数 | Integer | 每页显示的记录数量 |
| sort | 排序字段 | String | 用于排序的字段名称 |
| order | 排序顺序 | String | 排序顺序，'asc'表示升序，'desc'表示降序 |
| filter | 过滤条件 | app.dataSources.defaultDS.entities.PaymentRecord | 过滤条件，包含员工ID、发放月份、确认状态等可选过滤字段 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 发放记录列表 | List<{ paymentRecord: app.dataSources.defaultDS.entities.PaymentRecord, monthlySalaryAmount: app.dataSources.defaultDS.entities.MonthlySalaryAmount }> | 发放记录列表，每项包含发放记录实体和关联的月工资额实体 |
| total | 总记录数 | Integer | 符合过滤条件的总记录数 |

### 被前端调用

- **发放记录（paymentRecord）**：发放记录页面使用此服务端逻辑加载薪资发放记录数据，支持用户进行查询、筛选、排序等操作，展示发放方式、发放日期、确认状态等详细信息，并提供数据导出功能。

### 依赖的枚举、实体

- **数据建模-实体-发放记录**：[薪资管理-实体-发放记录（PaymentRecord）](specs/001-bootdo-management-system/plan/data-model/entity-PaymentRecord.md)
- **数据建模-实体-月工资额**：[薪资管理-实体-月工资额（MonthlySalaryAmount）](specs/001-bootdo-management-system/plan/data-model/entity-MonthlySalaryAmount.md)

### 依赖的外部能力

无