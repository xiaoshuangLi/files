# 办公自动化-加载邮件列表（loadEmailList）

- **生成时间**：2026-03-25

## 加载邮件列表（loadEmailList）

### 功能概述

加载邮件列表服务端逻辑用于查询和获取用户的邮件收件箱、发件箱或特定文件夹中的邮件列表。该逻辑支持分页查询、排序、过滤和搜索功能，能够根据用户ID、邮件类型、搜索关键词等条件筛选邮件，并返回包含邮件基本信息的分页结果。通过与系统账户实体的关联，确保只返回当前用户有权访问的邮件数据。该逻辑还支持按已读状态、发送时间等字段进行排序，帮助用户高效管理大量邮件。

### 功能要点

- **分页查询与性能优化**：实现高效的分页查询机制，支持大容量邮件数据的快速加载。通过数据库索引优化和查询条件预处理，确保在高并发场景下仍能保持良好的响应性能。分页参数包括页码(page)和每页条数(size)，默认每页显示20条邮件记录，最大支持每页100条，避免一次性加载过多数据导致内存溢出或响应延迟.

- **多维度过滤与搜索**：提供灵活的邮件过滤和搜索能力，支持按邮件类型(mailType)、收件人(recipientId)、搜索关键词(searchKeyword)等多维度条件组合查询。搜索关键词支持对邮件主题(subject)和正文(emailBody)内容进行模糊匹配，帮助用户快速定位目标邮件。同时支持按已读状态(isRead)筛选未读或已读邮件，提升邮件管理效率.

- **关联数据加载**：在返回邮件列表的同时，自动关联加载发送者的系统账户信息，包括用户名、头像等基本信息，避免前端多次请求获取关联数据。通过数据库关联查询操作一次性获取完整的邮件展示所需数据，减少网络往返次数，提升用户体验。对于收件人列表，返回简化的收件人ID数组，前端可根据需要单独请求详细信息.

### 逻辑签名

```naturalts path="app.logics.loadEmailList.ts"
$Logic({
    description: '加载邮件列表',
    directory: 'office_automation(办公自动化)'
})
export declare function loadEmailList(page: Integer, size: Integer, sort: String, order: String, userId: Integer, mailType?: String, searchKeyword?: String, recipientId?: Integer): { list: List<{ email: app.dataSources.defaultDS.entities.EmailCommunication, sender: app.dataSources.defaultDS.entities.SystemAccount }>, total: Integer };
```

### 被前端调用

- **邮件集成（emailCommunication）**：邮件集成功能页面通过调用此服务端逻辑来加载用户的邮件列表，支持收件箱、发件箱等不同视图的邮件展示。该逻辑为邮件列表提供了分页、排序、搜索和过滤功能，使用户能够高效地浏览和管理大量邮件。

### 依赖的枚举、实体

- **数据建模-实体-邮件通信**：[办公自动化-实体-邮件通信（EmailCommunication）](specs/001-bootdo-management-system/plan/data-model/entity-EmailCommunication.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

#### 邮件服务（EmailService） 【当前业务功能相关】

- 关联文档：[邮件服务（EmailService）](specs/001-bootdo-management-system/plan/integration/retrieval-EmailService.md)