# 办公自动化-更新邮件（updateEmail）

- **生成时间**：2026-03-25

## 更新邮件（updateEmail）

### 功能概述

更新邮件功能允许用户修改已保存的草稿邮件或已发送邮件的部分内容。该功能支持修改邮件主题、正文内容、收件人列表等关键信息，同时保留邮件的原始ID和创建时间戳。对于已发送的邮件，系统会记录修改历史并通知相关收件人邮件内容已更新。此功能确保用户在邮件管理过程中能够灵活调整邮件内容，提高办公效率和沟通准确性。

### 功能要点

- **邮件内容更新**：用户可以修改邮件的主题、正文内容和附件，系统会验证更新后的邮件内容是否符合格式要求，并确保敏感信息不会被意外泄露。更新操作会保留原始邮件的ID和创建时间，但会更新最后修改时间和修改者信息，以便进行审计跟踪。

- **收件人列表管理**：支持添加或删除邮件的收件人，系统会验证所有收件人ID的有效性，并确保用户有权限向这些收件人发送邮件。对于已发送的邮件，添加新收件人时会自动发送更新通知，而删除收件人则会从后续的邮件交互中排除该用户。

- **版本控制与历史记录**：系统会自动保存邮件的每次修改版本，包括修改时间、修改者和具体变更内容。用户可以查看邮件的历史版本并恢复到任意先前状态，确保重要邮件内容不会因误操作而丢失。

- **权限与安全控制**：只有邮件的原始发送者或具有相应管理权限的用户才能更新邮件内容。系统会根据用户的权限级别限制可修改的字段范围，例如普通用户只能修改自己发送的草稿邮件，而管理员可以修改系统内任何邮件的关键信息。

### 逻辑签名

```naturalts path="app.logics.updateEmail.ts"
$Logic({
    description: '更新邮件',
    directory: 'office_automation(办公自动化)',
    transactional: true
})
export declare function updateEmail(emailId: String, updateData: {subject?: String; emailBody?: String; recipientIds?: String[]; isRead?: Boolean}, updaterId: Integer): app.dataSources.defaultDS.entities.EmailCommunication;
```

### 被前端调用

- **邮件集成（emailCommunication）**：在邮件详情页面，用户可以通过编辑按钮调用updateEmail服务端逻辑来修改邮件内容。该功能主要用于更新草稿邮件或对已发送邮件进行内容修正，确保邮件信息的准确性和时效性。

### 依赖的枚举、实体

- **数据建模-实体-邮件通信**：[办公自动化-实体-邮件通信（EmailCommunication）](specs/001-bootdo-management-system/plan/data-model/entity-EmailCommunication.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无匹配内容

