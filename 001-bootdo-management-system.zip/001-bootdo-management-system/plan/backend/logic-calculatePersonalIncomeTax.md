# 薪资管理-计算个人所得税（calculatePersonalIncomeTax）

- **生成时间**：2026-03-25

## 计算个人所得税（calculatePersonalIncomeTax）

### 功能概述

该服务端逻辑负责根据中国个人所得税法规定，计算员工应缴纳的个人所得税金额。系统会根据员工的月工资额、专项附加扣除、社保公积金缴纳情况以及其他收入来源等信息，按照累进税率表进行精确计算，确保税务计算的合规性和准确性。此功能是薪资管理系统的核心组成部分，为薪资发放提供准确的税后金额数据。

### 功能要点

- **个税计算规则实现**：根据最新的个人所得税法规定，实现包括起征点（5000元/月）、专项附加扣除（子女教育、继续教育、大病医疗、住房贷款利息或住房租金、赡养老人等）、社保公积金扣除等在内的完整计算规则。系统支持按月度和年度两种方式进行计算，并能处理年终奖等特殊收入的单独计税方式，确保计算结果符合国家税务法规要求。

### 逻辑签名

```naturalts path="app.logics.calculatePersonalIncomeTax.ts"
$Logic({
    description: '计算个人所得税',
    directory: 'salary_management(薪资管理)'
})
export declare function calculatePersonalIncomeTax(
  monthlySalaryAmount: Decimal,
  specialAdditionalDeductions: Decimal,
  socialSecurityAndHousingFund: Decimal,
  otherIncome?: Decimal,
  isYearEndBonus?: Boolean
): Decimal;
```

### 被前端调用

- **税务计算（taxCalculation）**：在税务计算页面中，系统调用此服务端逻辑来计算每位员工的应缴个人所得税，并展示计算结果，便于财务人员审核和确认最终税额。

### 依赖的枚举、实体

- **数据建模-实体-月工资额**：[薪资管理-实体-月工资额（MonthlySalaryAmount）](specs/001-bootdo-management-system/plan/data-model/entity-MonthlySalaryAmount.md)
- **数据建模-实体-税务计算**：[薪资管理-实体-税务计算（TaxCalculation）](specs/001-bootdo-management-system/plan/data-model/entity-TaxCalculation.md)

### 依赖的外部能力

[文件内部已经提供，无需进行生成。如果文件内部已经有 `依赖的外部能力` 内容，禁止修改或删除文件内的 `依赖的外部能力` 内容]