# 办公自动化-创建新邮件（createEmail）

- **生成时间**：2026-03-25

## 创建新邮件（createEmail）

### 功能概述

创建新邮件功能是办公自动化子域的核心服务端逻辑，用于处理用户在系统中撰写并发送新邮件的业务需求。该逻辑负责接收前端传递的邮件基本信息（包括主题、正文内容、收件人列表等），验证数据完整性，并将邮件信息持久化到数据库中。同时，该逻辑还负责更新相关用户的未读邮件计数，确保收件人能够及时收到新邮件通知。创建新邮件功能支持富文本内容和附件管理，为用户提供完整的邮件撰写体验，并与系统的用户管理、权限控制等基础功能无缝集成，确保邮件通信的安全性和可靠性。

### 功能要点

- **邮件创建与存储**：接收前端传递的邮件数据，包括主题、正文、收件人ID列表等必要信息，验证数据完整性和有效性后，将邮件信息持久化存储到EmailCommunication实体中。系统会自动生成唯一的邮件ID，并记录创建时间、创建者等审计信息，确保邮件数据的完整性和可追溯性。

- **收件人管理与通知**：处理多收件人场景，将收件人ID列表以JSON格式存储，并为每个收件人更新未读邮件计数。系统会自动触发通知机制，确保收件人能够及时获知新邮件到达，提升沟通效率。同时，该功能支持收件人列表的动态添加和删除，满足不同业务场景下的邮件发送需求。

- **邮件状态跟踪与审计**：在邮件创建过程中，系统会自动设置初始状态（如已读状态为false），并记录完整的审计信息（创建时间、创建者等）。这些信息为后续的邮件状态跟踪、阅读统计和操作审计提供数据基础，确保邮件通信过程的透明度和可管理性。

### 逻辑签名

```naturalts path="app.logics.createEmail.ts"
$Logic({
    description: '创建新邮件',
    directory: 'office_automation(办公自动化)'
})
export declare function createEmail(subject: String, emailBody: String, recipientIds: List<Integer>): app.dataSources.defaultDS.entities.EmailCommunication;
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| subject | 邮件主题 | String | 邮件的主题内容，必填项 |
| emailBody | 邮件正文 | String | 邮件的正文内容，支持富文本格式 |
| recipientIds | 收件人ID列表 | List<Integer> | 收件人的系统账户ID列表 |

| 返回值整体 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| result | 创建结果 | app.dataSources.defaultDS.entities.EmailCommunication | 创建成功的邮件通信实体，包含完整的邮件信息 |

### 被前端调用

- **邮件集成（emailIntegration）**：用户在邮件集成功能页面点击"撰写"按钮后，填写邮件主题、正文内容和收件人列表，系统调用createEmail逻辑完成新邮件的创建和存储。该逻辑确保邮件数据的完整性和一致性，并为收件人更新未读邮件状态。

### 依赖的枚举、实体

- **数据建模-实体-邮件通信**：[办公自动化-实体-邮件通信（EmailCommunication）](specs/001-bootdo-management-system/plan/data-model/entity-EmailCommunication.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

邮件发送服务：系统需要集成SMTP邮件服务器或第三方邮件服务API，用于实际发送邮件到收件人的邮箱。该外部能力负责处理邮件的传输、投递和状态反馈，确保邮件能够成功送达目标收件人。