# 内容管理-获取热门文章排行（getTopArticles）

- **生成时间**：2026-03-25

## 获取热门文章排行（getTopArticles）

### 功能概述

获取热门文章排行服务端逻辑提供内容管理系统中文章热度排名的查询功能，支持按不同维度和时间范围获取热门文章列表。该逻辑通过分析文章的浏览量、评论数、分享数等关键指标，计算文章的综合热度值，并返回指定数量的热门文章排行结果。系统支持按时间范围筛选（如最近7天、最近30天、自定义日期范围），并可按不同排序规则（如按浏览量、评论数、综合热度）进行排序。该服务为统计分析页面的热门文章排行榜功能提供数据支持，帮助内容管理员识别高价值内容，优化内容策略。

### 功能要点

- **热门文章排行计算**：基于文章的浏览量、评论数、分享数等多维度指标，采用加权算法计算每篇文章的综合热度值，确保排行结果能够准确反映文章的实际受欢迎程度和用户参与度。
- **时间范围筛选**：支持灵活的时间范围筛选功能，包括预设选项（最近7天、最近30天）和自定义日期范围，系统根据指定的时间范围统计相关指标数据，确保排行结果的时效性和针对性。
- **多维度排序支持**：提供多种排序方式选择，包括按浏览量排序、按评论数排序、按综合热度排序等，满足不同场景下的排行需求，为内容分析提供多样化的视角。
- **分页与限制控制**：支持分页查询和结果数量限制，可指定返回的热门文章数量（默认返回前10名），避免一次性返回过多数据影响系统性能，同时支持深度分页以满足详细分析需求。

### 逻辑签名

```naturalts path="app.logics.getTopArticles.ts"
$Logic({
    description: '获取热门文章排行',
    directory: 'content_management(内容管理)'
})
export declare function getTopArticles(maxCount: Integer, timeRangeStart: DateTime, timeRangeEnd: DateTime, sortBy: String, sortOrder: String): { list: List<{ article: app.dataSources.defaultDS.entities.ArticleContent, viewCount: Integer, commentCount: Integer, shareCount: Integer, heatScore: Decimal }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| maxCount | 返回数量限制 | Integer | 指定返回的热门文章数量，默认为10 |
| timeRangeStart | 时间范围开始 | DateTime | 统计时间范围的开始时间，用于筛选指定时间段内的文章数据 |
| timeRangeEnd | 时间范围结束 | DateTime | 统计时间范围的结束时间，用于筛选指定时间段内的文章数据 |
| sortBy | 排序字段 | String | 排序依据字段，可选值包括'viewCount'（浏览量）、'commentCount'（评论数）、'heatScore'（综合热度）等 |
| sortOrder | 排序顺序 | String | 排序顺序，可选值为'asc'（升序）或'desc'（降序），默认为'desc' |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 热门文章列表 | List<{ article: app.dataSources.defaultDS.entities.ArticleContent, viewCount: Integer, commentCount: Integer, shareCount: Integer, heatScore: Decimal }> | 热门文章列表，每个列表项包含文章实体和相关的统计指标数据 |
| total | 总条数 | Integer | 符合条件的热门文章总数量 |

### 被前端调用

- **统计分析（contentStatistics）**：在统计分析页面中，该服务端逻辑用于获取指定时间范围内的热门文章排行榜数据，支持按不同指标排序展示，帮助内容管理员识别高价值内容并进行内容策略优化。

### 依赖的枚举、实体

- **数据建模-实体-文章内容**：[内容管理-实体-文章内容（ArticleContent）](specs/001-bootdo-management-system/plan/data-model/entity-ArticleContent.md)

### 依赖的外部能力

无外部能力依赖。