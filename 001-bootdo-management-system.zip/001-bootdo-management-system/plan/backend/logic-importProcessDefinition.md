# 工作流引擎-导入流程定义（importProcessDefinition）

- **生成时间**：2026-03-25

## 导入流程定义（importProcessDefinition）

### 功能概述

导入流程定义功能允许系统管理员通过上传BPMN格式的XML文件来批量创建或更新工作流流程模板。该功能支持标准BPMN 2.0格式的流程定义文件导入，系统会自动解析文件内容，验证流程结构的合法性，并将有效的流程定义持久化到数据库中。导入过程中，系统会检查文件格式是否正确、流程节点配置是否完整、是否存在重复的流程标识等关键要素，确保导入的流程定义能够正常用于后续的流程实例化和执行。此功能大大简化了复杂业务流程的建模过程，提高了流程定义的复用性和部署效率。

### 功能要点

- **BPMN文件解析与验证**：系统能够正确解析上传的BPMN XML文件，提取流程名称、描述和完整的流程定义数据，并对文件格式和结构进行严格验证，确保导入的流程定义符合BPMN 2.0标准规范，避免因格式错误导致后续流程执行异常。
- **批量导入处理**：支持单次操作导入多个流程定义，系统会逐个处理每个流程定义，分别进行验证和持久化操作，并在导入完成后返回详细的处理结果，包括成功导入的数量、失败的数量及具体的错误信息，便于管理员进行问题排查和修正。
- **重复流程检测**：在导入过程中，系统会自动检测是否存在相同名称或标识的流程定义，根据预设策略（如覆盖或跳过）处理重复项，确保流程定义库的数据一致性和完整性，避免因重复定义导致的业务混乱。
- **错误处理与回滚**：当导入过程中出现任何验证错误或持久化失败时，系统会立即停止当前流程定义的处理，记录详细的错误日志，并在必要时执行事务回滚，确保数据库状态的一致性，同时向用户提供清晰的错误提示信息。

### 逻辑签名

```naturalts path="app.logics.importProcessDefinition.ts"
$Logic({
    description: '导入BPMN格式的流程定义文件',
    directory: 'workflow_engine(工作流引擎)',
    transactional: true
})
export declare function importProcessDefinition(bpmnFiles: List<String>): { successCount: Integer, failureCount: Integer, errors: List<{ fileName: String, errorMessage: String }> };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| bpmnFiles | BPMN文件内容列表 | List<String> | 包含BPMN XML格式内容的字符串列表，每个字符串代表一个完整的BPMN流程定义文件 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| successCount | 成功导入数量 | Integer | 成功导入并保存的流程定义数量 |
| failureCount | 失败导入数量 | Integer | 导入失败的流程定义数量 |
| errors | 错误详情 | List<{ fileName: String, errorMessage: String }> | 导入失败的详细错误信息列表，包含文件名和具体错误描述 |

### 被前端调用

- **流程定义（processDefinition）**：流程定义管理页面通过导入按钮调用此服务端逻辑，实现BPMN流程定义文件的批量导入功能，用户选择本地BPMN文件后，前端将文件内容转换为字符串格式传递给此逻辑进行处理。

### 依赖的枚举、实体

- **数据建模-实体-流程定义**：[工作流引擎-实体-流程定义（ProcessDefinition）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessDefinition.md)

### 依赖的外部能力

（无）