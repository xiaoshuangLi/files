# 质量管理-查询整改进度列表（queryRectificationProgressList）

- **生成时间**：2026-03-25

## 查询整改进度列表（queryRectificationProgressList）

### 功能概述

查询整改进度列表服务端逻辑提供分页查询系统中整改进度记录的功能，支持按整改任务ID、完成百分比范围、更新时间等条件进行过滤，并支持按指定字段和顺序进行排序。该逻辑返回符合条件的整改进度列表及其总数，用于在整改进度管理页面中展示整改任务的执行情况。通过关联查询整改任务、质量问题等相关实体，该逻辑能够提供完整的整改进度上下文信息，包括任务描述、问题标题、责任人等关键数据，为质量管理人员提供全面的整改跟踪视图。

### 功能要点

- **分页查询与排序功能**：支持标准的分页参数（页码、每页条数）和排序参数（排序字段、排序方向），能够高效处理大量整改进度数据，避免一次性加载过多数据导致性能问题。默认按更新时间降序排列，确保最新的整改进度记录优先显示，便于用户及时了解整改执行的最新状态。
- **多条件过滤功能**：支持通过整改任务ID、完成百分比范围（最小值和最大值）、更新时间范围等多个维度对整改进度数据进行精确筛选。用户可以根据实际需求组合不同的过滤条件，快速定位到关注的整改进度记录，提高数据查询的准确性和效率。
- **关联数据查询**：在查询整改进度记录的同时，自动关联获取对应的整改任务、质量问题和责任人的详细信息。这种关联查询减少了前端的多次请求，提供了完整的整改上下文，包括任务描述、问题标题、责任人姓名等关键信息，便于用户全面了解整改任务的背景和执行情况。
- **进度状态计算**：根据整改进度的完成百分比自动计算并返回相应的进度状态描述（如"未开始"、"进行中"、"已完成"等），帮助用户直观理解整改任务的执行状态，无需手动计算百分比数值。

### 逻辑签名

```naturalts path="app.logics.queryRectificationProgressList.ts"
$Logic({
    description: '分页查询整改进度列表',
    directory: 'quality_management(质量管理)'
})
export declare function queryRectificationProgressList(page: Integer, size: Integer, sort: String, order: String, filter: { rectificationTaskId?: Integer, minCompletionPercentage?: Integer, maxCompletionPercentage?: Integer, updatedTimeFrom?: DateTime, updatedTimeTo?: DateTime }): { list: List<{ rectificationProgress: app.dataSources.defaultDS.entities.RectificationProgress, rectificationTask: app.dataSources.defaultDS.entities.RectificationTask, qualityIssue: app.dataSources.defaultDS.entities.QualityIssue, assignee: app.dataSources.defaultDS.entities.SystemAccount }>, total: Integer };
```

| 输入参数 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| page | 页码 | Integer | 查询的页码，从1开始 |
| size | 每页条数 | Integer | 每页显示的记录数量 |
| sort | 排序字段 | String | 用于排序的字段名称 |
| order | 排序顺序 | String | 排序顺序，'asc'表示升序，'desc'表示降序 |
| filter | 过滤条件 | { rectificationTaskId?: Integer, minCompletionPercentage?: Integer, maxCompletionPercentage?: Integer, updatedTimeFrom?: DateTime, updatedTimeTo?: DateTime } | 过滤条件对象，包含整改任务ID、完成百分比范围、更新时间范围等可选过滤字段 |

| 返回值字段 | 标题 | 数据类型 | 描述 |
| --- | --- | --- | --- |
| list | 整改进度列表 | List<{ rectificationProgress: app.dataSources.defaultDS.entities.RectificationProgress, rectificationTask: app.dataSources.defaultDS.entities.RectificationTask, qualityIssue: app.dataSources.defaultDS.entities.QualityIssue, assignee: app.dataSources.defaultDS.entities.SystemAccount }> | 整改进度记录列表，每项包含整改进度实体及其关联的整改任务、质量问题和责任人信息 |
| total | 总记录数 | Integer | 符合过滤条件的总记录数 |

### 被前端调用

- **整改进度（rectificationProgress）**：整改进度管理页面使用此服务端逻辑加载整改进度数据列表，支持用户进行查询、筛选、排序等操作，展示整改任务的执行进度、关联的质量问题及责任人等详细信息。

### 依赖的枚举、实体

- **数据建模-实体-整改进度**：[质量管理-实体-整改进度（RectificationProgress）](specs/001-bootdo-management-system/plan/data-model/entity-RectificationProgress.md)
- **数据建模-实体-整改任务**：[质量管理-实体-整改任务（RectificationTask）](specs/001-bootdo-management-system/plan/data-model/entity-RectificationTask.md)
- **数据建模-实体-质量问题**：[质量管理-实体-质量问题（QualityIssue）](specs/001-bootdo-management-system/plan/data-model/entity-QualityIssue.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无