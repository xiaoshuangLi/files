# 薪资管理-批量处理薪资（batchProcessSalary）

- **生成时间**：2026-03-25

## 批量处理薪资（batchProcessSalary）

### 功能概述

批量处理薪资服务端逻辑负责高效处理大量员工的月度薪资计算、税务计算和薪资报表生成任务。该逻辑支持按部门、岗位或指定员工列表进行批量薪资处理，能够自动根据员工的薪资结构计算税前金额，并结合当前税收政策计算个人所得税，最终生成准确的税后金额。系统会为每个处理的员工记录详细的薪资计算过程，并自动生成对应的月工资额实体和税务计算实体。同时，该逻辑还支持薪资报表的批量生成，确保财务部门能够及时获取完整的薪资发放数据。批量处理过程中会进行数据验证和异常处理，确保薪资计算的准确性和一致性，对于处理失败的记录会提供详细的错误信息以便后续排查和重试。

### 功能要点

- **批量薪资计算处理**：支持一次性处理多个员工的月度薪资计算任务，系统会根据每个员工关联的薪资结构（包含基本工资、奖金、津贴等组成部分）自动计算税前总金额。处理过程采用高效的并行计算机制，显著提升大批量薪资处理的性能，同时确保每个员工的薪资计算结果准确无误。系统会验证薪资结构的有效性和完整性，对于缺失或无效的薪资结构会标记为处理失败并记录详细错误信息。

- **自动化税务计算**：在完成薪资计算后，系统会自动执行个人所得税计算逻辑，根据当前有效的税收政策和税率表，计算每位员工应缴纳的个人所得税金额。税务计算考虑了各项扣除项和适用税率，确保计算结果符合国家税收法规要求。系统会为每次税务计算生成独立的税务计算记录，包含税额、适用税率、计算时间等关键信息，为薪资报表和财务审计提供完整数据支持。

- **薪资数据持久化与报表生成**：批量处理完成后，系统会将所有计算结果持久化到数据库中，包括创建月工资额实体（记录税前金额、税后金额、支付月份等信息）和税务计算实体（记录税额、税率等信息）。同时，系统会自动生成对应的薪资报表实体，包含详细的薪资构成明细，为财务部门提供标准化的薪资发放凭证。所有数据操作都包含完整的事务管理，确保数据的一致性和完整性。

### 逻辑签名

```naturalts path="app.logics.batchProcessSalary.ts"
$Logic({
    description: '批量处理薪资',
    directory: 'salary_management(薪资管理)'
})
export declare function batchProcessSalary(
  departmentId?: Integer,
  positionId?: Integer,
  employeeIds?: List<Integer>,
  paymentMonth: String
): {
  successCount: Integer;
  failedCount: Integer;
  failedDetails: List<{
    employeeId: Integer;
    errorMessage: String;
  }>;
  status: String;
};
```

### 被前端调用

- **月工资额计算（monthlySalaryAmount）**：在月工资额计算页面中，用户可以通过批量处理功能触发此服务端逻辑，对选定的员工或整个部门进行月度薪资的批量计算和处理，确保薪资数据的及时性和准确性。
- **薪资报表（salaryReport）**：在薪资报表页面中，当需要为特定月份生成完整的薪资报表时，系统会调用此批量处理逻辑，确保所有员工的薪资数据都已正确计算并生成相应的报表记录。

### 依赖的枚举、实体

- **数据建模-实体-月工资额**：[薪资管理-实体-月工资额（MonthlySalaryAmount）](specs/001-bootdo-management-system/plan/data-model/entity-MonthlySalaryAmount.md)
- **数据建模-实体-税务计算**：[薪资管理-实体-税务计算（TaxCalculation）](specs/001-bootdo-management-system/plan/data-model/entity-TaxCalculation.md)
- **数据建模-实体-薪资报表**：[薪资管理-实体-薪资报表（SalaryReport）](specs/001-bootdo-management-system/plan/data-model/entity-SalaryReport.md)
- **数据建模-实体-薪资结构**：[薪资管理-实体-薪资结构（SalaryStructure）](specs/001-bootdo-management-system/plan/data-model/entity-SalaryStructure.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无外部能力依赖