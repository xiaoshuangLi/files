# 环保管理-更新合规检查（updateComplianceInspection）

- **生成时间**：2026-03-25

## 更新合规检查（updateComplianceInspection）

### 功能概述

更新合规检查服务端逻辑用于修改已存在的环保合规检查记录，支持环保管理人员对已录入的合规检查信息进行修正和更新。该逻辑允许修改检查员、检查发现、合规状态、检查时间和解决时间等关键字段，确保合规检查数据的准确性和时效性。当合规状态发生变化时，系统会自动记录更新时间戳，并在必要时触发相关业务流程，如不合规项的整改措施关联或已整改项的状态验证。

### 功能要点

- **合规检查信息更新**：支持修改合规检查的所有核心字段，包括检查员（inspectorId）、检查发现（findings）、合规状态（status）、检查时间（inspectedAt）和解决时间（resolvedAt）。系统会验证必填字段的完整性，并确保检查时间不晚于当前时间。对于合规状态的变更，系统会执行相应的业务规则校验，例如当状态变更为"已整改"时，必须提供有效的解决时间。

### 逻辑签名

```naturalts path="app.logics.updateComplianceInspection.ts"
$Logic({
    description: '更新合规检查记录',
    directory: 'environmental_management(环保管理)',
    transactional: true
})
export declare function updateComplianceInspection(
  id: Integer,
  inspectorId: Integer,
  findings: String,
  status: app.enums.ComplianceStatusEnum,
  inspectedAt: DateTime,
  resolvedAt?: DateTime
): app.dataSources.defaultDS.entities.ComplianceInspection;
```

### 被前端调用

- **合规检查（complianceInspection）**：在合规检查页面中，用户点击某条记录的"编辑"按钮后，通过表单弹框修改合规检查信息，提交后调用此服务端逻辑更新合规检查记录，并刷新列表显示最新数据。

### 依赖的枚举、实体

- **数据建模-枚举-环保合规状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-合规检查**：[环保管理-实体-合规检查（ComplianceInspection）](specs/001-bootdo-management-system/plan/data-model/entity-ComplianceInspection.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)

### 依赖的外部能力

无外部能力依赖。