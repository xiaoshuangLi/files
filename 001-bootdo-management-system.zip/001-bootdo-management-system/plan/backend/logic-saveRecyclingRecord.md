# 环保管理-保存回收记录（saveRecyclingRecord）

- **生成时间**：2026-03-25

## 保存回收记录（saveRecyclingRecord）

### 功能概述

保存回收记录服务端逻辑用于处理企业环保相关的废弃物回收处理活动的数据存储操作，是环保管理模块的核心业务功能之一。该逻辑支持创建新的回收记录或更新已存在的回收记录，确保回收数据的完整性和一致性。系统接收包含回收物品类型、回收数量、回收日期、处理方式、回收单位、合规状态等关键信息的请求参数，进行必要的业务验证后持久化到数据库中。当回收记录的合规状态为"不合规"时，该逻辑会自动触发关联整改措施和风险评估流程的初始化。通过标准化的回收记录管理，企业能够有效监控资源回收利用情况，确保符合环保法规要求，并为可持续发展决策提供准确的数据支持。

### 功能要点

- **回收记录数据完整性验证**：在保存回收记录前，系统会对所有必填字段进行严格验证，包括回收物品类型、回收数量、回收日期、处理方式、回收单位和合规状态等关键信息。任何必填字段缺失或格式不符合要求都会导致保存失败，并返回具体的错误信息指导用户修正。系统还会对回收数量进行数值范围验证，确保其为正数且在合理范围内，防止数据录入错误影响后续的统计分析和合规检查。

- **合规状态自动关联处理**：当用户提交的回收记录合规状态为"不合规"时，系统会自动初始化关联的整改措施和风险评估流程。这包括创建整改任务记录、设置风险评估参数，并将相关信息关联到当前回收记录中。这种自动化处理机制确保了环保问题能够得到及时响应和跟踪，避免因人为疏忽导致环保违规问题被忽视，从而降低企业的环境风险和法律风险。

- **回收记录版本控制与审计**：系统在保存回收记录时会自动记录操作日志，包括创建时间、更新时间、创建者和更新者等审计信息。对于更新操作，系统会保留历史版本记录，确保回收数据的可追溯性。这种版本控制机制不仅满足了环保监管的数据完整性要求，还为企业内部的质量管理和责任追溯提供了可靠的数据基础。

### 逻辑签名

```naturalts path="app.logics.saveRecyclingRecord.ts"
$Logic({
    description: '保存回收记录',
    directory: 'environmental_management(环保管理)',
    transactional: true
})
export declare function saveRecyclingRecord(
    recordId?: Integer,
    wasteType: String,
    recyclingQuantity: Decimal,
    recyclingDate: Date,
    treatmentMethod: String,
    recyclingUnit: String,
    complianceStatus: app.enums.ComplianceStatusEnum,
    departmentId: Integer
): Integer;
```

### 被前端调用

- **回收记录（recyclingRecord）**：在回收记录页面中，用户点击"新增"或"编辑"按钮后填写表单信息，系统调用此服务端逻辑保存回收记录数据。该逻辑实现了回收记录的创建和更新功能，支持完整的CRUD操作中的C（新建）和U（修改）操作。

### 依赖的枚举、实体

- **数据建模-枚举-环保合规状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-环境监测**：[环保管理-实体-环境监测（EnvironmentalMonitoring）](specs/001-bootdo-management-system/plan/data-model/entity-EnvironmentalMonitoring.md)

### 依赖的外部能力

无外部能力依赖