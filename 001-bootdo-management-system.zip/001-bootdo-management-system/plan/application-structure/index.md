# 应用架构概览

- **生成时间**：2026-03-25

## 一、核心领域划分

- **系统管理（SystemManagement）**
- **办公自动化（OfficeAutomation）**
- **工作流引擎（WorkflowEngine）**
- **质量管理（QualityManagement）**
- **内容管理（ContentManagement）**
- **预算管理（BudgetManagement）**
- **分包商管理（SubcontractorManagement）**
- **薪资管理（SalaryManagement）**
- **环保管理（EnvironmentalManagement）**
- **权限中心（PermissionCenter）**

## 二、关键服务集成

- **Activiti工作流引擎（ActivitiWorkflowEngine）**
- **Shiro安全框架（ShiroSecurityFramework）**
- **BootDo基础框架（BootDoFramework）**
- **MySQL数据库（MySQLDatabase）**
- **Redis缓存（RedisCache）**
- **文件存储服务（FileStorageService）**
- **邮件服务（EmailService）**
- **日志服务（LoggingService）**

## 三、国际化适配

适配中文（cn）一种语言。