# 应用架构-核心领域划分

- **生成时间**：2026-03-25

结合需求文档，详细说明核心领域划分面对实际业务系统的划分思路，并说明多个业务子域之间的关联关系。

## 系统管理（SystemManagement）

- **职责**：实现系统基础管理功能，包括用户账户管理、角色权限定义、访问控制、导航菜单配置、组织部门管理、数据字典维护、操作日志记录、在线会话管理和全局系统配置。
- **核心实体**：系统账户（SystemAccount）、用户角色（UserRole）、访问控制（AccessControl）、导航菜单（NavigationMenu）、组织部门（OrganizationDepartment）、数据字典（DataDictionary）、操作记录（OperationRecord）、在线会话（OnlineSession）、全局配置（GlobalConfiguration）
- **实体独立性说明**：系统管理子域负责所有基础用户和权限数据的管理，其他子域通过引用这些实体的标识符来实现权限控制和用户关联，确保了权限数据的一致性和安全性。

## 办公自动化（OfficeAutomation）

- **职责**：提供日常办公协作功能，包括通知公告发布、文件存储管理、日程安排、会议预约、待办任务跟踪、邮件通信、文档协作和个人工作台定制。
- **核心实体**：通知公告（NoticeAnnouncement）、文件存储（FileStorage）、日程安排（ScheduleArrangement）、会议预约（MeetingReservation）、待办任务（TodoTask）、邮件通信（EmailCommunication）、文档协作（DocumentCollaboration）、个人工作台（PersonalWorkspace）
- **实体独立性说明**：办公自动化子域专注于提升办公效率的协作工具，其核心实体具有独立的生命周期和业务规则，与其他子域通过事件驱动的方式进行集成。

## 工作流引擎（WorkflowEngine）

- **职责**：提供业务流程自动化能力，包括流程定义模板、流程实例执行、任务节点处理、用户组管理、表单数据集成、审批流程管理和流程监控。
- **核心实体**：流程定义（ProcessDefinition）、流程实例（ProcessInstance）、任务节点（TaskNode）、用户组（UserGroup）、表单集成（FormIntegration）、审批流程（ApprovalProcess）、节点配置（NodeConfiguration）、流程监控（ProcessMonitoring）
- **实体独立性说明**：工作流引擎子域作为流程中枢，其核心实体管理着所有业务流程的定义和执行状态，其他子域通过调用工作流引擎的接口来启动和管理特定业务流程。

## 质量管理（QualityManagement）

- **职责**：实现质量管控功能，包括质量问题登记、整改任务分配、质量检验执行、问题跟踪处理、验收标准定义、检验报告生成、整改进度监控和质量指标管理。
- **核心实体**：质量问题（QualityIssue）、整改任务（RectificationTask）、质量检验（QualityInspection）、问题跟踪（IssueTracking）、验收标准（AcceptanceStandard）、检验报告（InspectionReport）、整改进度（RectificationProgress）、质量指标（QualityIndicator）
- **实体独立性说明**：质量管理子域专注于质量问题的全生命周期管理，其核心实体独立维护质量问题相关的所有数据，与环保管理子域在整改任务方面有协作关系。

## 内容管理（ContentManagement）

- **职责**：提供内容创作和管理功能，包括文章内容管理、栏目结构维护、评论互动处理、用户订阅服务、内容权限控制、SEO优化配置、附件资源管理和内容统计分析。
- **核心实体**：文章内容（ArticleContent）、栏目结构（ColumnStructure）、评论互动（CommentInteraction）、用户订阅（UserSubscription）、内容权限（ContentPermission）、SEO优化（SeoOptimization）、附件资源（AttachmentResource）、内容统计（ContentStatistics）
- **实体独立性说明**：内容管理子域独立管理所有内容相关数据，其核心实体具有完整的内容生命周期管理能力，通过系统管理子域的权限控制来确保内容安全。

## 预算管理（BudgetManagement）

- **职责**：实现预算管控功能，包括预算类型定义、预算周期管理、审批流程配置、报表格式设置、预算分配执行、执行监控跟踪、调整申请处理和分析报告生成。
- **核心实体**：预算类型（BudgetType）、预算周期（BudgetCycle）、审批流程（ApprovalWorkflow）、报表格式（ReportFormat）、预算分配（BudgetAllocation）、执行监控（ExecutionMonitoring）、调整申请（AdjustmentApplication）、分析报告（AnalysisReport）
- **实体独立性说明**：预算管理子域独立维护预算相关的所有数据和流程，其核心实体通过工作流引擎子域来实现预算审批流程的自动化。

## 分包商管理（SubcontractorManagement）

- **职责**：提供分包商全生命周期管理功能，包括分包商信息维护、资质证书管理、合同关联处理、人员配置管理、评估记录维护、付款管理、项目分配和风险评估。
- **核心实体**：分包商信息（SubcontractorInformation）、资质证书（QualificationCertificate）、合同关联（ContractAssociation）、人员配置（PersonnelConfiguration）、评估记录（EvaluationRecord）、付款管理（PaymentManagement）、项目分配（ProjectAssignment）、风险评估（RiskAssessment）
- **实体独立性说明**：分包商管理子域独立管理分包商相关的所有数据，其人员配置实体与薪资管理子域有数据同步关系，确保薪资计算的准确性。

## 薪资管理（SalaryManagement）

- **职责**：实现薪资计算和发放功能，包括薪资结构定义、薪资调整审批、薪酬档级管理、月工资额计算、年薪总额统计、薪资报表生成、税务计算和发放记录维护。
- **核心实体**：薪资结构（SalaryStructure）、薪资调整（SalaryAdjustment）、薪酬档级（CompensationGrade）、月工资额（MonthlySalaryAmount）、年薪总额（AnnualSalaryTotal）、薪资报表（SalaryReport）、税务计算（TaxCalculation）、发放记录（PaymentRecord）
- **实体独立性说明**：薪资管理子域独立维护薪资相关的所有计算和发放数据，其核心实体通过工作流引擎子域来实现薪资调整的审批流程。

## 环保管理（EnvironmentalManagement）

- **职责**：提供环保合规管理功能，包括环境监测数据采集、排放控制管理、合规检查执行、整改措施制定、报告提交处理、环境风险评估、应急预案管理和资源消耗统计。
- **核心实体**：环境监测（EnvironmentalMonitoring）、排放控制（EmissionControl）、合规检查（ComplianceInspection）、整改措施（RectificationMeasure）、报告提交（ReportSubmission）、环境风险评估（EnvironmentalRiskAssessment）、应急预案（EmergencyPlan）、资源消耗（ResourceConsumption）
- **实体独立性说明**：环保管理子域独立管理环保相关的所有数据和流程，其整改措施实体与质量管理子域的整改任务有协作关系，实现跨模块的问题跟踪。

## 权限中心（PermissionCenter）

- **职责**：实现需求涉及 登录、认证、鉴权、权限管理、用户管理、角色管理、部门管理 等功能。
- **核心实体**：用户（LcapUser）、角色（LcapRole）、权限（LcapPermission）、资源（LcapResource）、部门（LcapDepartment）、角色与权限映射（LcapRolePerMapping）、用户与角色映射（LcapUserRoleMapping）、权限与资源映射（LcapPerResMapping）、用户与部门映射（LcapUserDeptMapping）