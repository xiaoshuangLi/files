# 邮件服务（EmailService）

提供企业级邮件发送功能，支持SMTP协议对接，用于系统通知、用户注册验证、密码重置等业务场景的邮件发送。

- 关键字：邮件发送、SMTP、通知邮件、企业邮件、邮件API

## 依赖的外部能力

### 后端依赖库（library）

#### send_email@6.1.7【当前业务功能相关】

**send_email@6.1.7**：`{"symbol":"send_email","version":"6.1.7"}`

- **sendEmail**：发送邮件

#### send_email@6.1.7【当前业务功能相关】

**send_email@6.1.7**：`{"symbol":"send_email","version":"6.1.7"}`

- **sendEmailWithAttach2**：发送邮件，支持设置端口、协议

#### send_email@6.1.7【当前业务功能相关】

**send_email@6.1.7**：`{"symbol":"send_email","version":"6.1.7"}`

- **sendEmailWithAttach2Async**：异步发送邮件，支持更多收件人(返回true不代表发送成功)

### API 服务（interface）

无匹配内容

### 连接器（connector）

无匹配内容

