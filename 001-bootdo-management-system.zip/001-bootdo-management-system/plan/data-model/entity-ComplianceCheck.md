# 环保管理-实体-合规检查（ComplianceCheck）

- **生成时间**：2026-03-25

## 合规检查（ComplianceCheck）

合规检查实体用于记录和管理企业环保法规的合规性检查活动，包括检查计划、执行过程、发现的问题以及合规状态评估。该实体支持环保管理人员对企业生产经营活动的环保合规情况进行系统化检查和跟踪，确保企业运营符合相关环保法规要求。每次合规检查都会记录检查员信息、被检查企业或部门、检查发现的具体问题、合规状态（合规、不合规、整改中或已整改），以及检查和解决的时间戳。对于不合规的情况，系统会自动关联整改措施实体，形成从问题发现到整改完成的闭环管理流程。该实体还与环境风险评估实体关联，为风险评估提供基础数据支持，帮助企业识别和预防潜在的环保风险。通过合规检查实体，企业能够建立完善的环保合规管理体系，及时发现并解决环保问题，降低环保违规风险。

```naturalts path="app.dataSources.defaultDS.entities.ComplianceCheck.ts"
@Entity({
    title: "合规检查",
    directory: "environmental_management(环保管理)"
})
export class ComplianceCheck {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "检查员",
        description: "执行合规检查的人员ID",
        required: true
    })
    @EntityRelation<app.dataSources.defaultDS.entities.SystemAccount['id']>('PROTECT')
    inspectorId: Integer;

    @EntityProperty({
        title: "被检查企业",
        description: "接受合规检查的企业或部门ID",
        required: true
    })
    @EntityRelation<app.dataSources.defaultDS.entities.Department['id']>('PROTECT')
    inspectedEntityId: Integer;

    @EntityProperty({
        title: "检查发现",
        description: "合规检查中发现的具体问题和情况描述",
        dbType: TEXT,
        required: true
    })
    findings: String;

    @EntityProperty({
        title: "合规状态",
        description: "合规检查的结果状态",
        required: true
    })
    status: app.enums.ComplianceStatusEnum = app.enums.ComplianceStatusEnum['Compliant'];

    @EntityProperty({
        title: "检查时间",
        description: "执行合规检查的具体时间",
        required: true
    })
    checkedAt: DateTime;

    @EntityProperty({
        title: "解决时间",
        description: "不合规问题得到解决的时间"
    })
    resolvedAt: DateTime;

    @EntityProperty({
        title: "检查类型",
        description: "合规检查的类型，如例行检查、专项检查等",
        required: true
    })
    checkType: String = '例行检查';

    @EntityProperty({
        title: "检查依据",
        description: "本次合规检查所依据的法规或标准",
        dbType: TEXT
    })
    regulatoryBasis: String = '';

    @EntityProperty({
        title: "检查范围",
        description: "本次合规检查覆盖的范围或区域",
        dbType: TEXT
    })
    inspectionScope: String = '';
}
export const ComplianceCheckEntity = createEntity<ComplianceCheck>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| inspectorId | 检查员 | Integer | 非空、外键关联实体 SystemAccount（PROTECT） | | | |
| inspectedEntityId | 被检查企业 | Integer | 非空、外键关联实体 Department（PROTECT） | | | |
| findings | 检查发现 | String | 非空 | | TEXT | |
| status | 合规状态 | app.enums.ComplianceStatusEnum | 非空 | ComplianceStatusEnum['Compliant'] | | |
| checkedAt | 检查时间 | DateTime | 非空 | | | |
| resolvedAt | 解决时间 | DateTime | | | | |
| checkType | 检查类型 | String | 非空 | '例行检查' | | |
| regulatoryBasis | 检查依据 | String | | '' | TEXT | |
| inspectionScope | 检查范围 | String | | '' | TEXT | |

### 依赖的枚举和实体

- **数据建模-枚举-环保合规状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)
- **数据建模-实体-部门**：[系统管理-实体-部门信息（Department）](specs/001-bootdo-management-system/plan/data-model/entity-Department.md)
- **数据建模-实体-整改措施**：[环保管理-实体-整改措施（RectificationMeasure）](specs/001-bootdo-management-system/plan/data-model/entity-RectificationMeasure.md)
- **数据建模-实体-环境风险评估**：[环保管理-实体-环境风险评估（EnvironmentalRiskAssessment）](specs/001-bootdo-management-system/plan/data-model/entity-EnvironmentalRiskAssessment.md)