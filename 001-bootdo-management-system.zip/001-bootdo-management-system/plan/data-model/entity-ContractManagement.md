# 预算管理-实体-合同管理（ContractManagement）

- **生成时间**：2026-03-25

## 合同管理（ContractManagement）

合同管理实体用于存储和管理企业各类合同的基本信息，是预算管理模块的核心数据实体之一。该实体包含合同的唯一标识、合同编号、所属板块、甲方名称和合同名称等关键字段，支持合同的创建、查询、编辑和删除等全生命周期管理操作。通过合同管理实体，系统能够为预算编制和执行提供准确的合同基础数据支持，确保企业合同信息的规范化管理。该实体还支持合同编号的唯一性验证、按多种条件进行模糊查询和筛选，以及将合同数据导出为Excel文件等功能，满足合同管理人员的日常业务需求。合同管理功能作为预算管理的重要组成部分，为企业的合同数据提供了统一的存储和管理平台，有效支撑了预算部门编制、预算修正、分包合同管理等相关业务流程，确保了合同信息在整个预算管理生命周期中的一致性和准确性。

```naturalts path="app.dataSources.defaultDS.entities.ContractManagement.ts"
@Entity({
    title: "合同管理",
    directory: "budget_management(预算管理)"
})
export class ContractManagement {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "合同编号",
        description: "合同的唯一标识编号",
        required: true
    })
    contractCode: String = '';

    @EntityProperty({
        title: "板块",
        description: "合同所属业务板块，选项包括：建筑工程、设备采购、技术服务等",
        required: true
    })
    sector: String = '';

    @EntityProperty({
        title: "甲方名称",
        description: "合同甲方单位名称",
        required: true
    })
    partyAName: String = '';

    @EntityProperty({
        title: "合同名称",
        description: "合同的完整名称",
        required: true
    })
    contractName: String = '';
}
export const ContractManagementEntity = createEntity<ContractManagement>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| contractCode | 合同编号 | String | 非空、唯一 | '' | | |
| sector | 板块 | String | 非空 | '' | | |
| partyAName | 甲方名称 | String | 非空 | '' | | |
| contractName | 合同名称 | String | 非空 | '' | | |

### 依赖的枚举和实体

（无）