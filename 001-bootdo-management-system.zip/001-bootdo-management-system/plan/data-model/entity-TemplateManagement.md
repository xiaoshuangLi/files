# 通用业务模块-实体-模板管理（TemplateManagement）

- **生成时间**：2026-03-25

## 模板管理（TemplateManagement）

模板管理实体用于管理系统中环境报告相关的模板配置，支持月度、季度、年度等不同类型环境报告的模板创建、编辑和管理。该实体提供标准化的模板结构定义，包含模板基本信息、内容结构、适用范围、状态控制等核心属性，确保环境报告数据的一致性和规范性。通过模板管理实体，环保管理人员可以灵活配置不同类型的环境报告模板，定义报告所需的字段结构、数据格式和填报要求，为环境报告的定期提交、审核审批和归档提供基础支撑。该实体还支持模板版本管理和启用状态控制，确保模板使用的准确性和时效性。

```naturalts path="app.dataSources.defaultDS.entities.TemplateManagement.ts"
@Entity({
    title: "模板管理",
    directory: "general_business(通用业务模块)"
})
export class TemplateManagement {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "模板名称",
        description: "环境报告模板的显示名称，用于标识模板用途",
        required: true
    })
    templateName: String;

    @EntityProperty({
        title: "模板编码",
        description: "环境报告模板的唯一编码，用于程序调用和识别",
        required: true
    })
    templateCode: String;

    @EntityProperty({
        title: "模板类型",
        description: "模板适用的报告类型，如月度、季度、年度环境报告",
        required: true
    })
    templateType: String;

    @EntityProperty({
        title: "模板描述",
        description: "模板的详细说明和使用场景",
        dbType: TEXT
    })
    description: String = '';

    @EntityProperty({
        title: "模板内容",
        description: "模板的JSON格式结构定义，包含字段配置和布局信息",
        required: true,
        "dbType": "TEXT",
        "rules": [maxLength(65535)]
    })
    templateContent: String;

    @EntityProperty({
        title: "适用部门",
        description: "模板适用的部门范围，空值表示适用于所有部门"
    })
    applicableDepartment: String = '';

    @EntityProperty({
        title: "是否启用",
        description: "控制模板是否可以被使用",
        required: true
    })
    isEnabled: Boolean = true;

    @EntityProperty({
        title: "模板版本",
        description: "模板的版本号，用于版本控制和管理",
        required: true
    })
    version: String = '1.0';

    @EntityProperty({
        title: "排序序号",
        description: "模板在列表中的显示顺序"
    })
    sortOrder: Integer = 0;
}
export const TemplateManagementEntity = createEntity<TemplateManagement>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| templateName | 模板名称 | String | 非空 | | | |
| templateCode | 模板编码 | String | 非空、唯一 | | | |
| templateType | 模板类型 | String | 非空 | | | |
| description | 模板描述 | String | | '' | TEXT | |
| templateContent | 模板内容 | String | 非空 | | TEXT | maxLength(65535) |
| applicableDepartment | 适用部门 | String | | '' | | |
| isEnabled | 是否启用 | Boolean | 非空 | true | | |
| version | 模板版本 | String | 非空 | '1.0' | | |
| sortOrder | 排序序号 | Integer | | 0 | | |

### 依赖的枚举和实体

- **数据建模-实体-EnvironmentalReport**：[环保管理-实体-环境报告（EnvironmentalReport）](specs/001-bootdo-management-system/plan/data-model/entity-EnvironmentalReport.md)