# 通用业务模块-实体-供应商信息（SupplierInformation）

- **生成时间**：2026-03-26

## 供应商信息（SupplierInformation）

供应商信息实体用于管理系统中所有供应商的基本信息和业务相关信息，是采购管理和供应链管理的基础数据载体。该实体支持供应商基本信息的完整记录，包括公司名称、联系人、联系方式、地址等核心信息，同时维护供应商的供应品类、合作状态和信用评级等业务属性。通过统一的供应商信息管理，系统能够实现对供应商的全生命周期管理，从供应商准入、评估到合作终止的全过程跟踪。供应商信息实体还包含了完整的审计字段，确保所有供应商信息变更都具有可追溯性，满足企业合规管理要求。该实体与采购订单、合同管理等业务模块紧密集成，为企业的采购决策和供应商管理提供数据支撑。

```naturalts path="app.dataSources.defaultDS.entities.SupplierInformation.ts"
@Entity({
    title: "供应商信息",
    directory: "general_business(通用业务)"
})
export class SupplierInformation {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "供应商名称",
        description: "供应商公司的全称",
        required: true
    })
    supplierName: String;

    @EntityProperty({
        title: "联系人姓名",
        description: "供应商的主要联系人姓名"
    })
    contactPerson: String = '';

    @EntityProperty({
        title: "联系电话",
        description: "供应商的联系电话"
    })
    contactPhone: String = '';

    @EntityProperty({
        title: "电子邮箱",
        description: "供应商的联系邮箱"
    })
    email: String = '';

    @EntityProperty({
        title: "公司地址",
        description: "供应商的注册地址或办公地址",
        dbType: TEXT
    })
    address: String = '';

    @EntityProperty({
        title: "供应品类",
        description: "供应商主要供应的产品或服务类别"
    })
    supplyCategory: String = '';

    @EntityProperty({
        title: "供应商状态",
        description: "供应商的合作状态",
        required: true
    })
    status: Boolean = true;

    @EntityProperty({
        title: "备注",
        description: "关于供应商的其他补充信息",
        dbType: TEXT
    })
    remark: String = '';
}
export const SupplierInformationEntity = createEntity<SupplierInformation>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| supplierName | 供应商名称 | String | 非空 | | TEXT_TYPE(100) | |
| contactPerson | 联系人姓名 | String | | '' | TEXT_TYPE(50) | |
| contactPhone | 联系电话 | String | | '' | TEXT_TYPE(20) | |
| email | 电子邮箱 | String | | '' | TEXT_TYPE(100) | |
| address | 公司地址 | String | | '' | TEXT | |
| supplyCategory | 供应品类 | String | | '' | TEXT_TYPE(200) | |
| status | 供应商状态 | Boolean | 非空 | true | | |
| remark | 备注 | String | | '' | TEXT | |

### 依赖的枚举和实体

- **数据建模-实体-通用实体**：[系统管理-实体-通用实体（GenericEntity）](specs/001-bootdo-management-system/plan/data-model/entity-GenericEntity.md)