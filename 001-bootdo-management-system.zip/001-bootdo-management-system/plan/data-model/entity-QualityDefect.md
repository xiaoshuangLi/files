# 质量管理-实体-质量缺陷（QualityDefect）

- **生成时间**：2026-03-26

## 质量缺陷（QualityDefect）

质量缺陷实体是质量管理模块的核心业务实体，用于记录和管理在生产或服务过程中发现的具体质量缺陷问题。该实体支持质量问题的详细登记、分配处理和整改跟踪全流程管理。质量缺陷实体包含了完整的项目相关信息，如项目ID、项目名称、项目工号、机号、部位等，确保能够准确定位缺陷发生的具体位置和环境。通过整改描述、备注、提出日期等核心业务字段，详细记录缺陷的具体情况和处理要求。特检标识字段用于标记需要特殊关注的重要缺陷，确保关键问题得到优先处理。该实体还支持图片附件上传功能，允许用户上传缺陷现场照片作为直观证据，提高问题描述的准确性和处理效率。质量缺陷实体与系统账户、质量问题等相关实体建立关联关系，实现从缺陷发现到整改完成的完整数据链路，为企业全面质量管理提供精细化的数据支撑。

```naturalts path="app.dataSources.defaultDS.entities.QualityDefect.ts"
@Entity({
    title: "质量缺陷",
    directory: "quality_management(质量管理)"
})
export class QualityDefect {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "项目ID",
        description: "关联的项目标识"
    })
    projectId: Integer;

    @EntityProperty({
        title: "项目名称",
        description: "项目名称",
        required: true
    })
    projectName: String;

    @EntityProperty({
        title: "项目工号",
        description: "项目的工号标识"
    })
    projectWorkNumber: String = '';

    @EntityProperty({
        title: "机号",
        description: "设备或机器编号"
    })
    machineNumber: String = '';

    @EntityProperty({
        title: "部位",
        description: "缺陷发生的具体部位"
    })
    location: String = '';

    @EntityProperty({
        title: "整改描述",
        description: "质量缺陷的整改详细描述信息",
        dbType: TEXT,
        required: true
    })
    rectificationDescription: String;

    @EntityProperty({
        title: "备注",
        description: "额外的备注信息",
        dbType: TEXT
    })
    remark: String = '';

    @EntityProperty({
        title: "提出日期",
        description: "质量缺陷被提出的日期",
        required: true
    })
    proposedDate: Date;

    @EntityProperty({
        title: "提出人",
        description: "提出质量缺陷的用户ID"
    })
    proposerId: Integer;

    @EntityProperty({
        title: "是否特检",
        description: "标记是否为特殊检查项目",
        required: true
    })
    isSpecialInspection: Boolean = false;

    @EntityProperty({
        title: "图片附件",
        description: "缺陷相关的图片附件路径",
        dbType: TEXT
    })
    imageAttachments: String = '';
}
export const QualityDefectEntity = createEntity<QualityDefect>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| projectId | 项目ID | Integer | 非空、外键[项目管理] | | | |
| projectName | 项目名称 | String | 非空 | | | |
| projectWorkNumber | 项目工号 | String | | '' | | |
| machineNumber | 机号 | String | | '' | | |
| location | 部位 | String | | '' | | |
| rectificationDescription | 整改描述 | String | 非空 | | TEXT | |
| remark | 备注 | String | | '' | TEXT | |
| proposedDate | 提出日期 | Date | 非空 | | | |
| proposerId | 提出人 | Integer | 非空、外键[系统账户] | | | |
| isSpecialInspection | 是否特检 | Boolean | 非空 | false | | |
| imageAttachments | 图片附件 | String | | '' | TEXT | |

### 依赖的枚举和实体

- **数据建模-实体-项目管理**：[通用业务模块-实体-项目管理（ProjectManagement）](specs/001-bootdo-management-system/plan/data-model/entity-ProjectManagement.md)
  - 【外键[项目管理]】
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)
  - 【外键[系统账户]】