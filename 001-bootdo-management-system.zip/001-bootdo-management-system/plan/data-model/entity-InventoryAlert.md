# 环保管理-实体-库存预警（InventoryAlert）

- **生成时间**：2026-03-25

## 库存预警（InventoryAlert）

库存预警实体用于监控企业各类物资、设备或资源的库存水平，并在库存量达到预设的预警阈值时自动触发预警通知。该实体记录了预警配置的详细信息，包括关联的库存计数ID、预警类型（低库存预警、高库存预警）、预警阈值、预警状态、触发条件等关键数据。通过与库存计数实体的关联，系统能够实时监控库存变化，当当前库存量低于安全库存量或超过最大库存容量时，自动生成相应的预警记录。预警状态包括未处理、已处理、已忽略等，支持用户对预警进行分类管理和后续跟踪。该实体还记录了预警的创建时间、处理时间、处理人员和处理备注等信息，为库存优化分析和供应链管理提供数据支持，帮助企业及时补充短缺物资或调整过剩库存，确保生产运营的连续性和资源利用的最优化。

```naturalts path="app.dataSources.defaultDS.entities.InventoryAlert.ts"
@Entity({
    title: "库存预警",
    directory: "environmental_management(环保管理)"
})
export class InventoryAlert {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "库存计数ID",
        description: "关联的库存计数记录ID"
    })
    @EntityRelation<app.dataSources.defaultDS.entities.InventoryCount['id']>('PROTECT')
    inventoryCountId: Integer;

    @EntityProperty({
        title: "预警类型",
        description: "预警的类型，如低库存预警、高库存预警",
        required: true
    })
    alertType: String;

    @EntityProperty({
        title: "预警阈值",
        description: "触发预警的库存数量阈值",
        dbType: 'FIXED_POINT(15, 4)',
        required: true,
        fieldRules: [minimumAllowed(0)]
    })
    threshold: Decimal = 0;

    @EntityProperty({
        title: "当前库存量",
        description: "触发预警时的实际库存量",
        dbType: 'FIXED_POINT(15, 4)',
        required: true,
        fieldRules: [minimumAllowed(0)]
    })
    currentQuantity: Decimal = 0;

    @EntityProperty({
        title: "预警状态",
        description: "预警的处理状态",
        required: true
    })
    status: app.enums.TaskStatusEnum = app.enums.TaskStatusEnum['Pending'];

    @EntityProperty({
        title: "触发时间",
        description: "预警被触发的时间",
        required: true
    })
    triggerTime: DateTime;

    @EntityProperty({
        title: "处理时间",
        description: "预警被处理的时间"
    })
    handledTime: DateTime;

    @EntityProperty({
        title: "处理人员",
        description: "处理预警的人员姓名"
    })
    handler: String = '';

    @EntityProperty({
        title: "处理备注",
        description: "处理预警时的备注信息",
        dbType: 'TEXT'
    })
    handleRemark: String = '';

    @EntityProperty({
        title: "是否已通知",
        description: "预警是否已经发送通知",
        required: true
    })
    isNotified: Boolean = false;
}
export const InventoryAlertEntity = createEntity<InventoryAlert>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| inventoryCountId | 库存计数ID | Integer | 非空、外键[库存计数] | | | |
| alertType | 预警类型 | String | 非空 | | | |
| threshold | 预警阈值 | Decimal | 非空 | 0 | decimal_15_4 | 最小值为0 |
| currentQuantity | 当前库存量 | Decimal | 非空 | 0 | decimal_15_4 | 最小值为0 |
| status | 预警状态 | app.enums.TaskStatusEnum | 非空 | TaskStatusEnum['Pending'] | | |
| triggerTime | 触发时间 | DateTime | 非空 | | | |
| handledTime | 处理时间 | DateTime | | | | |
| handler | 处理人员 | String | | '' | varchar_100 | |
| handleRemark | 处理备注 | String | | '' | text_type | |
| isNotified | 是否已通知 | Boolean | 非空 | false | | |

### 依赖的枚举和实体

- **数据建模-枚举-任务状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-库存计数**：[环保管理-实体-库存计数（InventoryCount）](specs/001-bootdo-management-system/plan/data-model/entity-InventoryCount.md)
  - 【外键[库存计数]】