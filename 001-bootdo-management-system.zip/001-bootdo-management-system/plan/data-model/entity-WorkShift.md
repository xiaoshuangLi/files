# 薪资管理-实体-工作班次（WorkShift）

- **生成时间**：2026-03-26

## 工作班次（WorkShift）

工作班次实体是薪资管理模块的基础配置实体，用于定义和管理系统中的标准工作班次模板。该实体详细记录了每个班次的基本信息，包括班次名称、班次代码、标准工作时间、休息时间安排、班次类型（如早班、中班、晚班、夜班等）以及适用的工作日类型等关键属性。通过工作班次实体，系统能够为排班计划提供标准化的班次模板，支持灵活的班次配置和管理。该实体还包含班次状态控制和生效日期管理，确保班次数据的规范性和时效性。工作班次实体与排班计划、员工档案等相关实体建立关联关系，为准确计算员工工作时长、加班时间和薪资提供基础数据支撑，满足企业复杂排班管理的需求。

```naturalts path="app.dataSources.defaultDS.entities.WorkShift.ts"
@Entity({
    title: "工作班次",
    directory: "salary_management(薪资管理)"
})
export class WorkShift {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "班次名称",
        description: "工作班次的显示名称，如'早班'、'中班'、'晚班'、'夜班'等",
        required: true
    })
    shiftName: String;

    @EntityProperty({
        title: "班次代码",
        description: "工作班次的唯一标识代码，用于系统内部引用",
        required: true
    })
    shiftCode: String;

    @EntityProperty({
        title: "班次类型",
        description: "班次的分类类型，如早班、中班、晚班、夜班等",
        required: true
    })
    shiftType: String = 'NORMAL';

    @EntityProperty({
        title: "开始时间",
        description: "班次的标准开始时间，格式为HH:mm",
        required: true
    })
    startTime: String;

    @EntityProperty({
        title: "结束时间",
        description: "班次的标准结束时间，格式为HH:mm",
        required: true
    })
    endTime: String;

    @EntityProperty({
        title: "休息开始时间",
        description: "班次内的休息开始时间，格式为HH:mm"
    })
    breakStartTime: String = '';

    @EntityProperty({
        title: "休息结束时间",
        description: "班次内的休息结束时间，格式为HH:mm"
    })
    breakEndTime: String = '';

    @EntityProperty({
        title: "标准工作时长",
        description: "扣除休息时间后的标准工作时长（小时）",
        required: true,
        rules: [min(0)]
    })
    standardHours: Decimal = 8.00;

    @EntityProperty({
        title: "加班开始时间",
        description: "超过此时间开始计算加班，格式为HH:mm"
    })
    overtimeStartTime: String = '';

    @EntityProperty({
        title: "适用工作日类型",
        description: "班次适用的工作日类型，如工作日、周末、节假日等"
    })
    applicableDayTypes: String = 'WORKDAY';

    @EntityProperty({
        title: "是否启用",
        description: "班次是否处于启用状态",
        required: true
    })
    isEnabled: Boolean = true;

    @EntityProperty({
        title: "生效日期",
        description: "班次配置的生效日期"
    })
    effectiveDate: Date;

    @EntityProperty({
        title: "失效日期",
        description: "班次配置的失效日期"
    })
    expirationDate: Date;

    @EntityProperty({
        title: "班次描述",
        description: "班次的详细描述信息"
    })
    description: String = '';

    @EntityProperty({
        title: "排序权重",
        description: "班次在列表中的显示顺序",
        rules: [min(0)]
    })
    sortWeight: Integer = 0;
}
export const WorkShiftEntity = createEntity<WorkShift>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| shiftName | 班次名称 | String | 非空 | | | |
| shiftCode | 班次代码 | String | 非空 | | | |
| shiftType | 班次类型 | String | 非空 | 'NORMAL' | | |
| startTime | 开始时间 | String | 非空 | | | |
| endTime | 结束时间 | String | 非空 | | | |
| breakStartTime | 休息开始时间 | String | | '' | | |
| breakEndTime | 休息结束时间 | String | | '' | | |
| standardHours | 标准工作时长 | Decimal | 非空 | 8.00 | | min(0) |
| overtimeStartTime | 加班开始时间 | String | | '' | | |
| applicableDayTypes | 适用工作日类型 | String | | 'WORKDAY' | | |
| isEnabled | 是否启用 | Boolean | 非空 | true | | |
| effectiveDate | 生效日期 | Date | | | | |
| expirationDate | 失效日期 | Date | | | | |
| description | 班次描述 | String | | '' | | |
| sortWeight | 排序权重 | Integer | | 0 | | min(0) |

### 依赖的枚举和实体

- **数据建模-实体-排班计划**：[薪资管理-实体-排班计划（ShiftSchedule）](specs/001-bootdo-management-system/plan/data-model/entity-ShiftSchedule.md)
- **数据建模-实体-员工档案**：[系统管理-实体-员工档案（EmployeeProfile）](specs/001-bootdo-management-system/plan/data-model/entity-EmployeeProfile.md)