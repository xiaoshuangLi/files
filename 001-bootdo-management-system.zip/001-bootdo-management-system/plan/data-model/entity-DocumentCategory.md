# 办公自动化-实体-文档分类（DocumentCategory）

- **生成时间**：2026-03-26

## 文档分类（DocumentCategory）

文档分类实体是办公自动化模块中的核心数据组织实体，用于定义和管理系统中文档资源的分类体系结构。该实体支持完整的树形层级分类管理，包括分类编号、分类名称、父级分类关系和排序权重等关键属性。通过维护文档分类的树形结构（包含父分类ID、树表等级、是否叶子节点等字段），系统能够实现多层级的文档归类和导航展示。文档分类实体还包含了分类状态控制（启用/禁用）、分类描述信息以及完整的审计跟踪字段，确保分类数据的完整性和可追溯性。该实体与文档存储、权限控制等功能紧密集成，为文档的有序管理和高效检索提供基础支撑，同时支持基于分类的权限分配和统计分析。

```naturalts path="app.dataSources.defaultDS.entities.DocumentCategory.ts"
@Entity({
    entityName: "DocumentCategory",
    tableName: "document_category",
    description: "文档分类实体，用于管理文档资源的分类体系"
})
export class DocumentCategory {
    @EntityProperty({
        title: "主键"
    })
    id: StringType;

    @EntityProperty({
        title: "分类编码",
        description: "文档分类的唯一编码标识",
        dbType: VarcharType(50),
        required: true
    })
    categoryCode: StringType;

    @EntityProperty({
        title: "分类名称",
        description: "文档分类的显示名称",
        dbType: VarcharType(100),
        required: true
    })
    categoryName: StringType;

    @EntityProperty({
        title: "父级分类ID",
        description: "父级分类ID，用于构建树形结构",
        dbType: VarcharType(32)
    })
    parentId: StringType;

    @EntityProperty({
        title: "树表等级",
        description: "树表等级，表示当前分类在树形结构中的层级",
        required: true
    })
    treeLevel: NumberType = 0;

    @EntityProperty({
        title: "是否叶子节点",
        description: "是否为叶子节点，true表示没有子分类",
        required: true
    })
    isLeaf: BooleanType = true;

    @EntityProperty({
        title: "排序权重",
        description: "排序权重，用于同级分类的排序",
        required: true
    })
    sortOrder: NumberType = 0;

    @EntityProperty({
        title: "分类状态",
        description: "分类状态，如enabled(启用)、disabled(禁用)",
        dbType: VarcharType(20),
        required: true
    })
    status: StringType = "enabled";

    @EntityProperty({
        title: "分类描述",
        description: "文档分类的详细描述"
    })
    description: StringType;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTimeType;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTimeType;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: StringType;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: StringType;
}
export const DocumentCategoryEntity = createEntity<DocumentCategory>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | StringType | 主键、非空 | （自动生成） | | |
| categoryCode | 分类编码 | StringType | 非空 | | VarcharType(50) | 唯一 |
| categoryName | 分类名称 | StringType | 非空 | | VarcharType(100) | |
| parentId | 父级分类ID | StringType | | | VarcharType(32) | 外键引用自身id |
| treeLevel | 树表等级 | NumberType | 非空 | 0 | | |
| isLeaf | 是否叶子节点 | BooleanType | 非空 | true | | |
| sortOrder | 排序权重 | NumberType | 非空 | 0 | | |
| status | 分类状态 | StringType | 非空 | enabled | VarcharType(20) | |
| description | 分类描述 | StringType | | | TEXT | |
| createdTime | 创建时间 | DateTimeType | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTimeType | 非空 | （自动生成） | | |
| createdBy | 创建者 | StringType | 非空 | （自动生成） | | |
| updatedBy | 更新者 | StringType | 非空 | （自动生成） | | |