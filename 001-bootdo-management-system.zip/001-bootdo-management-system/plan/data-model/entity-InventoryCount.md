# 环保管理-实体-库存计数（InventoryCount）

- **生成时间**：2026-03-25

## 库存计数（InventoryCount）

库存计数实体用于管理环保相关物资、设备和资源的库存数量记录，支持定期盘点、实时库存监控和库存预警功能。该实体跟踪各类环保物资的当前库存量、安全库存阈值、最后盘点时间和盘点状态，确保环保物资的充足供应和有效管理。库存计数与环境监测、排放控制等环保管理功能紧密集成，为环保合规提供物资保障数据支撑。

```naturalts path="app.dataSources.defaultDS.entities.InventoryCount.ts"
@Entity({
    title: "库存计数",
    directory: "environmental_management(环保管理)"
})
export class InventoryCount {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "物资名称",
        description: "环保相关物资的名称，如活性炭、过滤器、化学试剂等",
        required: true
    })
    materialName: String;

    @EntityProperty({
        title: "物资编码",
        description: "物资的唯一编码标识",
        required: true
    })
    materialCode: String;

    @EntityProperty({
        title: "当前库存数量",
        description: "当前实际库存数量",
        fieldRules: [minimumAllowed(0)]
    })
    currentQuantity: Integer = 0;

    @EntityProperty({
        title: "安全库存阈值",
        description: "触发补货提醒的安全库存下限",
        fieldRules: [minimumAllowed(0)]
    })
    safetyStockThreshold: Integer = 0;

    @EntityProperty({
        title: "单位",
        description: "库存计量单位，如kg、L、件等"
    })
    unit: String = '';

    @EntityProperty({
        title: "物资类别",
        description: "物资的分类，如消耗品、设备配件、化学品等"
    })
    materialCategory: String = '';

    @EntityProperty({
        title: "最后盘点时间",
        description: "最后一次盘点的时间"
    })
    lastCountTime: DateTime;

    @EntityProperty({
        title: "盘点状态",
        description: "当前盘点状态",
        required: true
    })
    countStatus: app.enums.TaskStatusEnum = app.enums.TaskStatusEnum['Completed'];

    @EntityProperty({
        title: "存储位置",
        description: "物资的存储位置或仓库"
    })
    storageLocation: String = '';

    @EntityProperty({
        title: "是否启用预警",
        description: "是否启用库存预警功能",
        required: true
    })
    enableAlert: Boolean = true;

    @EntityProperty({
        title: "备注",
        description: "其他补充信息",
        dbType: 'LONG_TEXT'
    })
    remark: String = '';
}
export const InventoryCountEntity = createEntity<InventoryCount>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| materialName | 物资名称 | String | 非空 | | 字符串类型，最大长度100 | |
| materialCode | 物资编码 | String | 非空 | | 字符串类型，最大长度50 | |
| currentQuantity | 当前库存数量 | Integer | | 0 | | 最小值为0 |
| safetyStockThreshold | 安全库存阈值 | Integer | | 0 | | 最小值为0 |
| unit | 单位 | String | | '' | 字符串类型，最大长度20 | |
| materialCategory | 物资类别 | String | | '' | 字符串类型，最大长度50 | |
| lastCountTime | 最后盘点时间 | DateTime | | | | |
| countStatus | 盘点状态 | app.enums.TaskStatusEnum | 非空 | TaskStatusEnum['Completed'] | | |
| storageLocation | 存储位置 | String | | '' | 字符串类型，最大长度100 | |
| enableAlert | 是否启用预警 | Boolean | 非空 | true | | |
| remark | 备注 | String | | '' | 长文本类型 | |

### 依赖的枚举和实体

- **数据建模-枚举-任务状态（TaskStatusEnum）**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)