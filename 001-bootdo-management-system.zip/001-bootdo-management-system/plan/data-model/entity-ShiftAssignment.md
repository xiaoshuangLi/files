# 薪资管理-实体-班次分配（ShiftAssignment）

- **生成时间**：2026-03-26

## 班次分配（ShiftAssignment）

班次分配实体是人力资源管理模块的核心组成部分，专门用于记录和管理员工在特定日期被分配到的具体工作班次。该实体作为工作班次（WorkShift）和排班计划（ShiftSchedule）之间的桥梁，实现了从班次模板到具体员工日程安排的精确映射。班次分配实体包含员工ID、班次ID、分配日期、实际开始时间、实际结束时间等关键属性，支持灵活的班次调整和临时变更。系统通过班次分配实体能够准确计算员工的实际工作时长、加班时长，并为考勤统计和薪资计算提供基础数据。该实体还支持记录班次分配的状态（如已确认、待确认、已取消），便于跟踪排班执行情况。通过完善的班次分配管理，企业能够实现精细化的工时管控，确保人力资源的合理配置，同时为员工提供清晰的工作安排信息。

```naturalts path="app.dataSources.defaultDS.entities.ShiftAssignment.ts"
@Entity({
    title: "班次分配",
    directory: "human_resources(人力资源)"
})
export class ShiftAssignment {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "员工ID",
        description: "被分配班次的员工唯一标识",
        required: true
    })
    @EntityRelation<app.dataSources.defaultDS.entities.EmployeeInformation['id']>("CASCADE")
    employeeId: Integer;

    @EntityProperty({
        title: "班次ID",
        description: "分配给员工的工作班次唯一标识",
        required: true
    })
    @EntityRelation<app.dataSources.defaultDS.entities.WorkShift['id']>("CASCADE")
    shiftId: Integer;

    @EntityProperty({
        title: "分配日期",
        description: "班次分配的具体日期",
        required: true
    })
    assignmentDate: Date;

    @EntityProperty({
        title: "实际开始时间",
        description: "班次的实际开始时间，格式 HH:mm",
        required: true
    })
    actualStartTime: String;

    @EntityProperty({
        title: "实际结束时间",
        description: "班次的实际结束时间，格式 HH:mm",
        required: true
    })
    actualEndTime: String;

    @EntityProperty({
        title: "工作时长",
        description: "实际工作时长（分钟），必须大于等于0"
    })
    workDuration: Integer = 0;

    @EntityProperty({
        title: "是否跨日",
        description: "标识该班次分配是否跨越到第二天",
        required: true
    })
    isOvernight: Boolean = false;

    @EntityProperty({
        title: "是否工作日",
        description: "标识该分配日期是否为工作日",
        required: true
    })
    isWorkday: Boolean = true;

    @EntityProperty({
        title: "是否节假日",
        description: "标识该分配日期是否为节假日",
        required: true
    })
    isHoliday: Boolean = false;

    @EntityProperty({
        title: "备注",
        description: "班次分配的额外说明信息"
    })
    remark: String = '';
}
export const ShiftAssignmentEntity = createEntity<ShiftAssignment>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| employeeId | 员工ID | Integer | 非空、外键关联实体 EmployeeInformation（级联删除） | | | |
| shiftId | 班次ID | Integer | 非空、外键关联实体 WorkShift（级联删除） | | | |
| assignmentDate | 分配日期 | Date | 非空 | | | |
| actualStartTime | 实际开始时间 | String | 非空 | | | |
| actualEndTime | 实际结束时间 | String | 非空 | | | |
| workDuration | 工作时长 | Integer | | 0 | | 大于等于0 |
| isOvernight | 是否跨日 | Boolean | 非空 | false | | |
| isWorkday | 是否工作日 | Boolean | 非空 | true | | |
| isHoliday | 是否节假日 | Boolean | 非空 | false | | |
| remark | 备注 | String | | '' | | |

### 依赖的枚举和实体

- **数据建模-实体-员工信息**：[系统管理-实体-员工信息（EmployeeInformation）](specs/001-bootdo-management-system/plan/data-model/entity-EmployeeInformation.md)
  - 【外键关联实体 EmployeeInformation（级联删除）】
- **数据建模-实体-工作班次**：[薪资管理-实体-工作班次（WorkShift）](specs/001-bootdo-management-system/plan/data-model/entity-WorkShift.md)
  - 【外键关联实体 WorkShift（级联删除）】