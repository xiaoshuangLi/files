# 环保管理-实体-环保缺陷输出（EnvironmentalDefectOutput）

- **生成时间**：2026-03-26

## 环保缺陷输出（EnvironmentalDefectOutput）

环保缺陷输出实体是环保管理模块的关键组成部分，专门用于记录和管理环保缺陷处理完成后的具体输出结果、验证信息及相关文档。该实体与环保缺陷实体形成一对一的关联关系，确保每个环保缺陷都有对应的处理输出记录，实现环保问题管理的完整闭环。环保缺陷输出实体包含了缺陷处理结果的详细描述、验证状态、验证人、验证时间等核心信息，支持对缺陷处理效果的全面评估和确认。通过输出文件字段，系统能够管理与缺陷处理相关的各类文档、报告和附件，便于后续的审计追溯和知识积累。该实体还支持输出状态的标准化管理，通过整改状态枚举确保处理输出的一致性和可追踪性。环保缺陷输出实体与系统账户、环保缺陷等相关实体建立关联，实现跨模块的数据协同，满足企业对环保缺陷处理结果闭环管理的需求，确保环境问题得到彻底解决并有据可查。

```naturalts path="app.dataSources.defaultDS.entities.EnvironmentalDefectOutput.ts"
@Entity({
    title: "环保缺陷输出",
    directory: "environmental_management(环保管理)"
})
export class EnvironmentalDefectOutput {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "环保缺陷ID",
        description: "关联的环保缺陷记录",
        required: true
    })
    @EntityRelation<app.dataSources.defaultDS.entities.EnvironmentalDefect['id']>('PROTECT')
    environmentalDefectId: Integer;

    @EntityProperty({
        title: "处理结果描述",
        description: "环保缺陷处理完成后的具体结果和效果描述",
        dbType: TEXT,
        required: true
    })
    handlingResultDescription: String;

    @EntityProperty({
        title: "验证状态",
        description: "缺陷处理输出的验证确认状态",
        required: true
    })
    verificationStatus: app.enums.RectificationStatus = app.enums.RectificationStatus['Pending'];

    @EntityProperty({
        title: "验证人",
        description: "负责验证缺陷处理结果的用户ID"
    })
    @EntityRelation<app.dataSources.defaultDS.entities.SystemAccount['id']>('PROTECT')
    verifierId: Integer;

    @EntityProperty({
        title: "验证时间",
        description: "缺陷处理结果被验证确认的时间"
    })
    verifiedAt: DateTime;

    @EntityProperty({
        title: "输出文件",
        description: "与缺陷处理相关的输出文档或附件路径",
        dbType: TEXT
    })
    outputFiles: String = '';

    @EntityProperty({
        title: "备注",
        description: "缺陷处理输出相关的补充说明信息",
        dbType: TEXT
    })
    remark: String = '';
}
export const EnvironmentalDefectOutputEntity = createEntity<EnvironmentalDefectOutput>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| environmentalDefectId | 环保缺陷ID | Integer | 非空、外键关联实体 EnvironmentalDefect（PROTECT） | | | |
| handlingResultDescription | 处理结果描述 | String | 非空 | | TEXT | |
| verificationStatus | 验证状态 | app.enums.RectificationStatus | 非空 | RectificationStatus['Pending'] | | |
| verifierId | 验证人 | Integer | 外键关联实体 SystemAccount（PROTECT） | | | |
| verifiedAt | 验证时间 | DateTime | | | | |
| outputFiles | 输出文件 | String | | '' | TEXT | |
| remark | 备注 | String | | '' | TEXT | |

### 依赖的枚举和实体

- **数据建模-枚举-整改状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **环保管理-实体-环保缺陷**：[环保管理-实体-环保缺陷（EnvironmentalDefect）](specs/001-bootdo-management-system/plan/data-model/entity-EnvironmentalDefect.md)
  - 【外键关联实体 EnvironmentalDefect（PROTECT）】
- **系统管理-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)
  - 【外键关联实体 SystemAccount（PROTECT）】