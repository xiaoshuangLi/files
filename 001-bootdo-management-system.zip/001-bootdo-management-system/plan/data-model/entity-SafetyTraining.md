# 通用业务模块-实体-安全培训（SafetyTraining）

- **生成时间**：2026-03-25

## 安全培训（SafetyTraining）

安全培训实体用于记录和管理企业安全生产培训活动的全过程，是安全管理模块的重要组成部分。该实体支持对安全法规、操作规程、应急处理、事故预防等内容的系统化培训管理，确保员工具备必要的安全知识和技能。通过记录培训主题、详细内容、培训时间、参与人员信息、培训效果评估结果以及相关安全考核数据，该实体为企业建立完善的安全培训体系提供数据支撑。安全培训数据与安全检查、事故报告和整改措施紧密关联，当安全检查发现员工安全知识不足或操作不规范时，可触发相应的培训需求。同时，培训效果评估结果也为持续改进培训内容和方法提供依据，确保培训的有效性和针对性。该实体的设计充分考虑了安全生产法规对人员培训的合规要求，支持培训记录的长期保存和追溯，满足安全审计和监管需求。

```naturalts path="app.dataSources.defaultDS.entities.SafetyTraining.ts"
@Entity({
    title: "安全培训",
    directory: "human_resource_management(人力资源管理)"
})
export class SafetyTraining {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "培训主题",
        description: "安全培训的主要主题或标题",
        required: true
    })
    trainingTopic: String;

    @EntityProperty({
        title: "培训内容",
        description: "详细的安全培训内容描述",
        dbType: TEXT,
        required: true
    })
    trainingContent: String = '';

    @EntityProperty({
        title: "培训时间",
        description: "培训活动的具体时间",
        required: true
    })
    trainingTime: DateTime;

    @EntityProperty({
        title: "培训地点",
        description: "培训活动的举办地点"
    })
    trainingLocation: String = '';

    @EntityProperty({
        title: "参与人数",
        description: "参加培训的人员数量"
    })
    participantCount: Integer = 0;

    @EntityProperty({
        title: "培训效果",
        description: "培训效果评估结果",
        required: true
    })
    isEffective: Boolean = false;

    @EntityProperty({
        title: "是否涉及特种作业",
        description: "培训内容是否涉及特种作业安全操作"
    })
    involvesSpecialOperations: Boolean = false;

    @EntityProperty({
        title: "安全考核分数",
        description: "安全培训后的考核分数"
    })
    safetyScore: Decimal = 0;

    @EntityProperty({
        title: "培训证书编号",
        description: "安全培训合格证书编号"
    })
    certificateNumber: String = '';
}
export const SafetyTrainingEntity = createEntity<SafetyTraining>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| trainingTopic | 培训主题 | String | 非空 | | | |
| trainingContent | 培训内容 | String | 非空 | '' | TEXT | |
| trainingTime | 培训时间 | DateTime | 非空 | | | |
| trainingLocation | 培训地点 | String | | '' | | |
| participantCount | 参与人数 | Integer | | 0 | | |
| isEffective | 培训效果 | Boolean | 非空 | false | | |
| involvesSpecialOperations | 是否涉及特种作业 | Boolean | | false | | |
| safetyScore | 安全考核分数 | Decimal | | 0 | 固定精度小数(5, 2) | 范围(0-100) |
| certificateNumber | 培训证书编号 | String | | '' | 可变长度字符串(100) | |

### 依赖的枚举和实体

- **数据建模-枚举-培训状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)