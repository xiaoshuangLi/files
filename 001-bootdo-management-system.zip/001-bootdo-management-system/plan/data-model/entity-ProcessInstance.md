# 工作流引擎-实体-流程实例（ProcessInstance）

- **生成时间**：2026-03-25

## 流程实例（ProcessInstance）

流程实例实体表示具体的工作流执行实例，用于跟踪业务流程的实际运行状态和进度。每个流程实例都基于一个流程定义模板创建，记录了流程的启动时间、结束时间、当前状态以及相关的业务数据。该实体支持工作流引擎的核心功能，包括流程实例的创建、查询、暂停、恢复和终止操作。通过关联启动用户ID，可以追溯流程的发起人；通过维护当前状态字段，可以实时监控流程的执行情况；通过记录开始和结束时间，可以进行流程执行效率的分析和优化。流程实例作为工作流引擎与业务系统之间的桥梁，确保了业务流程的规范化执行和全程可追溯性，为企业的流程自动化和数字化管理提供了基础支撑。

```naturalts path="app.dataSources.defaultDS.entities.ProcessInstance.ts"
@Entity({
    title: "流程实例",
    directory: "workflow_engine(工作流引擎)"
})
export class ProcessInstance {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "实例ID",
        description: "流程实例的唯一标识符",
        required: true
    })
    instanceId: String;

    @EntityProperty({
        title: "定义ID",
        description: "关联的流程定义ID"
    })
    @EntityRelation<app.dataSources.defaultDS.entities.ProcessDefinition['id']>('CASCADE')
    definitionId: Integer;

    @EntityProperty({
        title: "启动用户ID",
        description: "启动该流程实例的用户ID"
    })
    startUserId: Integer;

    @EntityProperty({
        title: "启动时间",
        description: "流程实例的启动时间"
    })
    startedAt: DateTime;

    @EntityProperty({
        title: "结束时间",
        description: "流程实例的结束时间"
    })
    endedAt: DateTime;

    @EntityProperty({
        title: "当前状态",
        description: "流程实例的当前执行状态",
        required: true
    })
    currentStatus: String = 'ACTIVE';
}
export const ProcessInstanceEntity = createEntity<ProcessInstance>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| instanceId | 实例ID | String | 非空 | | 可变长度字符串(64) | |
| definitionId | 定义ID | Integer | 非空、外键关联实体 ProcessDefinition（级联删除） | | | |
| startUserId | 启动用户ID | Integer | 外键关联实体 LcapUser | | | |
| startedAt | 启动时间 | DateTime | | | | |
| endedAt | 结束时间 | DateTime | | | | |
| currentStatus | 当前状态 | String | 非空 | 'ACTIVE' | 可变长度字符串(32) | |

### 依赖的枚举和实体

- **数据建模-实体-流程定义**：[工作流引擎-实体-流程定义（ProcessDefinition）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessDefinition.md)
  - 【外键关联实体 ProcessDefinition（级联删除）】
- **数据建模-实体-用户**：.specify/warehouse/plan/data-model/entity-LcapUser.md
  - 【外键关联实体 LcapUser】