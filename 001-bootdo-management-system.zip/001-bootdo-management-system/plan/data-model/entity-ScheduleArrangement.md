# 办公自动化-实体-日程安排（ScheduleArrangement）

- **生成时间**：2026-03-25

## 日程安排（ScheduleArrangement）

日程安排实体是办公自动化模块的核心组成部分，专门用于管理用户的个人日程和事件安排。该实体支持创建、编辑、查询和删除各类日程事件，包括会议、约会、提醒等不同类型的日程活动。系统提供灵活的时间设置选项，既支持精确到分钟的时间范围日程（包含开始时间和结束时间），也支持全天事件的快速创建。每个日程都关联到具体的用户账户，确保数据的私密性和归属明确性。日程安排还支持详细的描述信息，用户可以记录日程的具体内容、地点、参与人员等相关信息。该实体与系统中的通知提醒功能集成，能够在日程开始前自动发送提醒通知，帮助用户有效管理时间并避免错过重要事件。通过与其他办公自动化功能（如会议预约、待办任务）的协作，日程安排为用户提供了一站式的个人时间管理解决方案。

```naturalts path="app.dataSources.defaultDS.entities.ScheduleArrangement.ts"
@Entity({
    title: "日程安排",
    directory: "office_automation(办公自动化)"
})
export class ScheduleArrangement {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "日程标题",
        description: "日程事件的简短标题",
        required: true
    })
    title: String;

    @EntityProperty({
        title: "描述",
        description: "日程事件的详细描述信息",
        dbType: "TEXT"
    })
    description: String = '';

    @EntityProperty({
        title: "所有者",
        description: "日程所属的用户账户ID",
        required: true
    })
    @EntityRelation<app.dataSources.defaultDS.entities.SystemAccount['id']>("CASCADE")
    ownerId: Integer;

    @EntityProperty({
        title: "开始时间",
        description: "日程事件的开始时间",
        required: true
    })
    startTime: DateTime;

    @EntityProperty({
        title: "结束时间",
        description: "日程事件的结束时间",
        required: true
    })
    endTime: DateTime;

    @EntityProperty({
        title: "是否全天事件",
        description: "标识该日程是否为全天事件",
        required: true
    })
    isAllDay: Boolean = false;
}
export const ScheduleArrangementEntity = createEntity<ScheduleArrangement>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| title | 日程标题 | String | 非空 | | | |
| description | 描述 | String | | '' | TEXT | |
| ownerId | 所有者 | Integer | 非空、外键关联实体 SystemAccount（级联删除） | | | |
| startTime | 开始时间 | DateTime | 非空 | | | |
| endTime | 结束时间 | DateTime | 非空 | | | |
| isAllDay | 是否全天事件 | Boolean | 非空 | false | | |

### 依赖的枚举和实体

- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)