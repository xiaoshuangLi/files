# 环保管理-实体-环保缺陷（EnvironmentalDefect）

- **生成时间**：2026-03-26

## 环保缺陷（EnvironmentalDefect）

环保缺陷实体是环保管理模块的核心业务实体，专门用于记录和跟踪企业在环保合规检查、环境监测或日常运营过程中发现的各类环保问题和缺陷。该实体作为环保问题管理的基础数据载体，支持从缺陷识别、分类、风险评估、整改分配到验证关闭的完整生命周期管理。环保缺陷实体包含了缺陷的基本信息（如缺陷编号、标题、详细描述）、分类信息、严重程度、发现时间、发现人、发生位置等关键属性，并与合规检查、环境风险评估、整改措施等相关实体建立关联关系。通过该实体，系统能够实现对环保缺陷的标准化记录、分类管理和全过程跟踪，确保所有环保问题得到及时有效的处理，帮助企业履行环保责任，降低环境风险，满足环保法规的合规要求。

```naturalts path="app.dataSources.defaultDS.entities.EnvironmentalDefect.ts"
@Entity({
    title: "环保缺陷",
    directory: "environmental_management(环保管理)"
})
export class EnvironmentalDefect {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "缺陷编号",
        description: "环保缺陷的唯一标识编号",
        required: true
    })
    defectCode: String;

    @EntityProperty({
        title: "缺陷标题",
        description: "环保缺陷的简要标题",
        required: true
    })
    title: String;

    @EntityProperty({
        title: "缺陷描述",
        description: "环保缺陷的详细描述信息",
        dbType: 'TEXT'
    })
    description: String = '';

    @EntityProperty({
        title: "缺陷分类ID",
        description: "关联的环保缺陷分类"
    })
    @EntityRelation<app.dataSources.defaultDS.entities.EnvironmentalDefectCategory['id']>('PROTECT')
    categoryId: Integer;

    @EntityProperty({
        title: "合规检查ID",
        description: "关联的合规检查记录"
    })
    @EntityRelation<app.dataSources.defaultDS.entities.ComplianceInspection['id']>('PROTECT')
    complianceInspectionId: Integer;

    @EntityProperty({
        title: "风险等级",
        description: "环保缺陷的风险等级评估",
        required: true
    })
    riskLevel: app.enums.RiskLevelEnum = app.enums.RiskLevelEnum['Low'];

    @EntityProperty({
        title: "整改优先级",
        description: "缺陷整改的处理优先级",
        required: true
    })
    priority: app.enums.RectificationPriority = app.enums.RectificationPriority['Low'];

    @EntityProperty({
        title: "缺陷状态",
        description: "环保缺陷的当前处理状态",
        required: true
    })
    status: app.enums.ComplianceStatusEnum = app.enums.ComplianceStatusEnum['NonCompliant'];

    @EntityProperty({
        title: "发现时间",
        description: "环保缺陷被发现的时间"
    })
    discoveryTime: DateTime;

    @EntityProperty({
        title: "发现人ID",
        description: "发现环保缺陷的人员"
    })
    @EntityRelation<app.dataSources.defaultDS.entities.SystemAccount['id']>('PROTECT')
    discovererId: Integer;

    @EntityProperty({
        title: "发生位置",
        description: "环保缺陷发生的具体位置或区域"
    })
    location: String = '';

    @EntityProperty({
        title: "关联设备ID",
        description: "与环保缺陷相关的设备"
    })
    @EntityRelation<app.dataSources.defaultDS.entities.Equipment['id']>('PROTECT')
    equipmentId: Integer;

    @EntityProperty({
        title: "是否已分配整改",
        description: "标识该环保缺陷是否已经分配了整改措施",
        required: true
    })
    isAssigned: Boolean = false;

    @EntityProperty({
        title: "备注",
        description: "关于环保缺陷的额外备注信息",
        dbType: 'TEXT'
    })
    remark: String = '';
}
export const EnvironmentalDefectEntity = createEntity<EnvironmentalDefect>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| defectCode | 缺陷编号 | String | 非空 | | | maxLength(64) |
| title | 缺陷标题 | String | 非空 | | | |
| description | 缺陷描述 | String | | '' | | |
| categoryId | 缺陷分类ID | Integer | 非空、外键 | | | |
| complianceInspectionId | 合规检查ID | Integer | 非空、外键 | | | |
| riskLevel | 风险等级 | app.enums.RiskLevelEnum | 非空 | RiskLevelEnum['Low'] | | |
| priority | 整改优先级 | app.enums.RectificationPriority | 非空 | RectificationPriority['Low'] | | |
| status | 缺陷状态 | app.enums.ComplianceStatusEnum | 非空 | ComplianceStatusEnum['NonCompliant'] | | |
| discoveryTime | 发现时间 | DateTime | | | | |
| discovererId | 发现人ID | Integer | 非空、外键 | | | |
| location | 发生位置 | String | | '' | | |
| equipmentId | 关联设备ID | Integer | 非空、外键 | | | |
| isAssigned | 是否已分配整改 | Boolean | 非空 | false | | |
| remark | 备注 | String | | '' | | |

### 依赖的枚举和实体

- **数据建模-枚举-风险等级**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-枚举-整改优先级**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-枚举-环保合规状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-环保缺陷分类**：[环保管理-实体-环保缺陷分类（EnvironmentalDefectCategory）](specs/001-bootdo-management-system/plan/data-model/entity-EnvironmentalDefectCategory.md)
  - 【外键[环保缺陷分类]】
- **数据建模-实体-合规检查**：[环保管理-实体-合规检查（ComplianceInspection）](specs/001-bootdo-management-system/plan/data-model/entity-ComplianceInspection.md)
  - 【外键[合规检查]】
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)
  - 【外键[系统账户]】
- **数据建模-实体-设备**：[环保管理-实体-设备（Equipment）](specs/001-bootdo-management-system/plan/data-model/entity-Equipment.md)
  - 【外键[设备]】