# 分包商管理-实体-分包商付款（SubcontractorPayment）

- **生成时间**：2026-03-26

## 分包商付款（SubcontractorPayment）

分包商付款实体是分包商管理系统中的核心财务实体，用于记录和管理与分包商相关的所有付款活动和结算信息。该实体详细跟踪每次付款的具体金额、付款方式、付款状态以及相关的审批流程，确保分包商付款过程的透明性和可追溯性。分包商付款实体与分包商合同、分包商信息等其他实体紧密关联，形成完整的分包商业务闭环。通过该实体，系统能够实现付款计划的制定、实际付款的执行、付款状态的监控以及付款历史的查询分析等功能。实体设计支持多种付款方式（如银行转账、支票、现金等）、多种付款状态（如待审批、已批准、已付款、已取消等），并包含完整的审计字段以记录付款操作的全生命周期。同时，该实体还支持付款凭证的关联存储和付款备注信息的记录，满足企业对分包商付款管理的全面需求。

```naturalts path="app.dataSources.defaultDS.entities.SubcontractorPayment.ts"
@Entity({
    title: "分包商付款",
    directory: "subcontractor_management(分包商管理)"
})
export class SubcontractorPayment {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "分包商ID",
        description: "关联的分包商唯一标识"
    })
    subcontractorId: Integer;

    @EntityProperty({
        title: "合同ID",
        description: "关联的分包商合同唯一标识"
    })
    contractId: Integer;

    @EntityProperty({
        title: "付款金额",
        description: "本次付款的具体金额"
    })
    paymentAmount: Decimal;

    @EntityProperty({
        title: "付款币种",
        description: "付款使用的货币类型",
        defaultValue: "CNY"
    })
    paymentCurrency: String;

    @EntityProperty({
        title: "付款方式",
        description: "付款的具体方式"
    })
    paymentMethod: String;

    @EntityProperty({
        title: "付款日期",
        description: "实际付款的日期和时间"
    })
    paymentDate: DateTime;

    @EntityProperty({
        title: "应付日期",
        description: "计划付款的截止日期"
    })
    dueDate: Date;

    @EntityProperty({
        title: "付款状态",
        description: "付款的当前状态"
    })
    paymentStatus: String;

    @EntityProperty({
        title: "审批流程ID",
        description: "关联的付款审批流程唯一标识"
    })
    approvalWorkflowId: Integer;

    @EntityProperty({
        title: "付款参考号",
        description: "银行或支付系统的付款参考编号"
    })
    paymentReference: String;

    @EntityProperty({
        title: "付款备注",
        description: "付款相关的备注信息"
    })
    paymentNotes: Text;

    @EntityProperty({
        title: "付款凭证",
        description: "付款凭证文件的存储路径或引用"
    })
    paymentVoucher: Attachment;
}
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| subcontractorId | 分包商ID | Integer | 非空、外键[分包商实体] | | | |
| contractId | 合同ID | Integer | 非空、外键[分包商合同实体] | | | |
| paymentAmount | 付款金额 | Decimal | 非空 | | NUMERIC_TYPE(10,2) | 必须大于0 |
| paymentCurrency | 付款币种 | String | 非空 | CNY | TEXT_TYPE(3) | ISO 4217货币代码 |
| paymentMethod | 付款方式 | String | 非空 | | TEXT_TYPE(20) | 枚举值：BANK_TRANSFER,CHEQUE,CASH,OTHER |
| paymentDate | 付款日期 | DateTime | 可空 | | | |
| dueDate | 应付日期 | Date | 可空 | | | |
| paymentStatus | 付款状态 | String | 非空 | | TEXT_TYPE(20) | 枚举值：PENDING_APPROVAL,APPROVED,PAID,CANCELLED,REJECTED |
| approvalWorkflowId | 审批流程ID | Integer | 可空、外键[审批流程实体] | | | |
| paymentReference | 付款参考号 | String | 可空 | | TEXT_TYPE(100) | |
| paymentNotes | 付款备注 | Text | 可空 | | TEXT | 最大1000字符 |
| paymentVoucher | 付款凭证 | Attachment | 可空 | | | 支持PDF、JPG、PNG格式 |

### 依赖的枚举和实体

- **数据建模-实体-分包商**：[分包商管理-实体-分包商（Subcontractor）](specs/001-bootdo-management-system/plan/data-model/entity-Subcontractor.md)
  - 【外键[分包商实体]】
- **数据建模-实体-分包商合同**：[分包商管理-实体-分包商合同（SubcontractAgreement）](specs/001-bootdo-management-system/plan/data-model/entity-SubcontractAgreement.md)
  - 【外键[分包商合同实体]】
- **数据建模-实体-审批流程**：[预算管理-实体-审批流程（ApprovalWorkflow）](specs/001-bootdo-management-system/plan/data-model/entity-ApprovalWorkflow.md)
  - 【外键[审批流程实体]】