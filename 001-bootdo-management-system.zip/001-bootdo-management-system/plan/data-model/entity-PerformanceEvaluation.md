# 薪资管理-实体-绩效评估（PerformanceEvaluation）

- **生成时间**：2026-03-26

## 绩效评估（PerformanceEvaluation）

绩效评估实体是薪资管理子域的核心业务实体，用于记录和管理员工在特定考核周期内的完整绩效评估过程和结果。该实体支持对员工绩效的全面评估管理，包括评估周期设定、评估状态跟踪、综合评分计算和评估结果记录。通过绩效评估实体，系统能够为薪资调整、奖金发放和职业发展提供客观的数据支撑，确保绩效管理的规范性和透明度。绩效评估与员工档案、绩效指标等实体建立关联关系，形成完整的绩效管理体系。该实体还支持多级审批流程和历史版本追溯，满足企业对绩效评估过程的合规性要求，最终实现绩效结果与薪酬激励的有效联动。

```naturalts path="app.dataSources.defaultDS.entities.PerformanceEvaluation.ts"
@Entity({
    title: "绩效评估",
    directory: "salary_management(薪资管理)"
})
export class PerformanceEvaluation {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "员工ID",
        description: "被评估员工的唯一标识",
        required: true
    })
    employeeId: String;

    @EntityProperty({
        title: "员工姓名",
        description: "被评估员工的姓名",
        required: true
    })
    employeeName: String;

    @EntityProperty({
        title: "部门ID",
        description: "员工所属部门的唯一标识"
    })
    departmentId: String = '';

    @EntityProperty({
        title: "部门名称",
        description: "员工所属部门的名称"
    })
    departmentName: String = '';

    @EntityProperty({
        title: "评估周期开始日期",
        description: "绩效评估覆盖的时间段开始日期",
        required: true
    })
    evaluationPeriodStart: Date;

    @EntityProperty({
        title: "评估周期结束日期",
        description: "绩效评估覆盖的时间段结束日期",
        required: true
    })
    evaluationPeriodEnd: Date;

    @EntityProperty({
        title: "评估类型",
        description: "绩效评估的类型，如月度评估、季度评估、年度评估等",
        required: true
    })
    evaluationType: String;

    @EntityProperty({
        title: "评估状态",
        description: "绩效评估的当前状态",
        required: true
    })
    evaluationStatus: String = 'pending';

    @EntityProperty({
        title: "评估人ID",
        description: "执行评估的人员ID"
    })
    evaluatorId: String = '';

    @EntityProperty({
        title: "评估人姓名",
        description: "执行评估的人员姓名"
    })
    evaluatorName: String = '';

    @EntityProperty({
        title: "综合评分",
        description: "基于各绩效指标权重计算得出的综合评分"
    })
    overallScore: Decimal = 0;

    @EntityProperty({
        title: "绩效等级",
        description: "根据综合评分确定的绩效等级"
    })
    performanceGrade: String = '';

    @EntityProperty({
        title: "评估总结",
        description: "对员工整体表现的综合评价和总结"
    })
    evaluationSummary: String = '';

    @EntityProperty({
        title: "改进建议",
        description: "针对员工表现提出的改进建议和发展方向"
    })
    improvementSuggestions: String = '';

    @EntityProperty({
        title: "是否关联薪资调整",
        description: "该绩效评估结果是否用于薪资调整决策",
        required: true
    })
    isLinkedToSalaryAdjustment: Boolean = false;

    @EntityProperty({
        title: "审批流程ID",
        description: "关联的审批流程实例ID"
    })
    approvalProcessId: String = '';

    @EntityProperty({
        title: "备注信息",
        description: "其他补充说明信息"
    })
    remarks: String = '';
}
export const PerformanceEvaluationEntity = createEntity<PerformanceEvaluation>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| employeeId | 员工ID | String | 非空 | | | |
| employeeName | 员工姓名 | String | 非空 | | | |
| departmentId | 部门ID | String | | '' | | |
| departmentName | 部门名称 | String | | '' | | |
| evaluationPeriodStart | 评估周期开始日期 | Date | 非空 | | | |
| evaluationPeriodEnd | 评估周期结束日期 | Date | 非空 | | | |
| evaluationType | 评估类型 | String | 非空 | | | |
| evaluationStatus | 评估状态 | String | 非空 | 'pending' | | |
| evaluatorId | 评估人ID | String | | '' | | |
| evaluatorName | 评估人姓名 | String | | '' | | |
| overallScore | 综合评分 | Decimal | | 0 | | |
| performanceGrade | 绩效等级 | String | | '' | | |
| evaluationSummary | 评估总结 | String | | '' | | |
| improvementSuggestions | 改进建议 | String | | '' | | |
| isLinkedToSalaryAdjustment | 是否关联薪资调整 | Boolean | 非空 | false | | |
| approvalProcessId | 审批流程ID | String | | '' | | |
| remarks | 备注信息 | String | | '' | | |

### 依赖的枚举和实体

- **薪资管理-实体-绩效指标**：[薪资管理-实体-绩效指标（PerformanceIndicator）](specs/001-bootdo-management-system/plan/data-model/entity-PerformanceIndicator.md)
- **系统管理-实体-员工档案**：[系统管理-实体-员工档案（EmployeeProfile）](specs/001-bootdo-management-system/plan/data-model/entity-EmployeeProfile.md)
- **工作流引擎-实体-流程实例**：[工作流引擎-实体-流程实例（ProcessInstance）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessInstance.md)