# 分包商管理-实体-付款管理（PaymentManagement）

- **生成时间**：2026-03-25

## 付款管理（PaymentManagement）

付款管理实体负责分包商付款结算的全流程管理，包括付款金额、付款方式、付款状态等关键信息的记录和跟踪。该实体确保分包商付款过程的规范化和可追溯性，支持多种付款方式（如银行转账、支票、现金等）的灵活配置，并提供付款状态的实时监控。通过与分包商信息实体的关联，系统能够准确识别付款对象，并自动关联相关的合同和项目信息。付款管理还支持发票号的记录和付款确认机制，确保财务数据的准确性和完整性。该实体为分包商管理模块提供了完整的付款结算能力，是分包商全生命周期管理中财务环节的核心组成部分，有效支撑企业对分包商付款的精细化管控和财务合规要求。

```naturalts path="app.dataSources.defaultDS.entities.PaymentManagement.ts"
@Entity({
    title: "付款管理",
    directory: "subcontractor_management(分包商管理)"
})
export class PaymentManagement {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "分包商",
        required: true
    })
    @EntityRelation<app.dataSources.defaultDS.entities.SubcontractorInformation['id']>('PROTECT')
    subcontractorId: Integer;

    @EntityProperty({
        title: "付款金额",
        description: "单位：元，最多两位小数",
        dbType: TEXT,
        required: true
    })
    amount: String = '0.00';

    @EntityProperty({
        title: "付款方式",
        description: "如银行转账、支票、现金等",
        dbType: TEXT,
        required: true
    })
    paymentMethod: String;

    @EntityProperty({
        title: "付款日期",
        required: true
    })
    paymentDate: Date;

    @EntityProperty({
        title: "发票号",
        description: "关联的发票编号",
        dbType: TEXT
    })
    invoiceNumber: String = '';

    @EntityProperty({
        title: "付款状态",
        description: "如待付款、已付款、已取消等",
        dbType: TEXT,
        required: true
    })
    status: String = '待付款';
}
export const PaymentManagementEntity = createEntity<PaymentManagement>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| subcontractorId | 分包商 | Integer | 非空、外键关联实体 SubcontractorInformation（PROTECT） | | | |
| amount | 付款金额 | String | 非空 | 0.00 | TEXT | |
| paymentMethod | 付款方式 | String | 非空 | | TEXT | |
| paymentDate | 付款日期 | Date | 非空 | | | |
| invoiceNumber | 发票号 | String | | '' | TEXT | |
| status | 付款状态 | String | 非空 | 待付款 | TEXT | |

### 依赖的枚举和实体

- **数据建模-实体-分包商信息**：[分包商管理-实体-分包商信息（SubcontractorInformation）](specs/001-bootdo-management-system/plan/data-model/entity-SubcontractorInformation.md)