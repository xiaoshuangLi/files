# 办公自动化-实体-个人偏好设置（PersonalPreferenceEntity）

- **生成时间**：2026-03-25

## 个人偏好设置（PersonalPreferenceEntity）

个人偏好设置实体是办公自动化模块的核心数据实体，用于存储和管理用户的个性化系统偏好配置。该实体允许用户根据个人使用习惯和工作需求，自定义系统的界面主题、语言选择、通知方式、默认视图等关键参数，从而提供更加个性化的用户体验。通过与系统账户实体的关联，确保每个用户的偏好设置独立存储且安全隔离。偏好设置数据采用灵活的键值对结构存储，支持动态扩展新的偏好项而无需修改数据库结构，极大提升了系统的可维护性和扩展性。实体设计包含了完整的审计追踪字段（创建/更新时间、操作人），便于追踪用户偏好设置的变更历史。个人偏好设置功能与个人工作台紧密集成，共同为用户提供高度定制化的工作环境，显著提升工作效率和系统使用满意度。

```naturalts path="app.dataSources.defaultDS.entities.PersonalPreferenceEntity.ts"
@Entity({
    title: "个人偏好设置",
    directory: "office_automation(办公自动化)"
})
export class PersonalPreferenceEntity {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "用户ID",
        description: "关联的系统账户ID",
        required: true
    })
    @EntityRelation<app.dataSources.defaultDS.entities.SystemAccount['id']>('PROTECT')
    userId: Integer;

    @EntityProperty({
        title: "偏好键",
        description: "偏好设置的唯一标识符，用于程序中引用",
        required: true
    })
    preferenceKey: String;

    @EntityProperty({
        title: "偏好值",
        description: "偏好设置的具体值，可以是字符串、JSON等格式",
        dbType: TEXT
    })
    preferenceValue: String = '';
}
export const PersonalPreferenceEntityEntity = createEntity<PersonalPreferenceEntity>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| userId | 用户ID | Integer | 非空、外键关联实体 SystemAccount（PROTECT） | | | |
| preferenceKey | 偏好键 | String | 非空 | | | |
| preferenceValue | 偏好值 | String | | '' | TEXT | |

### 依赖的枚举和实体

- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)
  - 【外键关联实体 SystemAccount（PROTECT）】