# 系统管理-实体-安全事件（SecurityIncident）

- **生成时间**：2026-03-25

## 安全事件（SecurityIncident）

安全事件实体用于记录和管理系统中发生的所有安全相关事件，包括但不限于异常登录尝试、权限违规操作、敏感数据访问、系统配置变更等安全审计场景。该实体支持安全事件的全生命周期管理，从事件发现、分类、严重级别评估到处理状态跟踪和解决方案记录。通过维护完整的安全事件历史，系统能够提供有效的安全审计能力，帮助管理员识别潜在的安全威胁模式，及时响应安全事件，并满足合规性要求。实体设计包含了事件的基本信息（类型、描述、发生时间）、风险评估（严重级别、影响范围）、处理状态（待处理、处理中、已解决）以及关联的系统资源（涉及用户、IP地址、操作模块）等关键属性，确保安全事件管理的全面性和可追溯性。

```naturalts path="app.dataSources.defaultDS.entities.SecurityIncident.ts"
@Entity({
    title: "安全事件",
    directory: "system_management(系统管理)"
})
export class SecurityIncident {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "事件标题",
        description: "安全事件的简要标题",
        dbType: VARCHAR(100),
        required: true
    })
    title: String;

    @EntityProperty({
        title: "事件描述",
        description: "安全事件的详细描述信息",
        dbType: TEXT
    })
    description: String = '';

    @EntityProperty({
        title: "事件类型",
        description: "安全事件的分类类型",
        dbType: VARCHAR(50),
        required: true
    })
    eventType: String;

    @EntityProperty({
        title: "严重级别",
        description: "安全事件的严重程度",
        dbType: VARCHAR(20),
        required: true
    })
    severityLevel: String = 'Medium';

    @EntityProperty({
        title: "事件状态",
        description: "安全事件的当前处理状态",
        dbType: VARCHAR(20),
        required: true
    })
    status: String = 'Pending';

    @EntityProperty({
        title: "发生时间",
        description: "安全事件实际发生的时间"
    })
    incidentTime: DateTime;

    @EntityProperty({
        title: "涉及用户ID",
        description: "与安全事件相关的用户标识"
    })
    userId: Integer;

    @EntityProperty({
        title: "涉及用户名",
        description: "与安全事件相关的用户名",
        dbType: VARCHAR(50)
    })
    username: String = '';

    @EntityProperty({
        title: "源IP地址",
        description: "安全事件发生的源IP地址",
        dbType: VARCHAR(45)
    })
    sourceIp: String = '';

    @EntityProperty({
        title: "目标IP地址",
        description: "安全事件的目标IP地址",
        dbType: VARCHAR(45)
    })
    targetIp: String = '';

    @EntityProperty({
        title: "操作模块",
        description: "安全事件涉及的系统模块",
        dbType: VARCHAR(100)
    })
    module: String = '';

    @EntityProperty({
        title: "请求URL",
        description: "安全事件相关的请求URL",
        dbType: TEXT
    })
    requestUrl: String = '';

    @EntityProperty({
        title: "用户代理",
        description: "客户端用户代理信息",
        dbType: TEXT
    })
    userAgent: String = '';

    @EntityProperty({
        title: "是否已处理",
        description: "标记安全事件是否已被处理",
        required: true
    })
    isHandled: Boolean = false;

    @EntityProperty({
        title: "处理人",
        description: "处理该安全事件的人员",
        dbType: VARCHAR(50)
    })
    handler: String = '';

    @EntityProperty({
        title: "处理备注",
        description: "安全事件处理的备注信息",
        dbType: TEXT
    })
    handlingNotes: String = '';
}
export const SecurityIncidentEntity = createEntity<SecurityIncident>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| title | 事件标题 | String | 非空 | | VARCHAR(100) | |
| description | 事件描述 | String | | '' | TEXT | |
| eventType | 事件类型 | String | 非空 | | VARCHAR(50) | |
| severityLevel | 严重级别 | String | 非空 | 'Medium' | VARCHAR(20) | |
| status | 事件状态 | String | 非空 | 'Pending' | VARCHAR(20) | |
| incidentTime | 发生时间 | DateTime | | | | |
| userId | 涉及用户ID | Integer | 非空、外键关联实体 系统账户（PROTECT） | | | |
| username | 涉及用户名 | String | | '' | VARCHAR(50) | |
| sourceIp | 源IP地址 | String | | '' | VARCHAR(45) | |
| targetIp | 目标IP地址 | String | | '' | VARCHAR(45) | |
| module | 操作模块 | String | | '' | VARCHAR(100) | |
| requestUrl | 请求URL | String | | '' | TEXT | |
| userAgent | 用户代理 | String | | '' | TEXT | |
| isHandled | 是否已处理 | Boolean | 非空 | false | | |
| handler | 处理人 | String | | '' | VARCHAR(50) | |
| handlingNotes | 处理备注 | String | | '' | TEXT | |

### 依赖的枚举和实体

- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)
  - 【外键关联实体 系统账户（PROTECT）】
- **数据建模-实体-操作记录**：specs/001-bootdo-management-system/plan/data-model/entity-OperationRecordEntity.md