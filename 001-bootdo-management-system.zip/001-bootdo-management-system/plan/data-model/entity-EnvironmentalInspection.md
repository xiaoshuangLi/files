# 环保管理-实体-环保检查（EnvironmentalInspection）

- **生成时间**：2026-03-26

## 环保检查（EnvironmentalInspection）

环保检查实体用于记录和管理企业环保合规检查的全过程，是环保管理模块的核心业务实体之一。该实体全面记录环保检查的基本信息、检查过程、发现的问题以及合规状态评估，支持从检查计划、执行到结果处理的完整业务流程。环保检查实体包含检查编号、检查员、检查时间、检查地点、检查类型等基本信息，以及检查内容、合规状态、发现问题数量、整改要求和完整检查报告等详细内容。通过与环境问题实体和整改措施实体的关联，环保检查能够形成从问题发现到整改完成的闭环管理，确保环境问题得到及时有效的处理。同时，该实体还支持检查状态跟踪（是否已完成）和完成时间记录，为企业环保合规管理提供完整的数据支撑和历史追溯能力，满足环保法规的合规要求和企业内部环境管理需求。

```naturalts path="app.dataSources.defaultDS.entities.EnvironmentalInspection.ts"
@Entity({
    title: "环保检查",
    directory: "environmental_management(环保管理)"
})
export class EnvironmentalInspection {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "检查编号",
        description: "环保检查的唯一标识编号",
        required: true
    })
    inspectionNo: String;

    @EntityProperty({
        title: "检查员ID",
        description: "执行环保检查的人员ID"
    })
    @EntityRelation<app.dataSources.defaultDS.entities.SystemAccount['id']>('PROTECT')
    inspectorId: Integer;

    @EntityProperty({
        title: "检查时间",
        description: "执行环保检查的具体时间",
        required: true
    })
    inspectionTime: DateTime;

    @EntityProperty({
        title: "检查地点",
        description: "环保检查执行的具体位置或区域",
        required: true
    })
    location: String;

    @EntityProperty({
        title: "检查类型",
        description: "环保检查的分类类型，如例行检查、专项检查、突击检查等",
        required: true
    })
    inspectionType: String;

    @EntityProperty({
        title: "检查内容",
        description: "环保检查的具体内容和范围描述",
        dbType: TEXT,
        required: true
    })
    inspectionContent: String;

    @EntityProperty({
        title: "合规状态",
        description: "环保检查的结果合规状态",
        required: true
    })
    complianceStatus: app.enums.ComplianceStatusEnum = app.enums.ComplianceStatusEnum['Compliant'];

    @EntityProperty({
        title: "发现问题数量",
        description: "环保检查中发现的环境问题总数"
    })
    issueCount: Integer = 0;

    @EntityProperty({
        title: "整改要求",
        description: "针对发现的问题提出的整改要求和建议",
        dbType: TEXT
    })
    rectificationRequirements: String = '';

    @EntityProperty({
        title: "检查报告",
        description: "环保检查的完整报告内容",
        dbType: TEXT
    })
    inspectionReport: String = '';

    @EntityProperty({
        title: "是否已完成",
        description: "环保检查是否已经完成全部流程",
        required: true
    })
    isCompleted: Boolean = false;

    @EntityProperty({
        title: "完成时间",
        description: "环保检查完成的时间"
    })
    completedTime: DateTime;

    @EntityProperty({
        title: "备注",
        description: "关于环保检查的其他补充说明信息",
        dbType: TEXT
    })
    remark: String = '';
}
export const EnvironmentalInspectionEntity = createEntity<EnvironmentalInspection>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| inspectionNo | 检查编号 | String | 非空 | | | |
| inspectorId | 检查员ID | Integer | 外键关联实体 SystemAccount（PROTECT） | | | |
| inspectionTime | 检查时间 | DateTime | 非空 | | | |
| location | 检查地点 | String | 非空 | | | |
| inspectionType | 检查类型 | String | 非空 | | | |
| inspectionContent | 检查内容 | String | 非空 | | TEXT | |
| complianceStatus | 合规状态 | app.enums.ComplianceStatusEnum | 非空 | ComplianceStatusEnum['Compliant'] | | |
| issueCount | 发现问题数量 | Integer | | 0 | | |
| rectificationRequirements | 整改要求 | String | | '' | TEXT | |
| inspectionReport | 检查报告 | String | | '' | TEXT | |
| isCompleted | 是否已完成 | Boolean | 非空 | false | | |
| completedTime | 完成时间 | DateTime | | | | |
| remark | 备注 | String | | '' | TEXT | |

### 依赖的枚举和实体

- **数据建模-枚举-环保合规状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)
  - 【外键关联实体 SystemAccount（PROTECT）】
- **环保管理-实体-环境问题**：[环保管理-实体-环境问题（EnvironmentalIssue）](specs/001-bootdo-management-system/plan/data-model/entity-EnvironmentalIssue.md)
- **环保管理-实体-整改措施**：[环保管理-实体-整改措施（RectificationMeasure）](specs/001-bootdo-management-system/plan/data-model/entity-RectificationMeasure.md)