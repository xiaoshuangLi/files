# 预算管理-实体-调整申请（AdjustmentApplication）

- **生成时间**：2026-03-25

## 调整申请（AdjustmentApplication）

调整申请实体是预算管理模块的核心组成部分，专门用于管理预算额度调整的完整申请流程。该实体支持用户在预算执行过程中因业务需求变化而提出的预算调整请求，包含详细的调整信息如新的预算金额、调整原因说明等关键数据。通过与工作流引擎的深度集成，调整申请能够自动触发预设的审批流程，确保所有预算调整都经过适当的审核和批准。实体中维护的审批状态字段实时反映申请的处理进度，从草稿、已提交、审核中到最终的已批准或已驳回状态，为预算管理人员提供清晰的审批跟踪视图。同时，该实体与预算分配实体建立强关联关系，确保每个调整申请都能准确对应到具体的预算项目，保证预算数据的一致性和可追溯性。

```naturalts path="app.dataSources.defaultDS.entities.AdjustmentApplication.ts"
@Entity({
    title: "调整申请",
    directory: "budget_management(预算管理)"
})
export class AdjustmentApplication {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "调整ID",
        description: "调整申请的唯一标识",
        required: true
    })
    adjustmentId: String;

    @EntityProperty({
        title: "预算分配",
        description: "关联的预算分配记录"
    })
    @EntityRelation<app.dataSources.defaultDS.entities.BudgetAllocation['id']>('CASCADE')
    allocationId: Integer;

    @EntityProperty({
        title: "申请人",
        description: "提交调整申请的用户"
    })
    @EntityRelation<app.dataSources.defaultDS.entities.SystemAccount['id']>('PROTECT')
    requesterId: Integer;

    @EntityProperty({
        title: "新金额",
        description: "调整后的预算金额",
        required: true
    })
    newAmount: Decimal = 0;

    @EntityProperty({
        title: "调整原因",
        description: "预算调整的详细原因说明",
        required: true
    })
    reason: String;

    @EntityProperty({
        title: "审批状态",
        description: "当前审批流程的状态",
        required: true
    })
    approvalStatus: app.enums.ApprovalStatusEnum = app.enums.ApprovalStatusEnum['Draft'];

    @EntityProperty({
        title: "申请时间",
        description: "调整申请的提交时间"
    })
    requestedAt: DateTime;

    @EntityProperty({
        title: "批准时间",
        description: "调整申请的最终批准时间"
    })
    approvedAt: DateTime;
}
export const AdjustmentApplicationEntity = createEntity<AdjustmentApplication>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| adjustmentId | 调整ID | String | 非空 | | 可变长度字符串(64) | |
| allocationId | 预算分配 | Integer | 非空、外键关联实体 BudgetAllocation（级联删除） | | | |
| requesterId | 申请人 | Integer | 非空、外键关联实体 SystemAccount（保护性删除） | | | |
| newAmount | 新金额 | Decimal | 非空 | 0 | 固定精度小数(15, 2) | 最小值(0) |
| reason | 调整原因 | String | 非空 | | 长文本 | |
| approvalStatus | 审批状态 | app.enums.ApprovalStatusEnum | 非空 | ApprovalStatusEnum['Draft'] | | |
| requestedAt | 申请时间 | DateTime | | | | |
| approvedAt | 批准时间 | DateTime | | | | |

### 依赖的枚举和实体

- **数据建模-枚举-审批状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-预算分配**：[预算管理-实体-预算分配（BudgetAllocation）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetAllocation.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)