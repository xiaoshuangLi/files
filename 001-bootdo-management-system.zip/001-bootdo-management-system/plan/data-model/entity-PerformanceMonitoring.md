# 工作流引擎-实体-性能监控（PerformanceMonitoring）

- **生成时间**：2026-03-25

## 性能监控（PerformanceMonitoring）

性能监控实体用于跟踪和记录系统各模块的性能指标和运行状态，包括响应时间、吞吐量、资源利用率等关键性能数据。该实体支持实时监控系统健康状况，识别性能瓶颈，并为系统优化提供数据支撑。通过收集历史性能数据，可以进行趋势分析和容量规划，确保系统稳定高效运行。性能监控还与告警机制集成，当性能指标超出预设阈值时自动触发告警通知，便于运维人员及时响应和处理潜在问题，保障业务连续性和用户体验质量。

```naturalts path="app.dataSources.defaultDS.entities.PerformanceMonitoring.ts"
@Entity({
    title: "性能监控",
    directory: "workflow_engine(工作流引擎)"
})
export class PerformanceMonitoring {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "监控名称",
        description: "性能监控的名称标识",
        required: true
    })
    monitorName: String;

    @EntityProperty({
        title: "监控类型",
        description: "性能监控的类型分类",
        required: true
    })
    monitorType: String;

    @EntityProperty({
        title: "资源ID",
        description: "被监控的资源标识",
        required: true
    })
    resourceId: String;

    @EntityProperty({
        title: "响应时间",
        description: "系统响应时间（毫秒）",
        required: true
    })
    responseTime: Decimal;

    @EntityProperty({
        title: "吞吐量",
        description: "系统处理能力（TPS）",
        required: true
    })
    throughput: Decimal;

    @EntityProperty({
        title: "CPU使用率",
        description: "CPU资源使用百分比",
        required: true
    })
    cpuUsage: Decimal;

    @EntityProperty({
        title: "内存使用率",
        description: "内存资源使用百分比",
        required: true
    })
    memoryUsage: Decimal;

    @EntityProperty({
        title: "磁盘使用率",
        description: "磁盘空间使用百分比",
        required: true
    })
    diskUsage: Decimal;

    @EntityProperty({
        title: "网络延迟",
        description: "网络传输延迟（毫秒）",
        required: true
    })
    networkLatency: Decimal;

    @EntityProperty({
        title: "错误率",
        description: "请求错误率百分比",
        required: true
    })
    errorRate: Decimal;

    @EntityProperty({
        title: "监控状态",
        description: "当前监控状态",
        required: true
    })
    status: String;

    @EntityProperty({
        title: "阈值配置",
        description: "性能指标阈值配置",
        dbType: TEXT,
        required: true
    })
    thresholdConfig: String;

    @EntityProperty({
        title: "最后更新时间",
        description: "最后数据更新时间",
        required: true
    })
    lastUpdatedTime: DateTime;
}
export const PerformanceMonitoringEntity = createEntity<PerformanceMonitoring>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| monitorName | 监控名称 | String | 非空 | | | |
| monitorType | 监控类型 | String | 非空 | | | |
| resourceId | 资源ID | String | 非空 | | | |
| responseTime | 响应时间 | Decimal | 非空 | | | |
| throughput | 吞吐量 | Decimal | 非空 | | | |
| cpuUsage | CPU使用率 | Decimal | 非空 | | | |
| memoryUsage | 内存使用率 | Decimal | 非空 | | | |
| diskUsage | 磁盘使用率 | Decimal | 非空 | | | |
| networkLatency | 网络延迟 | Decimal | 非空 | | | |
| errorRate | 错误率 | Decimal | 非空 | | | |
| status | 监控状态 | String | 非空 | | | |
| thresholdConfig | 阈值配置 | String | 非空 | | TEXT | |
| lastUpdatedTime | 最后更新时间 | DateTime | 非空 | | | |

### 依赖的枚举和实体

- **数据建模-实体-流程监控**：[工作流引擎-实体-流程监控（ProcessMonitoring）](specs/001-bootdo-management-system/plan/data-model/entity-ProcessMonitoring.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)