# 环保管理-实体-维护计划（MaintenanceSchedule）

- **生成时间**：2026-03-26

## 维护计划（MaintenanceSchedule）

维护计划实体是环保管理模块的核心组成部分，专门用于管理和跟踪企业环保设备的预防性维护计划。该实体支持从设备注册信息自动创建维护计划，并能够根据预设的维护周期自动生成后续的维护任务。维护计划详细记录了每次计划维护的设备信息、计划时间、维护内容、负责人分配、执行状态和完成情况等关键数据。通过维护计划实体，环保管理人员能够有效规划设备维护工作，确保监测和控制设备的正常运行，避免因设备故障导致的环境监测数据缺失或排放控制失效。该实体与设备(Equipment)实体和维护记录(MaintenanceRecord)实体紧密关联，形成完整的设备维护管理闭环，支持按设备类型、维护状态、时间范围等多维度查询和统计分析，为企业环保合规提供可靠的技术保障。

```naturalts path="app.dataSources.defaultDS.entities.MaintenanceSchedule.ts"
@Entity({
    title: "维护计划",
    directory: "environmental_management(环保管理)"
})
export class MaintenanceSchedule {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "维护计划编号",
        description: "维护计划的唯一标识符",
        dbType: "VARCHAR_50",
        required: true
    })
    maintenancePlanNo: String;

    @EntityProperty({
        title: "关联设备ID",
        description: "被维护设备的唯一标识",
        required: true
    })
    @EntityRelation<app.dataSources.defaultDS.entities.Equipment['id']>("CASCADE")
    equipmentId: Integer;

    @EntityProperty({
        title: "设备名称",
        description: "被维护设备的名称",
        dbType: "VARCHAR_100",
        required: true
    })
    equipmentName: String;

    @EntityProperty({
        title: "计划开始时间",
        description: "维护计划的预期开始时间",
        required: true
    })
    plannedStartTime: DateTime;

    @EntityProperty({
        title: "计划结束时间",
        description: "维护计划的预期结束时间",
        required: true
    })
    plannedEndTime: DateTime;

    @EntityProperty({
        title: "实际开始时间",
        description: "维护计划的实际开始时间"
    })
    actualStartTime: DateTime;

    @EntityProperty({
        title: "实际结束时间",
        description: "维护计划的实际结束时间"
    })
    actualEndTime: DateTime;

    @EntityProperty({
        title: "维护类型",
        description: "维护的分类，如预防性维护、定期保养等",
        dbType: "VARCHAR_50",
        required: true
    })
    maintenanceType: String;

    @EntityProperty({
        title: "维护内容",
        description: "维护计划的具体内容描述",
        dbType: "TEXT",
        required: true
    })
    maintenanceContent: String;

    @EntityProperty({
        title: "负责人ID",
        description: "负责执行该维护计划的用户ID",
        required: true
    })
    assigneeId: Integer;

    @EntityProperty({
        title: "负责人姓名",
        description: "负责执行该维护计划的用户姓名",
        dbType: "VARCHAR_50"
    })
    assigneeName: String = '';

    @EntityProperty({
        title: "维护状态",
        description: "维护计划的当前状态",
        required: true
    })
    status: app.enums.TaskStatusEnum = app.enums.TaskStatusEnum.Pending;

    @EntityProperty({
        title: "优先级",
        description: "维护计划的处理优先级",
        required: true
    })
    priority: app.enums.RectificationPriority = app.enums.RectificationPriority.Medium;

    @EntityProperty({
        title: "是否重复",
        description: "维护计划是否为重复性计划",
        required: true
    })
    isRecurring: Boolean = false;

    @EntityProperty({
        title: "重复周期",
        description: "如果为重复计划，定义重复的时间周期（天数）"
    })
    recurrenceInterval: Integer = 180;

    @EntityProperty({
        title: "最后执行日期",
        description: "重复计划最后一次执行的日期"
    })
    lastExecutionDate: Date;

    @EntityProperty({
        title: "下次执行日期",
        description: "重复计划下一次执行的日期"
    })
    nextExecutionDate: Date;

    @EntityProperty({
        title: "预计维护成本",
        description: "本次维护计划的预计成本（元）",
        dbType: "DECIMAL_12_2"
    })
    estimatedCost: Decimal = 0;

    @EntityProperty({
        title: "备注",
        description: "其他补充说明信息",
        dbType: "TEXT"
    })
    remarks: String = '';
}
export const MaintenanceScheduleEntity = createEntity<MaintenanceSchedule>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| maintenancePlanNo | 维护计划编号 | String | 非空 | | 可变长度字符串(50) | |
| equipmentId | 关联设备ID | Integer | 非空、外键关联实体 Equipment（级联删除） | | | |
| equipmentName | 设备名称 | String | 非空 | | 可变长度字符串(100) | |
| plannedStartTime | 计划开始时间 | DateTime | 非空 | | | |
| plannedEndTime | 计划结束时间 | DateTime | 非空 | | | |
| actualStartTime | 实际开始时间 | DateTime | | | | |
| actualEndTime | 实际结束时间 | DateTime | | | | |
| maintenanceType | 维护类型 | String | 非空 | | 可变长度字符串(50) | |
| maintenanceContent | 维护内容 | String | 非空 | | 长文本 | |
| assigneeId | 负责人ID | Integer | 非空、外键关联实体 SystemAccount | | | |
| assigneeName | 负责人姓名 | String | | '' | 可变长度字符串(50) | |
| status | 维护状态 | app.enums.TaskStatusEnum | 非空 | TaskStatusEnum.Pending | | |
| priority | 优先级 | app.enums.RectificationPriority | 非空 | RectificationPriority.Medium | | |
| isRecurring | 是否重复 | Boolean | 非空 | false | | |
| recurrenceInterval | 重复周期 | Integer | | 180 | | |
| lastExecutionDate | 最后执行日期 | Date | | | | |
| nextExecutionDate | 下次执行日期 | Date | | | | |
| estimatedCost | 预计维护成本 | Decimal | | 0 | 固定精度小数(12,2) | |
| remarks | 备注 | String | | '' | 长文本 | |

### 依赖的枚举和实体

- **数据建模-枚举-任务状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
  - 【维护状态字段引用 TaskStatusEnum 枚举】
- **数据建模-枚举-整改优先级**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
  - 【优先级字段引用 RectificationPriority 枚举】
- **数据建模-实体-设备**：[环保管理-实体-设备（Equipment）](specs/001-bootdo-management-system/plan/data-model/entity-Equipment.md)
  - 【外键关联实体 Equipment（级联删除）】
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)
  - 【外键关联实体 SystemAccount】