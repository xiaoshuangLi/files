# 环保管理-实体-碳排放（CarbonEmission）

- **生成时间**：2026-03-25

## 碳排放（CarbonEmission）

碳排放实体用于专门管理和追踪企业碳排放相关的数据记录，是环保管理模块中针对碳排放管理的核心组成部分。该实体详细记录了各类碳排放源的排放量、排放类型、计算方法和报告周期等关键信息，支持企业碳足迹的精确计算和碳排放报告的自动生成。通过与环境监测实体和资源消耗实体的关联，碳排放数据能够全面反映企业的碳排放状况，为碳减排目标制定、碳交易参与和环保合规检查提供准确的数据支撑。系统管理员、环保专员和碳管理专员可以通过该实体监控企业的碳排放趋势，识别高排放环节并制定相应的减排措施。碳排放数据还用于生成碳排放报告、进行碳配额管理和支持碳中和目标的实现，帮助企业满足日益严格的碳排放法规要求，提升企业的环境责任形象和可持续发展能力。

```naturalts path="app.dataSources.defaultDS.entities.CarbonEmission.ts"
@Entity({
    title: "碳排放",
    directory: "environmental_management(环保管理)"
})
export class CarbonEmission {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "环境监测ID",
        description: "关联的环境监测记录ID",
        required: true
    })
    @EntityRelation<app.dataSources.defaultDS.entities.EnvironmentalMonitoring['id']>('protect')
    monitoringId: Integer;

    @EntityProperty({
        title: "资源消耗ID",
        description: "关联的资源消耗记录ID",
        required: true
    })
    @EntityRelation<app.dataSources.defaultDS.entities.ResourceConsumption['id']>('protect')
    consumptionId: Integer;

    @EntityProperty({
        title: "排放类型",
        description: "碳排放的类型，如范围1直接排放、范围2间接排放、范围3价值链排放等",
        required: true
    })
    emissionType: String;

    @EntityProperty({
        title: "排放源",
        description: "产生碳排放的具体来源，如燃煤锅炉、天然气设备、电力消耗等",
        required: true
    })
    emissionSource: String;

    @EntityProperty({
        title: "二氧化碳当量",
        description: "碳排放量，以二氧化碳当量（CO2e）计量",
        required: true
    })
    co2Equivalent: Decimal = 0;

    @EntityProperty({
        title: "单位",
        description: "排放量的计量单位，如吨、千克等",
        required: true
    })
    unit: String;

    @EntityProperty({
        title: "计算方法",
        description: "碳排放量的计算方法或标准",
        required: true
    })
    calculationMethod: String;

    @EntityProperty({
        title: "报告周期",
        description: "碳排放数据的报告周期，如月度、季度、年度等",
        required: true
    })
    reportingPeriod: String;

    @EntityProperty({
        title: "记录时间",
        description: "碳排放数据的记录时间",
        required: true
    })
    recordedAt: DateTime;
}
export const CarbonEmissionEntity = createEntity<CarbonEmission>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| monitoringId | 环境监测ID | Integer | 非空、外键关联实体 EnvironmentalMonitoring（protect） | | | |
| consumptionId | 资源消耗ID | Integer | 非空、外键关联实体 ResourceConsumption（protect） | | | |
| emissionType | 排放类型 | String | 非空 | | | |
| emissionSource | 排放源 | String | 非空 | | | |
| co2Equivalent | 二氧化碳当量 | Decimal | 非空 | 0 | | |
| unit | 单位 | String | 非空 | | | |
| calculationMethod | 计算方法 | String | 非空 | | | |
| reportingPeriod | 报告周期 | String | 非空 | | | |
| recordedAt | 记录时间 | DateTime | 非空 | | | |

### 依赖的枚举和实体

- **环保管理-实体-环境监测**：[环保管理-实体-环境监测（EnvironmentalMonitoring）](specs/001-bootdo-management-system/plan/data-model/entity-EnvironmentalMonitoring.md)
  - 【外键关联实体 EnvironmentalMonitoring（protect）】
- **环保管理-实体-资源消耗**：[环保管理-实体-资源消耗（ResourceConsumption）](specs/001-bootdo-management-system/plan/data-model/entity-ResourceConsumption.md)
  - 【外键关联实体 ResourceConsumption（protect）】