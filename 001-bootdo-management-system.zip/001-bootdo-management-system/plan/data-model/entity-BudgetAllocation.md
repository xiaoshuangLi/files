# 预算管理-实体-预算分配（BudgetAllocation）

- **生成时间**：2026-03-25

## 预算分配（BudgetAllocation）

预算分配实体是预算管理模块的核心数据结构，用于记录和管理具体的预算额度分配操作。该实体详细记录了每次预算分配的基本信息，包括分配的预算类型、所属的预算周期、分配的具体金额、执行分配的操作人员以及当前的预算状态。通过预算分配实体，系统能够实现对不同部门、项目或业务单元的预算资源进行精细化管理和跟踪。预算分配的状态流转支持从计划中、已批准、执行中到已完成或已调整的完整生命周期管理，确保预算执行过程的透明度和可控性。同时，该实体与预算类型、预算周期等基础配置实体建立关联，保证预算分配的规范性和一致性，并为后续的执行监控、调整申请和分析报告提供准确的数据基础。

```naturalts path="app.dataSources.defaultDS.entities.BudgetAllocation.ts"
@Entity({
    title: "预算分配",
    directory: "budget_management(预算管理)"
})
export class BudgetAllocation {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "预算类型",
        required: true
    })
    @EntityRelation<app.dataSources.defaultDS.entities.BudgetType['id']>('PROTECT')
    budgetTypeId: Integer;

    @EntityProperty({
        title: "预算周期",
        required: true
    })
    @EntityRelation<app.dataSources.defaultDS.entities.BudgetCycle['id']>('PROTECT')
    budgetCycleId: Integer;

    @EntityProperty({
        title: "分配金额",
        description: "单位：元，最多两位小数",
        required: true
    })
    amount: Decimal = 0;

    @EntityProperty({
        title: "分配人",
        required: true
    })
    @EntityRelation<app.dataSources.defaultDS.entities.SystemAccount['id']>('PROTECT')
    allocatedById: Integer;

    @EntityProperty({
        title: "预算状态",
        required: true
    })
    status: app.enums.BudgetStatusEnum = app.enums.BudgetStatusEnum['Planned'];

    @EntityProperty({
        title: "分配时间",
        required: true
    })
    allocatedAt: DateTime;
}
export const BudgetAllocationEntity = createEntity<BudgetAllocation>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| budgetTypeId | 预算类型 | Integer | 非空、外键关联实体 BudgetType（PROTECT） | | | |
| budgetCycleId | 预算周期 | Integer | 非空、外键关联实体 BudgetCycle（PROTECT） | | | |
| amount | 分配金额 | Decimal | 非空 | 0 | 固定精度小数(31, 2) | |
| allocatedById | 分配人 | Integer | 非空、外键关联实体 SystemAccount（PROTECT） | | | |
| status | 预算状态 | app.enums.BudgetStatusEnum | 非空 | BudgetStatusEnum['Planned'] | | |
| allocatedAt | 分配时间 | DateTime | 非空 | | | |

### 依赖的枚举和实体

- **数据建模-枚举-预算状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-预算类型**：[预算管理-实体-预算类型（BudgetType）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetType.md)
- **数据建模-实体-预算周期**：[预算管理-实体-预算周期（BudgetCycle）](specs/001-bootdo-management-system/plan/data-model/entity-BudgetCycle.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)