# 质量管理-实体-质量整改输入（QualityRectificationInput）

- **生成时间**：2026-03-26

## 质量整改输入（QualityRectificationInput）

质量整改输入实体是质量管理模块的重要数据结构，专门用于记录和管理质量整改过程中的输入信息和数据。该实体作为质量整改流程的起点，承载了整改任务创建时所需的所有初始数据和配置信息。质量整改输入包含了整改的基本描述、问题分类、优先级设置、关联的项目和质量问题信息，以及整改的预期完成时间和责任人分配等关键数据。通过与系统账户、项目信息、质量问题等相关实体建立关联关系，确保整改输入能够准确定位到具体的业务场景和责任主体。该实体还支持特检标识和整改分类字段，便于对不同类型的整改任务进行差异化处理和统计分析。质量整改输入的状态通过RectificationStatus枚举进行标准化控制，确保整改流程的一致性和可追溯性，为后续的整改任务分配和执行提供完整的数据基础。

```naturalts path="app.dataSources.defaultDS.entities.QualityRectificationInput.ts"
@Entity({
    title: "质量整改输入",
    directory: "quality_management(质量管理)"
})
export class QualityRectificationInput {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "整改描述",
        description: "质量问题的具体整改措施描述",
        dbType: TEXT,
        required: true
    })
    rectificationDescription: String;

    @EntityProperty({
        title: "备注",
        description: "整改相关的补充说明信息",
        dbType: TEXT
    })
    remark: String = '';

    @EntityProperty({
        title: "提出日期",
        description: "整改任务提出的日期"
    })
    proposedDate: DateTime;

    @EntityProperty({
        title: "提出人",
        description: "提出整改任务的用户ID"
    })
    proposerId: Integer;

    @EntityProperty({
        title: "项目ID",
        description: "关联的项目标识"
    })
    projectId: Integer;

    @EntityProperty({
        title: "项目名称",
        description: "整改所属项目的名称"
    })
    projectName: String = '';

    @EntityProperty({
        title: "项目工号",
        description: "项目的工号标识"
    })
    projectWorkNumber: String = '';

    @EntityProperty({
        title: "机号",
        description: "设备或机器的编号"
    })
    machineNumber: String = '';

    @EntityProperty({
        title: "部位",
        description: "问题发生的具体部位"
    })
    location: String = '';

    @EntityProperty({
        title: "是否特检",
        description: "标识是否需要特殊检验",
        required: true
    })
    isSpecialInspection: Boolean = false;

    @EntityProperty({
        title: "整改分类",
        description: "整改任务的分类类型"
    })
    rectificationCategory: String = '';

    @EntityProperty({
        title: "整改优先级",
        description: "整改任务的处理优先级",
        required: true
    })
    priority: app.enums.RectificationPriority = app.enums.RectificationPriority['Medium'];

    @EntityProperty({
        title: "预期完成时间",
        description: "整改任务的预期完成日期"
    })
    expectedCompletionDate: DateTime;

    @EntityProperty({
        title: "质量问题ID",
        description: "关联的质量问题标识"
    })
    qualityIssueId: Integer;

    @EntityProperty({
        title: "整改状态",
        description: "整改任务的当前处理状态",
        required: true
    })
    status: app.enums.RectificationStatus = app.enums.RectificationStatus['Pending'];
}
export const QualityRectificationInputEntity = createEntity<QualityRectificationInput>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| rectificationDescription | 整改描述 | String | 非空 | | TEXT | |
| remark | 备注 | String | | '' | TEXT | |
| proposedDate | 提出日期 | DateTime | | | | |
| proposerId | 提出人 | Integer | 非空、外键[系统账户] | | | |
| projectId | 项目ID | Integer | 非空、外键[项目信息] | | | |
| projectName | 项目名称 | String | | '' | | |
| projectWorkNumber | 项目工号 | String | | '' | | |
| machineNumber | 机号 | String | | '' | | |
| location | 部位 | String | | '' | | |
| isSpecialInspection | 是否特检 | Boolean | 非空 | false | | |
| rectificationCategory | 整改分类 | String | | '' | | |
| priority | 整改优先级 | app.enums.RectificationPriority | 非空 | RectificationPriority['Medium'] | | |
| expectedCompletionDate | 预期完成时间 | DateTime | | | | |
| qualityIssueId | 质量问题ID | Integer | 非空、外键[质量问题] | | | |
| status | 整改状态 | app.enums.RectificationStatus | 非空 | RectificationStatus['Pending'] | | |

### 依赖的枚举和实体

- **数据建模-枚举-整改优先级**：[数据建模-枚举-整改优先级](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-枚举-整改状态**：[数据建模-枚举-整改状态](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)
  - 【外键[系统账户]】
- **数据建模-实体-项目信息**：[项目管理-实体-项目信息（ProjectInformation）](specs/001-bootdo-management-system/plan/data-model/entity-ProjectInformation.md)
  - 【外键[项目信息]】
- **数据建模-实体-质量问题**：[质量管理-实体-质量问题（QualityIssue）](specs/001-bootdo-management-system/plan/data-model/entity-QualityIssue.md)
  - 【外键[质量问题]】