# 薪资管理-实体-费用报销（ExpenseReimbursementEntity）

- **生成时间**：2026-03-25

## 费用报销（ExpenseReimbursementEntity）

费用报销实体用于管理员工因公产生的各类费用报销申请和处理流程，是薪资管理模块的重要组成部分。该实体详细记录了报销申请的完整信息，包括申请人、报销类型、费用明细、总金额、申请日期以及审批状态等关键数据。通过费用报销实体，系统能够标准化报销流程，确保所有报销申请都经过适当的审批和验证，防止虚假或不合规的报销行为。该实体与员工账户实体建立关联关系，确保每笔报销都能准确归属到具体的申请人；同时，费用报销实体还与审批工作流紧密集成，支持多级审批流程，并记录完整的审批历史。报销成功后，相关金额会纳入员工的薪资计算中，确保报销款项能够及时准确地发放给员工。该实体还支持按部门、项目或费用类型进行统计分析，为企业成本控制和预算管理提供数据支持。

```naturalts path="app.dataSources.defaultDS.entities.ExpenseReimbursementEntity.ts"
@Entity({
    title: "费用报销",
    directory: "salary_management(薪资管理)"
})
export class ExpenseReimbursementEntity {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "申请人ID",
        description: "提交报销申请的员工ID",
        required: true
    })
    @EntityRelation<app.dataSources.defaultDS.entities.SystemAccount['id']>('PROTECT')
    applicantId: Integer;

    @EntityProperty({
        title: "报销类型",
        description: "差旅费、办公费、业务招待费等",
        required: true
    })
    expenseType: String = '';

    @EntityProperty({
        title: "费用明细",
        description: "详细的费用项目和说明",
        required: true
    })
    expenseDetails: String = '';

    @EntityProperty({
        title: "总金额",
        description: "报销申请的总金额，单位：元",
        required: true
    })
    totalAmount: Decimal = 0;

    @EntityProperty({
        title: "申请日期",
        description: "提交报销申请的日期",
        required: true
    })
    applicationDate: Date;

    @EntityProperty({
        title: "审批状态",
        description: "报销申请的当前审批状态",
        required: true
    })
    approvalStatus: String = 'Draft';

    @EntityProperty({
        title: "审批流程ID",
        description: "关联的审批流程实例ID"
    })
    workflowInstanceId: String = '';
}
export const ExpenseReimbursementEntityEntity = createEntity<ExpenseReimbursementEntity>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| applicantId | 申请人ID | Integer | 非空、外键关联实体 SystemAccount（PROTECT） | | | |
| expenseType | 报销类型 | String | 非空 | '' | | |
| expenseDetails | 费用明细 | String | 非空 | '' | | |
| totalAmount | 总金额 | Decimal | 非空 | 0 | 固定精度小数(12, 2) | 最小值为0 |
| applicationDate | 申请日期 | Date | 非空 | | | |
| approvalStatus | 审批状态 | String | 非空 | 'Draft' | | |
| workflowInstanceId | 审批流程ID | String | | '' | | |

### 依赖的枚举和实体

- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)
  - 【外键关联实体 SystemAccount（PROTECT）】
- **数据建模-枚举-审批状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
  - 【审批状态字段引用 ApprovalStatusEnum 枚举值】