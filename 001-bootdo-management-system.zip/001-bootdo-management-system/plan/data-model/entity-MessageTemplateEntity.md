# 系统管理-实体-邮件模板（MessageTemplateEntity）

- **生成时间**：2026-03-25

## 邮件模板（MessageTemplateEntity）

邮件模板实体用于管理系统中各类业务场景下的邮件通知模板，支持不同消息类型的模板配置和管理。该实体包含模板的基本信息、内容结构、使用状态等属性，为系统的邮件通知功能提供统一的模板管理能力。通过邮件模板实体，管理员可以创建、编辑、启用或禁用各种业务场景的邮件模板，如用户注册确认、密码重置、审批通知、系统告警等，确保邮件内容的一致性和专业性。模板支持变量占位符替换，能够在发送时动态填充实际数据，提高邮件通知的灵活性和实用性。

```naturalts path="app.dataSources.defaultDS.entities.MessageTemplateEntity.ts"
@Entity({
    title: "邮件模板",
    directory: "system_management(系统管理)"
})
export class MessageTemplateEntity {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "模板名称",
        description: "邮件模板的显示名称，用于标识模板用途",
        required: true
    })
    templateName: String;

    @EntityProperty({
        title: "模板编码",
        description: "邮件模板的唯一编码，用于程序调用",
        required: true
    })
    templateCode: String;

    @EntityProperty({
        title: "消息类型",
        description: "模板适用的消息类型",
        required: true
    })
    messageType: app.enums.MessageTypeEnum = app.enums.MessageTypeEnum['EMAIL'];

    @EntityProperty({
        title: "邮件主题",
        description: "邮件的主题行内容",
        required: true
    })
    subject: String;

    @EntityProperty({
        title: "邮件正文",
        description: "邮件的HTML格式正文内容，支持变量占位符",
        required: true
    })
    content: String;

    @EntityProperty({
        title: "模板描述",
        description: "模板的详细说明和使用场景"
    })
    description: String = '';

    @EntityProperty({
        title: "是否启用",
        description: "控制模板是否可以被使用",
        required: true
    })
    isEnabled: Boolean = true;

    @EntityProperty({
        title: "排序序号",
        description: "模板在列表中的显示顺序"
    })
    sortOrder: Integer = 0;
}
export const MessageTemplateEntity = createEntity<MessageTemplateEntity>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| templateName | 模板名称 | String | 非空 | | | |
| templateCode | 模板编码 | String | 非空、唯一 | | | |
| messageType | 消息类型 | app.enums.MessageTypeEnum | 非空 | MessageTypeEnum['EMAIL'] | | |
| subject | 邮件主题 | String | 非空 | | | |
| content | 邮件正文 | String | 非空 | | | |
| description | 模板描述 | String | | '' | | |
| isEnabled | 是否启用 | Boolean | 非空 | true | | |
| sortOrder | 排序序号 | Integer | | 0 | | |

### 依赖的枚举和实体

- **数据建模-枚举-消息类型（MessageTypeEnum）**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)