# 办公自动化-实体-个人工作台（PersonalWorkspace）

- **生成时间**：2026-03-25

## 个人工作台（PersonalWorkspace）

个人工作台实体用于管理用户的个性化工作界面配置，支持用户根据自身工作习惯和需求定制专属的工作环境。该实体存储用户的布局配置信息，包括工作台的模块排列、快捷入口设置、默认视图偏好等个性化参数。通过个人工作台功能，用户可以快速访问常用功能模块、查看关键业务数据摘要、设置个性化提醒和通知，从而提升工作效率和使用体验。系统会根据用户的部门角色和权限范围，动态调整可配置的布局选项和快捷入口内容，确保个性化配置与权限控制的一致性。个人工作台的配置数据采用JSON格式存储，支持灵活的布局结构和丰富的配置选项，同时提供配置版本管理和重置功能，便于用户在不同设备间同步工作环境或恢复默认设置。

```naturalts path="app.dataSources.defaultDS.entities.PersonalWorkspace.ts"
@Entity({
    title: "个人工作台",
    directory: "office_automation(办公自动化)"
})
export class PersonalWorkspace {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "用户ID",
        description: "关联的系统账户ID",
        required: true
    })
    @EntityRelation<app.dataSources.defaultDS.entities.SystemAccount['id']>('PROTECT')
    userId: Integer;

    @EntityProperty({
        title: "布局配置",
        description: "用户个性化工作台布局配置，JSON格式",
        dbType: TEXT
    })
    layoutConfig: String = '';
}
export const PersonalWorkspaceEntity = createEntity<PersonalWorkspace>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| userId | 用户ID | Integer | 非空、外键关联实体 SystemAccount（PROTECT） | | | |
| layoutConfig | 布局配置 | String | | '' | TEXT | |

### 依赖的枚举和实体

- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)
  - 【外键关联实体 SystemAccount（PROTECT）】