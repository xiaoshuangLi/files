# 办公自动化-实体-文件存储（FileStorage）

- **生成时间**：2026-03-25

## 文件存储（FileStorage）

文件存储实体用于管理用户上传的各类文件资源，包括文件元数据和存储路径信息。该实体支持办公自动化模块中的文件上传、下载、共享和版本控制功能，确保文件资源的安全存储和高效访问。文件存储实体记录了每个文件的基本信息，如文件名、文件类型、文件大小、存储路径等，并关联上传者信息和上传时间戳，便于文件的追踪和管理。系统通过该实体实现文件权限控制，确保只有授权用户才能访问特定文件。同时，文件存储实体还支持文件分类和标签功能，方便用户对大量文件进行组织和检索。该实体是办公自动化模块中文件管理功能的核心数据结构，为通知公告附件、会议资料、个人文档等业务场景提供统一的文件存储服务。

```naturalts path="app.dataSources.defaultDS.entities.FileStorage.ts"
@Entity({
    title: "文件存储",
    directory: "office_automation(办公自动化)"
})
export class FileStorage {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "文件名",
        description: "原始文件名称，包含扩展名",
        required: true
    })
    fileName: String;

    @EntityProperty({
        title: "文件路径",
        description: "文件在存储系统中的完整路径",
        dbType: TEXT,
        required: true
    })
    filePath: String;

    @EntityProperty({
        title: "文件大小",
        description: "文件大小，单位为字节"
    })
    fileSize: Integer = 0;

    @EntityProperty({
        title: "文件类型",
        description: "文件的MIME类型或扩展名",
        required: true
    })
    fileType: String;

    @EntityProperty({
        title: "上传者"
    })
    @EntityRelation<app.dataSources.defaultDS.entities.SystemAccount['id']>('PROTECT')
    uploaderId: Integer;

    @EntityProperty({
        title: "上传时间",
        required: true
    })
    uploadedAt: DateTime;
}
export const FileStorageEntity = createEntity<FileStorage>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| fileName | 文件名 | String | 非空 | | | |
| filePath | 文件路径 | String | 非空 | | TEXT | |
| fileSize | 文件大小 | Integer | 非空 | 0 | | |
| fileType | 文件类型 | String | 非空 | | | |
| uploaderId | 上传者 | Integer | 非空、外键关联实体 SystemAccount（PROTECT） | | | |
| uploadedAt | 上传时间 | DateTime | 非空 | | | |

### 依赖的枚举和实体

- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)