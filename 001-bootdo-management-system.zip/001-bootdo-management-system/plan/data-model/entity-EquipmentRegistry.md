# 通用业务模块-实体-设备注册（EquipmentRegistry）

- **生成时间**：2026-03-26

## 设备注册（EquipmentRegistry）

设备注册实体是通用业务模块中设备全生命周期管理的核心入口实体，用于记录和管理企业各类设备的初始注册信息。该实体作为设备资产管理的第一步，详细记录设备的基本信息、技术规格、归属关系和注册状态等关键数据，为后续的设备使用、维护、监控和报废提供完整的基础数据支撑。设备注册实体支持按设备类型、状态、部门、位置等多维度进行查询和统计分析，帮助企业建立完整的设备资产台账。该实体与设备分类、组织部门、用户管理等模块紧密集成，确保设备注册信息的准确性和完整性，同时为设备管理流程（如设备验收、设备启用、设备转移等）提供标准化的数据基础，实现设备从采购到报废全过程的规范化管理。

```naturalts path="app.dataSources.defaultDS.entities.EquipmentRegistry.ts"
@Entity({
    title: "设备注册",
    directory: "general_business_module(通用业务模块)"
})
export class EquipmentRegistry {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "设备编号",
        description: "设备的唯一标识符，用于设备识别和追踪，通常由系统自动生成或按规则分配",
        required: true
    })
    equipmentNo: String;

    @EntityProperty({
        title: "设备名称",
        description: "设备的完整显示名称，用于标识和区分不同设备",
        required: true
    })
    equipmentName: String;

    @EntityProperty({
        title: "设备分类ID",
        description: "设备所属分类的唯一标识，关联设备分类实体"
    })
    categoryId: Integer;

    @EntityProperty({
        title: "设备分类名称",
        description: "设备所属分类的显示名称，便于用户理解"
    })
    categoryName: String = '';

    @EntityProperty({
        title: "设备状态",
        description: "设备当前的注册和运行状态",
        required: true
    })
    status: app.enums.EquipmentStatusEnum = app.enums.EquipmentStatusEnum.Active;

    @EntityProperty({
        title: "设备型号",
        description: "设备的具体型号规格，用于精确识别设备类型"
    })
    model: String = '';

    @EntityProperty({
        title: "设备序列号",
        description: "设备的出厂序列号，用于设备的唯一性验证"
    })
    serialNumber: String = '';

    @EntityProperty({
        title: "制造商",
        description: "设备的生产制造商名称"
    })
    manufacturer: String = '';

    @EntityProperty({
        title: "安装位置",
        description: "设备的物理安装位置描述，包括具体地点和位置详情"
    })
    location: String = '';

    @EntityProperty({
        title: "所属部门ID",
        description: "设备归属部门的唯一标识，关联组织部门实体"
    })
    departmentId: Integer;

    @EntityProperty({
        title: "所属部门",
        description: "设备归属的部门或单位名称"
    })
    department: String = '';

    @EntityProperty({
        title: "责任人ID",
        description: "设备主要负责人的用户ID，关联用户实体"
    })
    responsiblePersonId: Integer;

    @EntityProperty({
        title: "责任人",
        description: "设备的主要负责人姓名"
    })
    responsiblePerson: String = '';

    @EntityProperty({
        title: "联系电话",
        description: "责任人的联系电话，用于紧急联系"
    })
    contactPhone: String = '';

    @EntityProperty({
        title: "注册日期",
        description: "设备在系统中完成注册的日期"
    })
    registrationDate: Date;

    @EntityProperty({
        title: "采购日期",
        description: "设备的实际采购日期"
    })
    purchaseDate: Date;

    @EntityProperty({
        title: "采购价格",
        description: "设备的采购金额（元）"
    })
    purchasePrice: Decimal = 0;

    @EntityProperty({
        title: "预计使用年限",
        description: "设备的预计使用寿命（年）"
    })
    expectedLifeYears: Integer = 0;

    @EntityProperty({
        title: "投产日期",
        description: "设备正式投入使用的日期"
    })
    commissioningDate: Date;

    @EntityProperty({
        title: "技术参数",
        description: "设备的主要技术参数和规格说明，包括性能指标和配置详情"
    })
    technicalParameters: String = '';

    @EntityProperty({
        title: "备注",
        description: "其他补充说明信息，如特殊要求、注意事项等"
    })
    remarks: String = '';
}
export const EquipmentRegistryEntity = createEntity<EquipmentRegistry>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| equipmentNo | 设备编号 | String | 非空 | | | |
| equipmentName | 设备名称 | String | 非空 | | | |
| categoryId | 设备分类ID | Integer | 外键[设备分类] | | | |
| categoryName | 设备分类名称 | String | | '' | | |
| status | 设备状态 | app.enums.EquipmentStatusEnum | 非空 | EquipmentStatusEnum.Active | | |
| model | 设备型号 | String | | '' | | |
| serialNumber | 设备序列号 | String | | '' | | |
| manufacturer | 制造商 | String | | '' | | |
| location | 安装位置 | String | | '' | | |
| departmentId | 所属部门ID | Integer | 外键[组织部门] | | | |
| department | 所属部门 | String | | '' | | |
| responsiblePersonId | 责任人ID | Integer | 外键[用户] | | | |
| responsiblePerson | 责任人 | String | | '' | | |
| contactPhone | 联系电话 | String | | '' | | |
| registrationDate | 注册日期 | Date | | | | |
| purchaseDate | 采购日期 | Date | | | | |
| purchasePrice | 采购价格 | Decimal | | 0 | | |
| expectedLifeYears | 预计使用年限 | Integer | | 0 | | |
| commissioningDate | 投产日期 | Date | | | | |
| technicalParameters | 技术参数 | String | | '' | | |
| remarks | 备注 | String | | '' | | |

### 依赖的枚举和实体

- **数据建模-枚举-设备状态**：[数据建模-枚举-设备状态（EquipmentStatusEnum）](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-设备分类**：[通用业务模块-实体-设备分类（EquipmentCategory）](specs/001-bootdo-management-system/plan/data-model/entity-EquipmentCategory.md)
  - 【外键[设备分类]】
- **数据建模-实体-组织部门**：[系统管理-实体-组织部门（OrganizationDepartment）](specs/001-bootdo-management-system/plan/data-model/entity-OrganizationDepartment.md)
  - 【外键[组织部门]】
- **数据建模-实体-用户**：[权限中心-实体-用户（LcapUser）](specs/001-bootdo-management-system/plan/data-model/entity-LcapUser.md)
  - 【外键[用户]】