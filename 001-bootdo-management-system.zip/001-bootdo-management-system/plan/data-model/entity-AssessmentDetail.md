# 分包商管理-实体-评估详情（AssessmentDetail）

- **生成时间**：2026-03-25

## 评估详情（AssessmentDetail）

评估详情实体用于存储分包商绩效评估的具体维度和详细评分信息，是评估记录实体的细化补充。该实体将整体的绩效评估分解为多个具体的评估项目，每个项目都有独立的评分、权重和评价标准。通过评估详情实体，企业能够实现更加精细化和结构化的分包商评估，确保评估结果的客观性和全面性。评估详情与评估记录实体形成一对多的关系，每个评估记录可以包含多个评估详情项，覆盖质量、交付、服务、成本等多个维度。该实体支持动态的评估模板配置，允许企业根据不同类型的分包商或项目需求调整评估维度和权重，提升评估体系的灵活性和适用性。

```naturalts path="app.dataSources.defaultDS.entities.AssessmentDetail.ts"
@Entity({
    title: "评估详情",
    directory: "subcontractor_management(分包商管理)"
})
export class AssessmentDetail {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "评估记录",
        description: "所属的评估记录",
        required: true
    })
    @EntityRelation<app.dataSources.defaultDS.entities.EvaluationRecord['id']>('cascade')
    evaluationRecordId: Integer;

    @EntityProperty({
        title: "评估项目名称",
        description: "具体的评估维度名称，如质量、交付、服务等",
        required: true
    })
    assessmentItemName: String;

    @EntityProperty({
        title: "评估项目描述",
        description: "评估项目的详细说明",
        dbType: TEXT
    })
    assessmentItemDescription: String = '';

    @EntityProperty({
        title: "权重",
        description: "该评估项目在总评分中的权重百分比",
        required: true
    })
    weight: Integer = 0;

    @EntityProperty({
        title: "评分",
        description: "该评估项目的具体得分，范围0-100",
        required: true
    })
    score: Integer = 0;

    @EntityProperty({
        title: "评价意见",
        description: "对该评估项目的具体评价意见",
        dbType: TEXT
    })
    comments: String = '';

    @EntityProperty({
        title: "评估标准",
        description: "该评估项目的评分标准说明",
        dbType: TEXT
    })
    evaluationCriteria: String = '';
}
export const AssessmentDetailEntity = createEntity<AssessmentDetail>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| evaluationRecordId | 评估记录 | Integer | 非空、外键关联实体 EvaluationRecord（级联删除） | | | |
| assessmentItemName | 评估项目名称 | String | 非空 | | | |
| assessmentItemDescription | 评估项目描述 | String | | '' | TEXT | |
| weight | 权重 | Integer | 非空 | 0 | | 范围0-100 |
| score | 评分 | Integer | 非空 | 0 | | 范围0-100 |
| comments | 评价意见 | String | | '' | TEXT | |
| evaluationCriteria | 评估标准 | String | | '' | TEXT | |

### 依赖的枚举和实体

- **数据建模-实体-评估记录**：[分包商管理-实体-评估记录（EvaluationRecord）](specs/001-bootdo-management-system/plan/data-model/entity-EvaluationRecord.md)