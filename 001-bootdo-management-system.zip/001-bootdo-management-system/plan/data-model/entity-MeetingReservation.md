# 办公自动化-实体-会议预约（MeetingReservation）

- **生成时间**：2026-03-25

## 会议预约（MeetingReservation）

会议预约实体用于管理企业内部的会议安排和会议室预订功能，支持完整的会议生命周期管理。该实体记录会议的基本信息，包括会议标题、议程内容、组织者、时间安排、地点等关键要素，为用户提供便捷的会议创建、修改、查询和取消服务。通过与系统账户实体的关联，确保会议组织者的身份验证和权限控制；同时支持会议时间冲突检测，避免会议室资源的重复预订。会议预约还集成了参会人员邀请功能，可自动向相关人员发送会议通知，并跟踪参会确认状态。该实体作为办公自动化模块的核心组成部分，有效提升了企业会议管理的效率和规范化水平，减少了人工协调成本，确保会议资源的合理分配和利用。

```naturalts path="app.dataSources.defaultDS.entities.MeetingReservation.ts"
@Entity({
    title: "会议预约",
    directory: "office_automation(办公自动化)"
})
export class MeetingReservation {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "会议标题",
        description: "会议的主题名称",
        required: true
    })
    title: String;

    @EntityProperty({
        title: "议程",
        description: "会议的详细议程内容"
    })
    agenda: String = '';

    @EntityProperty({
        title: "组织者",
        description: "会议的组织者用户ID"
    })
    @EntityRelation<app.dataSources.defaultDS.entities.SystemAccount['id']>('PROTECT')
    organizerId: Integer;

    @EntityProperty({
        title: "开始时间",
        description: "会议开始的时间",
        required: true
    })
    startTime: DateTime;

    @EntityProperty({
        title: "结束时间",
        description: "会议结束的时间",
        required: true
    })
    endTime: DateTime;

    @EntityProperty({
        title: "地点",
        description: "会议举行的地点"
    })
    location: String = '';
}
export const MeetingReservationEntity = createEntity<MeetingReservation>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| title | 会议标题 | String | 非空 | | | |
| agenda | 议程 | String | | '' | | |
| organizerId | 组织者 | Integer | 非空、外键关联实体 SystemAccount（PROTECT） | | | |
| startTime | 开始时间 | DateTime | 非空 | | | |
| endTime | 结束时间 | DateTime | 非空 | | | |
| location | 地点 | String | | '' | | |

### 依赖的枚举和实体

- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)