# 系统管理-实体-审计日志（AuditLogEntity）

- **生成时间**：2026-03-25

## 审计日志（AuditLogEntity）

审计日志实体用于全面记录和追踪用户在系统中的所有关键操作行为，是系统安全审计、合规性验证和责任追溯的核心组件。该实体详细捕获每次操作的关键信息，包括操作用户身份、操作类型分类、具体操作内容描述、执行时间戳以及操作来源的网络地址等完整上下文信息。通过建立完整的审计日志体系，系统管理员能够进行深度安全审计、异常行为检测、操作责任追溯和法规合规性验证。审计日志支持按用户、时间范围、操作类型、IP地址等多维度的灵活查询和统计分析，帮助识别潜在的安全威胁、系统滥用模式和性能瓶颈。所有敏感操作（如权限变更、数据删除、配置修改、登录登出等）都会被优先且完整地记录，确保关键业务操作的可追溯性、透明度和不可抵赖性，为系统的安全稳定运行、数据完整性保护以及满足各类监管合规要求提供坚实的技术保障。

```naturalts path="app.dataSources.defaultDS.entities.AuditLogEntity.ts"
@Entity({
    title: "审计日志",
    directory: "system_management(系统管理)"
})
export class AuditLogEntity {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "日志ID",
        description: "审计日志的唯一标识符",
        dbType: VARCHAR(64),
        required: true
    })
    logId: String;

    @EntityProperty({
        title: "用户ID",
        description: "执行操作的用户账户ID",
        required: true
    })
    @EntityRelation<app.dataSources.defaultDS.entities.SystemAccount['id']>('PROTECT')
    userId: Integer;

    @EntityProperty({
        title: "用户名",
        description: "执行操作的用户账户名称",
        dbType: VARCHAR(50),
        required: true
    })
    username: String;

    @EntityProperty({
        title: "操作类型",
        description: "操作的分类，如登录、创建、更新、删除、查询等",
        dbType: VARCHAR(50),
        required: true
    })
    operationType: String;

    @EntityProperty({
        title: "操作模块",
        description: "操作所属的系统模块或功能区域",
        dbType: VARCHAR(100),
        required: true
    })
    operationModule: String;

    @EntityProperty({
        title: "操作详情",
        description: "操作的具体内容描述，包含操作对象和参数",
        dbType: TEXT,
        required: true
    })
    operationDetails: String;

    @EntityProperty({
        title: "操作时间",
        description: "操作执行的具体时间戳",
        required: true
    })
    operationTime: DateTime;

    @EntityProperty({
        title: "IP地址",
        description: "操作发起的客户端IP地址",
        dbType: VARCHAR(45)
    })
    ipAddress: String = '';

    @EntityProperty({
        title: "用户代理",
        description: "操作发起的客户端浏览器或应用信息",
        dbType: TEXT
    })
    userAgent: String = '';

    @EntityProperty({
        title: "操作结果",
        description: "操作执行的结果状态，成功或失败",
        required: true
    })
    operationResult: Boolean = true;

    @EntityProperty({
        title: "错误信息",
        description: "操作失败时的错误详情",
        dbType: TEXT
    })
    errorMessage: String = '';
}
export const AuditLogEntityEntity = createEntity<AuditLogEntity>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| logId | 日志ID | String | 非空 | | VARCHAR(64) | |
| userId | 用户ID | Integer | 非空、外键关联实体 SystemAccount（PROTECT） | | | |
| username | 用户名 | String | 非空 | | VARCHAR(50) | |
| operationType | 操作类型 | String | 非空 | | VARCHAR(50) | |
| operationModule | 操作模块 | String | 非空 | | VARCHAR(100) | |
| operationDetails | 操作详情 | String | 非空 | | TEXT | |
| operationTime | 操作时间 | DateTime | 非空 | | | |
| ipAddress | IP地址 | String | | '' | VARCHAR(45) | |
| userAgent | 用户代理 | String | | '' | TEXT | |
| operationResult | 操作结果 | Boolean | 非空 | true | | |
| errorMessage | 错误信息 | String | | '' | TEXT | |

### 依赖的枚举和实体

- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)
  - 【外键关联实体 SystemAccount（PROTECT）】