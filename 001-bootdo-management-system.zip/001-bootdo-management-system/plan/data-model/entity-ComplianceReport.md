# 环保管理-实体-合规报告（ComplianceReport）

- **生成时间**：2026-03-26

## 合规报告（ComplianceReport）

合规报告实体用于整合和管理企业环保合规相关的综合报告数据，作为环境监测、合规检查、风险评估和整改措施等多维度信息的统一载体。该实体通过关联环境监测数据、合规检查结果、风险评估分析和整改措施计划，形成完整的合规报告视图，支持环保管理部门对企业的环境合规状况进行全面评估和监控。合规报告实体确保了合规数据的一致性和完整性，为环保决策提供可靠的数据支撑，同时满足环保法规对定期报告的要求。通过标准化的数据结构，该实体支持不同类型合规报告的灵活配置和管理，包括月度、季度和年度合规报告等，涵盖报告标题、类型、周期、状态、摘要等核心信息，并支持报告的提交、审核和归档全流程管理。

```naturalts path="app.dataSources.defaultDS.entities.ComplianceReport.ts"
@Entity({
    title: "合规报告",
    directory: "environmental_management(环保管理)"
})
export class ComplianceReport {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "报告标题",
        description: "合规报告的完整标题",
        required: true
    })
    reportTitle: String;

    @EntityProperty({
        title: "报告类型",
        description: "合规报告的具体类型，如月度、季度、年度报告",
        required: true
    })
    reportType: String;

    @EntityProperty({
        title: "报告周期",
        description: "合规报告覆盖的时间周期"
    })
    reportPeriod: String = '';

    @EntityProperty({
        title: "报告状态",
        description: "合规报告的当前状态",
        required: true
    })
    reportStatus: app.enums.ComplianceStatusEnum = app.enums.ComplianceStatusEnum['Compliant'];

    @EntityProperty({
        title: "环境监测",
        description: "关联的环境监测数据"
    })
    @EntityRelation<app.dataSources.defaultDS.entities.EnvironmentalMonitoring['id']>('PROTECT')
    environmentalMonitoringId: Integer;

    @EntityProperty({
        title: "合规检查",
        description: "关联的合规检查记录"
    })
    @EntityRelation<app.dataSources.defaultDS.entities.ComplianceInspection['id']>('PROTECT')
    complianceInspectionId: Integer;

    @EntityProperty({
        title: "环境风险评估",
        description: "关联的环境风险评估结果"
    })
    @EntityRelation<app.dataSources.defaultDS.entities.EnvironmentalRiskAssessment['id']>('PROTECT')
    environmentalRiskAssessmentId: Integer;

    @EntityProperty({
        title: "整改措施",
        description: "关联的整改措施计划"
    })
    @EntityRelation<app.dataSources.defaultDS.entities.RectificationMeasure['id']>('PROTECT')
    rectificationMeasureId: Integer;

    @EntityProperty({
        title: "报告摘要",
        description: "合规报告的简要概述",
        dbType: TEXT
    })
    reportSummary: String = '';

    @EntityProperty({
        title: "是否已提交",
        description: "合规报告是否已经提交",
        required: true
    })
    isSubmitted: Boolean = false;

    @EntityProperty({
        title: "提交时间",
        description: "合规报告的提交时间"
    })
    submittedAt: DateTime;

    @EntityProperty({
        title: "审核人",
        description: "合规报告的审核人员"
    })
    reviewer: String = '';

    @EntityProperty({
        title: "审核意见",
        description: "审核人员对合规报告的意见",
        dbType: TEXT
    })
    reviewComments: String = '';
}
export const ComplianceReportEntity = createEntity<ComplianceReport>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| reportTitle | 报告标题 | String | 非空 | | | |
| reportType | 报告类型 | String | 非空 | | | |
| reportPeriod | 报告周期 | String | | '' | | |
| reportStatus | 报告状态 | app.enums.ComplianceStatusEnum | 非空 | ComplianceStatusEnum['Compliant'] | | |
| environmentalMonitoringId | 环境监测 | Integer | 非空、外键关联实体 EnvironmentalMonitoring（PROTECT） | | | |
| complianceInspectionId | 合规检查 | Integer | 非空、外键关联实体 ComplianceInspection（PROTECT） | | | |
| environmentalRiskAssessmentId | 环境风险评估 | Integer | 非空、外键关联实体 EnvironmentalRiskAssessment（PROTECT） | | | |
| rectificationMeasureId | 整改措施 | Integer | 非空、外键关联实体 RectificationMeasure（PROTECT） | | | |
| reportSummary | 报告摘要 | String | | '' | TEXT | |
| isSubmitted | 是否已提交 | Boolean | 非空 | false | | |
| submittedAt | 提交时间 | DateTime | | | | |
| reviewer | 审核人 | String | | '' | | |
| reviewComments | 审核意见 | String | | '' | TEXT | |

### 依赖的枚举和实体

- **数据建模-枚举-环保合规状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-环境监测**：[环保管理-实体-环境监测（EnvironmentalMonitoring）](specs/001-bootdo-management-system/plan/data-model/entity-EnvironmentalMonitoring.md)
- **数据建模-实体-合规检查**：[环保管理-实体-合规检查（ComplianceInspection）](specs/001-bootdo-management-system/plan/data-model/entity-ComplianceInspection.md)
- **数据建模-实体-环境风险评估**：[环保管理-实体-环境风险评估（EnvironmentalRiskAssessment）](specs/001-bootdo-management-system/plan/data-model/entity-EnvironmentalRiskAssessment.md)
- **数据建模-实体-整改措施**：[环保管理-实体-整改措施（RectificationMeasure）](specs/001-bootdo-management-system/plan/data-model/entity-RectificationMeasure.md)