# 质量管理-实体-检查标准（InspectionStandard）

- **生成时间**：2026-03-25

## 检查标准（InspectionStandard）

检查标准实体是质量管理模块的核心数据模型，用于定义和管理企业各类质量检查的标准规范。该实体存储了质量检查的标准编号、名称、详细描述、具体检查项目、检查方法、合格判定标准、适用范围、版本信息、生效期限等关键要素。通过检查标准实体，系统能够为质量问题登记、质量检验执行、整改任务分配等业务流程提供标准化的参考依据，确保质量检查工作的一致性和规范性。检查标准支持版本管理和状态控制，允许企业根据业务发展和法规要求及时更新检查标准，并通过生效日期和失效日期实现标准的生命周期管理，有效支撑企业建立完善的质量管理体系。

```naturalts path="app.dataSources.defaultDS.entities.InspectionStandard.ts"
@Entity({
    title: "检查标准",
    directory: "quality_management(质量管理)"
})
export class InspectionStandard {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "标准编号",
        description: "检查标准的唯一标识编号",
        required: true
    })
    standardCode: String;

    @EntityProperty({
        title: "标准名称",
        description: "检查标准的名称",
        required: true
    })
    standardName: String;

    @EntityProperty({
        title: "标准描述",
        description: "检查标准的详细描述信息"
    })
    description: String = '';

    @EntityProperty({
        title: "检查项目",
        description: "具体的检查项目或内容",
        required: true
    })
    inspectionItems: String;

    @EntityProperty({
        title: "检查方法",
        description: "执行检查的具体方法和步骤"
    })
    inspectionMethod: String = '';

    @EntityProperty({
        title: "合格标准",
        description: "判定检查结果是否合格的标准",
        required: true
    })
    passCriteria: String;

    @EntityProperty({
        title: "适用范围",
        description: "该检查标准适用的产品、工序或场景"
    })
    applicableScope: String = '';

    @EntityProperty({
        title: "版本号",
        description: "检查标准的版本号",
        required: true
    })
    version: String;

    @EntityProperty({
        title: "生效日期",
        description: "检查标准开始生效的日期"
    })
    effectiveDate: Date;

    @EntityProperty({
        title: "失效日期",
        description: "检查标准失效的日期"
    })
    expiryDate: Date;

    @EntityProperty({
        title: "是否启用",
        description: "检查标准是否处于启用状态",
        required: true
    })
    isEnabled: Boolean = true;
}
export const InspectionStandardEntity = createEntity<InspectionStandard>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| standardCode | 标准编号 | String | 非空 | | | |
| standardName | 标准名称 | String | 非空 | | | |
| description | 标准描述 | String | | '' | | |
| inspectionItems | 检查项目 | String | 非空 | | | |
| inspectionMethod | 检查方法 | String | | '' | | |
| passCriteria | 合格标准 | String | 非空 | | | |
| applicableScope | 适用范围 | String | | '' | | |
| version | 版本号 | String | 非空 | | | |
| effectiveDate | 生效日期 | Date | 非空 | | | |
| expiryDate | 失效日期 | Date | | | | |
| isEnabled | 是否启用 | Boolean | 非空 | true | | |

### 依赖的枚举和实体

- **数据建模-实体-质量问题**：[质量管理-实体-质量问题（QualityIssue）](specs/001-bootdo-management-system/plan/data-model/entity-QualityIssue.md)
- **数据建模-实体-质量指标**：[质量管理-实体-质量指标（QualityIndicator）](specs/001-bootdo-management-system/plan/data-model/entity-QualityIndicator.md)