# 环保管理-实体-应急演练（EmergencyDrill）

- **生成时间**：2026-03-25

## 应急演练（EmergencyDrill）

应急演练实体用于管理企业环境事故应急演练的全生命周期，包括演练计划制定、演练类型选择、演练状态跟踪、参与人员管理、演练结果评估等功能。该实体支持桌面演练、实战演练和综合演练三种类型的应急演练，确保企业能够定期验证和优化环境事故应急预案的有效性。通过记录演练的详细信息、执行过程和评估结果，为企业环境风险管理提供数据支撑，并满足环保法规对应急演练的合规要求。

```naturalts path="app.dataSources.defaultDS.entities.EmergencyDrill.ts"
@Entity({
    title: "应急演练",
    directory: "environmental_management(环保管理)"
})
export class EmergencyDrill {
    @EntityProperty({
        title: "主键",
        primaryKey: true
    })
    id: Integer;

    @EntityProperty({
        title: "创建时间"
    })
    createdTime: DateTime;

    @EntityProperty({
        title: "更新时间"
    })
    updatedTime: DateTime;

    @EntityProperty({
        title: "创建者"
    })
    createdBy: String;

    @EntityProperty({
        title: "更新者"
    })
    updatedBy: String;

    @EntityProperty({
        title: "演练名称",
        description: "应急演练的名称，用于标识具体的演练活动",
        required: true
    })
    drillName: String;

    @EntityProperty({
        title: "演练类型",
        description: "应急演练的类型，包括桌面演练、实战演练、综合演练",
        required: true
    })
    drillType: app.enums.DrillType = app.enums.DrillType['Tabletop'];

    @EntityProperty({
        title: "演练状态",
        description: "应急演练的当前状态，包括草稿、已审批、进行中、已完成、已取消",
        required: true
    })
    drillStatus: app.enums.DrillStatus = app.enums.DrillStatus['Draft'];

    @EntityProperty({
        title: "计划开始时间",
        description: "应急演练计划的开始时间"
    })
    plannedStartTime: DateTime;

    @EntityProperty({
        title: "计划结束时间",
        description: "应急演练计划的结束时间"
    })
    plannedEndTime: DateTime;

    @EntityProperty({
        title: "实际开始时间",
        description: "应急演练实际的开始时间"
    })
    actualStartTime: DateTime;

    @EntityProperty({
        title: "实际结束时间",
        description: "应急演练实际的结束时间"
    })
    actualEndTime: DateTime;

    @EntityProperty({
        title: "演练地点",
        description: "应急演练的具体地点或区域"
    })
    drillLocation: String = '';

    @EntityProperty({
        title: "参与人数",
        description: "参与应急演练的总人数"
    })
    participantCount: Integer = 0;

    @EntityProperty({
        title: "演练目标",
        description: "应急演练的主要目标和预期效果"
    })
    drillObjectives: String = '';

    @EntityProperty({
        title: "演练场景",
        description: "应急演练模拟的具体事故场景描述"
    })
    drillScenario: String = '';

    @EntityProperty({
        title: "演练内容",
        description: "应急演练的具体内容和步骤"
    })
    drillContent: String = '';

    @EntityProperty({
        title: "评估结果",
        description: "应急演练的评估结果和改进建议"
    })
    evaluationResult: String = '';

    @EntityProperty({
        title: "关联应急预案",
        description: "关联的应急预案ID"
    })
    @EntityRelation<app.dataSources.defaultDS.entities.EmergencyPlan['id']>('PROTECT')
    emergencyPlanId: Integer;

    @EntityProperty({
        title: "组织部门",
        description: "负责组织应急演练的部门ID"
    })
    @EntityRelation<app.dataSources.defaultDS.entities.OrganizationDepartment['id']>('PROTECT')
    organizingDepartmentId: Integer;

    @EntityProperty({
        title: "负责人",
        description: "应急演练的负责人用户ID"
    })
    @EntityRelation<app.dataSources.defaultDS.entities.SystemAccount['id']>('PROTECT')
    responsibleUserId: Integer;

    @EntityProperty({
        title: "是否需要外部协调",
        description: "应急演练是否需要外部单位协调配合",
        required: true
    })
    requiresExternalCoordination: Boolean = false;

    @EntityProperty({
        title: "外部协调单位",
        description: "需要协调的外部单位名称列表"
    })
    externalCoordinationUnits: String = '';

    @EntityProperty({
        title: "预算费用",
        description: "应急演练的预算费用，单位：元"
    })
    budgetAmount: Decimal = 0;

    @EntityProperty({
        title: "实际费用",
        description: "应急演练的实际花费费用，单位：元"
    })
    actualAmount: Decimal = 0;

    @EntityProperty({
        title: "备注",
        description: "应急演练的其他备注信息"
    })
    remark: String = '';
}
export const EmergencyDrillEntity = createEntity<EmergencyDrill>();
```

| 字段名 | 标题 | 数据类型 | 字段特性（主键、唯一、非空、外键等） | 默认值 | 存储类型（可选） | 限制规则（可选） |
| --- | --- | --- | --- | --- | --- | --- |
| id | 主键 | Integer | 主键、非空 | （自动生成） | | |
| createdTime | 创建时间 | DateTime | 非空 | （自动生成） | | |
| updatedTime | 更新时间 | DateTime | 非空 | （自动生成） | | |
| createdBy | 创建人 | String | 非空 | （自动生成） | | |
| updatedBy | 更新人 | String | 非空 | （自动生成） | | |
| drillName | 演练名称 | String | 非空 | | 字符串(100) | |
| drillType | 演练类型 | app.enums.DrillType | 非空 | DrillType['Tabletop'] | | |
| drillStatus | 演练状态 | app.enums.DrillStatus | 非空 | DrillStatus['Draft'] | | |
| plannedStartTime | 计划开始时间 | DateTime | | | | |
| plannedEndTime | 计划结束时间 | DateTime | | | | |
| actualStartTime | 实际开始时间 | DateTime | | | | |
| actualEndTime | 实际结束时间 | DateTime | | | | |
| drillLocation | 演练地点 | String | | '' | 字符串(200) | |
| participantCount | 参与人数 | Integer | | 0 | | >=0 |
| drillObjectives | 演练目标 | String | | '' | 长文本 | |
| drillScenario | 演练场景 | String | | '' | 长文本 | |
| drillContent | 演练内容 | String | | '' | 长文本 | |
| evaluationResult | 评估结果 | String | | '' | 长文本 | |
| emergencyPlanId | 关联应急预案 | Integer | 非空、外键关联实体 EmergencyPlan（PROTECT） | | | |
| organizingDepartmentId | 组织部门 | Integer | 非空、外键关联实体 OrganizationDepartment（PROTECT） | | | |
| responsibleUserId | 负责人 | Integer | 非空、外键关联实体 SystemAccount（PROTECT） | | | |
| requiresExternalCoordination | 是否需要外部协调 | Boolean | 非空 | false | | |
| externalCoordinationUnits | 外部协调单位 | String | | '' | 长文本 | |
| budgetAmount | 预算费用 | Decimal | | 0 | 数值(12,2) | >=0 |
| actualAmount | 实际费用 | Decimal | | 0 | 数值(12,2) | >=0 |
| remark | 备注 | String | | '' | 长文本 | |

### 依赖的枚举和实体

- **数据建模-枚举-应急演练类型**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-枚举-演练状态**：[数据建模-枚举](specs/001-bootdo-management-system/plan/data-model/enums.md)
- **数据建模-实体-应急预案**：[环保管理-实体-应急预案（EmergencyPlan）](specs/001-bootdo-management-system/plan/data-model/entity-EmergencyPlan.md)
- **数据建模-实体-组织部门**：[系统管理-实体-组织部门（OrganizationDepartment）](specs/001-bootdo-management-system/plan/data-model/entity-OrganizationDepartment.md)
- **数据建模-实体-系统账户**：[系统管理-实体-系统账户（SystemAccount）](specs/001-bootdo-management-system/plan/data-model/entity-SystemAccount.md)