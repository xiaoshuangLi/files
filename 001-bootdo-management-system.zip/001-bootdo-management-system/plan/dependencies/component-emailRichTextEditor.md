# 特殊组件-邮件富文本编辑器（emailRichTextEditor）

- **生成时间**：2026-03-25

## 概述

* 组件名称：emailRichTextEditor（<email-rich-text-editor>）
* 技术栈：Vue3
* 核心职责：专为邮件撰写场景优化的富文本编辑器，支持邮件特有的格式要求、签名管理、模板插入等功能
* 适用场景：企业邮件系统、客户沟通平台、通知邮件编辑等邮件相关业务场景
* 依赖：quill@2.0.0（富文本核心）、email-validator@2.0.4（邮箱验证）、html-to-text@9.0.3（HTML转纯文本）

## 功能

### 1.邮件专用富文本编辑功能

#### 描述

邮件富文本编辑器针对邮件撰写场景进行了专门优化，解决了通用富文本编辑器无法满足邮件格式特殊要求的问题。该组件支持邮件特有的功能如个人签名管理（可设置多个签名模板并快速插入）、邮件模板库（预设常用邮件模板）、收件人智能提示（自动补全联系人邮箱）、邮件格式优化（确保在不同邮件客户端中的兼容性显示）。同时提供基础的富文本编辑功能，包括文字格式化、图片插入、表格创建等，并特别优化了HTML输出，确保生成的邮件内容在主流邮件客户端（Outlook、Gmail、Apple Mail等）中能够正确渲染，避免常见的邮件显示问题。

#### 验收标准

- [ ] 支持个人签名管理，可创建、编辑、删除多个签名模板
- [ ] 提供邮件模板库功能，支持快速插入预设邮件模板
- [ ] 实现收件人邮箱智能提示，自动补全联系人信息
- [ ] 优化HTML输出格式，确保在主流邮件客户端中的兼容性
- [ ] 支持基础富文本编辑功能（格式化、图片、表格等）
- [ ] 提供纯文本预览功能，可切换查看邮件的纯文本版本
- [ ] 支持附件占位符插入，与邮件附件功能集成
- [ ] 实现自动保存草稿功能，防止邮件内容丢失

#### 接口设计

通过v-model双向绑定邮件HTML内容，通过signatures属性接收签名模板列表，通过templates属性接收邮件模板列表。

#### 使用示例

```vue
<email-rich-text-editor 
  v-model="emailContent" 
  :signatures="userSignatures"
  :templates="emailTemplates"
/>
```

## 接口定义 (属性 & 事件 & 方法 & 插槽)

### 属性

| 属性名称 | 描述 | 类型 | 可选值 | 默认值 | 是否双向绑定 |
|:---|:---|:---|:---|:---|:---|
| modelValue | 邮件HTML内容 | String | - | '' | 是 |
| signatures | 签名模板列表 | Array | - | [] | 否 |
| templates | 邮件模板列表 | Array | - | [] | 否 |
| recipients | 收件人列表 | Array | - | [] | 否 |
| showPlainText | 显示纯文本模式 | Boolean | true/false | false | 否 |

### 事件

| 事件名称 | 描述 | 回调参数 | 参数类型 |
|:---|:---|:---|:---|
| update:modelValue | 内容变更事件 | content | String |
| insert-signature | 插入签名事件 | signature | Object |
| apply-template | 应用模板事件 | template | Object |
| recipient-select | 选择收件人事件 | recipient | Object |

### 方法

| 方法名称 | 描述 | 参数 | 返回值 |
|:---|:---|:---|:---|
| insertSignature | 插入签名 | signatureId: String | void |
| applyTemplate | 应用模板 | templateId: String | void |
| getPlainText | 获取纯文本内容 | - | String |
| validateEmailFormat | 验证邮件格式 | - | Boolean |

### 插槽

| 插槽名称 | 描述 | 参数 |
|:---|:---|:---|
| toolbar | 自定义工具栏 | { editor: Object } |
| signature-panel | 签名面板插槽 | { signatures: Array } |
| template-panel | 模板面板插槽 | { templates: Array } |

## 样式定制

| CSS 变量 | 描述 | 默认值 |
|:---|:---|:---|
| --email-editor-border-color | 编辑器边框颜色 | #e4e7ed |
| --email-editor-bg-color | 编辑器背景色 | #ffffff |
| --email-signature-color | 签名文本颜色 | #666666 |

## 注意事项

* 邮件HTML需要遵循邮件客户端的兼容性规范，避免使用复杂的CSS样式
* 图片插入建议使用内联Base64编码或确保图片URL可公开访问
* 签名和模板数据需要与用户配置服务集成，确保数据一致性
* 纯文本版本需要与HTML版本保持内容同步，用于邮件客户端不支持HTML的情况