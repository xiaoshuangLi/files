# 特殊组件-流程图可视化组件（processDiagramViewer）

- **生成时间**：2026-03-25

## 概述

* 组件名称：processDiagramViewer（<process-diagram-viewer>）
* 技术栈：Vue3
* 核心职责：提供BPMN流程图的可视化展示和运行时状态高亮功能，支持流程执行进度的实时监控
* 适用场景：工作流实例监控、流程审批跟踪、业务流程执行状态展示等需要流程可视化监控的业务场景
* 依赖：bpmn-js@13.1.0（BPMN渲染核心）、diagram-js@13.1.0（图形渲染框架）、lodash@4.17.21（工具函数库）

## 功能

### 1.BPMN流程图可视化监控功能

#### 描述

流程图可视化组件解决了UI组件库标准组件无法实现BPMN流程图渲染和运行时状态监控的问题。该组件专门用于展示已部署的BPMN流程定义，并能够根据流程实例的执行状态动态高亮当前活动节点、已完成节点和待处理节点。支持完整的BPMN 2.0元素渲染，包括事件、任务、网关、子流程等所有流程元素。组件提供交互式查看功能，用户可以点击查看节点详情、执行历史、处理人信息等运行时数据。同时支持流程图的缩放、平移、自动适应容器等视图操作，确保在不同屏幕尺寸下都能清晰展示复杂的业务流程执行状态。

#### 验收标准

- [ ] 支持完整的BPMN 2.0流程图渲染，正确显示所有流程元素
- [ ] 实现运行时状态高亮，区分当前活动节点、已完成节点、待处理节点
- [ ] 提供节点详情查看功能，可显示执行历史、处理人、耗时等信息
- [ ] 支持流程图的缩放、平移、自动布局等视图操作
- [ ] 支持BPMN XML或流程定义ID的输入方式
- [ ] 提供流程执行路径的可视化展示，清晰显示流程走向
- [ ] 支持多实例节点的状态分别显示
- [ ] 实现响应式设计，适配不同屏幕尺寸的展示需求

#### 接口设计

通过processDefinition属性接收流程定义（XML字符串或ID），通过executionState属性接收流程实例的执行状态数据。

#### 使用示例

```vue
<process-diagram-viewer 
  :process-definition="bpmnXml" 
  :execution-state="processInstanceState"
  :height="'500px'"
/>
```

## 接口定义 (属性 & 事件 & 方法 & 插槽)

### 属性

| 属性名称 | 描述 | 类型 | 可选值 | 默认值 | 是否双向绑定 |
|:---|:---|:---|:---|:---|:---|
| processDefinition | 流程定义（XML或ID） | String | - | null | 否 |
| executionState | 执行状态数据 | Object | - | null | 否 |
| height | 查看器高度 | String/Number | - | '400px' | 否 |
| showExecutionPath | 显示执行路径 | Boolean | true/false | true | 否 |

### 事件

| 事件名称 | 描述 | 回调参数 | 参数类型 |
|:---|:---|:---|:---|
| element-click | 元素点击事件 | element | Object |
| ready | 查看器就绪事件 | viewer | Object |
| error | 错误事件 | error | Error |

### 方法

| 方法名称 | 描述 | 参数 | 返回值 |
|:---|:---|:---|:---|
| highlightElement | 高亮指定元素 | elementId: String, color: String | void |
| clearHighlight | 清除高亮 | - | void |
| fitToContainer | 适应容器大小 | - | void |
| getRenderedElements | 获取已渲染元素 | - | Array<Object> |

### 插槽

| 插槽名称 | 描述 | 参数 |
|:---|:---|:---|
| element-tooltip | 元素提示插槽 | { element: Object, state: Object } |
| status-legend | 状态图例插槽 | { states: Array } |
| toolbar | 工具栏插槽 | { viewer: Object } |

## 样式定制

| CSS 变量 | 描述 | 默认值 |
|:---|:---|:---|
| --process-viewer-border-color | 查看器边框颜色 | #e4e7ed |
| --process-viewer-bg-color | 查看器背景色 | #ffffff |
| --process-active-color | 活动节点颜色 | #409eff |
| --process-completed-color | 完成节点颜色 | #67c23a |
| --process-pending-color | 待处理节点颜色 | #e6a23c |

## 注意事项

* 执行状态数据格式需要与后端流程引擎的输出格式保持一致
* 复杂流程图的渲染可能影响性能，建议对大型流程进行分页或简化展示
* 节点状态高亮需要确保颜色对比度符合无障碍访问标准
* 响应式设计需要考虑移动端的触摸交互体验