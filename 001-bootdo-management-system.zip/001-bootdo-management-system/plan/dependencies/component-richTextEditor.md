# 特殊组件-富文本编辑器（richTextEditor）

- **生成时间**：2026-03-25

## 概述

* 组件名称：richTextEditor（<rich-text-editor>）
* 技术栈：Vue3
* 核心职责：提供所见即所得的富文本编辑功能，支持文字格式化、图片插入、表格创建、代码块高亮等复杂编辑需求
* 适用场景：文章内容编辑、邮件撰写、文档协作等需要富文本处理的业务场景
* 依赖：quill@2.0.0，一个功能强大的现代富文本编辑器库，提供模块化架构和丰富的API支持

## 功能

### 1.富文本编辑功能

#### 描述

富文本编辑器提供完整的所见即所得编辑体验，支持文字基础格式化（粗体、斜体、下划线、删除线）、段落样式（标题、引用、代码块）、列表（有序/无序）、对齐方式、颜色设置等。同时支持高级功能如图片上传插入、表格创建编辑、超链接添加、代码块语法高亮等。该组件解决了UI组件库中ElInput等标准组件无法处理复杂富文本内容的问题，满足内容管理系统、邮件系统等业务场景的专业编辑需求。

#### 验收标准

- [ ] 支持基础文字格式化功能，包括粗体、斜体、下划线、删除线等样式设置
- [ ] 支持段落级别样式，包括标题（H1-H6）、引用、代码块、预格式化文本等
- [ ] 支持列表功能，包括有序列表和无序列表，以及列表嵌套
- [ ] 支持图片上传和插入功能，可从本地选择图片并自动上传到服务器
- [ ] 支持表格创建和编辑，包括插入表格、调整行列、合并单元格等操作
- [ ] 支持代码块语法高亮，自动识别多种编程语言并应用相应高亮样式
- [ ] 支持超链接添加和编辑，可设置链接地址、标题和打开方式
- [ ] 提供撤销/重做功能，支持多步操作的历史记录管理

#### 接口设计

支持v-model双向绑定，通过modelValue属性接收HTML字符串，通过update:modelValue事件返回编辑后的内容。提供focus()、blur()等方法控制编辑器焦点状态。

#### 使用示例

```vue
<rich-text-editor v-model="content" :placeholder="'请输入内容...'" />
```

## 接口定义 (属性 & 事件 & 方法 & 插槽)

### 属性

| 属性名称 | 描述 | 类型 | 可选值 | 默认值 | 是否双向绑定 |
|:---|:---|:---|:---|:---|:---|
| modelValue | 编辑器内容（HTML字符串） | String | - | '' | 是 |
| placeholder | 占位提示文本 | String | - | '请输入内容...' | 否 |
| readOnly | 是否只读模式 | Boolean | true/false | false | 否 |
| toolbar | 工具栏配置 | Array | - | ['bold', 'italic', 'underline', 'strike', 'blockquote', 'code-block', 'link', 'image', 'table', 'list', 'align', 'color'] | 否 |
| height | 编辑器高度 | String/Number | - | '300px' | 否 |

### 事件

| 事件名称 | 描述 | 回调参数 | 参数类型 |
|:---|:---|:---|:---|
| update:modelValue | 内容变更事件 | event | String |
| focus | 获得焦点事件 | event | Event |
| blur | 失去焦点事件 | event | Event |
| ready | 编辑器就绪事件 | editor | Object |

### 方法

| 方法名称 | 描述 | 参数 | 返回值 |
|:---|:---|:---|:---|
| focus | 聚焦编辑器 | - | void |
| blur | 失去焦点 | - | void |
| insertText | 插入文本 | text: String, index?: Number | void |
| getHTML | 获取HTML内容 | - | String |
| getText | 获取纯文本内容 | - | String |

### 插槽

| 插槽名称 | 描述 | 参数 |
|:---|:---|:---|
| toolbar | 自定义工具栏 | { editor: Object } |
| bottom | 底部插槽 | { editor: Object } |

## 样式定制

| CSS 变量 | 描述 | 默认值 |
|:---|:---|:---|
| --rich-text-editor-border-color | 编辑器边框颜色 | #dcdfe6 |
| --rich-text-editor-bg-color | 编辑器背景色 | #ffffff |
| --rich-text-editor-toolbar-bg | 工具栏背景色 | #f5f7fa |

## 注意事项

* 图片上传功能需要配合后端文件上传服务使用，确保上传接口的安全性和文件类型验证
* 在表单验证场景中，建议对富文本内容进行长度和安全过滤验证，防止XSS攻击
* 大量内容编辑时可能影响性能，建议在移动端或低性能设备上限制内容长度