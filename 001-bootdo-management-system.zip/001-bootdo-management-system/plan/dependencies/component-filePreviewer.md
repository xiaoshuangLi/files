# 特殊组件-文件预览器（filePreviewer）

- **生成时间**：2026-03-25

## 概述

* 组件名称：filePreviewer（<file-previewer>）
* 技术栈：Vue3
* 核心职责：支持多种文件格式的在线预览功能，包括PDF文档、Office文档（Word、Excel、PowerPoint）、图片（JPG、PNG、GIF等）、音视频文件等
* 适用场景：文件管理系统、文档协作平台、内容管理系统的文件预览需求
* 依赖：pdfjs-dist@3.4.120（PDF预览）、mammoth@1.6.0（Word文档转换）、xlsx@0.18.5（Excel解析）、video.js@7.20.3（视频播放）

## 功能

### 1.多格式文件预览功能

#### 描述

文件预览器特殊组件解决了UI组件库标准组件无法处理多格式文件在线预览的问题。该组件根据文件类型自动选择合适的渲染引擎：PDF文件使用pdf.js进行高质量渲染；Office文档通过后端转换服务或前端解析库转换为HTML进行展示；图片文件直接使用img标签显示并支持缩放；音视频文件集成video.js播放器提供完整的媒体控制功能。组件支持预览过程中的交互操作，如PDF文档的翻页、缩放，图片的放大缩小，视频的播放控制等，为用户提供流畅的预览体验。

#### 验收标准

- [ ] 支持PDF文档预览，提供翻页、缩放、搜索等功能
- [ ] 支持Word文档预览，保留基本格式和图片内容
- [ ] 支持Excel表格预览，可查看多个工作表和单元格数据
- [ ] 支持PowerPoint演示文稿预览，按幻灯片顺序展示
- [ ] 支持常见图片格式（JPG、PNG、GIF、BMP）预览，支持缩放和旋转
- [ ] 支持音视频文件（MP4、MP3、AVI等）预览，提供播放、暂停、音量控制
- [ ] 自动识别文件类型并选择合适的预览方式
- [ ] 预览加载过程中显示加载状态指示器

#### 接口设计

通过file属性接收文件信息对象，支持URL字符串或File对象。提供ready、error等事件通知预览状态。

#### 使用示例

```vue
<file-previewer :file="fileInfo" :width="'100%'" :height="'500px'" />
```

## 接口定义 (属性 & 事件 & 方法 & 插槽)

### 属性

| 属性名称 | 描述 | 类型 | 可选值 | 默认值 | 是否双向绑定 |
|:---|:---|:---|:---|:---|:---|
| file | 文件信息对象 | Object/String/File | - | null | 否 |
| width | 预览容器宽度 | String/Number | - | '100%' | 否 |
| height | 预览容器高度 | String/Number | - | '400px' | 否 |
| autoPlay | 视频是否自动播放 | Boolean | true/false | false | 否 |
| showToolbar | 是否显示工具栏 | Boolean | true/false | true | 否 |

### 事件

| 事件名称 | 描述 | 回调参数 | 参数类型 |
|:---|:---|:---|:---|
| ready | 预览就绪事件 | previewer | Object |
| error | 预览错误事件 | error | Error |
| loaded | 文件加载完成事件 | file | Object |

### 方法

| 方法名称 | 描述 | 参数 | 返回值 |
|:---|:---|:---|:---|
| reload | 重新加载文件 | - | void |
| zoomIn | 放大（图片/PDF） | step?: Number | void |
| zoomOut | 缩小（图片/PDF） | step?: Number | void |
| rotate | 旋转（图片） | degree: Number | void |
| nextPage | 下一页（PDF/PPT） | - | void |
| prevPage | 上一页（PDF/PPT） | - | void |

### 插槽

| 插槽名称 | 描述 | 参数 |
|:---|:---|:---|
| loading | 加载中状态插槽 | - |
| error | 错误状态插槽 | { error: Error } |
| toolbar | 自定义工具栏插槽 | { previewer: Object } |

## 样式定制

| CSS 变量 | 描述 | 默认值 |
|:---|:---|:---|
| --file-previewer-border-color | 预览器边框颜色 | #e4e7ed |
| --file-previewer-bg-color | 预览器背景色 | #ffffff |
| --file-previewer-toolbar-bg | 工具栏背景色 | #f5f7fa |

## 注意事项

* Office文档预览在前端直接解析可能存在兼容性问题，建议配合后端转换服务使用
* 大文件预览可能影响性能，建议对文件大小进行限制或提供分页加载
* PDF预览需要确保pdf.js的worker文件路径配置正确
* 音视频预览需要考虑浏览器兼容性和编解码器支持情况